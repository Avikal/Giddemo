package com.bigkoo.pickerview.listener;


public interface OnDismissListener {
    public void onDismiss(Object o);
}
