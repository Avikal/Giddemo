package com.bigkoo.pickerview.model;

public interface IPickerViewData {
    String getPickerViewText();
}
