package com.websocketpoc;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Toast;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by avikaljain on 17/8/17.
 */

public class ShowDataClick extends AppCompatActivity implements View.OnClickListener {

    @BindView(R.id.checkbox)
    CheckBox checkBox;

    @BindView(R.id.radioButton1)
    RadioButton radioButton1;

    @BindView(R.id.radioButton2)
    RadioButton radioButton2;

    @BindView(R.id.radioButton3)
    RadioButton radioButton3;

    @BindView(R.id.radioButton4)
    RadioButton radioButton4;

    @BindView(R.id.radioButton5)
    RadioButton radioButton5;

    @BindView(R.id.linearGroup)
    LinearLayout linearGroup;

    Animation slideUp;
    Animation slideDown;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_click);
        ButterKnife.bind(this);
        checkBox.setOnClickListener(this);
        radioButton1.setOnClickListener(this);
        radioButton2.setOnClickListener(this);
        radioButton3.setOnClickListener(this);
        radioButton4.setOnClickListener(this);
        radioButton5.setOnClickListener(this);
        slideUp = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide_up);
        slideDown = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide_down);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.checkbox:
               /* linearGroup.setVisibility(linearGroup.isShown()
                        ? View.GONE
                        : View.VISIBLE);*/


                if (checkBox.isChecked()) {

                    linearGroup.startAnimation(slideDown);
                    linearGroup.setVisibility(View.VISIBLE);
                    showToast("Check");
                } else {
                    linearGroup.startAnimation(slideUp);
                    linearGroup.setVisibility(View.GONE);
                    showToast("Uncheck");
                }
                break;
            case R.id.radioButton1:
                if (radioButton1.isChecked()) {
                    showToast("John Cine Check");
                } else {
                    showToast("John Cine Uncheck");
                }
                break;
            case R.id.radioButton2:
                if (radioButton2.isChecked()) {
                    showToast("Randy Check");
                } else {
                    showToast("Randy Uncheck");
                }
                break;
            case R.id.radioButton3:
                if (radioButton3.isChecked()) {
                    showToast("Roman Check");
                } else {
                    showToast("Roman Uncheck");
                }
                break;
            case R.id.radioButton4:
                if (radioButton4.isChecked()) {
                    showToast("Gold Check");
                } else {
                    showToast("Gold Uncheck");
                }
                break;
            case R.id.radioButton5:
                if (radioButton5.isChecked()) {
                    showToast("Shecoms Check");
                } else {
                    showToast("Shecoms Uncheck");
                }
                break;
        }
    }

    public void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();

    }
}
