package com.cdn.techquiq.consumer.model;

import com.cdn.techquiq.consumer.Utils.Utils;

/**
 * Created by avikaljain on 9/6/17.
 */

public class UrlResponse {

    public static String getAboutUs() {
        if (Utils.getLocale().equalsIgnoreCase("ar")) {
            return "http://cdnsolutionsgroup.com/techquiq/merchant/pages/aboutus/ar";
        } else {
            return "http://cdnsolutionsgroup.com/techquiq/merchant/pages/aboutus/en";
        }
    }

    public static String getTAC() {
        if (Utils.getLocale().equalsIgnoreCase("ar")) {
            return "http://cdnsolutionsgroup.com/techquiq/merchant/pages/tc/ar";
        } else {
            return "http://cdnsolutionsgroup.com/techquiq/merchant/pages/tc/en";
        }
    }

    public static String getFAQ() {
        if (Utils.getLocale().equalsIgnoreCase("ar")) {
            return "http://cdnsolutionsgroup.com/techquiq/merchant/pages/faq/ar";
        } else {
            return "http://cdnsolutionsgroup.com/techquiq/merchant/pages/faq/en";
        }
    }

    public static String getPrivacy() {
        if (Utils.getLocale().equalsIgnoreCase("ar")) {
            return "http://cdnsolutionsgroup.com/techquiq/merchant/pages/privacy_policy/ar";
        } else {
            return "http://cdnsolutionsgroup.com/techquiq/merchant/pages/privacy_policy/en";
        }
    }

    public static String getHelp()
    {
        if (Utils.getLocale().equalsIgnoreCase("ar")) {
            return "http://cdnsolutionsgroup.com/techquiq/merchant/pages/help/ar";
        } else {
            return "http://cdnsolutionsgroup.com/techquiq/merchant/pages/help/en";
        }
    }
}
