package com.cdn.techquiq.consumer.custom.Dialog;

import android.app.Dialog;
import android.content.Context;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;

import java.util.ArrayList;

/**
 * Created by bhushanvyas on 24/2/16.
 */
public class CountryDialog extends Dialog {

    private Context mContext;
    private ImageView cancel;
    private ListView listView;
    private ArrayList<String> data;
    private ArrayList<TextWithPosition> displayData;
    private CountryDialogAdapter adapter;
    private String headerTitle;
    private TextView header;
    EditText searchEditText;
    RelativeLayout searchBox;
    private int position = -1;

    private InputMethodManager imm;
    private boolean itemClick = false;

    public CountryDialog(Context context, String headerTitle, ArrayList<String> mData) {
        super(context);
        this.mContext = context;
        this.headerTitle = headerTitle;
        this.data = mData;
        displayData = new ArrayList<TextWithPosition>();
        for (int i = 0; i < data.size(); i++) {
            displayData.add(new TextWithPosition(data.get(i), i));
        }

        getDialog();
    }


    public void getDialog() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.spinner_list_dialog);
        getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        imm = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
        header = (TextView) findViewById(R.id.header);
        searchBox = (RelativeLayout) findViewById(R.id.searchBox);
        header.setText(headerTitle);

        searchEditText = (EditText) findViewById(R.id.searchdialog);



        adapter = new CountryDialogAdapter(mContext, displayData);
        listView = (ListView) findViewById(R.id.dialogList);

        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
                position = displayData.get(pos).getPos();
                itemClick = true;
                dismiss();
            }
        });

        cancel = (ImageView) findViewById(R.id.close_popup_btn);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itemClick = false;
                dismiss();
            }
        });

        searchEditText.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {


            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {

                String query = searchEditText.getText().toString().toLowerCase().trim();
                if (TextUtils.isEmpty(query.trim())) {
                    displayData.clear();
                    for (int i = 0; i < data.size(); i++) {
                        displayData.add(new TextWithPosition(data.get(i), i));
                    }
                } else {
                    displayData.clear();
                    if (data != null) {
                        for (int i = 0; i < data.size(); i++) {
                            final String text = data.get(i).toLowerCase();
                            if (text.contains(query)) {
                                displayData.add(new TextWithPosition(data.get(i), i));

                            }
                        }
                    }
                }
                adapter.notifyDataSetChanged();
                //adapter=new CountryDialogAdapter(mContext,displayData);
                // imm.hideSoftInputFromWindow(searchEditText.getWindowToken(), 0);// data set changed
            }
        });
        searchEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    imm.hideSoftInputFromWindow(searchEditText.getWindowToken(), 0);// data set changed
                    return true;
                }
                return false;
            }
        });
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public boolean isItemClick() {
        return itemClick;
    }

    public void setItemClick(boolean itemClick) {
        this.itemClick = itemClick;
    }

    /**
     * for Displaying search
     */
    public void setSearchEnable() {

        if (displayData.size() > 1) {
            searchBox.setVisibility(View.VISIBLE);
        } else {
            searchBox.setVisibility(View.GONE);
        }
    }

    public void clearSearch() {
        searchEditText.setText("");
    }

    public void setSearchHide() {
        searchBox.setVisibility(View.GONE);
    }

    /**
     * for take Position after perform Search
     */

    public class TextWithPosition {
        private String text;
        int pos;

        public TextWithPosition(String text, int pos) {
            this.text = text;
            this.pos = pos;
        }

        public void setPos(int pos) {
            this.pos = pos;
        }

        public int getPos() {
            return pos;
        }

        public String getText() {

            return text;
        }

        public void setText(String text) {
            this.text = text;
        }
    }


}
