package com.cdn.techquiq.consumer.model;

import com.cdn.techquiq.consumer.Utils.Utils;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by avikaljain on 12/6/17.
 */

public class AlertResponse extends BaseResponse {

    @SerializedName("Result")
    private ArrayList<AlertList> alertList;

    public ArrayList<AlertList> getAlertList() {
        return alertList;
    }

    public void setAlertList(ArrayList<AlertList> alertList) {
        this.alertList = alertList;
    }

    @SerializedName("Total_service")
    private int Total_service;

    public int getTotal_service() {
        return Total_service;
    }

    public void setTotal_service(int total_service) {
        Total_service = total_service;
    }

    public class AlertList {

        @SerializedName("id")
        private String id;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        @SerializedName("name_en")
        private String name_en;

        public String getName_en() {
            return name_en;
        }

        public void setName_en(String name_en) {
            this.name_en = name_en;
        }

        @SerializedName("name_ar")
        private String name_ar;

        public String getName_ar() {
            return name_ar;
        }

        public void setName_ar(String name_ar) {
            this.name_ar = name_ar;
        }

        @SerializedName("description_en")
        private String description_en;

        public String getDescription_en() {
            return description_en;
        }

        public void setDescription_en(String description_en) {
            this.description_en = description_en;
        }

        @SerializedName("description_ar")
        private String description_ar;

        public String getDescription_ar() {
            return description_ar;
        }

        public void setDescription_ar(String description_ar) {
            this.description_ar = description_ar;
        }

        @SerializedName("type")
        private String type;

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getDescription() {
            if (Utils.getLocale().equalsIgnoreCase("ar")) {
                return getDescription_ar();
            } else {
                return getDescription_en();
            }
        }

        public String getName() {
            if (Utils.getLocale().equalsIgnoreCase("ar")) {
                return getName_ar();
            } else {
                return getName_en();
            }
        }

        @SerializedName("date")
        private String date;

        public String getDate() {
            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }

        @SerializedName("image")
        private String image;

        public String getImage() {
            return image;
        }

        public void setImage(String image) {
            this.image = image;
        }
    }

}
