
package com.cdn.techquiq.consumer.adapter;

/**
 * Created by kajalsoni on 31/1/17.
 */

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.model.commonResponse;

import java.util.ArrayList;
import java.util.List;

public class ServiceAdapter extends RecyclerView.Adapter<ServiceAdapter.MyViewHolder> {

    private List<commonResponse> commonBeanList;
    Context mContext;
    LayoutInflater mLayoutInflater;


    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView titleTv, timeTv, descriptionTv, proposalTv;
        View mparent;

        public MyViewHolder(View view) {
            super(view);
            mparent = view;
            titleTv = (TextView) view.findViewById(R.id.titleTv);
            timeTv = (TextView) view.findViewById(R.id.timeTv);
            descriptionTv = (TextView) view.findViewById(R.id.descriptionTv);
            proposalTv = (TextView) view.findViewById(R.id.proposalTv);
        }
    }

    public ServiceAdapter(Context context, ArrayList<commonResponse> commonBeanList) {
        this.mContext = context;
        this.commonBeanList = commonBeanList;
        mLayoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mLayoutInflater
                .inflate(R.layout.service_list_item, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {
        final commonResponse commonBean = commonBeanList.get(position);

        holder.titleTv.setText(commonBean.getName());
        holder.timeTv.setText(commonBean.getTime());
        holder.descriptionTv.setText(commonBean.getDescription());
        holder.proposalTv.setText(commonBean.getProposalcount());

        holder.mparent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
    }


    @Override
    public int getItemCount() {
        return commonBeanList.size();
    }
}
