package com.cdn.techquiq.consumer.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;

/**
 * Created by kajalsoni on 3/2/17.
 */

public class TandCActivity extends BaseActivity {

    /**
     * Toolbar Id
     */
    private ImageView backIv;
    private TextView titleTv;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.t_and_c_activity);

        backIv = (ImageView) findViewById(R.id.backIv);
        backIv.setOnClickListener(this);
        titleTv = (TextView) findViewById(R.id.titleTv);
        titleTv.setText(mContext.getResources().getString(R.string.terms_and_condition));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.backIv:
                finish();
                break;

        }
    }


}
