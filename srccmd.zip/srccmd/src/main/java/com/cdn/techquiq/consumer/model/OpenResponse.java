package com.cdn.techquiq.consumer.model;

import java.io.Serializable;

/**
 * Created by avikaljain on 5/4/17.
 */

public class OpenResponse extends BaseResponse {

    private String title;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {

        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    private String description;

    public class OpenDetail implements Serializable {

        private String title;
        private String description;

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getDescription() {

            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }
    }
}
