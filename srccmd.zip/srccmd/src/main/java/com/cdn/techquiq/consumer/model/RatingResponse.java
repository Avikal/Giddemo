package com.cdn.techquiq.consumer.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by avikaljain on 6/5/17.
 */

public class RatingResponse extends BaseResponse {

    @SerializedName("Result")
    private ArrayList<RatingResult> ratingResult;

    public ArrayList<RatingResult> getRatingResult() {
        return ratingResult;
    }

    public void setRatingResult(ArrayList<RatingResult> ratingResult) {
        this.ratingResult = ratingResult;
    }

    public class RatingResult {
        @SerializedName("id")
        private String id;

        @SerializedName("rating")
        private String rating;

        @SerializedName("review")
        private String review;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getRating() {
            if (rating != null && rating.isEmpty() && rating.equalsIgnoreCase("")) {
                return "0.0";
            }
            return rating;
        }

        public void setRating(String rating) {
            this.rating = rating;
        }

        public String getReview() {
            return review;
        }

        public void setReview(String review) {
            this.review = review;
        }
    }
}


