package com.cdn.techquiq.consumer.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.activity.MainActivity;
import com.cdn.techquiq.consumer.adapter.OpenAdapter;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.ServiceResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;
import com.google.gson.Gson;
import com.marshalchen.ultimaterecyclerview.UltimateRecyclerView;

import java.net.SocketTimeoutException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by avikaljain on 4/4/17.
 */

public class OpenFragment extends BaseFragment {

    private static final String TAG = OpenFragment.class.getSimpleName();

    private UltimateRecyclerView recyclerView;
    private OpenAdapter openAdapter;
    private ArrayList<ServiceResponse.ServiceDetail> openDetails = new ArrayList<>();

    private int limit;
    private int currentOffset;
    private int totalRecord;
    private String keyword;
    private TextView noProductTv;
    public static int REQUEST_DELETE_SERVICE = 299;

    private LinearLayoutManager linearLayoutManager;

    private boolean isVisible;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_open, container, false);
        recyclerView = (UltimateRecyclerView) rootView.findViewById(R.id.openList);
        recyclerView.setHasFixedSize(false);
        noProductTv = (TextView) rootView.findViewById(R.id.text_no_product);

        linearLayoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(linearLayoutManager);

        recyclerView.setLoadMoreView(LayoutInflater.from(getActivity())
                .inflate(R.layout.custom_bottom_progressbar, null));
        return rootView;
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            isVisible = true;
        } else {
            isVisible = false;
        }
    }

    public void topAndBelowTab() {
        if (getActivity() != null) {
            ((MainActivity) getActivity()).hideBackBtn(true);
            ((MainActivity) getActivity()).hideCartButton(true);
            ((MainActivity) getActivity()).hideSearchButton(true);
            ((MainActivity) getActivity()).hideSettingButton(true);
            ((MainActivity) getActivity()).hideBelowTabBar(false);
        }

    }

    public void webServiceCall() {
        limit = AppConstant.OPEN_SERVICE_LIMIT;
        currentOffset = 0;
        totalRecord = 0;
        keyword = "";

        searchProduct(currentOffset, false, keyword);

        openLoadMore();

        setHasOptionsMenu(true);
    }

    public void searchProduct(int offset, final boolean isLoadMore, String keyword) {
        try {

            if (!CheckNetworkState.isOnline(getActivity())) {
                if (!isLoadMore) {
                    noProductTv.setVisibility(View.VISIBLE);
                    noProductTv.setText(getActivity().getString(R.string.network_error));
                    recyclerView.setVisibility(View.GONE);
                } else {
                    showToastMsg(getActivity(), getActivity().getString(R.string.network_error));
                }
                return;
            }


            if (!isLoadMore) {
                if (!showProgressDialog(getActivity())) {
                    return;
                }
            }

            final LoginResponse.Users userDetail = Utils.readUserDetail(getActivity());

            Call<ServiceResponse> myProductRequest = ((TechquiqApplication) getActivity().getApplicationContext())
                    .getService().getServiceList(userDetail.getUserId(),
                            Utils.getDeviceId(getActivity()),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID,
                            limit,
                            offset, 0,
                            "",
                            keyword);

            Log.e(TAG, "Request : " + myProductRequest.request().url());

            myProductRequest.enqueue(new Callback<ServiceResponse>() {
                @Override
                public void onResponse(Call<ServiceResponse> call, Response<ServiceResponse> response) {

                    if (response == null) {
                        showToastMsg(getContext(), getString(R.string.server_error));
                        return;
                    }

                    if (!isLoadMore) {
                        hideProgressDialog();
                    }

                    ServiceResponse serviceResponse = response.body();

                    if (serviceResponse == null) {
                        showToastMsg(getContext(), getString(R.string.server_error));
                        setErrorMessage(getString(R.string.server_error));

                        return;
                    }
                    Log.e(TAG, "Response : " + new Gson().toJson(serviceResponse));
                    int responseStatusCode = serviceResponse.getResponseStatusCode();
                    if (responseStatusCode == AppConstant.NO_DATA_FOUND) {
                        setErrorMessage(getString(R.string.ws_no_open_data_found));
                        ((MainActivity) getActivity()).hideSearchButton(true);
                    } else if (responseStatusCode == AppConstant.UNKNOWN_ERROR) {
                        setErrorMessage(getString(R.string.ws_unkonwn_error));

                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        totalRecord = serviceResponse.getTotalProduct();
                        Log.e(TAG, String.valueOf(totalRecord));
                        if (serviceResponse.getResponseCode().equalsIgnoreCase("0")) {
                            setErrorMessage(getString(R.string.ws_no_open_data_found));
                            ((MainActivity) getActivity()).hideSearchButton(true);
                            return;
                        } else {
                            recyclerView.setVisibility(View.VISIBLE);
                            noProductTv.setVisibility(View.GONE);
                            ((MainActivity) getActivity()).hideSearchButton(false);
                        }
                        if (isLoadMore) {
                            if (openDetails != null) {
                                int offset = openDetails.size();
                                for (int i = 0; i < serviceResponse.getServiceDetails().size(); i++) {
                                    openDetails.add(offset, serviceResponse.getServiceDetails().get(i));
                                    offset++;
                                }

                                openAdapter.notifyDataSetChanged();
                            }
                        } else {
                            openDetails = serviceResponse.getServiceDetails();
                            if (openDetails != null && openDetails.size() > 0) {
                                openAdapter = new OpenAdapter(getActivity(), openDetails);
                                recyclerView.setAdapter(openAdapter);
//                                recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
                            }
                        }

                    } else {
                        showToastMsg(getContext(), serviceResponse.getResponseMessage());
                    }


                }

                @Override
                public void onFailure(Call<ServiceResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        setErrorMessage(getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    setErrorMessage(getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void openLoadMore() {
        if (recyclerView != null) {
            recyclerView.reenableLoadmore();
            recyclerView.setOnLoadMoreListener(new UltimateRecyclerView.OnLoadMoreListener() {
                @Override
                public void loadMore(int itemsCount, int maxLastVisiblePosition) {
                    try {
                        if (totalRecord <= openDetails.size()) {
                            recyclerView.disableLoadmore();
                        } else {
                            currentOffset = currentOffset + limit;
                            searchProduct(currentOffset, true, keyword);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    }

    private void setErrorMessage(String msg) {
        noProductTv.setVisibility(View.VISIBLE);
        noProductTv.setText(msg);
        recyclerView.setVisibility(View.GONE);
    }

    public void openActivityDetail(String id) {

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_DELETE_SERVICE && resultCode == getActivity().RESULT_OK) {
            webServiceCall();
        }
    }

    public void onResume() {
        super.onResume();
        if (isVisible) {
            webServiceCall();
        }
    }
}
