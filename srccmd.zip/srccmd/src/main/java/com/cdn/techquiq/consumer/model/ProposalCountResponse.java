package com.cdn.techquiq.consumer.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by avikaljain on 19/6/17.
 */

public class ProposalCountResponse extends BaseResponse {

    @SerializedName("ProposalCount")
    private int ProposalCount;

    public int getProposalCount() {
        return ProposalCount;
    }

    public void setProposalCount(int proposalCount) {
        ProposalCount = proposalCount;
    }
}
