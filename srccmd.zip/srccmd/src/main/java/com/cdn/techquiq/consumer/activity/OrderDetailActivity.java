package com.cdn.techquiq.consumer.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.adapter.OrderDetailAdapter;
import com.cdn.techquiq.consumer.model.BaseResponse;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.OrderHistoryResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;
import com.google.gson.Gson;

import java.net.SocketTimeoutException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by akshaysoni on 3/2/17.
 */

public class OrderDetailActivity extends BaseActivity {

    private String TAG = OrderDetailActivity.class.getSimpleName();

    private ImageView backIv;
    private RecyclerView orderDetailList;
    private Context mContext;
    private TextView titleTv, totalAmountTv, totalCountTv, cancelOrderTv;
    private OrderHistoryResponse.OrderList orderList;

    @Nullable
    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.order_detail_activity);
        mContext = this;

        orderList = (OrderHistoryResponse.OrderList)
                (getIntent().getExtras().getSerializable("orderList"));

        setUpUI();

        setAdapter();

    }

    private void setUpUI() {
        titleTv = (TextView) findViewById(R.id.titleTv);
        titleTv.setText(getResources().getString(R.string.txt_order_detail_title));
        backIv = (ImageView) findViewById(R.id.backIv);
        backIv.setOnClickListener(this);
        orderDetailList = (RecyclerView) findViewById(R.id.orderDetailList);
        totalAmountTv = (TextView) findViewById(R.id.totalAmountTv);
        totalCountTv = (TextView) findViewById(R.id.totalCountTv);
        cancelOrderTv = (TextView) findViewById(R.id.cancelOrderTv);
        cancelOrderTv.setOnClickListener(this);
        if (orderList != null) {
            if (orderList.getOrderStatus() != null) {
                if (orderList.getOrderStatusCode() == AppConstant.ORDER_DELIVERED ||
                        orderList.getOrderStatusCode() == AppConstant.ORDER_CANCELED || orderList.getOrderStatusCode() == AppConstant.ORDER_COMPLETED) {
                    cancelOrderTv.setVisibility(View.GONE);
                } else {
                    cancelOrderTv.setVisibility(View.VISIBLE);
                }
            }

        }

    }

    public void setAdapter() {
        if (orderList != null && orderList.getOrderDetail() != null &&
                orderList.getOrderDetail().size() > 0) {
            OrderDetailAdapter orderDetailAdapter = new OrderDetailAdapter(mContext, orderList);
            LinearLayoutManager lManger = new LinearLayoutManager(OrderDetailActivity.this,
                    LinearLayoutManager.VERTICAL, false);
            orderDetailList.setLayoutManager(lManger);
            orderDetailList.setAdapter(orderDetailAdapter);
        }

        totalAmountTv.setText(mContext.getResources().getString(R.string.total_amount) + " : " +
                AppConstant.CURRENCY_SYMBOL + " " + Utils.roundDecimal(String.valueOf(orderList.getTotalAmount())));
        totalCountTv.setText(mContext.getResources().getString(R.string.total_count) + " : " +
                orderList.getOrderDetail().size());
    }


    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.backIv:
                finish();
                break;

            case R.id.cancelOrderTv:
                confirmDialog();

                break;
        }
    }

    private void confirmDialog() {
        new AlertDialog.Builder(mContext)
                .setTitle(mContext.getString(R.string.app_name))
                .setMessage(mContext.getString(R.string.cancel_order_alert))
                .setPositiveButton(getString(R.string.yes), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        updateOrderStatus();
                        dialog.dismiss();

                    }
                })
                .setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .setIcon(R.drawable.ic_launcher)
                .show();
    }


    public void updateOrderStatus() {
        try {
            if (!CheckNetworkState.isOnline(mContext)) {
                showToastMsg(mContext, getString(R.string.network_error));
                return;
            }

            if (!showProgressDialog(mContext)) {
                return;
            }

            final LoginResponse.Users userDetail = Utils.readUserDetail(this);
            final Call<BaseResponse> updateOrderStatusRequest = ((TechquiqApplication) mContext.getApplicationContext())
                    .getService().updateOrderStatus(userDetail.getUserId(),
                            Utils.getDeviceId(mContext),
                            AppConstant.FCM_ID,
                            ApiParameter.DEVICE_TYPE_VALUE,
                            orderList.getId(),
                            null);//merchantId

            Log.e(TAG, "Request : " + updateOrderStatusRequest.request().url());

            updateOrderStatusRequest.enqueue(new Callback<BaseResponse>() {
                @Override
                public void onResponse(Call<BaseResponse> call, Response<BaseResponse> response) {
                    Log.e(TAG, "Response : " + new Gson().toJson(response.body()));
                    hideProgressDialog();
                    if (response == null) {
                        showToastMsg(mContext, getString(R.string.server_error));
                        return;
                    }
                    BaseResponse apiError = response.body();
                    int responseStatusCode = apiError.getResponseStatusCode();
                    if (responseStatusCode == AppConstant.UNKNOWN_ERROR) {
                        showToastMsg(mContext, getString(R.string.ws_unkonwn_error));
                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        if (apiError.getResponseCode().equalsIgnoreCase("1")) {
                            showToastMsg(mContext, mContext.getString(R.string.ws_order_canceled));
                            finish();
                        }
                    } else {
                        showToastMsg(mContext, apiError.getResponseMessage());
                    }

                }

                @Override
                public void onFailure(Call<BaseResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                    Log.e(TAG, "Error : " + t.getMessage());
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
