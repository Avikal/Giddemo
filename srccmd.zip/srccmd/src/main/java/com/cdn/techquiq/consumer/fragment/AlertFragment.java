package com.cdn.techquiq.consumer.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.activity.MainActivity;
import com.cdn.techquiq.consumer.adapter.AlertAdapter;
import com.cdn.techquiq.consumer.model.AlertResponse;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.commonResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;
import com.google.gson.Gson;
import com.marshalchen.ultimaterecyclerview.UltimateRecyclerView;

import java.net.SocketTimeoutException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by kajalsoni on 3/2/17.
 */

public class AlertFragment extends BaseFragment {

    private String TAG = AlertFragment.class.getSimpleName();

    ArrayList<commonResponse> commonBeanArrayList = new ArrayList<>();
    private int limit;
    private int currentOffset;
    private int totalRecord;
    private String keyword;
    private UltimateRecyclerView alertRecycleView;
    private TextView tvNoAlert;

    private ArrayList<AlertResponse.AlertList> alertList;
    private LinearLayoutManager linearLayoutManager;
    private AlertAdapter alertAdapter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_alert, null);
        setTitleText(getString(R.string.txt_alert_title));
        tvNoAlert = (TextView) view.findViewById(R.id.tvNoAlert);
        alertRecycleView = (UltimateRecyclerView) view.findViewById(R.id.alertRecycleView);

        alertList = null;
        linearLayoutManager = new LinearLayoutManager(getContext());
        alertRecycleView.setLayoutManager(linearLayoutManager);

        alertRecycleView.setLoadMoreView(LayoutInflater.from(getActivity())
                .inflate(R.layout.custom_bottom_progressbar, null));

        webServiceCall();
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        topAndBelowTab();


    }

    public void topAndBelowTab() {
        ((MainActivity) getActivity()).hideBackBtn(true);
        ((MainActivity) getActivity()).hideCartButton(true);
        ((MainActivity) getActivity()).hideSearchButton(true);
        ((MainActivity) getActivity()).hideSettingButton(true);
        ((MainActivity) getActivity()).hideBelowTabBar(false);
    }

    public void webServiceCall() {
        limit = AppConstant.AWARDED_LIMIT;
        currentOffset = 0;
        totalRecord = 0;
        keyword = "";
        getAlertList(currentOffset, false, keyword);
        loadMore();
    }

    public void getAlertList(int offset, final boolean isLoadMore, String keyword) {
        try {
            if (!CheckNetworkState.isOnline(getActivity())) {
                if (!isLoadMore) {
                    tvNoAlert.setVisibility(View.VISIBLE);
                    tvNoAlert.setText(getActivity().getString(R.string.network_error));
                    alertRecycleView.setVisibility(View.GONE);
                } else {
                    showToastMsg(getActivity(), getActivity().getString(R.string.network_error));
                }
                return;
            }

            this.keyword = keyword;
            if (!isLoadMore) {
                if (!showProgressDialog(getActivity())) {
                    return;
                }
            }

            final LoginResponse.Users userDetail = Utils.readUserDetail(getActivity());
            final Call<AlertResponse> alertRequest = ((TechquiqApplication) getActivity()
                    .getApplicationContext()).getService().getAlert(
                    userDetail.getUserId(),
                    Utils.getDeviceId(getActivity()),
                    AppConstant.FCM_ID,
                    ApiParameter.DEVICE_TYPE_VALUE,
                    limit,
                    offset,
                    keyword
            );

            Log.e(TAG, "Request : " + alertRequest.request().url());

            alertRequest.enqueue(new Callback<AlertResponse>() {
                @Override
                public void onResponse(Call<AlertResponse> call, Response<AlertResponse> response) {
                    if (response == null) {
                        showToastMsg(getContext(), getString(R.string.server_error));
                        return;
                    }

                    if (!isLoadMore) {
                        hideProgressDialog();
                    }

                    Log.e(TAG, "Categories Response : " + new Gson().toJson(response.body()));
                    AlertResponse alertResponse = response.body();
                    if (alertResponse == null) {
                        showToastMsg(getContext(), getString(R.string.server_error));
                        setErrorMessage(getString(R.string.server_error));
                        return;
                    }

                    int responseStatusCode = alertResponse.getResponseStatusCode();
                    if (responseStatusCode == AppConstant.PARAM_MISSING) {
                        showToastMsg(getContext(), getString(R.string.ws_param_missing));
                    } else if (responseStatusCode == AppConstant.NO_DATA_FOUND) {
                        setErrorMessage(getString(R.string.ws_no_alert_found));
                    } else if (responseStatusCode == AppConstant.UNKNOWN_ERROR) {
                        setErrorMessage(getString(R.string.ws_unkonwn_error));
                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        totalRecord = alertResponse.getTotal_service();
                        Log.e(TAG, "Total Service " + String.valueOf(totalRecord));
                        if (alertResponse.getResponseCode().equalsIgnoreCase("0")) {
                            if (!isLoadMore) {
                                setErrorMessage(getResources().getString(R.string.ws_no_inbox_data_found));
                                ((MainActivity) getActivity()).hideSearchButton(true);
                            } else {
                                ((MainActivity) getActivity()).hideSearchButton(true);
                                showToastMsg(getActivity(), response.body().getResponseMessage());
                            }
                            return;
                        } else {
                            ((MainActivity) getActivity()).hideSearchButton(true);
                            alertRecycleView.setVisibility(View.VISIBLE);
                            tvNoAlert.setVisibility(View.GONE);
                            if (isLoadMore) {
                                if (alertList != null) {
                                    int offset = alertList.size();
                                    for (int i = 0; i < alertResponse.getAlertList().size(); i++) {
                                        alertList.add(offset, alertResponse.getAlertList().get(i));
                                        offset++;
                                    }
                                    alertAdapter.notifyDataSetChanged();
                                }
                            } else {
                                alertList = alertResponse.getAlertList();
                                if (alertList != null && alertList.size() > 0) {
                                    alertAdapter = new AlertAdapter(getActivity(), alertList);
                                    alertRecycleView.setAdapter(alertAdapter);
                                }
                            }
                        }

                    } else {
                        showToastMsg(getContext(), alertResponse.getResponseMessage());
                    }


                }

                @Override
                public void onFailure(Call<AlertResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        setErrorMessage(getString(R.string.connection_timeout));
                        return;
                    }
                    setErrorMessage(getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadMore() {
        alertRecycleView.reenableLoadmore();
        alertRecycleView.setOnLoadMoreListener(new UltimateRecyclerView.OnLoadMoreListener() {
            @Override
            public void loadMore(int itemsCount, int maxLastVisiblePosition) {
                try {
                    if (totalRecord <= alertList.size()) {
                        alertRecycleView.disableLoadmore();
                    } else {
                        currentOffset = currentOffset + limit;
                        getAlertList(currentOffset, true, keyword);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void setErrorMessage(String msg) {
        tvNoAlert.setVisibility(View.VISIBLE);
        tvNoAlert.setText(msg);
        alertRecycleView.setVisibility(View.GONE);
    }

}
