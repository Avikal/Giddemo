
package com.cdn.techquiq.consumer.adapter;

/**
 * Created by kajalsoni on 31/1/17.
 */

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.model.ProductResponse;

import java.util.ArrayList;
import java.util.List;

public class ProductImageAdapter extends RecyclerView.Adapter<ProductImageAdapter.MyViewHolder> {

    private List<ProductResponse> productResponseList;
    Context mContext;
    LayoutInflater mLayoutInflater;


    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView productImg, cancelBt;
        View mparent;

        public MyViewHolder(View view) {
            super(view);
            mparent = view;
            productImg = (ImageView) view.findViewById(R.id.productImg);
            cancelBt = (ImageView) view.findViewById(R.id.cancelBt);
        }
    }

    public ProductImageAdapter(Context context, ArrayList<ProductResponse> productResponseList) {
        this.mContext = context;
        this.productResponseList = productResponseList;
        mLayoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mLayoutInflater
                .inflate(R.layout.products_img_list_item, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {
        final ProductResponse productResponse = productResponseList.get(position);
       /* Glide.with(mContext).load(productResponse.get)
                .thumbnail(0.5f)
                .crossFade()
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(holder.productImg);*/
        holder.mparent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }


    @Override
    public int getItemCount() {
        return productResponseList.size();
    }
}
