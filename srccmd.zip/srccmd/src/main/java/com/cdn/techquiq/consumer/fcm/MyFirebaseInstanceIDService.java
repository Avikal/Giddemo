package com.cdn.techquiq.consumer.fcm;


import android.util.Log;

import com.cdn.techquiq.consumer.Utils.Utils;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;

/**
 * Created by avikaljain on 8/6/17.
 * used for getting token and store into sharedpref.
 */
public class MyFirebaseInstanceIDService extends FirebaseInstanceIdService {

    private static final String TAG = "MyFirebaseIIDService";

    @Override
    public void onTokenRefresh() {

        //Getting registration token
        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        if (refreshedToken != null) {
            Log.e(TAG, "Refreshed token: " + refreshedToken);
            try {
                Utils.saveDeviceTokenId(getApplicationContext(), refreshedToken);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}