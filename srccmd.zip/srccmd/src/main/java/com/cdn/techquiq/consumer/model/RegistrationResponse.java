package com.cdn.techquiq.consumer.model;

/**
 * Created by kajalsoni on 30/1/17.
 */

public class RegistrationResponse extends BaseResponse {
    /*   {
           "Chat": {
           "userId": 15
       },
           "ResponseMessage": "Thank you for registering! with techquiq.",
               "ResponseCode": 1
       }
   */
    Registration Result;

    public Registration getResult() {
        return Result;
    }

    public void setResult(Registration result) {
        Result = result;
    }

    public class Registration

    {
        String userId = "";

        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }
    }


}
