package com.cdn.techquiq.consumer.fragment;

import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.activity.MainActivity;
import com.cdn.techquiq.consumer.adapter.ViewPagerAdapter;

/**
 * Created by akshaysoni on 3/2/17.
 */
public class ProductParentFragment extends BaseFragment {

    private String TAG = ProductParentFragment.class.getSimpleName();

    private TabLayout tabLayout;
    private ViewPager viewPager;
    private ViewPagerAdapter adapter;
    private Fragment fragment;
    private int selectedPosition = 0;
    private long mLastClickTime = 0;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_product_parent, container, false);

        setTitleText(getString(R.string.txt_products_title));

        tabLayout = (TabLayout) rootView.findViewById(R.id.tab_layout);

        addViewPagerAdapter(rootView);

        webServiceCall(selectedPosition);

        return rootView;
    }

    private void webServiceCall(int position) {
        fragment = ((ViewPagerAdapter) viewPager.getAdapter()).getItem(position);
        if (fragment instanceof ProductFragment) {
            viewPager.setCurrentItem(0);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (fragment instanceof ProductFragment) {
                        ((ProductFragment) fragment).callWebService("");
                        ((ProductFragment) fragment).topAndBelowTab();
                    }
                }
            }, 100);
        } else if (fragment instanceof MyOrderFragment) {
            viewPager.setCurrentItem(1);
            ((MyOrderFragment) fragment).callWebService();
            ((MyOrderFragment) fragment).topAndBelowTab();
        }

        if (getActivity() != null) {
            Utils.hideKeyBoard(getActivity());
            ((MainActivity) getActivity()).closeSearchView();
        }
    }

    private void addViewPagerAdapter(final View view) {
        viewPager = (ViewPager) view.findViewById(R.id.pager);
        adapter = new ViewPagerAdapter(getChildFragmentManager());

        adapter.addFragment(new ProductFragment(), getResources().getString(R.string.txt_all_products_title));
        adapter.addFragment(new MyOrderFragment(), getResources().getString(R.string.txt_my_order_title));

        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

        View root = tabLayout.getChildAt(0);
        if (root instanceof LinearLayout) {
            ((LinearLayout) root).setShowDividers(LinearLayout.SHOW_DIVIDER_MIDDLE);
            GradientDrawable drawable = new GradientDrawable();
            drawable.setColor(getResources().getColor(R.color.black));
            drawable.setSize(1, 1);
            ((LinearLayout) root).setDividerDrawable(drawable);
        }
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (SystemClock.elapsedRealtime() - mLastClickTime < 1000) {
                    return;
                }
                mLastClickTime = SystemClock.elapsedRealtime();

                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                Log.e(TAG, "onPageSelected");
                selectedPosition = position;
                if (((MainActivity) getActivity()).isSearchOpen()) {
                    ((MainActivity) getActivity()).setApiCallOnSearchClose(false);
                }
                webServiceCall(selectedPosition);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    public Fragment getCurrentFragment() {
        return fragment;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (fragment instanceof ProductFragment) {
            ((ProductFragment) fragment).onActivityResult(requestCode, resultCode, data);
        }
    }
}
