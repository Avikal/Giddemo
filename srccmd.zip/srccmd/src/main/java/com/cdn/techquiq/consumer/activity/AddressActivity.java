package com.cdn.techquiq.consumer.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.adapter.AddressAdapter;
import com.cdn.techquiq.consumer.model.AddressResponse;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.google.gson.Gson;

import java.net.SocketTimeoutException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by avikaljain on 3/4/17.
 */


public class AddressActivity extends BaseActivity implements View.OnClickListener {

    private String TAG = AddressActivity.class.getSimpleName();

    private RecyclerView recyclerView;
    private AddressAdapter addressAdapter;
    private ArrayList<AddressResponse.AddressDetail> addressDetail = new ArrayList<>();
    private ImageView backIv;
    private TextView titleTv;

    private TextView addNewAddressTv;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_address);
        setUpUI();
    }

    private void setUpUI() {
        titleTv = (TextView) findViewById(R.id.titleTv);
        titleTv.setText(getResources().getString(R.string.delivery_address));
        recyclerView = (RecyclerView) findViewById(R.id.addressList);
        backIv = (ImageView) findViewById(R.id.backIv);
        addNewAddressTv = (TextView) findViewById(R.id.addNewAddressTv);
        addressAdapter = new AddressAdapter(this, addressDetail);
        recyclerView.setAdapter(addressAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        backIv.setOnClickListener(this);
        addNewAddressTv.setOnClickListener(this);
    }

    @Override
    public void onResume() {
        super.onResume();
        getShippingAddress();
    }

    public void setNewList() {
        getShippingAddress();
    }

    private void getShippingAddress() {
        showProgressDialog(this);
        try {
            final LoginResponse.Users userDetail = Utils.readUserDetail(this);
            final Call<AddressResponse> shippingAddressRequest = ((TechquiqApplication) this
                    .getApplicationContext()).getService().getShippingAddress(
                    userDetail.getUserId(),
                    Utils.getDeviceId(mContext),
                    AppConstant.FCM_ID,
                    ApiParameter.DEVICE_TYPE_VALUE
            );

            Log.e(TAG, "Request : " + shippingAddressRequest.request().url());

            shippingAddressRequest.enqueue(new Callback<AddressResponse>() {
                @Override
                public void onResponse(Call<AddressResponse> call, Response<AddressResponse> response) {
                    hideProgressDialog();

                    Log.e(TAG, "Response : " + new Gson().toJson(response.body()));
                    Log.e(TAG, response.toString());
                    AddressResponse addressResponse = response.body();
                    int responseStatusCode = addressResponse.getResponseStatusCode();
                    if (responseStatusCode == AppConstant.NO_DATA_FOUND) {
                        showToastMsg(mContext, getString(R.string.ws_no_address_found));
                    } else if (responseStatusCode == AppConstant.UNKNOWN_ERROR) {
                        showToastMsg(mContext, getString(R.string.ws_unkonwn_error));
                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        if (addressResponse.getResponseCode() != null && addressResponse.getResponseCode().equalsIgnoreCase("0")) {
                            showToastMsg(mContext, response.body().getResponseMessage());
                            return;
                        } else if (addressResponse.getResponseCode() != null
                                && addressResponse.getResponseCode().equalsIgnoreCase("1")) {
                            ArrayList<AddressResponse.AddressDetail> shippingResult = addressResponse.getAddressDetail();
                            addressAdapter = new AddressAdapter(AddressActivity.this, shippingResult);
                            recyclerView.setAdapter(addressAdapter);
                        }
                    } else {
                        showToastMsg(mContext, response.body().getResponseMessage());
                    }


                }

                @Override
                public void onFailure(Call<AddressResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.backIv:
                finish();
                break;
            case R.id.addNewAddressTv:
                Intent intent = new Intent(AddressActivity.this, AddAddressActivity.class);
                intent.putExtra("status", "add");
                startActivity(intent);
                break;
        }
    }
}
