package com.cdn.techquiq.consumer.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.Utils.SharedPrefrence;
import com.cdn.techquiq.consumer.database.DBHelper;
import com.cdn.techquiq.consumer.fragment.ProductDetailFragment;

/**
 * Created by avikaljain on 8/5/17.
 */
public class ProductDetailActivity extends BaseActivity {

    private String TAG = ProductDetailActivity.class.getSimpleName();
    private SharedPrefrence sPref;

    private TextView titleTv, cartCountTv;
    private ImageView backIv;
    private RelativeLayout cartCountTitleLayout;
    private boolean fromProduct;
    private boolean writeReview;
    private int productId;
    private ImageView cartIv;
    private ImageView sliderIv, settingIv, searchIv;

    public boolean isFromProduct() {
        return fromProduct;
    }

    public int getProductId() {
        return productId;
    }

    public boolean isWriteReview() {
        return writeReview;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);
        sPref = SharedPrefrence.getInstance(this);
        setUI();
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            productId = bundle.getInt("productId");
            fromProduct = bundle.getBoolean("isProduct");
            writeReview = bundle.getBoolean("isReview");

        }
        ProductDetailFragment fragment = new ProductDetailFragment();
        pushFragment(fragment);

    }

    private void setUI() {
        titleTv = (TextView) findViewById(R.id.titleTv);
        sliderIv = (ImageView) findViewById(R.id.sliderIv);
        backIv = (ImageView) findViewById(R.id.backIv);
        cartIv = (ImageView) findViewById(R.id.cartIv);
        settingIv = (ImageView) findViewById(R.id.settingIv);
        searchIv = (ImageView) findViewById(R.id.searchIcon);

        cartCountTitleLayout = (RelativeLayout) findViewById(R.id.cartCountTitleLayout);
        cartCountTv = (TextView) findViewById(R.id.cartCountTv);
        backIv.setOnClickListener(this);
        cartIv.setOnClickListener(this);
    }

    private void pushFragment(Fragment fragment) {
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction ft = manager.beginTransaction();
        ft.replace(R.id.fragment_container, fragment);
        ft.addToBackStack(null);
        ft.commitAllowingStateLoss();
    }

    public void setTitleText(String title) {
        if (titleTv != null && title != null && !title.isEmpty()) {
            titleTv.setText(title);
        }
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.backIv:
                finish();
                break;
            case R.id.cartIv:
                DBHelper.getInstance(mContext).clearAllProductFilter();
                openCartScreen();
                break;

        }
    }

    private void openCartScreen() {
        Intent cartIntent = new Intent(this, CartActivity.class);
        startActivity(cartIntent);
    }

    /**
     * Below methods is use for hide and show title bar and below bar
     */
    public void hideSearchButton(boolean hide) {
        if (hide) {
            searchIv.setVisibility(View.GONE);
        } else {
            searchIv.setVisibility(View.VISIBLE);
        }
    }

    public void hideBackBtn(boolean hide) {
        if (hide) {
            backIv.setVisibility(View.GONE);
            sliderIv.setVisibility(View.VISIBLE);
        } else {
            backIv.setVisibility(View.VISIBLE);
            sliderIv.setVisibility(View.GONE);
        }
    }

    public void hideSettingButton(boolean hide) {
        if (hide) {
            settingIv.setVisibility(View.GONE);
        } else {
            settingIv.setVisibility(View.VISIBLE);
        }
    }

    public void hideCartButton(boolean hide) {
        if (hide) {
            cartIv.setVisibility(View.GONE);
            cartCountTitleLayout.setVisibility(View.GONE);
        } else {
            cartIv.setVisibility(View.VISIBLE);
            int totalCart = SharedPrefrence.getInstance(this).readIntPrefs(SharedPrefrence.cartCount);
            if (totalCart > 0) {
                cartCountTitleLayout.setVisibility(View.VISIBLE);
                cartCountTv.setText("" + totalCart);
            } else {
                cartCountTitleLayout.setVisibility(View.GONE);
            }
        }
    }


    @Override
    public void onBackPressed() {
        backIv.performClick();
    }
}
