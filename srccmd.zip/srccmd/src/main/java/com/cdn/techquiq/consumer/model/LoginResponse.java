package com.cdn.techquiq.consumer.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Created by kajalsoni on 30/1/17.
 */

public class LoginResponse extends BaseResponse {


    @SerializedName("Result")
    Users Result;

    public Users getResult() {
        return Result;
    }

    public void setResult(Users result) {
        Result = result;
    }

    public class Users implements Serializable {

        @SerializedName("userId")
        private int userId;

        @SerializedName("email")
        private String email;

        @SerializedName("first_name")
        private String first_name;

        @SerializedName("last_name")
        private String last_name;

        @SerializedName("company")
        private String company;

        @SerializedName("address")
        private String address;

        @SerializedName("phone")
        private String phone;

        @SerializedName("country")
        private String country;

        @SerializedName("state")
        private String state;

        @SerializedName("city")
        private String city;

        @SerializedName("postalcode")
        private String postalcode;

        public String getStateName() {
            return stateName;
        }

        public void setStateName(String stateName) {
            this.stateName = stateName;
        }

        @SerializedName("cart_id")
        private int cartId;

        @SerializedName("total_cart")
        private int totalCart;

        @SerializedName("image")
        private String image;


        @SerializedName("country_name")
        private String countryName;

        @SerializedName("state_name")
        private String stateName;

        @SerializedName("city_name")
        private String cityName;

        public String getCountryName() {
            return countryName;
        }

        public void setCountryName(String countryName) {
            this.countryName = countryName;
        }

        public String getCityName() {

            return cityName;
        }

        public void setCityName(String cityName) {
            this.cityName = cityName;
        }

        public String getImage() {
            return image;
        }

        public void setImage(String image) {
            this.image = image;
        }

        public int getUserId() {
            return userId;
        }

        public void setUserId(int userId) {
            this.userId = userId;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getFirst_name() {
            return first_name;
        }

        public void setFirst_name(String first_name) {
            this.first_name = first_name;
        }

        public String getLast_name() {
            return last_name;
        }

        public void setLast_name(String last_name) {
            this.last_name = last_name;
        }

        public String getCompany() {
            return company;
        }

        public void setCompany(String company) {
            this.company = company;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getPhone() {
            return phone;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }

        public String getCountry() {
            return country;
        }

        public void setCountry(String country) {
            this.country = country;
        }

        public String getState() {
            return state;
        }

        public void setState(String state) {
            this.state = state;
        }

        public String getCity() {
            return city;
        }

        public void setCity(String city) {
            this.city = city;
        }

        public String getPostalcode() {
            return postalcode;
        }

        public void setPostalcode(String postalcode) {
            this.postalcode = postalcode;
        }

        public int getTotalCart() {
            return totalCart;
        }

        public void setTotalCart(int totalCart) {
            this.totalCart = totalCart;
        }

        public int getCartId() {
            return cartId;
        }

        public void setCartId(int cartId) {
            this.cartId = cartId;
        }
    }

}
