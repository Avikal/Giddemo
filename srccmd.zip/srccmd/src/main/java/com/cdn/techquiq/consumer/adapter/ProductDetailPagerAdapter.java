package com.cdn.techquiq.consumer.adapter;

import android.content.Context;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.model.ProductResponse;

import java.util.ArrayList;

/**
 * Created by akshaysoni on 29/1/16.
 */
public class ProductDetailPagerAdapter extends PagerAdapter {

    private LayoutInflater inflater = null;
    private ProductResponse.ProductDetail productDetail;
    private Context mContext;

    public ProductDetailPagerAdapter(Context c, ProductResponse.ProductDetail mDetail) {
        inflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        productDetail = mDetail;
        mContext = c;
    }

    @Override
    public int getCount() {
        return productDetail.getProductImages().size();
    }


    public long getItemId(int position) {
        return position;
    }

    @Override
    public Object instantiateItem(ViewGroup parent, int position) {
        View convertView = inflater.inflate(R.layout.image_item, parent, false);
        ((ViewGroup) parent).addView(convertView, 0);
        ImageView imageView = (ImageView) convertView.findViewById(R.id.imageView);
        ArrayList<ProductResponse.ProductDetail.ProductImage> productImages = productDetail.getProductImages();
        if (productImages != null && productImages.size() > 0) {
            Glide.with(mContext).load(productImages.get(position).getImage())
                    .crossFade()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .error(R.drawable.placeholder_1)
                    .placeholder(R.drawable.placeholder_1)
                    .into(imageView);
        }

        return convertView;
    }

    @Override
    public void destroyItem(View arg0, int arg1, Object arg2) {
        ((ViewPager) arg0).removeView((View) arg2);
    }

    @Override
    public boolean isViewFromObject(View arg0, Object arg1) {
        return arg0 == ((View) arg1);
    }

    @Override
    public Parcelable saveState() {
        return null;
    }

}