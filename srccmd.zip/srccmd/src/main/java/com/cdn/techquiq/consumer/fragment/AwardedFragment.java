package com.cdn.techquiq.consumer.fragment;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.activity.MainActivity;
import com.cdn.techquiq.consumer.adapter.AwardedAdapter;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.ServiceResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;
import com.marshalchen.ultimaterecyclerview.UltimateRecyclerView;

import java.net.SocketTimeoutException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by avikaljain on 4/4/17.
 */

public class AwardedFragment extends BaseFragment {

    private static final String TAG = AwardedFragment.class.getSimpleName();

    private UltimateRecyclerView recyclerView;
    private AwardedAdapter awardedAdapter;
    private ArrayList<ServiceResponse.ServiceDetail> openDetails = new ArrayList<>();

    private int limit;
    private int currentOffset;
    private int totalRecord;
    private String keyword;
    private TextView noProductTv;
    private LinearLayoutManager linearLayoutManager;
    private boolean isVisible;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_open, container, false);
        recyclerView = (UltimateRecyclerView) rootView.findViewById(R.id.openList);
        noProductTv = (TextView) rootView.findViewById(R.id.text_no_product);

        linearLayoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(linearLayoutManager);

        recyclerView.setLoadMoreView(LayoutInflater.from(getActivity())
                .inflate(R.layout.custom_bottom_progressbar, null));

        return rootView;
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            isVisible = true;
        } else {
            isVisible = false;
        }
    }

    public void topAndBelowTab() {
        if (getActivity() != null) {
            ((MainActivity) getActivity()).hideBackBtn(true);
            ((MainActivity) getActivity()).hideCartButton(true);
            ((MainActivity) getActivity()).hideSearchButton(true);
            ((MainActivity) getActivity()).hideSettingButton(true);
            ((MainActivity) getActivity()).hideBelowTabBar(false);
        }
    }


    public void webServiceCall() {
        limit = AppConstant.AWARDED_LIMIT;
        currentOffset = 0;
        totalRecord = 0;
        keyword = "";
        searchProduct(currentOffset, false, keyword);
        productLoadMore();
    }

    public void searchProduct(int offset, final boolean isLoadMore, String keyword) {
        try {
            if (!CheckNetworkState.isOnline(getActivity())) {
                if (!isLoadMore) {
                    noProductTv.setVisibility(View.VISIBLE);
                    noProductTv.setText(getActivity().getString(R.string.network_error));
                    recyclerView.setVisibility(View.GONE);
                } else {
                    showToastMsg(getActivity(), getActivity().getString(R.string.network_error));
                }
                return;
            }

            this.keyword = keyword;
            if (!isLoadMore) {
                if (!showProgressDialog(getActivity())) {
                    return;
                }
            }

            final LoginResponse.Users userDetail = Utils.readUserDetail(getActivity());

            Call<ServiceResponse> myProductRequest = ((TechquiqApplication) getActivity().getApplicationContext())
                    .getService().getServiceList(userDetail.getUserId(),
                            Utils.getDeviceId(getActivity()),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID,
                            limit,
                            offset,
                            1,
                            "",
                            keyword);

            Log.e(TAG, "Request : " + myProductRequest.request().url());

            myProductRequest.enqueue(new Callback<ServiceResponse>() {
                @Override
                public void onResponse(Call<ServiceResponse> call, Response<ServiceResponse> response) {

                    if (response == null) {
                        return;
                    }

                    if (!isLoadMore) {
                        hideProgressDialog();
                    }

                    ServiceResponse serviceResponse = response.body();
                    if (serviceResponse == null) {
                        showToastMsg(getContext(), getString(R.string.server_error));
                        setErrorMessage(getString(R.string.server_error));
                        return;
                    }
                    totalRecord = serviceResponse.getTotalProduct();
                    Log.e(TAG, "Total Service : " + String.valueOf(totalRecord));
                    int responseStatusCode = serviceResponse.getResponseStatusCode();
                    if (responseStatusCode == AppConstant.NO_DATA_FOUND) {
                        setErrorMessage(getString(R.string.ws_no_award_service_found));
                        ((MainActivity) getActivity()).hideSearchButton(true);
                    } else if (responseStatusCode == AppConstant.UNKNOWN_ERROR) {
                        setErrorMessage(getString(R.string.ws_unkonwn_error));

                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        if (serviceResponse.getResponseCode().equalsIgnoreCase("0")) {
                            setErrorMessage(getString(R.string.ws_no_award_service_found));
                            ((MainActivity) getActivity()).hideSearchButton(true);
                            return;
                        } else {
                            recyclerView.setVisibility(View.VISIBLE);
                            noProductTv.setVisibility(View.GONE);
                            ((MainActivity) getActivity()).hideSearchButton(false);
                        }


                        if (isLoadMore) {
                            if (openDetails != null && openDetails.size() > 0) {
                                int offset = openDetails.size();
                                for (int i = 0; i < serviceResponse.getServiceDetails().size(); i++) {
                                    openDetails.add(offset, serviceResponse.getServiceDetails().get(i));
                                    offset++;
                                }
                                awardedAdapter.notifyDataSetChanged();
                            }
                        } else {
                            openDetails = serviceResponse.getServiceDetails();
                            if (openDetails != null && openDetails.size() > 0) {
                                awardedAdapter = new AwardedAdapter(getActivity(), openDetails);
                                recyclerView.setAdapter(awardedAdapter);
                            } else {

                            }
                        }
                    } else {
                        showToastMsg(getContext(), serviceResponse.getResponseMessage());
                    }


                }

                @Override
                public void onFailure(Call<ServiceResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        setErrorMessage(getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    setErrorMessage(getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setErrorMessage(String msg) {
        noProductTv.setVisibility(View.VISIBLE);
        noProductTv.setText(msg);
        recyclerView.setVisibility(View.GONE);
    }

    private void productLoadMore() {
        if (recyclerView != null) {
            recyclerView.reenableLoadmore();
            recyclerView.setOnLoadMoreListener(new UltimateRecyclerView.OnLoadMoreListener() {
                @Override
                public void loadMore(int itemsCount, int maxLastVisiblePosition) {
                    try {
                        if (totalRecord <= openDetails.size()) {
                            recyclerView.disableLoadmore();
                        } else {
                            currentOffset = currentOffset + limit;
                            searchProduct(currentOffset, true, keyword);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    }

    public void onResume() {
        super.onResume();
        if (isVisible) {
            webServiceCall();
        }

    }
}
