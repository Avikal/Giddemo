package com.cdn.techquiq.consumer.activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.stripe.android.Stripe;
import com.stripe.android.TokenCallback;
import com.stripe.android.model.Card;
import com.stripe.android.model.Token;
import com.stripe.android.view.CardInputWidget;

/**
 * Created by avikaljain on 12/6/17.
 */

public class PaymentByCardActivity extends BaseActivity {

    public static final String PUBLISHABLE_KEY = "pk_test_cQwLSjOGaHpFdaCK7EguT8oX";
    public Button makePaymentBtn;
    public CardInputWidget mCardInputWidget;
    private ImageView backIv;
    private TextView titleTv;
    private Bundle bundle;
    private String totalAmount;
    private TextView tvPaymentAmount;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_card);
        bundle = getIntent().getExtras();
        if (bundle != null) {
            totalAmount = bundle.getString("totalAmount");
        }
        setUpUI();

    }

    private void setUpUI() {
        titleTv = (TextView) findViewById(R.id.titleTv);
        titleTv.setText(getResources().getString(R.string.payment));
        makePaymentBtn = (Button) findViewById(R.id.makePaymentBtn);
        tvPaymentAmount = (TextView) findViewById(R.id.tvPaymentAmount);
        tvPaymentAmount.setText(AppConstant.CURRENCY_SYMBOL + " " + totalAmount);
        backIv = (ImageView) findViewById(R.id.backIv);

        mCardInputWidget = (CardInputWidget) findViewById(R.id.card_input_widget);

        backIv.setOnClickListener(this);
        makePaymentBtn.setOnClickListener(this);

    }

    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.backIv:
                finish();
                break;
            case R.id.makePaymentBtn:
                makePayment();
                break;
        }
    }

    private void makePayment() {
        showProgressDialog(mContext);
        Card card = mCardInputWidget.getCard();
        if (card == null) {
            // Do not continue token creation.
            hideProgressDialog();
            showToastMsg(mContext, getString(R.string.invalid_card_data));
        } else {
            Stripe stripe = new Stripe(PaymentByCardActivity.this, PUBLISHABLE_KEY);
            stripe.createToken(
                    card,
                    new TokenCallback() {
                        public void onSuccess(Token token) {
                            // Send token to your server
                            Log.e("Token", String.valueOf(token));
                            String tokenId = token.getId();
                            Intent intent = getIntent();
                            intent.putExtra("tokenId", tokenId);
                            setResult(RESULT_OK, intent);
                            hideProgressDialog();
                            finish();
                        }

                        public void onError(Exception error) {
                            // Show localized error message
                            showToastMsg(mContext, getString(R.string.server_error));
                        }
                    }
            );
        }
    }

}
