package com.cdn.techquiq.consumer.model;

import java.io.Serializable;

/**
 * Created by avikaljain on 3/5/17.
 */

public class ReceiveMessageBean implements Serializable {

    public String message;

    public int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMsg_unique_id() {
        return msg_unique_id;
    }

    public void setMsg_unique_id(String msg_unique_id) {
        this.msg_unique_id = msg_unique_id;
    }

    public String msg_unique_id;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    private String service_id;

    public String getService_id() {
        return service_id;
    }

    public void setService_id(String service_id) {
        this.service_id = service_id;
    }

    private String sent_by;

    public String getSent_by() {
        return sent_by;
    }

    public void setSent_by(String sent_by) {
        this.sent_by = sent_by;
    }

    private String sent_to;

    public String getSent_to() {
        return sent_to;
    }

    public void setSent_to(String sent_to) {
        this.sent_to = sent_to;
    }

    private String date_created;

    public String getDate_created() {
        return date_created;
    }

    public void setDate_created(String date_created) {
        this.date_created = date_created;
    }

    private String service_name;

    public String getService_name() {
        return service_name;
    }

    public void setService_name(String service_name) {
        this.service_name = service_name;
    }

    private String merchant_first_name;

    public String getMerchant_first_name() {
        return merchant_first_name;
    }

    public void setMerchant_first_name(String merchant_first_name) {
        this.merchant_first_name = merchant_first_name;
    }

    private String merchant_last_name;

    public String getMerchant_last_name() {
        return merchant_last_name;
    }

    public void setMerchant_last_name(String merchant_last_name) {
        this.merchant_last_name = merchant_last_name;
    }

    public ReceiveMessageBean(String date_created) {
        this.date_created = date_created;
    }

    private String award_status;

    public int getAprove_status() {
        return aprove_status;
    }

    public void setAprove_status(int aprove_status) {
        this.aprove_status = aprove_status;
    }

    private int aprove_status;

    public String getAward_status() {
        return award_status;
    }

    public void setAward_status(String award_status) {
        this.award_status = award_status;
    }

    private long timestamp;

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
}
