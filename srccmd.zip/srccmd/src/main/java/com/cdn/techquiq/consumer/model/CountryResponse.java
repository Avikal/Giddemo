package com.cdn.techquiq.consumer.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by kajalsoni on 30/1/17.
 */

public class CountryResponse extends BaseResponse {

    @SerializedName("Result")
    ArrayList<Country> Result;

    public ArrayList<Country> getResult() {
        return Result;
    }

    public void setResult(ArrayList<Country> result) {
        Result = result;
    }

    public class Country {
        String country_id, country_code, country_name;

        public String getCountry_id() {
            return country_id;
        }

        public void setCountry_id(String country_id) {
            this.country_id = country_id;
        }

        public String getCountry_code() {
            return country_code;
        }

        public void setCountry_code(String country_code) {
            this.country_code = country_code;
        }

        public String getCountry_name() {
            return country_name;
        }

        public void setCountry_name(String country_name) {
            this.country_name = country_name;
        }
    }
}
