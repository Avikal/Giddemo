
package com.cdn.techquiq.consumer.adapter;

/**
 * Created by kajalsoni on 31/1/17.
 */

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.model.PaymentResponse;
import com.marshalchen.ultimaterecyclerview.UltimateRecyclerviewViewHolder;
import com.marshalchen.ultimaterecyclerview.UltimateViewAdapter;

import java.util.ArrayList;
import java.util.List;

public class PaymentAdapter extends UltimateViewAdapter {

    private List<PaymentResponse.PaymentDetails> paymentList;
    Context mContext;
    LayoutInflater mLayoutInflater;

    public PaymentAdapter(Context context, ArrayList<PaymentResponse.PaymentDetails> paymentList) {
        this.mContext = context;
        this.paymentList = paymentList;
        mLayoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (paymentList.size() == position) {
            Log.e("RETURN POSITION", "" + position);
            return;
        }

        final PaymentResponse.PaymentDetails paymentBean = paymentList.get(position);
        if (position < getItemCount() && (customHeaderView != null ? position <= paymentList.size() : position < paymentList.size()) && (customHeaderView != null ? position > 0 : true)) {
            ((ViewHolderPayment) holder).tvName.setText(paymentBean.getName());
            ((ViewHolderPayment) holder).tvOrderId.setText(paymentBean.getOrder_id());
            ((ViewHolderPayment) holder).tvPrice.setText(AppConstant.CURRENCY_SYMBOL + " " + paymentBean.getPrice());
            ((ViewHolderPayment) holder).tvDate.setText(paymentBean.getDate());
            ((ViewHolderPayment) holder).tvTime.setText(paymentBean.getTime());

            ((ViewHolderPayment) holder).mparent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });
        }
    }

    @Override
    public int getAdapterItemCount() {
        return paymentList.size();
    }

    @Override
    public RecyclerView.ViewHolder newFooterHolder(View view) {
        return new UltimateRecyclerviewViewHolder<>(view);
    }

    @Override
    public RecyclerView.ViewHolder newHeaderHolder(View view) {
        return new UltimateRecyclerviewViewHolder<>(view);
    }

    @Override
    public UltimateRecyclerviewViewHolder onCreateViewHolder(ViewGroup parent) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.payment_list_item, parent, false);
        ViewHolderPayment vh = new ViewHolderPayment(v);
        return vh;
    }


    public void insert(String string, int position) {
        insertInternal(paymentList, string, position);
    }

    public void remove(int position) {
        removeInternal(paymentList, position);
    }

    public void clear() {
        clearInternal(paymentList);
    }


    public void swapPositions(int from, int to) {
        swapPositions(paymentList, from, to);
    }


    @Override
    public long generateHeaderId(int position) {
        // URLogs.d("position--" + position + "   " + getItem(position));
        if (getItem(position).length() > 0)
            return getItem(position).charAt(0);
        else return -1;
    }

    @Override
    public RecyclerView.ViewHolder onCreateHeaderViewHolder(ViewGroup parent) {
        return null;
    }

    @Override
    public void onBindHeaderViewHolder(RecyclerView.ViewHolder holder, int position) {

    }


    @Override
    public void onItemMove(int fromPosition, int toPosition) {
        if (fromPosition > 0 && toPosition > 0) {
            swapPositions(fromPosition, toPosition);
            super.onItemMove(fromPosition, toPosition);
        }
    }

    @Override
    public void onItemDismiss(int position) {
        if (position > 0) {
            remove(position);
            notifyDataSetChanged();
            super.onItemDismiss(position);
        }

    }

    public void setOnDragStartListener(OnStartDragListener dragStartListener) {
        mDragStartListener = dragStartListener;

    }

    class ViewHolderPayment extends UltimateRecyclerviewViewHolder {

        public TextView tvName, tvOrderId, tvPrice, tvDate, tvTime;
        View mparent;

        public ViewHolderPayment(View view) {
            super(view);
            mparent = view;
            tvName = (TextView) view.findViewById(R.id.tvName);
            tvOrderId = (TextView) view.findViewById(R.id.tvOrderId);
            tvPrice = (TextView) view.findViewById(R.id.tvPrice);
            tvDate = (TextView) view.findViewById(R.id.tvDate);
            tvTime = (TextView) view.findViewById(R.id.tvTime);

        }

        @Override
        public void onItemSelected() {
            itemView.setBackgroundColor(Color.LTGRAY);
        }

        @Override
        public void onItemClear() {
            itemView.setBackgroundColor(0);
        }
    }

    public String getItem(int position) {
        if (customHeaderView != null)
            position--;

        if (position >= 0 && position < paymentList.size())
            return String.valueOf(paymentList.get(position));
        else return "";
    }

}

