package com.cdn.techquiq.consumer.socket;/*
 * socket.io-java-client IOAcknowledge.java
 *
 * Copyright (c) 2012, Enno Boland
 * PROJECT DESCRIPTION
 * 
 * See LICENSE file for more information
 */


import org.json.JSONArray;

/**
 * The Interface IOAcknowledge.
 */
public interface IOAcknowledge {
	
	/**
	 * Acknowledges home_message socket.io message.
	 *
	 * @param args may be all types which can be serialized by {@link JSONArray#put(Object)}
	 */
	void ack(Object... args);
}
