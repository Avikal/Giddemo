package com.cdn.techquiq.consumer.activity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.custom.Dialog.CountryDialog;
import com.cdn.techquiq.consumer.model.AddAddressResponse;
import com.cdn.techquiq.consumer.model.AddressResponse;
import com.cdn.techquiq.consumer.model.CityResponse;
import com.cdn.techquiq.consumer.model.CountryResponse;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.StateResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;

import java.net.SocketTimeoutException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by avikaljain on 24/3/17.
 */

public class AddAddressActivity extends BaseActivity {

    private String TAG = AddAddressActivity.class.getSimpleName();

    private EditText eTAddressFName;
    private EditText eTAddressLName;
    private EditText eTAddressAdd;
    private EditText eTPostalCode;

    private String selectedCountryId = "";
    private String selectedStateId = "";
    private String selectedCityId = "";

    private TextView titleTv;
    private TextView tVSelectCountry;
    private TextView tVSelectState;
    private TextView tVSelectCity;

    //    private Button buttonAddAddress;
    private ImageView backIv;

    private ImageView ivDone;
    private ImageView ivCancel;

    private Bundle bundle;

    private String screenStatus;
    private String addressId;

    private ArrayList<AddressResponse.AddressDetail> addressList = new ArrayList<>();
    private int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_address);
        mContext = this;
        bundle = getIntent().getExtras();

        if (bundle != null) {
            screenStatus = bundle.getString("status");
            if (screenStatus != null && screenStatus.equalsIgnoreCase("edit")) {
                position = bundle.getInt("position");
                addressList = (ArrayList<AddressResponse.AddressDetail>) getIntent().getSerializableExtra("addressList");
            }
        }
        setUpUI();
    }

    private void setUpUI() {
        titleTv = (TextView) findViewById(R.id.titleTv);
        backIv = (ImageView) findViewById(R.id.backIv);

        ivDone = (ImageView) findViewById(R.id.ivDone);
        ivCancel = (ImageView) findViewById(R.id.ivCancel);

        eTAddressFName = (EditText) findViewById(R.id.eTAddressFName);
        eTAddressLName = (EditText) findViewById(R.id.eTAddressLName);
        eTAddressAdd = (EditText) findViewById(R.id.eTAddressAdd);
        eTPostalCode = (EditText) findViewById(R.id.eTPostalCode);

        tVSelectCountry = (TextView) findViewById(R.id.tvSelectCountry);
        tVSelectState = (TextView) findViewById(R.id.tVSelectState);
        tVSelectCity = (TextView) findViewById(R.id.tVSelectCity);


        backIv.setOnClickListener(this);
        tVSelectCountry.setOnClickListener(this);
        tVSelectState.setOnClickListener(this);
        tVSelectCity.setOnClickListener(this);

        ivDone.setOnClickListener(this);
        ivCancel.setOnClickListener(this);

        eTAddressFName.setOnClickListener(this);
        eTAddressLName.setOnClickListener(this);
        eTAddressAdd.setOnClickListener(this);
        eTPostalCode.setOnClickListener(this);

        eTAddressFName.addTextChangedListener(mTextEditorWatcher);
        eTAddressLName.addTextChangedListener(mTextEditorWatcher);
        eTAddressAdd.addTextChangedListener(mTextEditorWatcherAddress);

        eTAddressFName.setFilters(new InputFilter[]{new InputFilter.LengthFilter(25)});
        eTAddressLName.setFilters(new InputFilter[]{new InputFilter.LengthFilter(25)});
        eTAddressAdd.setFilters(new InputFilter[]{new InputFilter.LengthFilter(150)});
        if (screenStatus != null && screenStatus.equalsIgnoreCase("edit")) {
            titleTv.setText(getResources().getString(R.string.edit_address));
            setEditField();
        } else if (screenStatus != null && screenStatus.equalsIgnoreCase("add")) {
            titleTv.setText(getResources().getString(R.string.add_address));
        }
        /**
         * Open Country picker dialog from the below code
         */
        eTAddressAdd.setOnEditorActionListener(new EditText.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_NEXT) {
                    getCountry();
                    return true; // Focus will do whatever you put in the logic.
                }
                return false;  // Focus will change according to the actionId
            }
        });


        /**
         * Open Country picker dialog from the below code
         */
        eTAddressAdd.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int keyCode, KeyEvent event) {
                if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    getCountry();
                    return true;
                }
                return false;
            }
        });
        checkFocus();

    }

    private void setEditField() {
        addressId = addressList.get(position).getId();
        eTAddressFName.setText(addressList.get(position).getFirstName());
        eTAddressLName.setText(addressList.get(position).getLastName());
        eTAddressAdd.setText(addressList.get(position).getAddress());
        tVSelectCity.setText(addressList.get(position).getCityName());
        tVSelectState.setText(addressList.get(position).getStateName());
        tVSelectCountry.setText(addressList.get(position).getCountryName());
        eTPostalCode.setText(addressList.get(position).getPostalCode());


        selectedCityId = addressList.get(position).getCityId();
        selectedStateId = addressList.get(position).getStateId();
        selectedCountryId = addressList.get(position).getCountryId();
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.backIv:
                finish();
                break;
            case R.id.ivCancel:
                finish();
                break;
            case R.id.ivDone:
                if (isValidate()) {
                    if (screenStatus != null && screenStatus.equalsIgnoreCase("add")) {
                        doAddAddress();
                    } else if (screenStatus != null && screenStatus.equalsIgnoreCase("edit")) {
                        editAddress();
                    }

                }
                break;
            case R.id.tvSelectCountry:
                cursorCheck();
                getCountry();
                break;

            case R.id.tVSelectState:
                cursorCheck();
                getState();
                break;

            case R.id.tVSelectCity:
                cursorCheck();
                getCity();
                break;
            case R.id.eTAddressFName:
                eTAddressFName.setCursorVisible(true);
                break;

            case R.id.eTAddressLName:
                eTAddressLName.setCursorVisible(true);
                break;

            case R.id.eTAddressAdd:
                eTAddressAdd.setCursorVisible(true);
                break;
        }
    }

    private void cursorCheck() {
        Utils.hideKeyBoard(this);
        eTAddressFName.setCursorVisible(false);
        eTAddressLName.setCursorVisible(false);
        eTAddressAdd.setCursorVisible(false);
    }

    private void checkFocus() {

        eTAddressFName.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    Log.d("focus", "focus loosed");
                    // Do whatever you want here
                } else {
                    eTAddressFName.setCursorVisible(true);
                    Log.d("focus", "focused");
                }
            }
        });

        eTAddressLName.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    Log.d("focus", "focus loosed");
                    // Do whatever you want here
                } else {
                    eTAddressLName.setCursorVisible(true);
                    Log.d("focus", "focused");
                }
            }
        });


        eTAddressAdd.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    Log.d("focus", "focus loosed");
                    // Do whatever you want here
                } else {
                    eTAddressAdd.setCursorVisible(true);
                    Log.d("focus", "focused");
                }
            }
        });
    }

    private boolean isValidate() {

        if (eTAddressFName.getText().toString().trim() == null || eTAddressFName.getText().toString().trim().isEmpty() && eTAddressFName.getText().toString().trim().equalsIgnoreCase("")) {
            showToastMsg(mContext, mContext.getString(R.string.enter_first_name));
            return false;
        } else if (eTAddressLName.getText().toString().trim() == null || eTAddressLName.getText().toString().trim().isEmpty() && eTAddressLName.getText().toString().trim().equalsIgnoreCase("")) {
            showToastMsg(mContext, mContext.getString(R.string.enter_last_name));
            return false;
        } else if (eTAddressAdd.getText().toString().trim() == null || eTAddressAdd.getText().toString().trim().isEmpty() && eTAddressAdd.getText().toString().trim().equalsIgnoreCase("")) {
            showToastMsg(mContext, mContext.getString(R.string.enter_address));
            return false;
        } else if (tVSelectCountry.getText().toString().trim() == null || tVSelectCountry.getText().toString().trim().isEmpty() || tVSelectCountry.getText().toString().equalsIgnoreCase(getResources().getString(R.string.country))) {
            showToastMsg(mContext, mContext.getString(R.string.select_country_msg));
            return false;
        } else if (tVSelectState.getText().toString().trim() == null || tVSelectState.getText().toString().trim().isEmpty() || tVSelectState.getText().toString().equalsIgnoreCase(getResources().getString(R.string.region_state))) {
            showToastMsg(mContext, mContext.getString(R.string.select_state_msg));
            return false;
        } else if (tVSelectCity.getText().toString().trim() == null || tVSelectCity.getText().toString().trim().isEmpty() || tVSelectCity.getText().toString().equalsIgnoreCase(getResources().getString(R.string.city))) {
            showToastMsg(mContext, mContext.getString(R.string.select_city_msg));
            return false;
        } else if (eTPostalCode.getText().toString().trim() == null || eTPostalCode.getText().toString().trim().isEmpty()) {
            showToastMsg(mContext, getString(R.string.enter_postal_code));
            return false;
        } else {
            return true;
        }

    }

    private void doAddAddress() {
        showProgressDialog(mContext);
        try {
            final LoginResponse.Users userDetail = Utils.readUserDetail(mContext);
            Call<AddAddressResponse> addAddressRequest = ((TechquiqApplication) mContext
                    .getApplicationContext()).getService().addAddress(
                    userDetail.getUserId(),
                    Utils.getDeviceId(this),
                    AppConstant.FCM_ID,
                    ApiParameter.DEVICE_TYPE_VALUE,
                    eTAddressFName.getText().toString(),
                    eTAddressLName.getText().toString(),
                    selectedCountryId,
                    selectedStateId,
                    selectedCityId,
                    eTAddressAdd.getText().toString(),
                    Integer.parseInt(eTPostalCode.getText().toString())
            );

            Log.e(TAG, "Request : " + addAddressRequest.request().url());

            addAddressRequest.enqueue(new Callback<AddAddressResponse>() {
                @Override
                public void onResponse(Call<AddAddressResponse> call, Response<AddAddressResponse> response) {
                    hideProgressDialog();
                    if (response == null) {
                        showToastMsg(AddAddressActivity.this, getString(R.string.server_error));
                        return;
                    }
                    Log.e(TAG, response.toString());
                    AddAddressResponse addAddressResponse = response.body();
                    int responseStatusCode = addAddressResponse.getResponseStatusCode();
                    if (responseStatusCode == AppConstant.SUCCESS) {
                        if (addAddressResponse.getResponseCode() != null && addAddressResponse.getResponseCode().equalsIgnoreCase("0")) {
                            showToastMsg(AddAddressActivity.this, addAddressResponse.getResponseMessage());
                            return;
                        } else if (addAddressResponse.getResponseCode() != null && addAddressResponse.getResponseCode().equalsIgnoreCase("1")) {
                            showToastMsg(mContext, getResources().getString(R.string.address_add_successful));
                            finish();
                        }
                    } else {
                        showToastMsg(mContext, addAddressResponse.getResponseMessage());
                    }


                }

                @Override
                public void onFailure(Call<AddAddressResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void editAddress() {
        showProgressDialog(mContext);
        try {
            final LoginResponse.Users userDetail = Utils.readUserDetail(mContext);
            Call<AddAddressResponse> editAddressRequest = ((TechquiqApplication) mContext
                    .getApplicationContext()).getService().editAddress(
                    userDetail.getUserId(),
                    addressId,
                    Utils.getDeviceId(this),
                    AppConstant.FCM_ID,
                    ApiParameter.DEVICE_TYPE_VALUE,
                    eTAddressFName.getText().toString(),
                    eTAddressLName.getText().toString(),
                    selectedCountryId,
                    selectedStateId,
                    selectedCityId,
                    eTAddressAdd.getText().toString(), eTPostalCode.getText().toString().trim()
            );

            Log.e(TAG, "Request : " + editAddressRequest.request().url());

            editAddressRequest.enqueue(new Callback<AddAddressResponse>() {
                @Override
                public void onResponse(Call<AddAddressResponse> call, Response<AddAddressResponse> response) {
                    hideProgressDialog();
                    if (response == null) {
                        showToastMsg(AddAddressActivity.this, getString(R.string.server_error));
                        return;
                    }
                    Log.e(TAG, response.toString());
                    AddAddressResponse addAddressResponse = response.body();
                    int responseStatusCode = addAddressResponse.getResponseStatusCode();
                    if (responseStatusCode == AppConstant.PARAM_MISSING) {
                        showToastMsg(mContext, getString(R.string.ws_param_missing));
                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        if (addAddressResponse.getResponseCode() != null && addAddressResponse.getResponseCode().equalsIgnoreCase("0")) {
                            showToastMsg(AddAddressActivity.this, addAddressResponse.getResponseMessage());
                            return;
                        } else if (addAddressResponse.getResponseCode() != null && addAddressResponse.getResponseCode().equalsIgnoreCase("1")) {

                            showToastMsg(mContext, addAddressResponse.getResponseMessage());
                            finish();
                        }
                    } else {
                        showToastMsg(mContext, addAddressResponse.getResponseMessage());
                    }


                }

                @Override
                public void onFailure(Call<AddAddressResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void getCountry() {

        if (!CheckNetworkState.isOnline(mContext)) {
            showToastMsg(mContext, getString(R.string.network_error));
            return;
        }

        showProgressDialog(mContext);

        try {
            Call<CountryResponse> countryRequest = ((TechquiqApplication) mContext
                    .getApplicationContext()).getService().getCountryService(
                    Utils.getDeviceId(mContext),
                    ApiParameter.DEVICE_TYPE_VALUE,
                    AppConstant.FCM_ID);

            countryRequest.enqueue(new Callback<CountryResponse>() {
                @Override
                public void onResponse(Call<CountryResponse> call, Response<CountryResponse> response) {
                    hideProgressDialog();
                    if (response == null) {
                        showToastMsg(AddAddressActivity.this, getString(R.string.server_error));
                        return;
                    }
                    final ArrayList<CountryResponse.Country> countries = response.body().getResult();
                    if (countries != null && countries.size() > 0) {
                        final ArrayList<String> countryData = new ArrayList<String>();
                        for (int i = 0; i < countries.size(); i++) {
                            countryData.add(i, countries.get(i).getCountry_name());
                        }
                        final CountryDialog countryDialog = new CountryDialog(AddAddressActivity.this,
                                mContext.getString(R.string.select_country), countryData);
                        countryDialog.setSearchEnable();
                        countryDialog.show();

                        countryDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialogInterface) {
                                if (countryDialog.getPosition() > -1 && countryDialog.isItemClick()) {
                                    selectedCountryId = countries.get(countryDialog.getPosition()).getCountry_id();
                                    tVSelectCountry.setText(countries.get(countryDialog.getPosition()).getCountry_name());
                                    tVSelectState.setText(mContext.getString(R.string.region_state));
                                    tVSelectCity.setText(mContext.getString(R.string.city));
                                    selectedStateId = "";
                                    selectedCityId = "";
                                    tVSelectCountry.setTextColor(getResources().getColor(R.color.black));

                                }
                            }
                        });
                    }
                }

                @Override
                public void onFailure(Call<CountryResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void getState() {

        if (!CheckNetworkState.isOnline(mContext)) {
            showToastMsg(mContext, getString(R.string.network_error));
            return;
        }

        if (selectedCountryId == null || selectedCountryId.isEmpty()) {
            showToastMsg(mContext, mContext.getString(R.string.select_country_msg));
            return;
        }

        showProgressDialog(mContext);

        try {
            Call<StateResponse> stateRequest = ((TechquiqApplication) mContext
                    .getApplicationContext()).getService().getStateService(
                    selectedCountryId,
                    Utils.getDeviceId(mContext),
                    ApiParameter.DEVICE_TYPE_VALUE,
                    AppConstant.FCM_ID);

            stateRequest.enqueue(new Callback<StateResponse>() {
                @Override
                public void onResponse(Call<StateResponse> call, Response<StateResponse> response) {
                    hideProgressDialog();
                    if (response == null) {
                        showToastMsg(AddAddressActivity.this, getString(R.string.server_error));
                        return;
                    }
                    final ArrayList<StateResponse.State> states = response.body().getResult();
                    if (states != null && states.size() > 0) {
                        ArrayList<String> stateData = new ArrayList<String>();
                        for (int i = 0; i < states.size(); i++) {
                            stateData.add(i, states.get(i).getState_name());
                        }
                        final CountryDialog stateDialog = new CountryDialog(AddAddressActivity.this,
                                mContext.getString(R.string.select_state), stateData);
                        stateDialog.setSearchEnable();
                        stateDialog.show();


                        stateDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialogInterface) {
                                if (stateDialog.getPosition() > -1 && stateDialog.isItemClick()) {
                                    selectedStateId = states.get(stateDialog.getPosition()).getState_id();
                                    tVSelectState.setText(states.get(stateDialog.getPosition()).getState_name());
                                    tVSelectCity.setText(mContext.getString(R.string.city));
                                    selectedCityId = "";
                                    tVSelectState.setTextColor(getResources().getColor(R.color.black));
                                }
                            }
                        });
                    }
                }

                @Override
                public void onFailure(Call<StateResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void getCity() {

        if (!CheckNetworkState.isOnline(mContext)) {
            showToastMsg(mContext, getString(R.string.network_error));
            return;
        }
        if (selectedStateId == null || selectedStateId.isEmpty()) {
            showToastMsg(mContext, getString(R.string.select_state_msg));
            return;
        }


        showProgressDialog(mContext);

        try {
            Call<CityResponse> cityRequest = ((TechquiqApplication) mContext
                    .getApplicationContext()).getService().getCityService(
                    selectedStateId,
                    Utils.getDeviceId(mContext),
                    ApiParameter.DEVICE_TYPE_VALUE,
                    AppConstant.FCM_ID);

            cityRequest.enqueue(new Callback<CityResponse>() {
                @Override
                public void onResponse(Call<CityResponse> call, Response<CityResponse> response) {
                    hideProgressDialog();
                    if (response == null) {
                        showToastMsg(AddAddressActivity.this, getString(R.string.server_error));
                        return;
                    }
                    final ArrayList<CityResponse.City> cities = response.body().getResult();
                    if (cities != null && cities.size() > 0) {
                        ArrayList<String> cityData = new ArrayList<String>();
                        for (int i = 0; i < cities.size(); i++) {
                            cityData.add(i, cities.get(i).getCity_name());
                        }
                        final CountryDialog cityDialog = new CountryDialog(AddAddressActivity.this,
                                mContext.getString(R.string.select_city), cityData);
                        cityDialog.setSearchEnable();
                        cityDialog.show();

                        cityDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialogInterface) {
                                if (cityDialog.getPosition() > -1 && cityDialog.isItemClick()) {
                                    selectedCityId = cities.get(cityDialog.getPosition()).getCity_id();
                                    tVSelectCity.setText(cities.get(cityDialog.getPosition()).getCity_name());
                                    tVSelectCity.setTextColor(getResources().getColor(R.color.black));
                                }
                            }
                        });
                    }
                }

                @Override
                public void onFailure(Call<CityResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private final TextWatcher mTextEditorWatcher = new TextWatcher() {
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        public void afterTextChanged(Editable s) {
            //This sets a textview to the current length
            if (s.length() >= 25) {
                showToastMsg(mContext, mContext.getResources().getString(R.string.error_msg_max));

            }

        }
    };
    private final TextWatcher mTextEditorWatcherAddress = new TextWatcher() {
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        public void afterTextChanged(Editable s) {
            //This sets a textview to the current length
            if (s.length() >= 150) {
                showToastMsg(mContext, mContext.getResources().getString(R.string.error_msg_max_address));
            }
        }
    };

}
