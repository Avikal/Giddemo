package com.cdn.techquiq.consumer.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.activity.ChatActivity;
import com.cdn.techquiq.consumer.activity.UserActivity;
import com.cdn.techquiq.consumer.database.DBHelper;
import com.cdn.techquiq.consumer.model.UserResponse;
import com.marshalchen.ultimaterecyclerview.UltimateRecyclerviewViewHolder;
import com.marshalchen.ultimaterecyclerview.UltimateViewAdapter;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by avikaljain on 7/4/17.
 */

public class UserAdapter extends UltimateViewAdapter {

    private List<UserResponse.UserInfo> userList = new ArrayList<>();
    private List<UserResponse.UserInfo.UserImage> proposalData;
    private Context mContext;
    private DBHelper dbHelper;

    public UserAdapter(Context mContext, List<UserResponse.UserInfo> userList) {
        this.mContext = mContext;
        this.userList = userList;
        dbHelper = DBHelper.getInstance(mContext);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {

        proposalData = userList.get(0).getUserImages();

        if (proposalData.size() == position) {
            Log.e("RETURN POSITION", "" + position);
            return;
        }
        final UserResponse.UserInfo userResponse = userList.get(0);
        if (position < getItemCount() && (customHeaderView != null ? position <= proposalData.size() : position < proposalData.size()) && (customHeaderView != null ? position > 0 : true)) {

            if (proposalData.size() > 0) {
                ((ViewHolderUser) holder).userContainer.setVisibility(View.VISIBLE);
                //holder.tvNoResult.setVisibility(View.GONE);
                Glide.with(mContext).load(proposalData.get(position).getImage()).asBitmap().centerCrop()
                        .placeholder(R.drawable.profile_img)
                        .error(R.drawable.profile_img)
                        .override(100, 100)
                        .into(((ViewHolderUser) holder).circleProfile);

                final String merchantName = proposalData.get(position).getFirst_name() + " " + proposalData.get(position).getLast_name();
                ((ViewHolderUser) holder).tvUserName.setText(merchantName);
                ((ViewHolderUser) holder).userContainer.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ((UserActivity) mContext).stopChatReciever();
                        Intent intent = new Intent(mContext, ChatActivity.class);
                        intent.putExtra("merchantId", proposalData.get(position).getUser_id());
                        intent.putExtra("serviceId", userResponse.getId());
                        intent.putExtra("merchantName", merchantName);
                        intent.putExtra("merchantImage", proposalData.get(position).getImage());
                        intent.putExtra("awardStatus", userResponse.getAwardStatus());
                        intent.putExtra("title", userResponse.getName());
                        intent.putExtra("bidId",proposalData.get(position).getBidId());
                        mContext.startActivity(intent);
                    }
                });

            } else {
                ((ViewHolderUser) holder).userContainer.setVisibility(View.GONE);
            }

            /**
             * below code for show unread message count.
             */
            int unreadMsgCount = dbHelper.getUnReadMessageCountForMerchant(userResponse.getId(), proposalData.get(position).getUser_id());
            if (unreadMsgCount > 0) {
                ((ViewHolderUser) holder).linearMsgRight.setVisibility(View.VISIBLE);
                if (unreadMsgCount > 99) {
                    ((ViewHolderUser) holder).tvMsgCount.setText("" + 99 + "+");
                } else {
                    ((ViewHolderUser) holder).tvMsgCount.setText("" + unreadMsgCount);
                }

            } else {
                ((ViewHolderUser) holder).linearMsgRight.setVisibility(View.GONE);
            }

        }

    }

    @Override
    public int getAdapterItemCount() {
        return userList.get(0).getUserImages().size();
    }

    @Override
    public RecyclerView.ViewHolder newFooterHolder(View view) {
        return new UltimateRecyclerviewViewHolder<>(view);
    }

    @Override
    public RecyclerView.ViewHolder newHeaderHolder(View view) {
        return new UltimateRecyclerviewViewHolder<>(view);
    }

    @Override
    public UltimateRecyclerviewViewHolder onCreateViewHolder(ViewGroup parent) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_user, parent, false);
        ViewHolderUser vh = new ViewHolderUser(v);
        return vh;
    }


    public void insert(String string, int position) {
        insertInternal(proposalData, string, position);
    }

    public void remove(int position) {
        removeInternal(proposalData, position);
    }

    public void clear() {
        clearInternal(proposalData);
    }


    public void swapPositions(int from, int to) {
        swapPositions(proposalData, from, to);
    }


    @Override
    public long generateHeaderId(int position) {
        // URLogs.d("position--" + position + "   " + getItem(position));
        if (getItem(position).length() > 0)
            return getItem(position).charAt(0);
        else return -1;
    }


    @Override
    public RecyclerView.ViewHolder onCreateHeaderViewHolder(ViewGroup parent) {
        return null;
    }

    @Override
    public void onBindHeaderViewHolder(RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    public void onItemMove(int fromPosition, int toPosition) {
        if (fromPosition > 0 && toPosition > 0) {
            swapPositions(fromPosition, toPosition);
            super.onItemMove(fromPosition, toPosition);
        }
    }

    @Override
    public void onItemDismiss(int position) {
        if (position > 0) {
            remove(position);
            notifyDataSetChanged();
            super.onItemDismiss(position);
        }

    }

    public void setOnDragStartListener(OnStartDragListener dragStartListener) {
        mDragStartListener = dragStartListener;

    }

    class ViewHolderUser extends UltimateRecyclerviewViewHolder {

        public TextView tvUserName, tvMsgCount;
        public CircleImageView circleProfile;
        public LinearLayout userContainer;

        LinearLayout linearMsgRight;

        public ViewHolderUser(View view) {
            super(view);
            circleProfile = (CircleImageView) view.findViewById(R.id.circleProfile);
            tvUserName = (TextView) view.findViewById(R.id.tvUserName);
            userContainer = (LinearLayout) view.findViewById(R.id.userContainer);
            tvMsgCount = (TextView) view.findViewById(R.id.tvMsgCount);
            linearMsgRight = (LinearLayout) view.findViewById(R.id.linearMsgRight);
        }

        @Override
        public void onItemSelected() {
            itemView.setBackgroundColor(Color.LTGRAY);
        }

        @Override
        public void onItemClear() {
            itemView.setBackgroundColor(0);
        }
    }

    public String getItem(int position) {
        if (customHeaderView != null)
            position--;

        if (position >= 0 && position < proposalData.size())
            return String.valueOf(proposalData.get(position));
        else return "";
    }
}

