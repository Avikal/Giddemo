package com.cdn.techquiq.consumer.Utils;

/**
 * Created by akshaysoni on 5/5/16.
 */


import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerializationUtils {
    /**
     * @param obj - object to serialize to a byte array
     * @return byte array containing the serialized obj
     */
    public static byte[] serialize(Object obj) {
        byte[] result = null;
        ByteArrayOutputStream fos = null;

        try {
            fos = new ByteArrayOutputStream();
            ObjectOutputStream o = new ObjectOutputStream(fos);
            o.writeObject(obj);
            result = fos.toByteArray();
        } catch (IOException e) {
            System.err.println(e);
        } finally {
            try {
                fos.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return result;
    }


    /**
     * @param arr - the byte array that holds the serialized object
     * @return the deserialize object
     */
    public static Object deserialize(byte[] arr) {
        InputStream fis = null;

        try {
            fis = new ByteArrayInputStream(arr);
            ObjectInputStream o = new ObjectInputStream(fis);
            return o.readObject();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                fis.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return null;
    }

    /**
     * @param obj - object to be cloned
     * @return a clone of obj
     */
    @SuppressWarnings("unchecked")
    public static <T> T cloneObject(T obj) {
        return (T) deserialize(serialize(obj));
    }
}