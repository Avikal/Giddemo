package com.cdn.techquiq.consumer.activity;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.adapter.OpenDetailAdapter;
import com.cdn.techquiq.consumer.adapter.ServiceViewAdapter;
import com.cdn.techquiq.consumer.model.DeleteServiceResponse;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.ServiceImage;
import com.cdn.techquiq.consumer.model.ServiceResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;
import com.google.gson.Gson;

import java.net.SocketTimeoutException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by avikaljain on 5/4/17.
 */

public class OpenDetailActivity extends BaseActivity {

    private String TAG = OpenDetailActivity.class.getSimpleName();
    private RecyclerView recyclerView;
    private OpenDetailAdapter openDetailAdapter;
    private ArrayList<ServiceResponse.ServiceDetail> proposalDetail = new ArrayList<>();

    private ImageView backIv;
    private TextView titleTv;

    private TextView tVOpenTitle;
    private TextView tVOpenCategories;
    private TextView tVOpenComplainDes;
    private TextView tvOpenDate;
    private TextView tvView;
    private String serviceId;
    private Bundle bundle;

    private RecyclerView serviceList;
    private ArrayList<ServiceImage> serviceImageArrayList = new ArrayList<>();
    private ServiceViewAdapter serviceAdapter;

    public TextView tvPaymentND;
    private ScrollView scrollMain;

    private LinearLayout tvServiceDelete;

    private String title, description;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open_detail);
        bundle = getIntent().getExtras();

        if (bundle != null) {
            serviceId = bundle.getString("id");
        }
        setUpUi();
        serviceList = (RecyclerView) findViewById(R.id.serviceList);
        serviceAdapter = new ServiceViewAdapter(this, serviceImageArrayList);
        serviceList.setAdapter(serviceAdapter);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        serviceList.setLayoutManager(layoutManager);
        registerReceiver(broadcast_reciever, new IntentFilter("finish_activity"));

    }

    private void setUpUi() {
        titleTv = (TextView) findViewById(R.id.titleTv);
        tVOpenTitle = (TextView) findViewById(R.id.tvOpenTitle);
        tVOpenCategories = (TextView) findViewById(R.id.tVOpenCategories);
        tVOpenComplainDes = (TextView) findViewById(R.id.tVOpenComplainDes);
        tvOpenDate = (TextView) findViewById(R.id.tvOpenDate);
        tvPaymentND = (TextView) findViewById(R.id.tvPaymentND);
        backIv = (ImageView) findViewById(R.id.backIv);
        tvServiceDelete = (LinearLayout) findViewById(R.id.tvServiceDelete);

        recyclerView = (RecyclerView) findViewById(R.id.openDetailList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        backIv.setOnClickListener(this);
        tvServiceDelete.setOnClickListener(this);
        scrollMain = (ScrollView) findViewById(R.id.scrollMain);
        tvView = (TextView) findViewById(R.id.tvView);
        tvView.setVisibility(View.GONE);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.backIv:
                onBackPressed();
                break;
            case R.id.tvServiceDelete:
                conformationDialog();
                break;

        }
    }

    private void conformationDialog() {
        new AlertDialog.Builder(mContext)
                .setTitle(mContext.getString(R.string.app_name))
                .setMessage(mContext.getString(R.string.delete_open_service_alert))
                .setPositiveButton(getString(R.string.yes), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        deleteService();
                    }
                })
                .setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .setIcon(R.drawable.ic_launcher)
                .show();
    }

    private void deleteService() {
        if (!CheckNetworkState.isOnline(this)) {
            showToastMsg(this, getString(R.string.network_error));
            return;
        }
        if (!showProgressDialog(this)) {
            return;
        }
        showProgressDialog(this);
        try {
            final LoginResponse.Users userDetail = Utils.readUserDetail(this);
            Log.e(TAG, String.valueOf(userDetail.getUserId()));
            Call<DeleteServiceResponse> deleteServiceRequest = ((TechquiqApplication) getApplicationContext())
                    .getService().deleteServices(userDetail.getUserId(),
                            Utils.getDeviceId(this),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID,
                            Integer.parseInt(serviceId)
                    );

            Log.e(TAG, "Request Delete Service: " + deleteServiceRequest.request().url());

            deleteServiceRequest.enqueue(new Callback<DeleteServiceResponse>() {
                @Override
                public void onResponse(Call<DeleteServiceResponse> call, Response<DeleteServiceResponse> response) {
                    hideProgressDialog();
                    if (response == null) {
                        return;
                    }
                    Log.e(TAG, "Response Delete Service: " + new Gson().toJson(response.body()));
                    Log.e(TAG, response.toString());
                    DeleteServiceResponse deleteResponse = response.body();

                    if (deleteResponse.getResponseCode() != null && deleteResponse.getResponseCode().equalsIgnoreCase("0")) {
                        showToastMsg(mContext, deleteResponse.getResponseMessage());
                    } else if (deleteResponse.getResponseCode() != null && deleteResponse.getResponseCode().equalsIgnoreCase("1")) {
                        showToastMsg(mContext, getResources().getString(R.string.ws_service_deleted));
                        setResult(Activity.RESULT_OK);
                        finish();
                    }
                }


                @Override
                public void onFailure(Call<DeleteServiceResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void serviceDetail() {
        if (!CheckNetworkState.isOnline(this)) {
            showToastMsg(this, getString(R.string.network_error));
            setUpErrorMsg(getResources().getString(R.string.network_error));
            return;
        }
        if (!showProgressDialog(this)) {
            setUpErrorMsg(getResources().getString(R.string.network_error));
            return;
        }
        showProgressDialog(this);
        try {
            final LoginResponse.Users userDetail = Utils.readUserDetail(this);
            Log.e(TAG, String.valueOf(userDetail.getUserId()));
            Call<ServiceResponse> myServiceProductRequest = ((TechquiqApplication) getApplicationContext())
                    .getService().getServiceList(userDetail.getUserId(),
                            Utils.getDeviceId(this),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID,
                            10,
                            0, 0,
                            serviceId,
                            null);

            Log.e(TAG, "Request : " + myServiceProductRequest.request().url());


            myServiceProductRequest.enqueue(new Callback<ServiceResponse>() {
                @Override
                public void onResponse(Call<ServiceResponse> call, Response<ServiceResponse> response) {
                    hideProgressDialog();
                    if (response == null) {
                        showToastMsg(mContext, getString(R.string.server_error));
                        return;
                    }
                    Log.e(TAG, "Response : " + new Gson().toJson(response.body()));
                    Log.e(TAG, response.toString());
                    ServiceResponse serviceResponse = response.body();
                    int responseStatusCode = serviceResponse.getResponseStatusCode();
                    if (responseStatusCode == AppConstant.PARAM_MISSING) {
                        showToastMsg(mContext, getString(R.string.ws_param_missing));
                    } else if (responseStatusCode == AppConstant.UNKNOWN_ERROR) {
                        setUpErrorMsg(getResources().getString(R.string.ws_unkonwn_error));
                    } else if (responseStatusCode == AppConstant.NO_DATA_FOUND) {
                        setUpErrorMsg(getResources().getString(R.string.ws_no_open_data_found));
                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        if (serviceResponse.getResponseCode() != null && serviceResponse.getResponseCode().equalsIgnoreCase("0")) {
                            setUpErrorMsg(getResources().getString(R.string.ws_no_open_data_found));
                            return;
                        } else if (serviceResponse.getResponseCode() != null && serviceResponse.getResponseCode().equalsIgnoreCase("1")) {
                            tvPaymentND.setVisibility(View.GONE);
                            tvView.setVisibility(View.VISIBLE);
                            scrollMain.setVisibility(View.VISIBLE);
                            tvServiceDelete.setVisibility(View.VISIBLE);
                            ArrayList<ServiceResponse.ServiceDetail> serviceList = serviceResponse.getServiceDetails();

                            for (int i = 0; i < serviceList.size(); i++) {

                                title = Utils.decodeString(serviceList.get(i).getName());
                                description = Utils.decodeString(serviceList.get(i).getDescription());
                                titleTv.setText(title);
                                tVOpenTitle.setText(title);
                                tVOpenCategories.setText(serviceList.get(i).getServiceCategory() + " > " +
                                        serviceList.get(i).getServiceSubCategory());
                                tVOpenComplainDes.setText(description);
                                tvOpenDate.setText(serviceList.get(i).getDate());
                                ArrayList<ServiceResponse.ServiceDetail.SProductImage> productImages = serviceList.get(i).getsProductImages();
                                proposalDetail = serviceList;
                                for (int j = 0; j < productImages.size(); j++) {
                                    if (productImages != null && productImages.size() > 0) {
                                        ServiceImage serviceImage = new ServiceImage();
                                        serviceImage.setFileName(productImages.get(j).getImage());
                                        serviceImageArrayList.add(serviceImage);
                                    }
                                }
                                ArrayList<ServiceResponse.ServiceDetail.ServiceProposalData> proposalData = serviceList.get(i).getServiceProposal();
                                if (serviceList.size() > 0) {
                                    serviceAdapter.notifyDataSetChanged();
                                    if (proposalDetail.size() > 0) {
                                        openDetailAdapter = new OpenDetailAdapter(OpenDetailActivity.this, proposalDetail, proposalData);
                                        recyclerView.setAdapter(openDetailAdapter);
                                        recyclerView.setLayoutManager(new LinearLayoutManager(OpenDetailActivity.this));

                                    }
                                }
                            }

                        }
                    } else {
                        showToastMsg(mContext, serviceResponse.getResponseMessage());
                    }


                }

                @Override
                public void onFailure(Call<ServiceResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        setUpErrorMsg(getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    setUpErrorMsg(getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        setResult(Activity.RESULT_OK);
        finish();
    }

    @Override
    public void onResume() {
        super.onResume();
        serviceDetail();
    }

    private void setUpErrorMsg(String msg) {
        scrollMain.setVisibility(View.GONE);
        tvView.setVisibility(View.GONE);
        tvPaymentND.setText(msg);
        tvPaymentND.setVisibility(View.VISIBLE);
        tvServiceDelete.setVisibility(View.GONE);
        titleTv.setText(getResources().getString(R.string.txt_services_title));

    }

    BroadcastReceiver broadcast_reciever = new BroadcastReceiver() {

        @Override
        public void onReceive(Context arg0, Intent intent) {
            String action = intent.getAction();
            if (action.equals("finish_activity")) {
                finish();
                // DO WHATEVER YOU WANT.
            }
        }
    };

    public void onDestroy() {
        super.onDestroy();
        unregisterReceiver(broadcast_reciever);
    }
}
