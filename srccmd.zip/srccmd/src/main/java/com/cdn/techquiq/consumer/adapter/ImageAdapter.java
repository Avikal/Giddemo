package com.cdn.techquiq.consumer.adapter;

import android.content.Context;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.cdn.techquiq.consumer.R;

/**
 * Created by akshaysoni on 29/1/16.
 */
public class ImageAdapter extends PagerAdapter {

    private LayoutInflater inflater = null;


    public ImageAdapter(Context c) {
        inflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return 10;
    }


    public long getItemId(int position) {
        return position;
    }

    @Override
    public Object instantiateItem(ViewGroup parent, int position) {
        View convertView = inflater.inflate(R.layout.image_item, parent, false);
        ((ViewGroup) parent).addView(convertView, 0);
        return convertView;
    }

    @Override
    public void destroyItem(View arg0, int arg1, Object arg2) {
        ((ViewPager) arg0).removeView((View) arg2);
    }

    @Override
    public boolean isViewFromObject(View arg0, Object arg1) {
        return arg0 == ((View) arg1);
    }

    @Override
    public Parcelable saveState() {
        return null;
    }

}