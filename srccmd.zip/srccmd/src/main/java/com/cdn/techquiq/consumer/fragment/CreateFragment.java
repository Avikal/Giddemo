package com.cdn.techquiq.consumer.fragment;

import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.activity.AddressActivity;
import com.cdn.techquiq.consumer.activity.MainActivity;
import com.cdn.techquiq.consumer.adapter.CreateImageAdapter;
import com.cdn.techquiq.consumer.custom.Dialog.CountryDialog;
import com.cdn.techquiq.consumer.model.AddressResponse;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.ServiceAddResponse;
import com.cdn.techquiq.consumer.model.ServiceCategoriesResponse;
import com.cdn.techquiq.consumer.model.ServiceImage;
import com.cdn.techquiq.consumer.model.SubCategoriesResponse;
import com.cdn.techquiq.consumer.model.UrlResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;
import com.google.gson.Gson;
import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Date;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by avikaljain on 4/4/17.
 */

public class CreateFragment extends BaseFragment {

    private static final String TAG = CreateFragment.class.getSimpleName();

    private EditText eTSubject;
    private EditText eTDescription;

    private TextView tvCategories;
    private TextView tvSubCategories;
    private TextView tVSubmit;

    public static int addedImageCount = 0;
    public static int REQUEST_FOR_ADDRESS = 199;

    private Uri fileUri;

    private String selectCategoriesId;
    private String selectSubcategoryId;

    MultipartBody.Part body[];
    private String pickAddress;
    public TextView tvPickAddressDetail;
    private LinearLayout llPickAddressContainer;

    private ServiceImage serviceImage;
    private CreateImageAdapter createAdapter;
    private RecyclerView createServiceList;
    private ArrayList<ServiceImage> serviceImageArrayList;
    private View rootView;
    private RelativeLayout relativeAddImage;

    private TextView tvHelp;
    private WebView webViewHelp;
    private ProgressDialog progressDialog;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_create, container, false);

        setUpUI(rootView);

        return rootView;
    }

    private void setUpUI(View rootView) {
        serviceImageArrayList = new ArrayList<>();
        eTSubject = (EditText) rootView.findViewById(R.id.etSubject);
        eTDescription = (EditText) rootView.findViewById(R.id.eTDescription);

        tvCategories = (TextView) rootView.findViewById(R.id.tvCategories);
        tvSubCategories = (TextView) rootView.findViewById(R.id.tvSubCategories);
        tVSubmit = (TextView) rootView.findViewById(R.id.tVSubmit);
        tvPickAddressDetail = (TextView) rootView.findViewById(R.id.tvPickAddressDetail);
        createServiceList = (RecyclerView) rootView.findViewById(R.id.createServiceList);
        llPickAddressContainer = (LinearLayout) rootView.findViewById(R.id.llPickAddressContainer);
        addedImageCount = 0;
        relativeAddImage = (RelativeLayout) rootView.findViewById(R.id.relativeAddImage);
        tvCategories.setOnClickListener(this);
        tvSubCategories.setOnClickListener(this);
        tVSubmit.setOnClickListener(this);
        relativeAddImage.setOnClickListener(this);
        llPickAddressContainer.setOnClickListener(this);
        eTDescription.setOnClickListener(this);
        eTSubject.setOnClickListener(this);
        tvHelp = (TextView) rootView.findViewById(R.id.tvHelp);
        tvHelp.setOnClickListener(this);
        setImageAdapter();
        checkFocus();
        eTDescription.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {

                v.getParent().requestDisallowInterceptTouchEvent(true);
                switch (event.getAction() & MotionEvent.ACTION_MASK) {
                    case MotionEvent.ACTION_UP:
                        v.getParent().requestDisallowInterceptTouchEvent(false);
                        break;
                }
                return false;
            }
        });
    }

    public void topAndBelowTab() {
        if (getActivity() != null) {
            ((MainActivity) getActivity()).hideBackBtn(true);
            ((MainActivity) getActivity()).hideCartButton(true);
            ((MainActivity) getActivity()).hideSearchButton(true);
            ((MainActivity) getActivity()).hideSettingButton(true);
            ((MainActivity) getActivity()).hideBelowTabBar(false);
        }

    }

    public void getShippingAddress() {

        if (!CheckNetworkState.isOnline(getActivity())) {
            if (getActivity() != null) {
                showToastMsg(getActivity(), getActivity().getString(R.string.network_error));
                return;
            }

        }

        showProgressDialog(getActivity());

        try {
            final LoginResponse.Users userDetail = Utils.readUserDetail(getActivity());
            Call<AddressResponse> shippingAddressRequest =
                    ((TechquiqApplication) getActivity().getApplicationContext())
                            .getService().getShippingAddress(
                            userDetail.getUserId(),
                            Utils.getDeviceId(getActivity()),
                            AppConstant.FCM_ID,
                            ApiParameter.DEVICE_TYPE_VALUE);

            Log.e(TAG, "Request : " + shippingAddressRequest.request().url());

            shippingAddressRequest.enqueue(new Callback<AddressResponse>() {
                @Override
                public void onResponse(Call<AddressResponse> call, Response<AddressResponse> response) {
                    hideProgressDialog();
                    Log.e(TAG, "Response : " + new Gson().toJson(response.body()));
                    Log.e(TAG, "Response Address : " + response.toString());
                    AddressResponse registrationResponse = response.body();
                    if (registrationResponse == null) {
                        showToastMsg(getContext(), getString(R.string.server_error));
                        return;
                    }
                    if (registrationResponse.getResponseCode() != null && registrationResponse.getResponseCode().equalsIgnoreCase("0")) {
                        showToastMsg(getActivity(), response.body().getResponseMessage());
                        return;
                    } else if (registrationResponse.getResponseCode() != null && registrationResponse.getResponseCode().equalsIgnoreCase("1")) {
                        ArrayList<AddressResponse.AddressDetail> shippingResult = registrationResponse.getAddressDetail();
                        for (int i = 0; i < shippingResult.size(); i++) {
                            if (shippingResult.get(i).getAddressType().equalsIgnoreCase("1")) {
                                pickAddress = shippingResult.get(i).getAddress();
                                String city = shippingResult.get(i).getCityName();
                                String state = shippingResult.get(i).getStateName();
                                String country = shippingResult.get(i).getCountryName();
                                String postalCode = shippingResult.get(i).getPostalCode();
                                tvPickAddressDetail.setText(pickAddress + ", " + city + ", " + state + ", " + country + ", " + postalCode);
                                Log.e(TAG, "Address Dara : " + pickAddress);
                            }
                        }
                    }

                }

                @Override
                public void onFailure(Call<AddressResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(getContext(), getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(getActivity(), getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.relativeAddImage:
                checkCursor();
                checkPermission();
                break;
            case R.id.tvCategories:
                checkCursor();
                getCategories();
                break;
            case R.id.tvSubCategories:
                checkCursor();
                if (tvCategories.getText().toString().equalsIgnoreCase(getResources().getString(R.string.category))) {
                    showToastMsg(getActivity(), getResources().getString(R.string.select_category_first));
                } else {
                    getSubCategory();
                }
                break;
            case R.id.tVSubmit:
                checkCursor();
                submitData();
                break;
            case R.id.llPickAddressContainer:

                if (!CheckNetworkState.isOnline(getActivity())) {
                    showToastMsg(getActivity(), getActivity().getString(R.string.network_error));
                    return;
                }

                checkCursor();
                Intent intent = new Intent(getActivity(), AddressActivity.class);
                startActivityForResult(intent, REQUEST_FOR_ADDRESS);
                break;

            case R.id.etSubject:
                eTSubject.setCursorVisible(true);
                break;
            case R.id.eTDescription:
                eTDescription.setCursorVisible(true);
                break;
            case R.id.tvHelp:
                helpDialog();
                break;
        }
    }

    private void helpDialog() {
        try {
            final Dialog dialog = new Dialog(getActivity());
            View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_help, null);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(view);
            TextView tvClose = (TextView) view.findViewById(R.id.tvClose);
            tvClose.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
            try {
                webViewHelp = (WebView) view.findViewById(R.id.webViewHelp);
                webViewHelp.setWebViewClient(new MyBrowser());
                webViewHelp.getSettings().setLoadsImagesAutomatically(true);
                webViewHelp.getSettings().setJavaScriptEnabled(true);
                webViewHelp.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
                progressDialog = new ProgressDialog(getContext(),
                        R.style.AppTheme_Dark_Dialog);
                progressDialog.setIndeterminate(true);
                progressDialog.setMessage("Loading...");
                progressDialog.show();
                webViewHelp.loadUrl(UrlResponse.getHelp());


            } catch (Exception e) {

            }
            DisplayMetrics metrics = getContext().getResources().getDisplayMetrics();
            int width = metrics.widthPixels;
            final int height1 = metrics.heightPixels;
            dialog.getWindow().setLayout((6 * width) / 7, (4 * height1) / 5);
            dialog.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private class MyBrowser extends WebViewClient {
        boolean timeout;

        public MyBrowser() {
            timeout = true;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            // TODO Auto-generated method stub
            super.onPageStarted(view, url, favicon);
            progressDialog.show();
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
//            progressBar.setVisibility(View.VISIBLE);
            view.loadUrl(url);
            return true;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            // TODO Auto-generated method stub
            super.onPageFinished(view, url);
            if (progressDialog.isShowing()) {
                progressDialog.dismiss();
            }
        }

    }

    private void checkCursor() {
        Utils.hideKeyBoard(getActivity());
        eTSubject.setCursorVisible(false);
        eTDescription.setCursorVisible(false);
    }

    private void checkFocus() {
        eTSubject.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {

                } else {
                    eTSubject.setCursorVisible(true);
                }
            }
        });
        eTDescription.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {

                } else {
                    eTDescription.setCursorVisible(true);
                }
            }
        });
    }

    private void getCategories() {

        if (!CheckNetworkState.isOnline(getActivity())) {
            showToastMsg(getActivity(), getActivity().getString(R.string.network_error));
            return;
        }

        showProgressDialog(getActivity());

        try {
            final LoginResponse.Users userDetail = Utils.readUserDetail(getActivity());
            Call<ServiceCategoriesResponse> serviceCategories = ((TechquiqApplication) getActivity()
                    .getApplicationContext()).getService().getServiceCategories(
                    userDetail.getUserId(),
                    Utils.getDeviceId(getActivity()),
                    ApiParameter.DEVICE_TYPE_VALUE,
                    AppConstant.FCM_ID);
            Log.e(TAG, "Categories Request : " + serviceCategories.request().url());
            serviceCategories.enqueue(new Callback<ServiceCategoriesResponse>() {
                @Override
                public void onResponse(Call<ServiceCategoriesResponse> call, Response<ServiceCategoriesResponse> response) {
                    hideProgressDialog();
                    Log.e(TAG, "Categories Response : " + new Gson().toJson(response.body()));
                    Log.e(TAG, "Response Categories :" + response.toString());

                    if (response == null) {
                        showToastMsg(getContext(), getString(R.string.server_error));
                        return;
                    }
                    final ArrayList<ServiceCategoriesResponse.ServiceCategories> categories = response.body().getCategoriesList();
                    if (categories == null) {
                        showToastMsg(getContext(), getString(R.string.server_error));
                        return;
                    }
                    if (categories != null && categories.size() > 0) {
                        final ArrayList<String> categoryData = new ArrayList<String>();

                        for (int i = 0; i < categories.size(); i++) {
                            categoryData.add(i, categories.get(i).getName());
                        }
                        final CountryDialog countryDialog = new CountryDialog(getActivity(),
                                getActivity().getString(R.string.category), categoryData);
                        countryDialog.setSearchEnable();
                        countryDialog.show();

                        countryDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialogInterface) {
                                if (countryDialog.getPosition() > -1 && countryDialog.isItemClick()) {
                                    selectCategoriesId = categories.get(countryDialog.getPosition()).getId();

                                    tvCategories.setText(categories.get(countryDialog.getPosition()).getName());
                                    tvSubCategories.setText(getActivity().getString(R.string.sub_category));
                                    selectSubcategoryId = "";
                                }
                            }
                        });
                    }
                }

                @Override
                public void onFailure(Call<ServiceCategoriesResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(getContext(), getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(getActivity(), getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void getSubCategory() {

        if (!CheckNetworkState.isOnline(getActivity())) {
            showToastMsg(getActivity(), getActivity().getString(R.string.network_error));
            return;
        }

        if (selectCategoriesId == null || selectCategoriesId.isEmpty()) {
            return;
        }

        showProgressDialog(getActivity());

        try {
            final LoginResponse.Users userDetail = Utils.readUserDetail(getActivity());

            final Call<SubCategoriesResponse> serviceCategories = ((TechquiqApplication) getActivity()
                    .getApplicationContext()).getService().getSubCategories(
                    selectCategoriesId,
                    userDetail.getUserId(),
                    Utils.getDeviceId(getActivity()),
                    ApiParameter.DEVICE_TYPE_VALUE,
                    AppConstant.FCM_ID);

            Log.e(TAG, "Categories Request : " + serviceCategories.request().url());

            serviceCategories.enqueue(new Callback<SubCategoriesResponse>() {
                @Override
                public void onResponse(Call<SubCategoriesResponse> call, Response<SubCategoriesResponse> response) {
                    hideProgressDialog();
                    Log.e(TAG, "SubCategories Response : " + new Gson().toJson(response.body()));
                    Log.e(TAG, "Response Categories : " + response.toString());
                    if (response == null) {
                        showToastMsg(getContext(), getString(R.string.server_error));
                        return;
                    }
                    SubCategoriesResponse subCategoriesResponse = response.body();

                    if (subCategoriesResponse == null) {
                        showToastMsg(getContext(), getString(R.string.server_error));
                        return;
                    }
                    if (subCategoriesResponse.getResponseCode().equalsIgnoreCase("0")) {
                        showToastMsg(getActivity(), subCategoriesResponse.getResponseMessage());
                    } else {
                        final ArrayList<SubCategoriesResponse.SubCategory> subCategories = response.body().getSubCategoriesList();

                        if (subCategories != null && subCategories.size() > 0) {
                            final ArrayList<String> categoryData = new ArrayList<String>();

                            for (int i = 0; i < subCategories.size(); i++) {
                                categoryData.add(i, subCategories.get(i).getName());
                            }
                            final CountryDialog countryDialog = new CountryDialog(getActivity(),
                                    getActivity().getString(R.string.sub_category), categoryData);
                            countryDialog.setSearchEnable();
                            countryDialog.show();

                            countryDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                                @Override
                                public void onDismiss(DialogInterface dialogInterface) {
                                    if (countryDialog.getPosition() > -1 && countryDialog.isItemClick()) {
                                        selectSubcategoryId = subCategories.get(countryDialog.getPosition()).getId();
                                        tvSubCategories.setText(subCategories.get(countryDialog.getPosition()).getName());
                                    }
                                }
                            });
                        }
                    }
                }

                @Override
                public void onFailure(Call<SubCategoriesResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(getContext(), getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(getActivity(), getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void submitData() {
        try {

            if (!CheckNetworkState.isOnline(getActivity())) {
                showToastMsg(getActivity(), getActivity().getString(R.string.network_error));
                return;
            }

            if (!isValidate()) {
                return;
            }

            if (!showProgressDialog(getActivity())) {
                return;
            }

            final LoginResponse.Users userDetail = Utils.readUserDetail(getActivity());

            String subjectStr = Utils.encodeString(eTSubject.getText().toString().trim());
            String descriptionStr = Utils.encodeString(eTDescription.getText().toString().trim());

            MediaType mediaType = MediaType.parse("text/plain");

            RequestBody userId = RequestBody.create(mediaType, "" + userDetail.getUserId());
            RequestBody deviceId = RequestBody.create(mediaType, "" + Utils.getDeviceId(getActivity()));
            RequestBody deviceToken = RequestBody.create(mediaType, "" + ApiParameter.DEVICE_TYPE_VALUE);
            RequestBody deviceType = RequestBody.create(mediaType, "" + AppConstant.FCM_ID);
            RequestBody subject = RequestBody.create(mediaType, "" + subjectStr);
            RequestBody categoryId = RequestBody.create(mediaType, "" + selectCategoriesId);
            RequestBody subCategoryId = RequestBody.create(mediaType, "" + selectSubcategoryId);
            RequestBody description = RequestBody.create(mediaType, "" + descriptionStr);

            RequestBody pickup_address = RequestBody.create(mediaType, "" + tvPickAddressDetail.getText().toString());

            Call<ServiceAddResponse> serviceAdd;

            imageArray();

            Log.e(TAG, "Length : " + String.valueOf(body.length));

            serviceAdd = ((TechquiqApplication) getActivity().getApplicationContext())
                    .getService().addService(userId, deviceId, deviceToken, deviceType,
                            subject, categoryId, subCategoryId, description, pickup_address, body);

            Log.e(TAG, "Add Service Request : " + serviceAdd.request().url());

            serviceAdd.enqueue(new Callback<ServiceAddResponse>() {
                @Override
                public void onResponse(Call<ServiceAddResponse> call, Response<ServiceAddResponse> response) {
                    hideProgressDialog();

                    Log.e(TAG, "Add Service Response : " + new Gson().toJson(response.body()));

                    if (response == null) {
                        showToastMsg(getContext(), getString(R.string.server_error));
                        return;
                    }

                    ServiceAddResponse serviceAddResponse = response.body();
                    if (serviceAddResponse == null) {
                        showToastMsg(getContext(), getString(R.string.server_error));
                        return;
                    }
                    int responseStatusCode = serviceAddResponse.getResponseStatusCode();

                    if (responseStatusCode == AppConstant.UNKNOWN_ERROR) {
                        showToastMsg(getContext(), getString(R.string.ws_unkonwn_error));
                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        clearPage();
                        showToastMsg(getActivity(), getString(R.string.ws_service_created));
                        addedImageCount = 0;
                        checkImageCount();
                    } else {
                        showToastMsg(getContext(), serviceAddResponse.getResponseMessage());
                    }
                }

                @Override
                public void onFailure(Call<ServiceAddResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(getContext(), getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(getActivity(), getResources().getString(R.string.server_error));
                    Log.e(TAG, t.getMessage());
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void clearPage() {
        if (eTDescription != null)
            eTDescription.setText("");

        if (eTSubject != null)
            eTSubject.setText("");

        if (tvCategories != null)
            tvCategories.setText(getResources().getString(R.string.category));

        if (tvSubCategories != null)
            tvSubCategories.setText(getResources().getString(R.string.sub_category));

        serviceImageArrayList = new ArrayList<>();
        setImageAdapter();
    }


    private void setImageAdapter() {
        if (createServiceList != null) {
            createAdapter = new CreateImageAdapter(getActivity(), serviceImageArrayList, this);
            createServiceList.setAdapter(createAdapter);
            LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
            createServiceList.setLayoutManager(layoutManager);
        }
    }

    private boolean isValidate() {
        if (eTSubject.getText().toString().trim() == null || eTSubject.getText().toString().trim().isEmpty() || eTSubject.getText().toString().trim().equalsIgnoreCase("")) {
            showToastMsg(getActivity(), getResources().getString(R.string.please_enter_subject));
            return false;
        } else if (selectCategoriesId == null || selectCategoriesId.isEmpty()) {
            showToastMsg(getActivity(), getResources().getString(R.string.please_select_category));
            return false;
        } else if (selectSubcategoryId == null || selectSubcategoryId.isEmpty()) {
            showToastMsg(getActivity(), getResources().getString(R.string.please_select_sub_category));
            return false;
        } else if (eTDescription.getText().toString().trim() == null || eTDescription.getText().toString().trim().isEmpty() || eTDescription.getText().toString().trim().equalsIgnoreCase("")) {
            showToastMsg(getActivity(), getResources().getString(R.string.please_select_description));
            return false;
        } else {
            return true;
        }


    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Bitmap bitmap = null;

        if (requestCode == CropImage.PICK_IMAGE_CHOOSER_REQUEST_CODE && resultCode == getActivity().RESULT_OK) {
            Uri imageUri = CropImage.getPickImageResultUri(getContext(), data);
            CropImage.activity(imageUri)
                    .setAutoZoomEnabled(false)
                    .setInitialCropWindowPaddingRatio(0)
                    .setRequestedSize(500, 500)
                    .setGuidelines(CropImageView.Guidelines.ON)
                    .start(getContext(), this);
        } else if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE && resultCode == getActivity().RESULT_OK) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);

            try {
                fileUri = result.getUri();
                bitmap = MediaStore.Images.Media.getBitmap(getContext().getContentResolver(), fileUri);

                if (addedImageCount < 4) {
                    addedImageCount += 1;
                }

                serviceImage = new ServiceImage();
                serviceImage.setUri(fileUri);
                String fileName = "command_" + new Date().getTime() + ".jpg";
                serviceImage.setFileName(fileName);
                serviceImageArrayList.add(serviceImage);
                createAdapter.notifyDataSetChanged();
                createFileFromBitmap(bitmap, fileName);

                checkImageCount();

            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
            showToastMsg(getContext(), "Cropping failed");
        } else if (requestCode == REQUEST_FOR_ADDRESS && resultCode == getActivity().RESULT_OK) {
            getShippingAddress();
        }
    }

    public void checkImageCount() {
        if (addedImageCount == 3) {
            relativeAddImage.setEnabled(false);
            relativeAddImage.setAlpha(0.5f);
        } else {
            relativeAddImage.setEnabled(true);
            relativeAddImage.setAlpha(1);
        }
    }

    /**
     * check runtime permisiion
     */
    private void checkPermission() {
        new TedPermission(getContext())
                .setPermissionListener(new PermissionListener() {
                    @Override
                    public void onPermissionGranted() {
                        CropImage.startPickImageActivity(getActivity());
                    }

                    @Override
                    public void onPermissionDenied(ArrayList arrayList) {

                    }
                })
                .setDeniedMessage(getResources().getString(R.string.permission))
                .setGotoSettingButton(false)
                .setPermissions(Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE)
                .check();
    }

    private void createFileFromBitmap(Bitmap myBitmap, String fileName) {
        try {
            if (myBitmap == null) {
                return;
            }
            File file = new File(getContext().getCacheDir(), fileName);
            file.createNewFile();

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            myBitmap.compress(Bitmap.CompressFormat.PNG, 0 /*ignored for PNG*/, bos);
            byte[] bitmapdata = bos.toByteArray();

            FileOutputStream fos = new FileOutputStream(file);
            fos.write(bitmapdata);
            fos.flush();
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void imageArray() {

        File[] file = new File[serviceImageArrayList.size()];
        for (int i = 0; i < serviceImageArrayList.size(); i++) {
            File f = new File(getActivity().getCacheDir(), serviceImageArrayList.get(i).getFileName());
            file[i] = f;
        }

        body = new MultipartBody.Part[addedImageCount];
        for (int i = 0; i < body.length; i++) {
            RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file[i]);
            body[i] = MultipartBody.Part.createFormData("image[]", file[i].getName(), requestFile);
            Log.e("MultiPart " + i, body[i].toString());
        }
    }

}

