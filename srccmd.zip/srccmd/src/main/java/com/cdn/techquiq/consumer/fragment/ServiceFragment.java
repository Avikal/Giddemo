package com.cdn.techquiq.consumer.fragment;

import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.activity.MainActivity;
import com.cdn.techquiq.consumer.adapter.ViewPagerAdapter;

/**
 * Created by kajalsoni on 3/2/17.
 */

public class ServiceFragment extends BaseFragment {

    private String TAG = ServiceFragment.class.getSimpleName();

    private TabLayout tabLayout;
    private ViewPager viewPager;
    private ViewPagerAdapter adapter;
    private Fragment fragment;
    private int selectedPosition = 0;
    private boolean isClicked;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_services, container, false);

        setTitleText(getString(R.string.txt_services_title));

        tabLayout = (TabLayout) rootView.findViewById(R.id.tab_layout);

        addViewPagerAdapter(rootView);

        webServiceCall(selectedPosition);

        disableTabClick();

        return rootView;
    }

    private void disableTabClick() {
        LinearLayout tabStrip = ((LinearLayout) tabLayout.getChildAt(0));
        for (int i = 0; i < tabStrip.getChildCount(); i++) {
            tabStrip.getChildAt(i).setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    return isClicked;
                }
            });
        }
    }

    private void webServiceCall(final int position) {
        fragment = ((ViewPagerAdapter) viewPager.getAdapter()).getItem(position);
        if (fragment instanceof CreateFragment) {
            viewPager.setCurrentItem(0);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    ((CreateFragment) adapter.getItem(position)).clearPage();
                    ((CreateFragment) adapter.getItem(position)).getShippingAddress();
                    ((CreateFragment) adapter.getItem(position)).topAndBelowTab();
                }
            }, 100);
        } else if (fragment instanceof OpenFragment) {
            viewPager.setCurrentItem(1);
            ((OpenFragment) adapter.getItem(position)).webServiceCall();
            ((OpenFragment) fragment).topAndBelowTab();
        } else if (fragment instanceof AwardedFragment) {
            viewPager.setCurrentItem(2);
            ((AwardedFragment) adapter.getItem(position)).webServiceCall();
            ((AwardedFragment) fragment).topAndBelowTab();
        }
        ((MainActivity) getActivity()).closeSearchView();
        Utils.hideKeyBoard(getActivity());
    }

    private void addViewPagerAdapter(final View view) {
        viewPager = (ViewPager) view.findViewById(R.id.pager);
        adapter = new ViewPagerAdapter(getChildFragmentManager());
        adapter.addFragment(new CreateFragment(), getResources().getString(R.string.txt_create_service));
        adapter.addFragment(new OpenFragment(), getResources().getString(R.string.txt_open_service));
        adapter.addFragment(new AwardedFragment(), getResources().getString(R.string.txt_awarded_service));
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);
        View root = tabLayout.getChildAt(0);
        if (root instanceof LinearLayout) {
            ((LinearLayout) root).setShowDividers(LinearLayout.SHOW_DIVIDER_MIDDLE);
            GradientDrawable drawable = new GradientDrawable();
            drawable.setColor(getResources().getColor(R.color.black));
            drawable.setSize(1, 1);
            ((LinearLayout) root).setDividerDrawable(drawable);
        }
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                Log.e(TAG, "" + tab.getPosition());
                if (!isClicked) {
                    isClicked = true;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            isClicked = false;
                        }
                    }, 1000);
                }
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                Log.e(TAG, "onPageSelected");
                selectedPosition = position;
                if (((MainActivity) getActivity()).isSearchOpen()) {
                    ((MainActivity) getActivity()).setApiCallOnSearchClose(false);
                }
                webServiceCall(selectedPosition);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    public Fragment getCurrentFragment() {
        return fragment;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        fragment.onActivityResult(requestCode, resultCode, data);
    }
}
