package com.cdn.techquiq.consumer.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.cdn.techquiq.consumer.R;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by avikaljain on 10/5/17.
 */

public class ReviewDetailActivity extends BaseActivity {


    public Bundle bundle;
    private String merchantName;
    private String merchantImage;
    private String ratingMerchant;
    private String merchantReview;
    private String ratingType;

    private ImageView backIv;
    private TextView titleTv;

    private TextView tvMerchantName;
    private RatingBar merchantRating;
    private CircleImageView ivMerchantProfile;
    private TextView tvReviewDetail;
    private LinearLayout mainContainer;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review_detail);
        setUpUI();

    }

    private void setUpUI() {
        titleTv = (TextView) findViewById(R.id.titleTv);
        backIv = (ImageView) findViewById(R.id.backIv);
        mainContainer = (LinearLayout) findViewById(R.id.mainContainer);
        bundle = getIntent().getExtras();
        if (bundle != null) {
            merchantName = bundle.getString("merchantName");
            merchantImage = bundle.getString("merchantImage");
            ratingMerchant = bundle.getString("merchantRating");
            merchantReview = bundle.getString("merchantReview");
            ratingType = bundle.getString("ratingType");
        }
        tvMerchantName = (TextView) findViewById(R.id.tvMerchantName);
        merchantRating = (RatingBar) findViewById(R.id.merchantRating);
        ivMerchantProfile = (CircleImageView) findViewById(R.id.ivMerchantProfile);
        tvReviewDetail = (TextView) findViewById(R.id.tvReviewDetail);
        backIv.setOnClickListener(this);

        setReviewDetail();
        hideMerchantDetail();
    }

    private void hideMerchantDetail() {
        if (ratingType != null && ratingType.equalsIgnoreCase("Product")) {
            mainContainer.setVisibility(View.GONE);
        } else {
            mainContainer.setVisibility(View.VISIBLE);
            tvMerchantName.setText(merchantName);
            merchantRating.setRating(Float.parseFloat(ratingMerchant));
            Glide.with(mContext).load(merchantImage).asBitmap().centerCrop()
                    .override(100, 100)
                    .placeholder(R.drawable.profile_img)
                    .error(R.drawable.profile_img)
                    .into(ivMerchantProfile);
        }
    }

    private void setReviewDetail() {
        titleTv.setText(getResources().getString(R.string.reviews));
        tvReviewDetail.setText(merchantReview);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.backIv:
                finish();
                break;

        }
    }
}
