package com.cdn.techquiq.consumer.model;

/**
 * Created by avikaljain on 23/6/17.
 */

public class ReportSuccessResponse extends BaseResponse {
}
