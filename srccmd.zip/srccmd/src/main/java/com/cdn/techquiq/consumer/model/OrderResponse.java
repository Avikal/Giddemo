package com.cdn.techquiq.consumer.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by avikaljain on 27/4/17.
 */

public class OrderResponse extends BaseResponse {

    @SerializedName("Result")
    private OrderResult orderResult;

    public OrderResult getOrderResult() {
        return orderResult;
    }

    public void setOrderResult(OrderResult orderResult) {
        this.orderResult = orderResult;
    }

    public class OrderResult {
        @SerializedName("total_price")
        private String totalPrice;

        public String getTotalPrice() {
            return totalPrice;
        }

        public void setTotalPrice(String totalPrice) {
            this.totalPrice = totalPrice;
        }

        @SerializedName("promo_code_id")
        private String promoCodeId;

        public String getPromoCodeId() {
            return promoCodeId;
        }

        public void setPromoCodeId(String promoCodeId) {
            this.promoCodeId = promoCodeId;
        }

        @SerializedName("promo_code")
        private String promoCode;

        public String getPromoCode() {
            return promoCode;
        }

        public void setPromoCode(String promoCode) {
            this.promoCode = promoCode;
        }

        @SerializedName("promo_code_description")
        private String promoCodeDescription;

        @SerializedName("offer_amount")
        private String offerAmount;

        @SerializedName("cart_id")
        private String cartId;

        @SerializedName("order_id")
        private String orderId;

        public String getPromoCodeDescription() {
            return promoCodeDescription;
        }

        public void setPromoCodeDescription(String promoCodeDescription) {
            this.promoCodeDescription = promoCodeDescription;
        }

        public String getOfferAmount() {

            return offerAmount;
        }

        public void setOfferAmount(String offerAmount) {
            this.offerAmount = offerAmount;
        }

        public String getOrderId() {

            return orderId;
        }

        public void setOrderId(String orderId) {
            this.orderId = orderId;
        }

        public String getCartId() {

            return cartId;
        }

        public void setCartId(String cartId) {
            this.cartId = cartId;
        }
    }
}

