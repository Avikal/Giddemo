package com.cdn.techquiq.consumer.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.model.ForgetPasswordResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;

import java.net.SocketTimeoutException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by kajalsoni on 28/1/17.
 */
public class ForgetPasswordActivity extends BaseActivity {

    private String TAG = ForgetPasswordActivity.class.getSimpleName();

    private EditText emailEd;
    private Button submitBtn;
    private Context mContext;

    private TextView titleTv;
    private ImageView backIv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.forget_password_activity);
        mContext = this;

        setUpUI();
    }

    private void setUpUI() {
        emailEd = (EditText) findViewById(R.id.emailEd);
        submitBtn = (Button) findViewById(R.id.submitBtn);
        backIv = (ImageView) findViewById(R.id.backIv);
        submitBtn.setOnClickListener(this);
        backIv.setOnClickListener(this);
        titleTv = (TextView) findViewById(R.id.titleTv);
        titleTv.setText(getResources().getString(R.string.forget_password));
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.submitBtn:
                String emailId = emailEd.getText().toString();
                if (isValidate(emailId)) {
                    doForgotPassword(emailId);
                }
                break;

            case R.id.backIv:
                finish();
                break;
        }
    }

    private boolean isValidate(String email) {
        if (email.isEmpty()) {
            showToastMsg(mContext, mContext.getString(R.string.enter_email));
            return false;
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            showToastMsg(mContext, mContext.getString(R.string.enter_valid_email));
            return false;
        } else {
            return true;
        }
    }


    private void doForgotPassword(String emailId) {


        if (!CheckNetworkState.isOnline(mContext)) {
            showToastMsg(mContext, getString(R.string.network_error));
            return;
        }

        showProgressDialog(this);

        try {
            Call<ForgetPasswordResponse> changePwdReq = ((TechquiqApplication) this
                    .getApplicationContext()).getService().forgetPasswordService(
                    emailId, Utils.getDeviceId(mContext),
                    ApiParameter.DEVICE_TYPE_VALUE,
                    AppConstant.FCM_ID);

            changePwdReq.enqueue(new Callback<ForgetPasswordResponse>() {
                @Override
                public void onResponse(Call<ForgetPasswordResponse> call, Response<ForgetPasswordResponse> response) {
                    hideProgressDialog();
                    if (response.code() == 0) {
                        showToastMsg(mContext, response.message());
                        return;
                    }

                    ForgetPasswordResponse forgetPasswordResponse = response.body();
                    int responseStatusCode = forgetPasswordResponse.getResponseStatusCode();

                    if (responseStatusCode == AppConstant.NOT_REGISTERED) {
                        showToastMsg(mContext, getString(R.string.ws_not_registerd));
                    } else if (responseStatusCode == AppConstant.UNAUTHORIZED_USER) {
                        showToastMsg(mContext, getString(R.string.ws_unauthorized_user));
                    } else if (responseStatusCode == AppConstant.UNKNOWN_ERROR) {
                        showToastMsg(mContext, getString(R.string.ws_unkonwn_error));
                    } else if (responseStatusCode == AppConstant.PASSWORD_SENT) {
                        showToastMsg(mContext, getString(R.string.ws_password_sent));
                        Intent intent = new Intent(mContext, LoginActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        showToastMsg(mContext, forgetPasswordResponse.getResponseMessage());
                    }


                }

                @Override
                public void onFailure(Call<ForgetPasswordResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
