package com.cdn.techquiq.consumer.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.activity.MainActivity;
import com.cdn.techquiq.consumer.activity.OpenDetailActivity;
import com.cdn.techquiq.consumer.fragment.OpenFragment;
import com.cdn.techquiq.consumer.model.ServiceResponse;
import com.marshalchen.ultimaterecyclerview.UltimateRecyclerviewViewHolder;
import com.marshalchen.ultimaterecyclerview.UltimateViewAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by avikaljain on 5/4/17.
 */

public class OpenAdapter extends UltimateViewAdapter {

    private List<ServiceResponse.ServiceDetail> openDetails;
    private Context mContext;
    private LayoutInflater mLayoutInflater;

    private String title, description;

    public OpenAdapter(Context context, ArrayList<ServiceResponse.ServiceDetail> openDetails) {
        this.mContext = context;
        this.openDetails = openDetails;
    }

    @Override
    public RecyclerView.ViewHolder newFooterHolder(View view) {
        return new UltimateRecyclerviewViewHolder<>(view);
    }

    @Override
    public RecyclerView.ViewHolder newHeaderHolder(View view) {
        return new UltimateRecyclerviewViewHolder<>(view);
    }


    @Override
    public int getAdapterItemCount() {
        return openDetails.size();
    }

    @Override
    public UltimateRecyclerviewViewHolder onCreateViewHolder(ViewGroup parent) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.open_list_item, parent, false);
        ViewHolderOpen vh = new ViewHolderOpen(v);
        return vh;
    }


    public void insert(String string, int position) {
        insertInternal(openDetails, string, position);
    }

    public void remove(int position) {
        removeInternal(openDetails, position);
    }

    public void clear() {
        clearInternal(openDetails);
    }


    public void swapPositions(int from, int to) {
        swapPositions(openDetails, from, to);
    }


    @Override
    public long generateHeaderId(int position) {
        // URLogs.d("position--" + position + "   " + getItem(position));
        if (getItem(position).length() > 0)
            return getItem(position).charAt(0);
        else return -1;
    }


    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (openDetails.size() == position) {
            Log.e("RETURN POSITION", "" + position);
            return;
        }
        final ServiceResponse.ServiceDetail openDetail = openDetails.get(position);
        if (position < getItemCount() && (customHeaderView != null ? position <= openDetails.size() : position < openDetails.size()) && (customHeaderView != null ? position > 0 : true)) {

            ((ViewHolderOpen) holder).tVOpenTitle.setText(Utils.decodeString(openDetail.getName()));
            ((ViewHolderOpen) holder).tVOpenDes.setText(Utils.decodeString(openDetail.getDescription()));
            ((ViewHolderOpen) holder).tVOpenDay.setText(openDetail.getDate());
            ((ViewHolderOpen) holder).tVOpenPraposal.setText(openDetail.getTotalProposal() + " " + mContext.getResources().getString(R.string.txt_proposal));
            ArrayList<ServiceResponse.ServiceDetail.SProductImage> productImages = openDetail.getsProductImages();
            if (productImages != null && productImages.size() > 0) {
                //Log.e("Image Url", productImages.get(0).getImage());
                Glide.with(mContext).load(productImages.get(0).getImage())
                        .crossFade()
                        .override(100, 100)
                        .centerCrop()
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .placeholder(R.drawable.placeholder_1)
                        .into(((ViewHolderOpen) holder).iVService);
            }

            ((ViewHolderOpen) holder).openContainer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(mContext, OpenDetailActivity.class);
                    intent.putExtra("id", openDetail.getId());
                    ((MainActivity) mContext).startActivityForResult(intent, OpenFragment.REQUEST_DELETE_SERVICE);
                }
            });
        }
    }


    @Override
    public RecyclerView.ViewHolder onCreateHeaderViewHolder(ViewGroup parent) {
        return null;
    }

    @Override
    public void onBindHeaderViewHolder(RecyclerView.ViewHolder holder, int position) {


    }

    @Override
    public void onItemMove(int fromPosition, int toPosition) {
        if (fromPosition > 0 && toPosition > 0) {
            swapPositions(fromPosition, toPosition);
            super.onItemMove(fromPosition, toPosition);
        }
    }

    @Override
    public void onItemDismiss(int position) {
        if (position > 0) {
            remove(position);
            notifyDataSetChanged();
            super.onItemDismiss(position);
        }

    }

    public void setOnDragStartListener(OnStartDragListener dragStartListener) {
        mDragStartListener = dragStartListener;

    }

    class ViewHolderOpen extends UltimateRecyclerviewViewHolder {

        public TextView tVOpenTitle, tVOpenDes, tVOpenDay, tVOpenPraposal;
        ImageView iVService;

        View mparent;
        LinearLayout openContainer;

        public ViewHolderOpen(View itemView) {
            super(itemView);
            mparent = itemView;
            tVOpenTitle = (TextView) itemView.findViewById(R.id.tvOpenTitle);
            iVService = (ImageView) itemView.findViewById(R.id.ivService);

            tVOpenDes = (TextView) itemView.findViewById(R.id.tvOpenDes);
            tVOpenDay = (TextView) itemView.findViewById(R.id.tvOpenDay);
            tVOpenPraposal = (TextView) itemView.findViewById(R.id.tvOpenProposal);

            openContainer = (LinearLayout) itemView.findViewById(R.id.openContainer);

        }

        @Override
        public void onItemSelected() {
            itemView.setBackgroundColor(Color.LTGRAY);
        }

        @Override
        public void onItemClear() {
            itemView.setBackgroundColor(0);
        }
    }


    public String getItem(int position) {
        if (customHeaderView != null)
            position--;

        if (position >= 0 && position < openDetails.size())
            return String.valueOf(openDetails.get(position));
        else return "";
    }
}
