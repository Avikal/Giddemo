package com.cdn.techquiq.consumer.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ToggleButton;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.activity.MainActivity;

/**
 * Created by kajalsoni on 6/2/17.
 */
public class SettingFragment extends BaseFragment {

    private String TAG = SettingFragment.class.getSimpleName();

    private ToggleButton alertBtn;
    private ToggleButton soundBtn;
    private ToggleButton previewBtn;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_settings, null, false);

        alertBtn = (ToggleButton) rootView.findViewById(R.id.alertbt);
        previewBtn = (ToggleButton) rootView.findViewById(R.id.previewbt);
        soundBtn = (ToggleButton) rootView.findViewById(R.id.soundbt);

        alertBtn.setOnClickListener(this);
        previewBtn.setOnClickListener(this);
        soundBtn.setOnClickListener(this);

        setTitleText(getString(R.string.setting));
        ((MainActivity) getActivity()).hideBackBtn(false);
        ((MainActivity) getActivity()).hideCartButton(true);

        return rootView;
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.alertbt:
                if (alertBtn.isChecked()) {
                    alertBtn.setChecked(true);
                } else {
                    alertBtn.setChecked(false);
                }

                break;
            case R.id.previewbt:
                if (previewBtn.isChecked()) {
                    previewBtn.setChecked(true);
                } else {
                    previewBtn.setChecked(false);
                }

                break;
            case R.id.soundbt:
                if (soundBtn.isChecked()) {
                    soundBtn.setChecked(true);
                } else {
                    soundBtn.setChecked(false);
                }

                break;
        }
    }
}
