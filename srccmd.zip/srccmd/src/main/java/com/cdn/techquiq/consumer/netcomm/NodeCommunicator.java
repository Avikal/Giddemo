package com.cdn.techquiq.consumer.netcomm;

import android.content.Context;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import com.cdn.techquiq.consumer.AppSettings;
import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.socket.SocketIO;
import com.cdn.techquiq.consumer.socket.SocketIOManager;

import org.json.JSONObject;

/*
* this class work as a bridge between node connection and user
* make connection using SocketIoManager class from node...
* */
public class NodeCommunicator {

    static final String TAG = "NodeCommunicator";
    private static NodeCommunicator instance;
    private SocketIOManager mSocketIOManager;
    private SocketIO mSocketIO;
    private Handler mCallerHandler;

    public void setCallerHandler(Handler callerHandler) {
        mCallerHandler = callerHandler;
    }

    public static NodeCommunicator getInstance() {
        if (null == instance) {
            instance = new NodeCommunicator();
        }
        return instance;
    }


    public static void setInstance(NodeCommunicator instance) {
        NodeCommunicator.instance = instance;
    }

    /**
     * this method use to connect node or socket...
     * using node port and server ip
     *
     * @param handler
     */
    public void connectToServer(Handler handler) {
        try {
            Log.v(TAG, "connecting to Server()");
            mSocketIOManager = new SocketIOManager(handler);
            mSocketIO = mSocketIOManager.connect(AppSettings.CHAT_SERVER_IP + AppSettings.CHAT_PORT);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
    * when user connect to socket then need to join user in node chat...
    * paramters of this emitter (user id)
    * */
    public void joinChatServer(String userOwnId) {
        try {
            JSONObject obj = new JSONObject();//"{\"userId\":\"12\"}");

            obj.put("user_id", userOwnId);
            mSocketIO.emit("create_node_room", obj);//"{userId:12}"
            Log.e("join complete ", "create");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
    * used to check socket connect or not...
    * */
    public boolean isConnected() {
        if (mSocketIO == null) {
            return false;
        }
        return mSocketIO.isConnected();
    }

    public void reconnectToServer() {
        mSocketIO.reconnect();
    }

    /**
     * use to dis-connect node server and clear.
     */
    public void disconnectToServer() {
        try {
            if (mSocketIOManager != null)
                mSocketIOManager.disconnect();
            mSocketIOManager = null;
            mSocketIO = null;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void sendMessageToNode(int methodType, JSONObject object, Context context) {
        String methodName = "";
        switch (methodType) {
            case 1:
                methodName = "send_to_admin";
                break;

        }
        if (mSocketIO != null && object != null) {
            mSocketIO.emit(methodName, object);
        } else {
            Toast.makeText(context, context.getString(R.string.server_error), Toast.LENGTH_LONG).show();
        }

    }

}