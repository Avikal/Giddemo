package com.cdn.techquiq.consumer.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by avikaljain on 9/5/17.
 */

public class ReviewResponse extends BaseResponse {

    @SerializedName("AverageRating")
    private String averageRating;

    @SerializedName("TotalRating")
    private int totalRating;

    public String getAverageRating() {
        return averageRating;
    }

    public void setAverageRating(String averageRating) {
        this.averageRating = averageRating;
    }

    public int getTotalRating() {
        return totalRating;
    }

    public void setTotalRating(int totalRating) {
        this.totalRating = totalRating;
    }

    @SerializedName("Result")
    private ArrayList<UserReviews> userReviews;

    public ArrayList<UserReviews> getUserReviews() {
        return userReviews;
    }

    public void setUserReviews(ArrayList<UserReviews> userReviews) {
        this.userReviews = userReviews;
    }


    @SerializedName("productData")
    public ProductData productData;

    public ProductData getProductData() {
        return productData;
    }

    public void setProductData(ProductData productData) {
        this.productData = productData;
    }

    public class ProductData {

        @SerializedName("name_en")
        public String name_en;

        @SerializedName("name_ar")
        public String name_ar;

        @SerializedName("sku")
        public String sku;

        @SerializedName("price")
        public float price;

        @SerializedName("quantity")
        public String quantity;

        @SerializedName("description_en")
        public String description_en;

        public String getSku() {
            return sku;
        }

        public void setSku(String sku) {
            this.sku = sku;
        }

        public String getQuantity() {
            return quantity;
        }

        public void setQuantity(String quantity) {
            this.quantity = quantity;
        }

        public float getPrice() {
            return price;
        }

        public void setPrice(float price) {
            this.price = price;
        }

        public String getName_en() {
            return name_en;
        }

        public void setName_en(String name_en) {
            this.name_en = name_en;
        }

        public String getName_ar() {
            return name_ar;
        }

        public void setName_ar(String name_ar) {
            this.name_ar = name_ar;
        }

        public String getDescription_en() {
            return description_en;
        }

        public void setDescription_en(String description_en) {
            this.description_en = description_en;
        }
    }

    @SerializedName("merchantData")
    public MerchantInfo merchantInfo;

    public MerchantInfo getMerchantInfo() {
        return merchantInfo;
    }

    public void setMerchantInfo(MerchantInfo merchantInfo) {
        this.merchantInfo = merchantInfo;
    }


    public class MerchantInfo {
        @SerializedName("merchant_id")
        private String merchantId;

        @SerializedName("merchant_first_name")
        private String merchantFirstName;

        @SerializedName("merchant_last_name")
        private String merchantLastName;

        @SerializedName("merchant_image")
        private String merchantImage;

        @SerializedName("merchant_company")
        private String merchantCompany;

        @SerializedName("merchant_phone")
        private String merchantPhone;

        public String getMerchantPhone() {
            return merchantPhone;
        }

        public void setMerchantPhone(String merchantPhone) {
            this.merchantPhone = merchantPhone;
        }

        public String getMerchantLastName() {

            return merchantLastName;
        }

        public void setMerchantLastName(String merchantLastName) {
            this.merchantLastName = merchantLastName;
        }

        public String getMerchantImage() {

            return merchantImage;
        }

        public void setMerchantImage(String merchantImage) {
            this.merchantImage = merchantImage;
        }

        public String getMerchantId() {

            return merchantId;
        }

        public void setMerchantId(String merchantId) {
            this.merchantId = merchantId;
        }

        public String getMerchantFirstName() {

            return merchantFirstName;
        }

        public void setMerchantFirstName(String merchantFirstName) {
            this.merchantFirstName = merchantFirstName;
        }

        public String getMerchantCompany() {

            return merchantCompany;
        }

        public void setMerchantCompany(String merchantCompany) {
            this.merchantCompany = merchantCompany;
        }
    }

    public class UserReviews {
        @SerializedName("id")
        private String id;

        @SerializedName("first_name")
        private String userFirstName;

        @SerializedName("last_name")
        private String userLastName;

        @SerializedName("company")
        private String company;

        @SerializedName("phone")
        private String phone;

        @SerializedName("rating")
        private String rating;

        @SerializedName("review")
        private String review;

        @SerializedName("image")
        private String image;

        @SerializedName("rating_type")
        private String ratingType;

        public String getRatingType() {
            return ratingType;
        }

        public void setRatingType(String ratingType) {
            this.ratingType = ratingType;
        }

        public String getUserFirstName() {
            return userFirstName;
        }

        public void setUserFirstName(String userFirstName) {
            this.userFirstName = userFirstName;
        }

        public String getId() {

            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getUserLastName() {
            return userLastName;
        }

        public void setUserLastName(String userLastName) {
            this.userLastName = userLastName;
        }

        public String getReview() {

            return review;
        }

        public void setReview(String review) {
            this.review = review;
        }

        public String getPhone() {

            return phone;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }

        public String getRating() {
            if (rating == null || rating.isEmpty()) {
                return "0.0";
            }
            return rating;
        }

        public void setRating(String rating) {
            this.rating = rating;
        }

        public String getImage() {

            return image;
        }

        public void setImage(String image) {
            this.image = image;
        }

        public String getCompany() {
            return company;
        }

        public void setCompany(String company) {
            this.company = company;
        }
    }
}
