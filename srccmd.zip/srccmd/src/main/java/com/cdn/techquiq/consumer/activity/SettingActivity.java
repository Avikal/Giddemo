package com.cdn.techquiq.consumer.activity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.SharedPrefrence;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.NotificationResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;
import com.google.gson.Gson;

import java.net.SocketTimeoutException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by avikaljain on 1/3/17.
 */

public class SettingActivity extends BaseActivity implements View.OnClickListener {

    private String TAG = SettingActivity.class.getSimpleName();
    private ToggleButton alertBtn;
    private ToggleButton soundBtn;
    private ToggleButton previewBtn;
    private ImageView backIv;
    private TextView titleTv;

    private boolean previewBool;
    private boolean soundBool;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setting_activity);
        alertBtn = (ToggleButton) findViewById(R.id.alertbt);
        previewBtn = (ToggleButton) findViewById(R.id.previewbt);
        soundBtn = (ToggleButton) findViewById(R.id.soundbt);

        alertBtn.setOnClickListener(this);
        previewBtn.setOnClickListener(this);
        soundBtn.setOnClickListener(this);
        backIv = (ImageView) findViewById(R.id.backIv);
        backIv.setOnClickListener(this);
        titleTv = (TextView) findViewById(R.id.titleTv);
        titleTv.setText(getResources().getString(R.string.setting));

        getNotificationStatus();
        soundBool = SharedPrefrence.getInstance(this).readBooleanPrefs(SharedPrefrence.sound);
        previewBool = SharedPrefrence.getInstance(this).readBooleanPrefs(SharedPrefrence.showPreview);

        soundBtn.setChecked(soundBool);
        previewBtn.setChecked(previewBool);


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.previewbt:
                if (previewBool) {
                    updateNotification("OFF");
                } else {
                    updateNotification("ON");
//                    SharedPrefrence.getInstance(this).writeBooleanPrefs(SharedPrefrence.showPreview, true);
//                    previewBool = SharedPrefrence.getInstance(this).readBooleanPrefs(SharedPrefrence.showPreview);
//                    previewBtn.setChecked(previewBool);
                }
                break;
            case R.id.soundbt:
                if (soundBool) {
                    SharedPrefrence.getInstance(this).writeBooleanPrefs(SharedPrefrence.sound, false);
                    soundBool = SharedPrefrence.getInstance(this).readBooleanPrefs(SharedPrefrence.sound);
                    soundBtn.setChecked(soundBool);
                } else {
                    SharedPrefrence.getInstance(this).writeBooleanPrefs(SharedPrefrence.sound, true);
                    soundBool = SharedPrefrence.getInstance(this).readBooleanPrefs(SharedPrefrence.sound);
                    soundBtn.setChecked(soundBool);
                }
                break;
            case R.id.backIv:
                finish();
                break;
        }
    }

    private void updateNotification(String status) {
        try {
            if (!CheckNetworkState.isOnline(mContext)) {
                showToastMsg(mContext, getString(R.string.network_error));
                return;
            }

            if (!showProgressDialog(mContext)) {
                return;
            }
            final LoginResponse.Users userDetail = Utils.readUserDetail(mContext);
            final Call<NotificationResponse> updateStatus = ((TechquiqApplication) mContext.getApplicationContext())
                    .getService().updateNotificationStatus(userDetail.getUserId(),
                            Utils.getDeviceId(mContext),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID,
                            status);

            Log.e(TAG, "Request : " + updateStatus.request().url());

            updateStatus.enqueue(new Callback<NotificationResponse>() {
                @Override
                public void onResponse(Call<NotificationResponse> call, Response<NotificationResponse> response) {
                    Log.e(TAG, "Response : " + new Gson().toJson(response.toString()));

                    if (response == null) {
                        hideProgressDialog();
                        showToastMsg(mContext, getString(R.string.server_error));
                        return;
                    }

                    NotificationResponse notificationResponse = response.body();

                    Log.e(TAG, new Gson().toJson(notificationResponse));
                    if (notificationResponse == null) {
                        hideProgressDialog();
                        showToastMsg(mContext, getString(R.string.server_error));
                        return;
                    }
                    int responseStatusCode = notificationResponse.getResponseStatusCode();

                    if (responseStatusCode == AppConstant.SUCCESS) {
                        if (notificationResponse.getResponseCode() != null && notificationResponse.getResponseCode().equalsIgnoreCase("0")) {
                            hideProgressDialog();
                            showToastMsg(SettingActivity.this, notificationResponse.getResponseMessage());
                            return;
                        } else if (notificationResponse.getResponseCode() != null && notificationResponse.getResponseCode().equalsIgnoreCase("1")) {
                            hideProgressDialog();
                            if (notificationResponse.getResult().getNotificationStatus().equalsIgnoreCase("ON")) {
                                SharedPrefrence.getInstance(mContext).writeBooleanPrefs(SharedPrefrence.showPreview, true);
                            } else {
                                SharedPrefrence.getInstance(mContext).writeBooleanPrefs(SharedPrefrence.showPreview, false);
                            }
                            previewBool = SharedPrefrence.getInstance(mContext).readBooleanPrefs(SharedPrefrence.showPreview);
                            previewBtn.setChecked(previewBool);

                        }
                    } else {
                        hideProgressDialog();
                        showToastMsg(mContext, notificationResponse.getResponseMessage());
                    }

                }

                @Override

                public void onFailure(Call<NotificationResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getString(R.string.server_error));
                    Log.e(TAG, "Error : " + t.getMessage());
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void getNotificationStatus() {
        try {
            if (!CheckNetworkState.isOnline(mContext)) {
                hideProgressDialog();
                showToastMsg(mContext, getString(R.string.network_error));
                return;
            }

            if (!showProgressDialog(mContext)) {
                return;
            }
            final LoginResponse.Users userDetail = Utils.readUserDetail(mContext);
            final Call<NotificationResponse> statusRequest = ((TechquiqApplication) mContext.getApplicationContext())
                    .getService().getNotificationStatus(userDetail.getUserId(),
                            Utils.getDeviceId(mContext),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID);

            Log.e(TAG, "Request : " + statusRequest.request().url());

            statusRequest.enqueue(new Callback<NotificationResponse>() {
                @Override
                public void onResponse(Call<NotificationResponse> call, Response<NotificationResponse> response) {
                    Log.e(TAG, "Response : " + new Gson().toJson(response.toString()));

                    if (response == null) {
                        hideProgressDialog();
                        showToastMsg(mContext, getString(R.string.server_error));
                        return;
                    }

                    NotificationResponse notificationResponse = response.body();

                    Log.e(TAG, new Gson().toJson(notificationResponse));
                    if (notificationResponse == null) {
                        hideProgressDialog();
                        return;
                    }
                    int responseStatusCode = notificationResponse.getResponseStatusCode();

                    if (responseStatusCode == AppConstant.SUCCESS) {
                        if (notificationResponse.getResponseCode() != null && notificationResponse.getResponseCode().equalsIgnoreCase("0")) {
                            hideProgressDialog();
                            showToastMsg(SettingActivity.this, notificationResponse.getResponseMessage());
                            return;
                        } else if (notificationResponse.getResponseCode() != null && notificationResponse.getResponseCode().equalsIgnoreCase("1")) {
                            hideProgressDialog();
                            if (notificationResponse.getResult().getNotificationStatus().equalsIgnoreCase("ON")) {
                                SharedPrefrence.getInstance(mContext).writeBooleanPrefs(SharedPrefrence.showPreview, true);
                            } else {
                                SharedPrefrence.getInstance(mContext).writeBooleanPrefs(SharedPrefrence.showPreview, false);
                            }

                        }
                    } else {
                        showToastMsg(mContext, notificationResponse.getResponseMessage());
                    }

                }

                @Override
                public void onFailure(Call<NotificationResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getString(R.string.server_error));
                    Log.e(TAG, "Error : " + t.getMessage());
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

