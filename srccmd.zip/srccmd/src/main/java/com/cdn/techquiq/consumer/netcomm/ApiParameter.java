package com.cdn.techquiq.consumer.netcomm;

/**
 * Created by devendrasahu on 13/2/17.
 */
public interface ApiParameter {

    String REQUEST_TYPE_POST = "POST";

    String DEVICE_TYPE = "devicetype";
    String DEVICE_TOKEN = "devicetoken";
    String DEVICE_ID = "deviceid";
    String DEVICE_TYPE_VALUE = "and";
    String EMAIL = "email";
    String PASSWORD = "password";
    String USER_ID = "user_id";
    String OLD_PASSWORD = "old_password";
    String NEW_PASSWORD = "new_password";
    String COUNTRY_ID = "country_id";
    String STATE_ID = "state_id";
    String CITY_ID = "city_id";
    String USER_NAME = "username";
    String FIRST_NAME = "first_name";
    String LAST_NAME = "last_name";
    String COUNTRY = "country";
    String STATE = "state";
    String CITY = "city";
    String TIMESTAMP = "timestamp";
    String MESSAGE_ID = "message_id";

    String ADDRESS = "address";
    String ADDRESS_ID = "address_id";
    String POSTAL_CODE = "postcode";
    String PHONE = "phone";
    String PRODUCT_ID = "product_id";
    String ORDER_ID = "order_id";
    String PRODUCT_QTY = "product_qty";
    String PRODUCT_BASE_PRICE = "product_base_price";
    String CART_ID = "cart_id";
    String CART_ITEM_ID = "cart_item_id";
    String COMPANY = "company";
    String IMAGE = "image";
    String LIMIT = "limit";
    String OFFSET = "offset";
    String KEYWORD = "keyword";
    String PROMO_CODE = "promo_code";
    String PROMO_CODE_ID = "promo_code_id";
    String FILTER = "filter";
    String C_FILTER_TYPE = "c_filter_type";
    String SERVICE_ID = "service_id";
    String M_FILTER_TYPE = "m_filter_type";

    String CATEGORY_ID = "category_id";
    String SUBJECT = "subject";
    String SUB_CATEGORY_ID = "sub_category_id";
    String DESCRIPTION = "description";
    String PAYMENT_MODE = "payment_mode";
    String TRANSACTION = "transaction";
    String SHIPPING_ADDRESS = "shipping_address";

    String PICKUP_ADDRESS = "pickup_address";
    String BRAINTREE_NONCE = "payment_method_nonce";
    String STATUS = "status";

    String MERCHANT_ID = "merchant_id";
    String RATING = "rating";
    String MESSAGE = "message";

    String FILTER_DATA = "filter_data";

    String POSTAL_CODE_ADD = "postalcode";

    String RATING_TYPE = "rating_type";

    String RATING_ID = "rating_id";

    String MESSAGE_SUBJECT = "message_subject";
    String MESSAGE_DESCRIPTION = "message_descripation";

    String NOTIFICATION_STATUS = "notification_status";
    String BID_ID = "bid_id";

}
