package com.cdn.techquiq.consumer.model;

/**
 * Created by avikaljain on 12/5/17.
 */

public class DeleteServiceResponse extends BaseResponse {
}
