package com.cdn.techquiq.consumer.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognizerIntent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.NotificationUtils;
import com.cdn.techquiq.consumer.Utils.SharedPrefrence;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.database.DBHelper;
import com.cdn.techquiq.consumer.database.Notification;
import com.cdn.techquiq.consumer.fragment.AlertFragment;
import com.cdn.techquiq.consumer.fragment.AwardedFragment;
import com.cdn.techquiq.consumer.fragment.BaseFragment;
import com.cdn.techquiq.consumer.fragment.FragmentNavDrawer;
import com.cdn.techquiq.consumer.fragment.HomeFragment;
import com.cdn.techquiq.consumer.fragment.InboxFragment;
import com.cdn.techquiq.consumer.fragment.MyOrderFragment;
import com.cdn.techquiq.consumer.fragment.OpenFragment;
import com.cdn.techquiq.consumer.fragment.ProductFragment;
import com.cdn.techquiq.consumer.fragment.ProductParentFragment;
import com.cdn.techquiq.consumer.fragment.ServiceFragment;
import com.cdn.techquiq.consumer.fragment.SettingFragment;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.LogoutResponse;
import com.cdn.techquiq.consumer.model.NotificationResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;
import com.cdn.techquiq.consumer.netcomm.NodeCommunicator;
import com.cdn.techquiq.consumer.socket.MessageService;
import com.google.gson.Gson;
import com.miguelcatalan.materialsearchview.MaterialSearchView;

import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEvent;
import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEventListener;

import java.io.File;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Stack;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MainActivity extends BaseActivity implements FragmentNavDrawer.FragmentDrawerListener,
        View.OnClickListener {

    private String TAG = MainActivity.class.getSimpleName();

    private ActionBarDrawerToggle mDrawerToggle;
    private FragmentNavDrawer fragmentNavDrawer;
    public View containerView;
    private ActionBar actionBar;
    private Toolbar toolbar;

    public static String mainCurrentTab;
    public static HashMap<String, Stack<Fragment>> mainStacks;
    private boolean doubleBackToExitPressedOnce, isFromBack;
    private LinearLayout homeTab, productTab, serviceTab, inboxTab, alertTab;

    private RelativeLayout mainLayout, cartCountTitleLayout;
    private TextView cartCountTv;
    private DrawerLayout drawerLayout;
    private LinearLayout tabBar;

    private ImageView backIv, sliderIv, cartIv, settingIv, searchIv;
    private TextView titleTv;
    private MaterialSearchView searchView;
    private boolean isSearchVisible, isKeyBoardVisible;
    private SharedPrefrence sPref;

    public static final int REQUEST_FOR_FILTER = 1;
    private boolean apiCallOnSearchClose = true;
    private DBHelper dbHelper;

    private CircleImageView ivInbox;
    private TextView tvInboxCount;
    private int inboxCount;

    private CircleImageView ivAlert;
    private TextView tvAlertCount;
    private int alertCount;
    //private TextView alertCountTv, tvMsgCount;

    public boolean isApiCallOnSearchClose() {
        return apiCallOnSearchClose;
    }

    public void setApiCallOnSearchClose(boolean apiCallOnSearchClose) {
        this.apiCallOnSearchClose = apiCallOnSearchClose;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);
        sPref = SharedPrefrence.getInstance(this);
        setUpUI();
        setNavigationDrawer();

        mainTabBar();
        getNotificationStatus();
        KeyboardVisibilityEvent.setEventListener(
                this,
                new KeyboardVisibilityEventListener() {
                    @Override
                    public void onVisibilityChanged(boolean isOpen) {
                        isKeyBoardVisible = isOpen;
                        if (isOpen) {
                            tabBar.setVisibility(View.GONE);
                        } else {
                            if (isSearchVisible) {
                                tabBar.setVisibility(View.GONE);
                            } else {
                                tabBar.setVisibility(View.VISIBLE);
                            }
                        }

                    }
                });

        /**
         * Chat communication
         */
        Intent intent = new Intent(mContext, MessageService.class);
        intent.putExtra("START", "START");
        startService(intent);

        String registerToken = sPref.readPrefs(SharedPrefrence.pushToken);

        Log.e(TAG, "Token " + registerToken);

    }

    private void setUpUI() {
        searchView = (MaterialSearchView) findViewById(R.id.search_view);
        mainLayout = (RelativeLayout) findViewById(R.id.main_layout);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        cartIv = (ImageView) findViewById(R.id.cartIv);
        settingIv = (ImageView) findViewById(R.id.settingIv);
        tabBar = (LinearLayout) findViewById(R.id.tabBar);
        searchIv = (ImageView) findViewById(R.id.searchIcon);
        searchIv.setOnClickListener(this);
        cartCountTitleLayout = (RelativeLayout) findViewById(R.id.cartCountTitleLayout);
        cartCountTv = (TextView) findViewById(R.id.cartCountTv);
        ivInbox = (CircleImageView) findViewById(R.id.ivInbox);
        tvInboxCount = (TextView) findViewById(R.id.tvInboxCount);
        ivAlert = (CircleImageView) findViewById(R.id.ivAlert);
        tvAlertCount = (TextView) findViewById(R.id.tvAlertCount);
        /*tvMsgCount = (TextView) findViewById(R.id.tvMsgCount);
        alertCountTv = (TextView) findViewById(R.id.alertCountTv);*/

        dbHelper = DBHelper.getInstance(mContext);

        addToolBar();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // getIntent() should always return the most recent
        setTabFragment(AppConstant.TAB_ALERT, new AlertFragment());
//        setIntent(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        startChatReceiver();
        setUnreadMsgCount();
        setAlertCount();
    }

    private void setUnreadMsgCount() {

        inboxCount = dbHelper.getUnReadMessageCount();
        if (inboxCount > 0) {
            ivInbox.setVisibility(View.VISIBLE);
            tvInboxCount.setVisibility(View.VISIBLE);
            if (inboxCount > 9) {
                tvInboxCount.setText("" + 9 + "+");
            } else {
                tvInboxCount.setText("" + inboxCount);
            }

        } else {
            tvInboxCount.setVisibility(View.GONE);
            ivInbox.setVisibility(View.GONE);
        }

    }

    private void setAlertCount() {
        List<Notification> alertList = dbHelper.getAlertNotification();
        alertCount = alertList.size();/*SharedPrefrence.getInstance(mContext).readIntPrefs(SharedPrefrence.alertMessage);*/
        if (alertCount > 0) {
            ivAlert.setVisibility(View.VISIBLE);
            tvAlertCount.setVisibility(View.VISIBLE);
            if (alertCount > 9) {
                tvAlertCount.setText("" + 9 + "+");
            } else {
                tvAlertCount.setText("" + alertCount);
            }
        } else {
            tvAlertCount.setVisibility(View.GONE);
            ivAlert.setVisibility(View.GONE);
        }
        /*alertCountTv.setVisibility(View.GONE);*/
    }

    private void mainTabBar() {

        mainStacks = new HashMap<>();
        mainStacks.put(AppConstant.TAB_HOME, new Stack<Fragment>());
        mainStacks.put(AppConstant.TAB_PRODUCT, new Stack<Fragment>());
        mainStacks.put(AppConstant.TAB_SERVICE, new Stack<Fragment>());
        mainStacks.put(AppConstant.TAB_INBOX, new Stack<Fragment>());
        mainStacks.put(AppConstant.TAB_ALERT, new Stack<Fragment>());

        HashMap<String, Integer> mainMapIndex = new HashMap<>();
        mainMapIndex.put(AppConstant.TAB_HOME, 0);
        mainMapIndex.put(AppConstant.TAB_PRODUCT, 1);
        mainMapIndex.put(AppConstant.TAB_SERVICE, 2);
        mainMapIndex.put(AppConstant.TAB_INBOX, 3);
        mainMapIndex.put(AppConstant.TAB_ALERT, 4);

        /**
         * Below Tab Id and click events
         */
        homeTab = (LinearLayout) findViewById(R.id.homeTab);
        productTab = (LinearLayout) findViewById(R.id.productTab);
        serviceTab = (LinearLayout) findViewById(R.id.serviceTab);
        inboxTab = (LinearLayout) findViewById(R.id.inboxTab);
        alertTab = (LinearLayout) findViewById(R.id.alertTab);

        homeTab.setOnClickListener(this);
        productTab.setOnClickListener(this);
        serviceTab.setOnClickListener(this);
        inboxTab.setOnClickListener(this);
        alertTab.setOnClickListener(this);

        if (mainCurrentTab != null && mainCurrentTab.equalsIgnoreCase(AppConstant.TAB_PRODUCT)
                && mainStacks.get(AppConstant.TAB_PRODUCT).size() == 0) {
            setTabFragment(AppConstant.TAB_PRODUCT, new ProductParentFragment());
        } else if (mainCurrentTab != null && mainCurrentTab.equalsIgnoreCase(AppConstant.TAB_ALERT)
                && mainStacks.get(AppConstant.TAB_ALERT).size() == 0) {
            setTabFragment(AppConstant.TAB_ALERT, new AlertFragment());
        } else if (mainCurrentTab != null && mainCurrentTab.equalsIgnoreCase(AppConstant.TAB_SERVICE)
                && mainStacks.get(AppConstant.TAB_SERVICE).size() == 0) {
            setTabFragment(AppConstant.TAB_ALERT, new ServiceFragment());
        } else if (mainCurrentTab != null && mainCurrentTab.equalsIgnoreCase(AppConstant.TAB_INBOX)
                && mainStacks.get(AppConstant.TAB_INBOX).size() == 0) {
            setTabFragment(AppConstant.TAB_INBOX, new InboxFragment());
        } else {
            setTabFragment(AppConstant.TAB_HOME, new HomeFragment());
        }
    }

    public void setTabFragment(String tab, Fragment fragment) {

        mainCurrentTab = tab;
        changeTabColor();
        if (mainStacks.get(tab).size() == 0) {
            pushFragment(tab, fragment, false, true);
        } else {
            pushFragment(tab, mainStacks.get(tab).lastElement(), false, false);
        }
    }

    public void changeTabColor() {
        homeTab.setBackgroundColor(ContextCompat.getColor(this, R.color.app_theme_color_black));
        productTab.setBackgroundColor(ContextCompat.getColor(this, R.color.app_theme_color_black));
        serviceTab.setBackgroundColor(ContextCompat.getColor(this, R.color.app_theme_color_black));
        inboxTab.setBackgroundColor(ContextCompat.getColor(this, R.color.app_theme_color_black));
        alertTab.setBackgroundColor(ContextCompat.getColor(this, R.color.app_theme_color_black));
        ivInbox.setImageResource(R.color.app_theme_color_orange);
        tvInboxCount.setTextColor(ContextCompat.getColor(this, R.color.black));

        ivAlert.setImageResource(R.color.app_theme_color_orange);
        tvAlertCount.setTextColor(ContextCompat.getColor(this, R.color.black));

        if (mainCurrentTab.equalsIgnoreCase(AppConstant.TAB_HOME)) {
            homeTab.setBackgroundColor(ContextCompat.getColor(this, R.color.app_theme_color_orange));
        } else if (mainCurrentTab.equalsIgnoreCase(AppConstant.TAB_PRODUCT)) {
            productTab.setBackgroundColor(ContextCompat.getColor(this, R.color.app_theme_color_orange));
        } else if (mainCurrentTab.equalsIgnoreCase(AppConstant.TAB_SERVICE)) {
            serviceTab.setBackgroundColor(ContextCompat.getColor(this, R.color.app_theme_color_orange));
        } else if (mainCurrentTab.equalsIgnoreCase(AppConstant.TAB_INBOX)) {
            inboxTab.setBackgroundColor(ContextCompat.getColor(this, R.color.app_theme_color_orange));
            ivInbox.setImageResource(R.color.white);
            tvInboxCount.setTextColor(ContextCompat.getColor(this, R.color.black));
        } else if (mainCurrentTab.equalsIgnoreCase(AppConstant.TAB_ALERT)) {
            alertTab.setBackgroundColor(ContextCompat.getColor(this, R.color.app_theme_color_orange));
            ivAlert.setImageResource(R.color.white);
            tvAlertCount.setTextColor(ContextCompat.getColor(this, R.color.black));
            /**
             * Remove notification from notification tray using notification type and id
             */
            List<Notification> alertNotification = DBHelper.getInstance(mContext).getAlertNotification();
            for (int i = 0; i < alertNotification.size(); i++) {
                NotificationUtils.clearNotifications(mContext, alertNotification.get(i).notificationId);
                DBHelper.getInstance(mContext).removeReadNotification(alertNotification.get(i).notificationId);
            }
            setAlertCount();
        }
    }

    /* To add fragment to a tab. tag -> Tab identifier fragment -> Fragment to
   * show, in tab identified by tag shouldAnimate -> should animate
   * transaction. false when we switch tabs, or adding first fragment to a tab
   * true when when we are pushing more fragment into navigation stack.
   * shouldAdd -> Should add to fragment navigation stack (mStacks.get(tag)).
   * false when we are switching tabs (except for the first time) true in all
   * other cases.
   */
    public void pushFragment(String tag, Fragment fragment,
                             boolean shouldAnimate, boolean shouldAdd) {
        doubleBackToExitPressedOnce = false;

        setIsFromBack(false);
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction ft = manager.beginTransaction();

        if (shouldAdd) {
            mainStacks.get(tag).push(fragment);
        }

        /*shouldAnimate = false;
        if (shouldAnimate) {
            ft.setCustomAnimations(R.anim.slide_in_right, R.anim.slide_out_left);
        }*/

        ft.replace(R.id.fragment_container, fragment);
        ft.addToBackStack(null);
        ft.commitAllowingStateLoss();
    }


    public void popFragment() {

        setIsFromBack(true);
        Fragment fragment = mainStacks.get(mainCurrentTab).elementAt(mainStacks.get(mainCurrentTab).size() - 2);
        mainStacks.get(mainCurrentTab).pop();

        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction ft = manager.beginTransaction();
        //ft.setCustomAnimations(R.anim.slide_in_left, R.anim.slide_out_right);
        ft.replace(R.id.fragment_container, fragment);
        ft.commitAllowingStateLoss();
    }

    public boolean isFromBack() {
        return isFromBack;
    }

    public void setIsFromBack(boolean isFromBack) {
        this.isFromBack = isFromBack;
    }


    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.sliderIv:
                if (isDrawerOpen()) {
                    closeDrawer();
                } else {
                    openDrawer();
                }
                break;

            case R.id.backIv:
                dbHelper.clearAllProductFilter();
                onBackPressed();
                break;

            case R.id.settingIv:
                dbHelper.clearAllProductFilter();
                pushFragment(AppConstant.TAB_ALERT, new SettingFragment(), false, true);
                break;

            case R.id.searchIcon:
                searchFunctionality();
                break;

            case R.id.cartIv:
                dbHelper.clearAllProductFilter();
                openCartScreen();
                break;

            /**
             * Tab clicks
             */
            case R.id.homeTab:
                openHomeTab();
                break;

            case R.id.productTab:
                openProductTab();
                break;

            case R.id.serviceTab:
                openServiceTab();
                break;

            case R.id.inboxTab:
                inboxTab();
                break;

            case R.id.alertTab:
                openAlertTab();
                break;
        }

    }

    private void openHomeTab() {
        if (mainCurrentTab != null && mainCurrentTab.equalsIgnoreCase(AppConstant.TAB_HOME)) {
            return;
        }
        dbHelper.clearAllProductFilter();
        closeSearchView();
        setTabFragment(AppConstant.TAB_HOME, new HomeFragment());
    }

    public void openAlertTab() {
        if (mainCurrentTab != null && mainCurrentTab.equalsIgnoreCase(AppConstant.TAB_ALERT)) {
            return;
        }

        dbHelper.clearAllProductFilter();
        closeSearchView();
        setTabFragment(AppConstant.TAB_ALERT, new AlertFragment());
    }

    public void openServiceTab() {
        if (mainCurrentTab != null && mainCurrentTab.equalsIgnoreCase(AppConstant.TAB_SERVICE)) {
            return;
        }

        dbHelper.clearAllProductFilter();
        closeSearchView();
        MainActivity.mainStacks.get(AppConstant.TAB_SERVICE).clear();
        setTabFragment(AppConstant.TAB_SERVICE, new ServiceFragment());
    }

    public void inboxTab() {
        if (mainCurrentTab != null && mainCurrentTab.equalsIgnoreCase(AppConstant.TAB_INBOX)) {
            return;
        }
        dbHelper.clearAllProductFilter();
        closeSearchView();
        MainActivity.mainStacks.get(AppConstant.TAB_INBOX).clear();
        setTabFragment(AppConstant.TAB_INBOX, new InboxFragment());
    }

    public void openProductTab() {
        if (mainCurrentTab != null && mainCurrentTab.equalsIgnoreCase(AppConstant.TAB_PRODUCT)) {
            return;
        }
        MainActivity.mainStacks.get(AppConstant.TAB_PRODUCT).clear();
        setTabFragment(AppConstant.TAB_PRODUCT, new ProductParentFragment());
    }

    private void openCartScreen() {
        Intent cartIntent = new Intent(this, CartActivity.class);
        startActivity(cartIntent);
    }

    @Override
    public void onBackPressed() {

        Utils.hideKeyBoard(this);

        if (isDrawerOpen()) {
            closeDrawer();
            return;
        }
        try {
            if (!((BaseFragment) mainStacks.get(mainCurrentTab).lastElement())
                    .onBackPressed()) {
                if (doubleBackToExitPressedOnce) {
                    exitDialog();
                }
                if (mainStacks.get(mainCurrentTab).size() == 1) {
                    this.doubleBackToExitPressedOnce = true;
                    new Handler().postDelayed(new Runnable() {

                        @Override
                        public void run() {
                            doubleBackToExitPressedOnce = false;
                        }
                    }, 1500);
                } else {
                    popFragment();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            exitDialog();
        }
    }

    private void addToolBar() {

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        /**
         * Toolbars ID
         */
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        titleTv = (TextView) findViewById(R.id.titleTv);
        sliderIv = (ImageView) findViewById(R.id.sliderIv);
        backIv = (ImageView) findViewById(R.id.backIv);
        cartIv = (ImageView) findViewById(R.id.cartIv);
        settingIv = (ImageView) findViewById(R.id.settingIv);

        /**
         * enable Click event on View
         */
        sliderIv.setOnClickListener(this);
        backIv.setOnClickListener(this);
        cartIv.setOnClickListener(this);
        settingIv.setOnClickListener(this);

        actionBar = getSupportActionBar();

        if (actionBar != null) {
            actionBar.setHomeAsUpIndicator(R.drawable.back_arrow);
            actionBar.setDisplayHomeAsUpEnabled(false);
            actionBar.setDisplayShowTitleEnabled(false);
        }
    }

    /**
     * Drawer Methods.
     */
    public void setNavigationDrawer() {
        fragmentNavDrawer = (FragmentNavDrawer) getSupportFragmentManager().findFragmentById(R.id.slider);
        fragmentNavDrawer.setUp(R.id.slider, drawerLayout, toolbar);
        fragmentNavDrawer.setDrawerListener(this);
        drawerLayout.addDrawerListener(mDrawerToggle);


        drawerLayout.addDrawerListener(new DrawerLayout.DrawerListener() {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {

                /**
                 * Below code is used for slider sliding
                 */
                if (android.os.Build.VERSION.SDK_INT > 4.2) {
                    if (Utils.getLocale().equalsIgnoreCase("ar")) {
                        mainLayout.setTranslationX(-drawerView.getWidth() * slideOffset);
                    } else {
                        mainLayout.setTranslationX(slideOffset * drawerView.getWidth());
                    }
                } else {
                    mainLayout.setTranslationX(slideOffset * drawerView.getWidth());
                }


                drawerLayout.bringChildToFront(drawerView);
                drawerLayout.requestLayout();

            }

            @Override
            public void onDrawerOpened(View drawerView) {
                Utils.hideKeyBoard(MainActivity.this);
            }

            @Override
            public void onDrawerClosed(View drawerView) {
                Utils.hideKeyBoard(MainActivity.this);
            }

            @Override
            public void onDrawerStateChanged(int newState) {

            }
        });
    }

    private boolean isDrawerOpen() {
        containerView = findViewById(R.id.slider);
        return drawerLayout.isDrawerOpen(containerView);
    }

    private void openDrawer() {
        if (drawerLayout != null && containerView != null) {
            drawerLayout.openDrawer(containerView);
        }
    }

    private void closeDrawer() {
        if (drawerLayout != null && containerView != null) {
            drawerLayout.closeDrawer(containerView);
        }
    }

    public void setTitleText(String title) {
        if (titleTv != null && title != null && !title.isEmpty()) {
            titleTv.setText(title);
        }
    }

    @Override
    public void onDrawerItemSelected(View view, int position) {
        closeDrawer();
        switch (position) {

            //header
            case 0:
                break;
            //search
            case 1:
                dbHelper.clearAllProductFilter();
                Intent intent = new Intent(MainActivity.this, GlobalSearchActivity.class);
                startActivity(intent);
                break;
            //profile
            case 2:
                Intent profileIntent = new Intent(this, ProfileActivity.class);
                startActivity(profileIntent);
                break;
            //cart
            case 3:
                dbHelper.clearAllProductFilter();
                openCartScreen();
                break;
            //setting
            case 4:
                dbHelper.clearAllProductFilter();
                Intent settingIntent = new Intent(this, SettingActivity.class);
                startActivity(settingIntent);
                break;

            case 5:
                dbHelper.clearAllProductFilter();
                Intent intent1 = new Intent(this, PaymentListActivity.class);
                startActivity(intent1);
                break;
            case 6:
                dbHelper.clearAllProductFilter();
                Intent aboutUsIntent = new Intent(this, PrivacyPolicyActivity.class);
                aboutUsIntent.putExtra("position", 6);
                startActivity(aboutUsIntent);
                break;
            case 7:
                dbHelper.clearAllProductFilter();
                Intent privacyPolicyIntent = new Intent(this, PrivacyPolicyActivity.class);
                privacyPolicyIntent.putExtra("position", 7);
                startActivity(privacyPolicyIntent);
                break;
            case 8:
                dbHelper.clearAllProductFilter();
                Intent privacyFaqIntent = new Intent(this, PrivacyPolicyActivity.class);
                privacyFaqIntent.putExtra("position", 8);
                startActivity(privacyFaqIntent);
                break;
            case 9:
                dbHelper.clearAllProductFilter();
                Intent privacyContactIntent = new Intent(this, ContactUsActivity.class);
                startActivity(privacyContactIntent);
                break;
            case 10:
                logoutDialog();
                break;
        }
    }

    private void Logout() {

        try {
            if (!showProgressDialog(mContext)) {
                return;
            }

            final LoginResponse.Users userDetail = Utils.readUserDetail(mContext);

            final Call<LogoutResponse> loginRequest = ((TechquiqApplication) getApplicationContext())
                    .getService().doLogout(userDetail.getUserId(),
                            Utils.getDeviceId(this),
                            AppConstant.FCM_ID, ApiParameter.DEVICE_TYPE_VALUE);

            Log.e(TAG, "Request : " + loginRequest.request().url());

            loginRequest.enqueue(new Callback<LogoutResponse>() {
                @Override
                public void onResponse(Call<LogoutResponse> call, Response<LogoutResponse> response) {
                    hideProgressDialog();
                    logout();
                }

                @Override
                public void onFailure(Call<LogoutResponse> call, Throwable t) {
                    hideProgressDialog();
                    logout();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void logout() {

        NodeCommunicator.getInstance().disconnectToServer();

        deleteCache(MainActivity.this);

        DBHelper.getInstance(this).clearChatHistory();

        SharedPrefrence sPref = SharedPrefrence.getInstance(this);
        sPref.writeBooleanPrefs(SharedPrefrence.isLoggedIn, false);
        sPref.writePrefs(SharedPrefrence.userDetail, "");
        sPref.writePrefs(SharedPrefrence.cartCount, "");
        sPref.clearPrefs();

        mainCurrentTab = null;

        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    private void deleteCache(Context context) {
        try {
            File dir = context.getCacheDir();
            deleteDir(dir);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean deleteDir(File dir) {
        if (dir != null && dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
            return dir.delete();
        } else if (dir != null && dir.isFile()) {
            return dir.delete();
        } else {
            return false;
        }
    }


    private void exitDialog() {
        AlertDialog alertDialog = new AlertDialog.Builder(mContext)
                .setTitle(mContext.getString(R.string.app_name))
                .setMessage(mContext.getString(R.string.exit_dialog_msg))
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        mainCurrentTab = null;
                        dialog.dismiss();
                        finishAffinity();
                    }
                })
                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .setIcon(R.drawable.ic_launcher)
                .show();

        Button negativeBtn = alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE);
        negativeBtn.setBackgroundResource(R.drawable.ripple_effect);
        Button positiveBtn = alertDialog.getButton(DialogInterface.BUTTON_POSITIVE);
        positiveBtn.setBackgroundResource(R.drawable.ripple_effect);

    }

    private void logoutDialog() {
        AlertDialog alertDialog = new AlertDialog.Builder(mContext)
                .setTitle(mContext.getString(R.string.app_name))
                .setMessage(mContext.getString(R.string.logout_dialog_msg))
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dbHelper.clearAllProductFilter();
                        Logout();
                        dialog.dismiss();
                    }
                })
                .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .setIcon(R.drawable.ic_launcher)
                .show();

        Button negativeBtn = alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE);
        negativeBtn.setBackgroundResource(R.drawable.ripple_effect);
        Button positiveBtn = alertDialog.getButton(DialogInterface.BUTTON_POSITIVE);
        positiveBtn.setBackgroundResource(R.drawable.ripple_effect);

    }


    /**
     * Below methods is used for search functionality
     */
    public void closeSearchView() {
        if (searchView.isSearchOpen()) {
            searchView.closeSearch();
        }
    }

    private void openSearchView() {
        if (!searchView.isSearchOpen()) {
            searchView.showSearch();
        }
    }

    public boolean isSearchOpen() {
        return searchView.isSearchOpen();
    }

    private void searchFunctionality() {

        final Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.fragment_container);

        /**
         * Global search on home screen search Icon
         */
        if (fragment instanceof HomeFragment) {
            dbHelper.clearAllProductFilter();
            Intent intent = new Intent(MainActivity.this, GlobalSearchActivity.class);
            startActivity(intent);
        } else {

            openSearchView();

            searchView.setOnQueryTextListener(new MaterialSearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {

                    searchView.clearFocus();

                    /**
                     * For product searching
                     */
                    if (fragment instanceof ProductParentFragment) {
                        Fragment fragment1 = ((ProductParentFragment) fragment).getCurrentFragment();
                        if (fragment1 instanceof ProductFragment) {
                            ((ProductFragment) fragment1).searchProduct(0, false, query);
                        } else if (fragment1 instanceof MyOrderFragment) {
                            ((MyOrderFragment) fragment1).getOrderHistory(0, false, query);
                        }
                    }

                    /**
                     * This is used for service section
                     */
                    else if (fragment instanceof ServiceFragment) {
                        /**
                         * For open Fragment
                         */
                        if (((ServiceFragment) fragment).getCurrentFragment() instanceof OpenFragment) {
                            ((OpenFragment) ((ServiceFragment) fragment).getCurrentFragment())
                                    .searchProduct(0, false, query);
                        }

                        /**
                         * For Awarded Fragment
                         */
                        else if (((ServiceFragment) fragment).getCurrentFragment() instanceof AwardedFragment) {
                            ((AwardedFragment) ((ServiceFragment) fragment).getCurrentFragment())
                                    .searchProduct(0, false, query);
                        }
                    }

                    /**
                     * For Inbox fragment
                     */
                    else if (fragment instanceof InboxFragment) {
                        ((InboxFragment) fragment).searchProduct(0, false, query);
                    } else if (fragment instanceof AlertFragment) {
                        ((AlertFragment) fragment).getAlertList(0, false, query);
                    }

                    return true;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    return false;
                }
            });

            searchView.setOnSearchViewListener(new MaterialSearchView.SearchViewListener() {
                @Override
                public void onSearchViewShown() {
                    isSearchVisible = true;
                }

                @Override
                public void onSearchViewClosed() {

                    if (!apiCallOnSearchClose) {
                        apiCallOnSearchClose = true;
                        return;
                    }

                    Log.e(TAG, "onSearchViewClosed");

                    isSearchVisible = false;
                    if (isKeyBoardVisible) {
                        tabBar.setVisibility(View.GONE);
                    } else {
                        tabBar.setVisibility(View.VISIBLE);
                    }

                    /**
                     * For product searching
                     */
                    if (fragment instanceof ProductParentFragment) {
                        Fragment fragment1 = ((ProductParentFragment) fragment).getCurrentFragment();
                        if (fragment1 instanceof ProductFragment) {
                            ((ProductFragment) fragment1).searchProduct(0, false, "");
                            ((ProductFragment) fragment1).enableLoadMore();
                        } else if (fragment1 instanceof MyOrderFragment) {
                            ((MyOrderFragment) fragment1).getOrderHistory(0, false, "");
                            ((MyOrderFragment) fragment1).enableLoadMore();
                        }
                    }

                    /**
                     * This is used for service section
                     */
                    else if (fragment instanceof ServiceFragment) {
                        /**
                         * For open Fragment
                         */
                        if (((ServiceFragment) fragment).getCurrentFragment() instanceof OpenFragment) {
                            ((OpenFragment) ((ServiceFragment) fragment).getCurrentFragment())
                                    .searchProduct(0, false, "");
                        }

                        /**
                         * For Awarded Fragment
                         */
                        else if (((ServiceFragment) fragment).getCurrentFragment() instanceof AwardedFragment) {
                            ((AwardedFragment) ((ServiceFragment) fragment).getCurrentFragment())
                                    .searchProduct(0, false, "");
                        }
                    }

                    /**
                     * For Inbox fragment
                     */
                    else if (fragment instanceof InboxFragment) {
                        ((InboxFragment) fragment).searchProduct(0, false, "");
                    }

                    /**
                     * For Alert fragment
                     */
                    else if (fragment instanceof AlertFragment) {
                        ((AlertFragment) fragment).getAlertList(0, false, "");
                    }
                }
            });
        }
    }

    /**
     * Below methods is use for hide and show title bar and below bar
     */
    public void hideSearchButton(boolean hide) {
        if (hide) {
            searchIv.setVisibility(View.GONE);
        } else {
            searchIv.setVisibility(View.VISIBLE);
        }
    }

    public void hideBackBtn(boolean hide) {
        if (backIv != null && sliderIv != null) {
            if (hide) {
                backIv.setVisibility(View.GONE);
                sliderIv.setVisibility(View.VISIBLE);
            } else {
                backIv.setVisibility(View.VISIBLE);
                sliderIv.setVisibility(View.GONE);
            }
        }
    }

    public void hideSettingButton(boolean hide) {
        if (hide) {
            settingIv.setVisibility(View.GONE);
        } else {
            settingIv.setVisibility(View.VISIBLE);
        }
    }

    public void hideCartButton(boolean hide) {
        if (hide) {
            cartIv.setVisibility(View.GONE);
            cartCountTitleLayout.setVisibility(View.GONE);
        } else {
            cartIv.setVisibility(View.VISIBLE);
            int totalCart = SharedPrefrence.getInstance(this).readIntPrefs(SharedPrefrence.cartCount);
            if (totalCart > 0) {
                cartCountTitleLayout.setVisibility(View.VISIBLE);
                cartCountTv.setText("" + totalCart);
            } else {
                cartCountTitleLayout.setVisibility(View.GONE);
            }
        }
    }

    public void hideBelowTabBar(boolean hide) {
        if (hide) {
            tabBar.setVisibility(View.GONE);
        } else {
            tabBar.setVisibility(View.VISIBLE);
        }
    }


    /**
     * Below method is used for chat
     */
    public BroadcastReceiver getOwnMessageBroadCastRec = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            if (intent != null && intent.getExtras() != null) {

                switch (intent.getAction()) {
                    case AppConstant.UPDATE_CHAT_OWN_MSG:

                        break;

                    case AppConstant.UPDATE_CHAT_RECEIVE_MSG:
                        Utils.callOnRecivedChatMsg(intent, mContext, false, null);
                        setUnreadMsgCount();
                        break;

                    case AppConstant.UPDATE_CHAT_HISTORY:

                        break;

                    case AppConstant.REGISTRATION_COMPLETE:
                        break;

                    case AppConstant.PUSH_NOTIFICATION:
                        setAlertCount();
//                        showToastMsg(getApplicationContext(), "Push notification: " + message);
                        break;

                }
            }
        }
    };

    private void startChatReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(AppConstant.CHAT_ACTION);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(AppConstant.UPDATE_CHAT_OWN_MSG);
        intentFilter.addAction(AppConstant.UPDATE_CHAT_RECEIVE_MSG);
        intentFilter.addAction(AppConstant.UPDATE_CHAT_HISTORY);
        intentFilter.addAction(AppConstant.PUSH_NOTIFICATION);
        LocalBroadcastManager.getInstance(this).registerReceiver(getOwnMessageBroadCastRec, intentFilter);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopChatReceiver();
    }

    public void stopChatReceiver() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(getOwnMessageBroadCastRec);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == MaterialSearchView.REQUEST_VOICE && resultCode == RESULT_OK) {
            ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (matches != null && matches.size() > 0) {
                String searchWrd = matches.get(0);
                if (!TextUtils.isEmpty(searchWrd)) {
                    searchView.setQuery(searchWrd, false);
                }
            }
            return;
        } else {
            FragmentManager fragmentManager = getSupportFragmentManager();
            android.support.v4.app.Fragment fragment = fragmentManager.findFragmentById(R.id.fragment_container);
            fragment.onActivityResult(requestCode, resultCode, data);
        }

    }

    private void getNotificationStatus() {
        try {
            if (!CheckNetworkState.isOnline(mContext)) {
                showToastMsg(mContext, getString(R.string.network_error));
                return;
            }

            if (!showProgressDialog(mContext)) {
                return;
            }
            final LoginResponse.Users userDetail = Utils.readUserDetail(mContext);
            final Call<NotificationResponse> statusRequest = ((TechquiqApplication) mContext.getApplicationContext())
                    .getService().getNotificationStatus(userDetail.getUserId(),
                            Utils.getDeviceId(mContext),
                            AppConstant.FCM_ID,
                            ApiParameter.DEVICE_TYPE_VALUE
                    );

            Log.e(TAG, "Request : " + statusRequest.request().url());

            statusRequest.enqueue(new Callback<NotificationResponse>() {
                @Override
                public void onResponse(Call<NotificationResponse> call, Response<NotificationResponse> response) {
                    Log.e(TAG, "Response : " + new Gson().toJson(response.toString()));

                    if (response == null) {
                        showToastMsg(mContext, getString(R.string.server_error));
                        return;
                    }

                    NotificationResponse notificationResponse = response.body();

                    Log.e(TAG, new Gson().toJson(notificationResponse));
                    if (notificationResponse == null) {
                        return;
                    }
                    int responseStatusCode = notificationResponse.getResponseStatusCode();

                    if (responseStatusCode == AppConstant.SUCCESS) {
                        if (notificationResponse.getResponseCode() != null && notificationResponse.getResponseCode().equalsIgnoreCase("0")) {
                            showToastMsg(MainActivity.this, notificationResponse.getResponseMessage());
                            return;
                        } else if (notificationResponse.getResponseCode() != null && notificationResponse.getResponseCode().equalsIgnoreCase("1")) {
                            if (notificationResponse.getResult().getNotificationStatus().equalsIgnoreCase("ON")) {
                                SharedPrefrence.getInstance(mContext).writeBooleanPrefs(SharedPrefrence.showPreview, true);
                            } else {
                                SharedPrefrence.getInstance(mContext).writeBooleanPrefs(SharedPrefrence.showPreview, false);
                            }

                        }
                    } else {
                        showToastMsg(mContext, notificationResponse.getResponseMessage());
                    }

                }

                @Override
                public void onFailure(Call<NotificationResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                    Log.e(TAG, "Error : " + t.getMessage());
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}