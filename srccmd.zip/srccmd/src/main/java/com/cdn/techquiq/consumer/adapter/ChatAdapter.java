package com.cdn.techquiq.consumer.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.activity.ChatActivity;
import com.cdn.techquiq.consumer.database.Chat;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;

import java.util.List;

/**
 * Created by avikaljain on 22/4/17.
 */

public class ChatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<Chat> chatList;
    private Context mContext;

    public ChatAdapter(Context context, List<Chat> chatList) {
        this.mContext = context;
        this.chatList = chatList;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        final LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View root;
        switch (viewType) {
            case 1:
                root = inflater.inflate(R.layout.chat_send, parent, false);
                return new SendViewHolder(root, viewType);

            case 2:
                root = inflater.inflate(R.layout.chat_receive, parent, false);
                return new ReceiveViewHolder(root, viewType);

            default:
                return null;
        }
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {

        Chat messageBean = chatList.get(position);
        switch (holder.getItemViewType()) {
            case 1:
                SendViewHolder sendViewHolder = (SendViewHolder) holder;
                sendViewHolder.bindItem(messageBean, position);
                break;
            case 2:
                ReceiveViewHolder receiveViewHolder = (ReceiveViewHolder) holder;
                receiveViewHolder.bindItem(messageBean, position);
                break;
        }

    }

    @Override
    public int getItemViewType(int position) {
        final LoginResponse.Users userDetail = Utils.readUserDetail(mContext);
        if (chatList.get(position).getSent_by() == userDetail.getUserId()) {
            return 1;
        } else {
            return 2;
        }
    }

    class SendViewHolder extends RecyclerView.ViewHolder {


        public TextView tvChatSend;
        public TextView tvDateTimeSend;
        public ImageView ivOffline;
        public TextView tvRejected;
        public RelativeLayout relativeParent;

        public SendViewHolder(View itemView, int viewType) {
            super(itemView);
            tvChatSend = (TextView) itemView.findViewById(R.id.tvChatSend);
            tvDateTimeSend = (TextView) itemView.findViewById(R.id.tvDateTimeSend);
            ivOffline = (ImageView) itemView.findViewById(R.id.ivOffline);
            tvRejected = (TextView) itemView.findViewById(R.id.tvRejected);
            relativeParent = (RelativeLayout) itemView.findViewById(R.id.relativeParent);
        }

        public void bindItem(final Chat item, int position) {
            try {
                tvChatSend.setText(item.getMessage());
                String approveStatus = "";
                if (item.getAprove_status() == AppConstant.CHAT_APPROVED) {
                    approveStatus = mContext.getResources().getString(R.string.chat_approved);
                    tvRejected.setVisibility(View.GONE);
                } else if (item.getAprove_status() == AppConstant.CHAT_REJECTED) {
                    approveStatus = mContext.getResources().getString(R.string.chat_rejected);
                    tvRejected.setVisibility(View.VISIBLE);
                } else if (item.getAprove_status() == AppConstant.CHAT_PENDING) {
                    tvRejected.setVisibility(View.GONE);
                    approveStatus = mContext.getResources().getString(R.string.chat_sent);
                } else {
                    tvRejected.setVisibility(View.GONE);
                    approveStatus = mContext.getResources().getString(R.string.chat_pending);
                }
                String dateShow = Utils.getRequiredFormatDate(Utils.serverFormatWithZone,
                        Utils.requiredFormat, item.getDate_created()) + " " + approveStatus;
                tvDateTimeSend.setText(dateShow);
                if (item.isSent()) {
                    ivOffline.setVisibility(View.GONE);
                } else {
                    ivOffline.setVisibility(View.GONE);
                }
                RelativeLayout.LayoutParams layoutParams =
                        (RelativeLayout.LayoutParams) tvDateTimeSend.getLayoutParams();

                if (Utils.getLocale().equalsIgnoreCase("ar")) {
                    layoutParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
                    tvDateTimeSend.setLayoutParams(layoutParams);
                } else {
                    layoutParams.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
                    tvDateTimeSend.setLayoutParams(layoutParams);
                }
                ivOffline.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (CheckNetworkState.isOnline(mContext)) {
                            ((ChatActivity) mContext).showToastMsg(mContext, "Offline mode");
                            ((ChatActivity) mContext).sendOfflineMessage(item);
                        } else {
                            ((ChatActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.network_error));
                        }

                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    class ReceiveViewHolder extends RecyclerView.ViewHolder {

        public TextView tvChatReceive;
        public TextView tvDateTimeReceive;

        public ReceiveViewHolder(View itemView, int position) {
            super(itemView);
            tvChatReceive = (TextView) itemView.findViewById(R.id.tvChatReceive);
            tvDateTimeReceive = (TextView) itemView.findViewById(R.id.tvDateTimeReceive);
        }

        public void bindItem(Chat item, int position) {
            try {
                tvChatReceive.setText(item.getMessage());
                String dateShow = Utils.getRequiredFormatDate(Utils.serverFormatWithZone,
                        Utils.requiredFormat, item.getDate_created());
                tvDateTimeReceive.setText(dateShow);

                RelativeLayout.LayoutParams layoutParams =
                        (RelativeLayout.LayoutParams) tvDateTimeReceive.getLayoutParams();

                if (Utils.getLocale().equalsIgnoreCase("ar")) {
                    layoutParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
                    tvDateTimeReceive.setLayoutParams(layoutParams);
                } else {
                    layoutParams.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
                    tvDateTimeReceive.setLayoutParams(layoutParams);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public int getItemCount() {
        return chatList.size();
    }
}

