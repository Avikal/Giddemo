package com.cdn.techquiq.consumer.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.SharedPrefrence;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;
import com.google.gson.Gson;

import java.net.SocketTimeoutException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * Created by akshaysoni on 28/1/17.
 */

public class LoginActivity extends BaseActivity {

    private String TAG = LoginActivity.class.getSimpleName();

    private EditText passwordEd, usernameEd;
    private TextView registerBtn;
    private TextView forgetPasswordTxt;
    private TextView signInTv;

    private Context mContext;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mContext = this;

        setUpUI();
    }


    private void setUpUI() {
        signInTv = (TextView) findViewById(R.id.signInTv);
        passwordEd = (EditText) findViewById(R.id.passwordEt);
        usernameEd = (EditText) findViewById(R.id.usernameEt);
        forgetPasswordTxt = (TextView) findViewById(R.id.forgetPasswordTxt);
        registerBtn = (TextView) findViewById(R.id.registerBtn);

        forgetPasswordTxt.setOnClickListener(this);
        registerBtn.setOnClickListener(this);
        signInTv.setOnClickListener(this);
    }

    private long mLastClickTime = 0;

    public void onClick(View view) {

        if (SystemClock.elapsedRealtime() - mLastClickTime < 1000) {
            return;
        }
        mLastClickTime = SystemClock.elapsedRealtime();

        switch (view.getId()) {

            case R.id.forgetPasswordTxt:
                Intent fIntent = new Intent(this, ForgetPasswordActivity.class);
                startActivity(fIntent);
                break;
            case R.id.signInTv:
                String email = usernameEd.getText().toString();
                String password = passwordEd.getText().toString();
                if (isValidate(email, password)) {
                    doLogin(email, password);
                }
                break;
            case R.id.registerBtn:
                Intent regIntent = new Intent(this, RegistrationActivity.class);
                startActivity(regIntent);
                break;
        }
    }


    private boolean isValidate(String email, String password) {
        if (email.isEmpty()) {
            showToastMsg(mContext, mContext.getString(R.string.enter_email));
            return false;
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            showToastMsg(mContext, mContext.getString(R.string.enter_valid_email));
            return false;
        } else if (password.isEmpty()) {
            showToastMsg(mContext, mContext.getString(R.string.enter_password));
            return false;
        } else {
            return true;
        }
    }


    private void doLogin(String email, String password) {
        try {
            String sEncoded = Utils.encodeString(email);
            if (!CheckNetworkState.isOnline(mContext)) {
                showToastMsg(mContext, getString(R.string.network_error));
                return;
            }

            if (!showProgressDialog(mContext)) {
                return;
            }
            AppConstant.FCM_ID = SharedPrefrence.getInstance(mContext).readPrefs(SharedPrefrence.pushToken);
            final Call<LoginResponse> loginRequest = ((TechquiqApplication) mContext.getApplicationContext())
                    .getService().loginService(sEncoded,
                            password,
                            Utils.getDeviceId(mContext),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID);

            Log.e(TAG, "Request : " + loginRequest.request().url());

            loginRequest.enqueue(new Callback<LoginResponse>() {
                @Override
                public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                    Log.e(TAG, "Response : " + new Gson().toJson(response.toString()));

                    if (response == null) {
                        showToastMsg(mContext, getString(R.string.server_error));
                        return;
                    }

                    loginResponse(response);
                }

                @Override
                public void onFailure(Call<LoginResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                    Log.e(TAG, "Error : " + t.getMessage());
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loginResponse(Response<LoginResponse> response) {

        hideProgressDialog();

        if (response == null) {
            showToastMsg(mContext, getString(R.string.server_error));
            return;
        }

        LoginResponse loginResponse = response.body();
        Log.e(TAG, new Gson().toJson(loginResponse));
        if (loginResponse == null) {
            showToastMsg(mContext, getString(R.string.server_error));
            return;
        }
        int responseStatusCode = loginResponse.getResponseStatusCode();
        if (responseStatusCode == AppConstant.PARAM_MISSING) {
            showToastMsg(mContext, getString(R.string.ws_param_missing));
        } else if (responseStatusCode == AppConstant.UNAUTHORIZED_USER) {
            showToastMsg(mContext, getString(R.string.ws_unauthorized_user));
        } else if (responseStatusCode == AppConstant.WRONG_CREDENTIALS) {
            showToastMsg(mContext, getString(R.string.ws_wrong_credaintial));
        } else if (responseStatusCode == AppConstant.SUCCESS) {
            if (loginResponse.getResponseCode() != null && loginResponse.getResponseCode().equalsIgnoreCase("0")) {
                showToastMsg(LoginActivity.this, loginResponse.getResponseMessage());
                return;
            } else if (loginResponse.getResponseCode() != null && loginResponse.getResponseCode().equalsIgnoreCase("1")) {
                SharedPrefrence.getInstance(mContext).writeBooleanPrefs(SharedPrefrence.sound, true);
                SharedPrefrence.getInstance(mContext).writeBooleanPrefs(SharedPrefrence.isLoggedIn, true);
                Utils.writeUserDetail(mContext, loginResponse.getResult());
                SharedPrefrence.getInstance(mContext)
                        .writeIntPrefs(SharedPrefrence.cartCount, loginResponse.getResult().getTotalCart());
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        } else {
            showToastMsg(mContext, loginResponse.getResponseMessage());
        }
    }

}
