package com.cdn.techquiq.consumer.model;

import com.cdn.techquiq.consumer.Utils.Utils;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by avikaljain on 10/4/17.
 */

public class SubCategoriesResponse extends BaseResponse {

    @SerializedName("Result")
    private ArrayList<SubCategory> subCategoriesList;

    public ArrayList<SubCategory> getSubCategoriesList() {
        return subCategoriesList;
    }

    public void setSubCategoriesList(ArrayList<SubCategory> subCategoriesList) {
        this.subCategoriesList = subCategoriesList;
    }

    public class SubCategory implements Serializable {
        @SerializedName("id")
        private String id;

        @SerializedName("name_en")
        private String name_en;

        @SerializedName("name_ar")
        private String name_ar;

        @SerializedName("description_en")
        private String description_en;

        @SerializedName("description_ar")
        private String description_ar;

        public String getName_en() {
            return name_en;
        }

        public void setName_en(String name_en) {
            this.name_en = name_en;
        }

        public String getName_ar() {

            return name_ar;
        }

        public void setName_ar(String name_ar) {
            this.name_ar = name_ar;
        }

        public String getId() {

            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getDescription_en() {

            return description_en;
        }

        public void setDescription_en(String description_en) {
            this.description_en = description_en;
        }

        public String getDescription_ar() {

            return description_ar;
        }

        public void setDescription_ar(String description_ar) {
            this.description_ar = description_ar;
        }

        public String getDescription() {
            if (Utils.getLocale().equalsIgnoreCase("ar")) {
                return getDescription_ar();
            } else {
                return getDescription_en();
            }
        }

        public String getName() {
            if (Utils.getLocale().equalsIgnoreCase("ar")) {
                return getName_ar();
            } else {
                return getName_en();
            }
        }
    }
}
