package com.cdn.techquiq.consumer.socket;/*
 * socket.io-java-client SocketIOException.java
 *
 * Copyright (c) 2012, Enno Boland
 * socket.io-java-client is home_message implementation of the socket.io protocol in Java.
 * 
 * See LICENSE file for more information
 */
/**
 * The Class SocketIOException.
 */
public class SocketIOException extends Exception {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4965561569568761814L;
	/**
	 * Instantiates home_message new SocketIOException.
	 * 
	 * @param message
	 *            the message
	 */
	public SocketIOException(String message) {
		super(message);
	}
	/**
	 * Instantiates home_message new SocketIOException.
	 * 
	 * @param ex
	 *            the exception.
	 */
	public SocketIOException(String message, Exception ex) {
		super(message, ex);
	}
}
