package com.cdn.techquiq.consumer.socket;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.SystemClock;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.activity.ChatActivity;
import com.cdn.techquiq.consumer.database.Chat;
import com.cdn.techquiq.consumer.database.DBHelper;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.ReceiveMessageBean;
import com.cdn.techquiq.consumer.netcomm.NodeCommunicator;
import com.google.gson.Gson;

import org.json.JSONObject;

import java.util.List;

/**
 * Created by avikaljain on 28/4/17.
 */

public class MessageService extends Service {

    public NodeCommunicator socketClass;
    private String TAG = MessageService.class.getSimpleName();
    private String merchantId;
    private String serviceId;
    private DBHelper dbHelper;
    private Bitmap icon;
    private NotificationCompat.Builder notificationBuilder;
    private NotificationManager notificationManager;
    private int currentNotificationID = 0;
    private CountDownTimer countDownTimer;
    private String merchantName;
    private String serviceName;
    private String awardStatus;
    private int NODE_CONNECTION_CHECK = 15000;

    Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case SocketIOManager.SOCKETIO_CONNECT:
                    final LoginResponse.Users userDetail = Utils.readUserDetail(getApplicationContext());
                    if (userDetail == null) {
                        return;
                    }


                    NodeCommunicator.getInstance().joinChatServer(String.valueOf(userDetail.getUserId()));

                    Intent intentHistory = new Intent();
                    intentHistory.putExtra("merchantId", merchantId);
                    intentHistory.putExtra("serviceId", serviceId);
                    intentHistory.setAction(AppConstant.UPDATE_CHAT_HISTORY);
                    LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(intentHistory);
                    break;

                case SocketIOManager.SOCKETIO_DISCONNECT:

                    break;

                case SocketIOManager.SOCKETIO_ERROR:

                    break;

                case SocketIOManager.SOCKETIO_MESSAGE_RECEIVE:
                    Intent intentReceive = new Intent();
                    intentReceive.setAction(AppConstant.UPDATE_CHAT_RECEIVE_MSG);
                    intentReceive.putExtra("bean", msg.obj.toString());

                    Gson gsonReceive = new Gson();
                    ReceiveMessageBean message2 = gsonReceive.fromJson(msg.obj.toString(), ReceiveMessageBean.class);
                    Log.d(TAG, message2.getMessage());

                    merchantId = message2.getSent_by();
                    serviceId = message2.getService_id();
                    merchantName = message2.getMerchant_first_name() + " " + message2.getMerchant_last_name();
                    serviceName = message2.getService_name();
                    awardStatus = message2.getAward_status();

                    Chat chat = new Chat();
                    chat.setMessage(message2.getMessage());
                    chat.setSent_by(Integer.parseInt(message2.getSent_by()));
                    chat.setSent_to(Integer.parseInt(message2.getSent_to()));
                    chat.setService_id(serviceId);
                    chat.setMerchant_id(merchantId);
                    chat.setDate_created(message2.getDate_created());
                    chat.setTimestamp(message2.getTimestamp());
                    chat.setAprove_status(message2.getAprove_status());
                    chat.setMsg_unique_id(message2.getMsg_unique_id());
                    chat.setId(message2.getId());
                    chat.setAprove_status(message2.getAprove_status());
                    chat.setReadMsg(false);
                    chat.setSent(true);
                    dbHelper.insertChatHistory(chat);

                    setDataForMaxPriorityNotification(message2.getMessage());
                    LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(intentReceive);
                    break;


                case SocketIOManager.SOCKETIO_RECVIE_OWNMSG:

                    Intent intent = new Intent();
                    intent.setAction(AppConstant.UPDATE_CHAT_OWN_MSG);
                    intent.putExtra("bean", msg.obj.toString());

                    LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(intent);
                    break;
            }
        }
    };


    public void countdownForConnection() {
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        countDownTimer = new CountDownTimer(30000, NODE_CONNECTION_CHECK) {
            public void onTick(long millisUntilFinished) {
                checkIsConnectedOrNot();
            }

            public void onFinish() {
                countDownTimer.start();
            }
        }.start();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        socketClass = NodeCommunicator.getInstance();
        dbHelper = DBHelper.getInstance(MessageService.this);
        icon = BitmapFactory.decodeResource(this.getResources(),
                R.drawable.ic_launcher);
        notificationManager = (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE);
        countdownForConnection();
    }

    private boolean isNodeConnected;

    public void checkIsConnectedOrNot() {
        if (socketClass != null) {
            if (socketClass.isConnected()) {
                Log.d(TAG, "Node Connected");
                sendMsgToServer(this);
                isNodeConnected = true;
            } else {
                Log.d(TAG, "Node DISCONNECTED");
                connectToServer();
                isNodeConnected = false;
            }
        }

    }

    private void sendMsgToServer(final Context context) {

        if (!isNodeConnected) {
            List<Chat> offlineMessage = DBHelper.getInstance(context).getOfflineMessage();
            if (offlineMessage != null) {
                for (int i = 0; i < offlineMessage.size(); i++) {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("message", offlineMessage.get(i).getMessage());
                        jsonObject.put("sent_to", offlineMessage.get(i).getMerchant_id());
                        jsonObject.put("sent_by", offlineMessage.get(i).getSent_by());
                        jsonObject.put("service_id", offlineMessage.get(i).getService_id());
                        jsonObject.put("timestamp", offlineMessage.get(i).getTimestamp());
                        jsonObject.put("msg_unique_id", offlineMessage.get(i).getMsg_unique_id());
                        jsonObject.put("date_created", offlineMessage.get(i).getDate_created());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    Log.e(TAG, jsonObject.toString());
                    NodeCommunicator.getInstance().sendMessageToNode(1, jsonObject, context);
                }
            }
        }

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        if (intent != null) {
            if (intent.getExtras() != null) {
                if (intent.getExtras().getString("START").equalsIgnoreCase("START")) {
                    countdownForConnection();
                }
            }
        }
        return START_STICKY;
    }

    public void connectToServer() {
        socketClass.disconnectToServer();
        NodeCommunicator.getInstance().connectToServer(mHandler);
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        Intent restartServiceIntent = new Intent(TechquiqApplication.getAppInstance().getApplicationContext(), this.getClass());
        restartServiceIntent.setPackage(getPackageName());
        restartServiceIntent.putExtra("START", "START");
        PendingIntent restartServicePendingIntent = PendingIntent.getService(TechquiqApplication.getAppInstance().getApplicationContext(), 1, restartServiceIntent, PendingIntent.FLAG_ONE_SHOT);
        AlarmManager alarmService = (AlarmManager) getApplicationContext().getSystemService(Context.ALARM_SERVICE);
        alarmService.set(
                AlarmManager.ELAPSED_REALTIME,
                SystemClock.elapsedRealtime() + 1000,
                restartServicePendingIntent);
    }


    private void setDataForMaxPriorityNotification(String message) {
        notificationBuilder = new NotificationCompat.Builder(this)
                .setSmallIcon(getNotificationIcon())
                .setLargeIcon(icon)
                .setContentTitle(getResources().getString(R.string.app_name))
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(Notification.PRIORITY_MAX)
                .setContentText(message);

        sendNotification();
    }

    private void sendNotification() {
        Intent notificationIntent = new Intent(this, ChatActivity.class);
        notificationIntent.putExtra("merchantId", merchantId);
        notificationIntent.putExtra("serviceId", serviceId);
        notificationIntent.putExtra("merchantName", merchantName);
        notificationIntent.putExtra("awardStatus", awardStatus);
        notificationIntent.putExtra("title", serviceName);
        notificationIntent.putExtra("notification", true);
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        notificationBuilder.setContentIntent(contentIntent);
        Notification notification = notificationBuilder.build();
        notification.flags |= Notification.FLAG_AUTO_CANCEL;
        notification.defaults |= Notification.DEFAULT_SOUND;

        currentNotificationID++;
        int notificationId = currentNotificationID;
        if (notificationId == Integer.MAX_VALUE - 1)
            notificationId = 0;

        dbHelper.insertNotificationType(merchantId, notificationId, AppConstant.CHAT_NOTIFICATION);
        notificationManager.notify(notificationId, notification);
    }

    private int getNotificationIcon() {
        boolean useWhiteIcon = (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP);
        return useWhiteIcon ? R.drawable.icon_silhouette : R.drawable.ic_launcher;
    }
}
