package com.cdn.techquiq.consumer.model;

/**
 * Created by kajalsoni on 6/2/17.
 */

public class commonResponse {

    String name, description, time,proposalcount;

    public String getProposalcount() {
        return proposalcount;
    }

    public void setProposalcount(String proposalcount) {
        this.proposalcount = proposalcount;
    }

    public commonResponse(String name, String description, String time, String proposalcount) {
        this.name = name;
        this.description = description;
        this.time = time;
        this.proposalcount = proposalcount;
    }

    public commonResponse(String name, String description, String time) {
        this.name = name;
        this.description = description;
        this.time = time;


    }

    public String getName() {

        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
