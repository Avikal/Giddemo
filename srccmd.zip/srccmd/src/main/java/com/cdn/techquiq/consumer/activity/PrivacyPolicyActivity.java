package com.cdn.techquiq.consumer.activity;

import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.model.UrlResponse;

/**
 * Created by avikaljain on 8/6/17.
 */

public class PrivacyPolicyActivity extends BaseActivity {
    private ImageView backIv;
    private TextView titleTv;
    private ProgressDialog progressDialog;
    private Bundle bundle;
    private String title;
    private String loadUrl;
    private int position;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.privacy_policy_activity);
        bundle = getIntent().getExtras();
        if (bundle != null) {
            position = bundle.getInt("position");
        }
        setUpUI();

    }

    private void setUpUI() {

        if (position == 6) {
            title = mContext.getResources().getString(R.string.txt_aboutUs_title);
            loadUrl = UrlResponse.getAboutUs();
        } else if (position == 7) {
            title = mContext.getResources().getString(R.string.txt_privacy_policy);
            loadUrl = UrlResponse.getPrivacy();
        } else if (position == 8) {
            title = mContext.getResources().getString(R.string.txt_faq);
            loadUrl = UrlResponse.getFAQ();
        } else if (position == 1) {
            title = mContext.getResources().getString(R.string.terms_and_condition);
            loadUrl = UrlResponse.getTAC();
        }
        backIv = (ImageView) findViewById(R.id.backIv);
        backIv.setOnClickListener(this);
        titleTv = (TextView) findViewById(R.id.titleTv);
        titleTv.setText(title);


        try {
            WebView wv = (WebView) findViewById(R.id.webView);
            wv.setWebViewClient(new MyBrowser());
            wv.getSettings().setLoadsImagesAutomatically(true);
            wv.getSettings().setJavaScriptEnabled(true);
            wv.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
            progressDialog = new ProgressDialog(PrivacyPolicyActivity.this,
                    R.style.AppTheme_Dark_Dialog);
            progressDialog.setIndeterminate(true);
            progressDialog.setMessage("Loading...");
            progressDialog.show();
//            String pdfUrl = "http://196.192.9.131/Admin//UploadAssets/PDFFile/GlobalisationTermsandConditions.pdf";
            wv.loadUrl(loadUrl);

        } catch (Exception e) {

        }
    }

    public void onResume() {
        super.onResume();

    }

    private class MyBrowser extends WebViewClient {
        boolean timeout;

        public MyBrowser() {
            timeout = true;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            // TODO Auto-generated method stub
            super.onPageStarted(view, url, favicon);
            progressDialog.show();
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
//            progressBar.setVisibility(View.VISIBLE);
            view.loadUrl(url);
            return true;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            // TODO Auto-generated method stub
            super.onPageFinished(view, url);
            if (progressDialog.isShowing()) {
                progressDialog.dismiss();
            }
//            progressBar.setVisibility(View.GONE);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.backIv:
                finish();
                break;

        }
    }
}
