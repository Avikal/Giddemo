package com.cdn.techquiq.consumer.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by avikaljain on 7/4/17.
 */

public class UserResponse extends BaseResponse implements Serializable {

    @SerializedName("Result")
    private ArrayList<UserInfo> userInfo;

    public ArrayList<UserInfo> getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(ArrayList<UserInfo> userInfo) {
        this.userInfo = userInfo;
    }

    public class UserInfo implements Serializable {

        @SerializedName("id")
        private String id;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        @SerializedName("award_status")
        public String awardStatus;

        public String getAwardStatus() {
            return awardStatus;
        }

        public void setAwardStatus(String awardStatus) {
            this.awardStatus = awardStatus;
        }

        @SerializedName("name")
        private String name;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        @SerializedName("description")
        private String description;

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        @SerializedName("total_proposal")
        private String total_proposal;

        public String getTotal_proposal() {
            return total_proposal;
        }

        public void setTotal_proposal(String total_proposal) {
            this.total_proposal = total_proposal;
        }

        @SerializedName("proposal_data")
        private ArrayList<UserImage> userImages;

        public ArrayList<UserImage> getUserImages() {
            return userImages;
        }

        public void setUserImages(ArrayList<UserImage> userImages) {
            this.userImages = userImages;
        }

        public class UserImage implements Serializable {

            @SerializedName("user_id")
            private String user_id;

            public String getUser_id() {
                return user_id;
            }

            public void setUser_id(String user_id) {
                this.user_id = user_id;
            }

            @SerializedName("first_name")
            private String first_name;

            public String getFirst_name() {
                return first_name;
            }

            public void setFirst_name(String first_name) {
                this.first_name = first_name;
            }

            @SerializedName("last_name")
            private String last_name;

            public String getLast_name() {
                return last_name;
            }

            public void setLast_name(String last_name) {
                this.last_name = last_name;
            }

            @SerializedName("image")
            private String image;

            public String getImage() {
                return image;
            }

            public void setImage(String image) {
                this.image = image;
            }

            @SerializedName("bid_id")
            private String bidId;

            public String getBidId() {
                return bidId;
            }

            public void setBidId(String bidId) {
                this.bidId = bidId;
            }
        }
    }

}