package com.cdn.techquiq.consumer.adapter;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.model.FilterResponse;

import java.util.HashMap;
import java.util.List;

/**
 * Created by akshaysoni on 29/1/16.
 */
public class FilterListAdapter extends BaseExpandableListAdapter {

    private Context _context;
    private List<FilterResponse.FilterResult> _listDataHeader;
    private HashMap<FilterResponse.FilterResult, List<FilterResponse.FilterResult.Items>> _listDataChild;
    private ExpandableListView expandableListView;

    public FilterListAdapter(ExpandableListView exList, Context context, List<FilterResponse.FilterResult> listDataHeader,
                             HashMap<FilterResponse.FilterResult, List<FilterResponse.FilterResult.Items>> listChildData) {
        this.expandableListView = exList;
        this._context = context;
        this._listDataHeader = listDataHeader;
        this._listDataChild = listChildData;
    }

    @Override
    public Object getChild(int groupPosition, int childPosititon) {
        return this._listDataChild.get(this._listDataHeader.get(groupPosition)).get(childPosititon);
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public View getChildView(final int groupPosition, final int childPosition,
                             boolean isLastChild, View convertView, ViewGroup parent) {

        final FilterResponse.FilterResult.Items filterItem = (FilterResponse.FilterResult.Items) getChild(groupPosition, childPosition);

        if (convertView == null) {
            LayoutInflater infalInflater = (LayoutInflater) this._context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = infalInflater.inflate(R.layout.list_item, null);
        }
        LinearLayout linearLayout = (LinearLayout) convertView.findViewById(R.id.lblListItem);
        TextView tvFilter = (TextView) convertView.findViewById(R.id.tvFilter);
        ImageView ivCheckBox = (ImageView) convertView.findViewById(R.id.ivCheckBox);
        tvFilter.setText(filterItem.getName());
        if (filterItem.isSelected()) {
            Drawable img = _context.getResources().getDrawable(R.drawable.fill_check_box);
            ivCheckBox.setImageDrawable(img);
        } else {
            Drawable img = _context.getResources().getDrawable(R.drawable.blank_check_box);
            ivCheckBox.setImageDrawable(img);
        }


        return convertView;
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        if (this._listDataChild.get(this._listDataHeader.get(groupPosition)) != null) {
            return this._listDataChild.get(this._listDataHeader.get(groupPosition)).size();
        } else {
            return 0;
        }
    }

    @Override
    public Object getGroup(int groupPosition) {
        return this._listDataHeader.get(groupPosition);
    }

    @Override
    public int getGroupCount() {
        return this._listDataHeader.size();
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded,
                             View convertView, ViewGroup parent) {
        expandableListView.expandGroup(groupPosition);
        FilterResponse.FilterResult filterGroup = (FilterResponse.FilterResult) getGroup(groupPosition);
        if (convertView == null) {
            LayoutInflater infalInflater = (LayoutInflater) this._context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = infalInflater.inflate(R.layout.list_group, null);
        }

        TextView lblListHeader = (TextView) convertView
                .findViewById(R.id.lblListHeader);
        lblListHeader.setTypeface(null, Typeface.BOLD);
        lblListHeader.setText(filterGroup.getFilter_name());

        return convertView;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

    public void notifyData() {
        this.notifyDataSetChanged();
    }
}
