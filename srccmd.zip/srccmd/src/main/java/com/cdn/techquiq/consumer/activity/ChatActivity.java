package com.cdn.techquiq.consumer.activity;

import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.NotificationUtils;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.adapter.ChatAdapter;
import com.cdn.techquiq.consumer.database.Chat;
import com.cdn.techquiq.consumer.database.DBHelper;
import com.cdn.techquiq.consumer.database.Notification;
import com.cdn.techquiq.consumer.model.BidDetailResponse;
import com.cdn.techquiq.consumer.model.ChatHistoryResponse;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.SendOwnMessageBean;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;
import com.cdn.techquiq.consumer.netcomm.NodeCommunicator;
import com.google.gson.Gson;

import org.json.JSONObject;

import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * Created by akshaysoni on 22/4/17.
 */
public class ChatActivity extends BaseActivity implements View.OnClickListener {

    private String TAG = ChatActivity.class.getSimpleName();

    public String chatMessage;
    public Context mContext;
    private NodeCommunicator nodeCommunicator;
    private RecyclerView rvChatList;
    private List<Chat> chatHistoryList;
    private ChatAdapter chatAdapter;
    private EditText etChatType;
    private ImageView ivSend;
    private DBHelper dbHelper;
    private Bundle bundle;
    private String userId;
    private String merchantId;
    private String serviceId;
    private SwipeRefreshLayout swipeLayout;
    private ImageView backIv;
    private TextView titleTv;
    private String merchantName;
    private String merchantImage;
    public static String awardStatus;
    private boolean notify;
    private CircleImageView iVProfile1;
    private TextView tVName;
    private TextView tVAward;
    private String title;
    private LinearLayout rlChat;
    private boolean isKeyBoardVisible;
    private String bidId;
    private Dialog dialog;


    /**
     * Chat variable
     */
    private long pageLimit = AppConstant.CHAT_LIMIT;
    private int pageNumber = 0;
    private String totalAmount;


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        bundle = getIntent().getExtras();
        mContext = this;
        nodeCommunicator = NodeCommunicator.getInstance();
        dbHelper = DBHelper.getInstance(mContext);

        if (bundle != null) {
            merchantId = bundle.getString("merchantId");
            serviceId = bundle.getString("serviceId");
            notify = bundle.getBoolean("notification");

            merchantImage = bundle.getString("merchantImage");
            merchantName = bundle.getString("merchantName");
            awardStatus = bundle.getString("awardStatus");
            title = bundle.getString("title");

            totalAmount = bundle.getString("totalAmount");
            bidId = bundle.getString("bidId");
            if (title != null) {
                title = Utils.decodeString(title);
            } else {
                title = getResources().getString(R.string.app_name);
            }

        }

        setUpUI();

        startChatReciver();

        getMessages();
        /**
         * Remove notification from notification tray using notification type and id
         */
        List<Notification> chatNotification = dbHelper.getChatNotification();
        for (int i = 0; i < chatNotification.size(); i++) {
            NotificationUtils.clearNotifications(mContext, chatNotification.get(i).notificationId);
            dbHelper.removeReadNotification(chatNotification.get(i).notificationId);
        }
    }

    private void setUpUI() {
        LoginResponse.Users userDetail = Utils.readUserDetail(this);
        userId = String.valueOf(userDetail.getUserId());
        titleTv = (TextView) findViewById(R.id.titleTv);
        titleTv.setText(title);

        backIv = (ImageView) findViewById(R.id.backIv);
        swipeLayout = (SwipeRefreshLayout) findViewById(R.id.swipeLayout);
        rvChatList = (RecyclerView) findViewById(R.id.rvChatList);
        etChatType = (EditText) findViewById(R.id.etChatType);
        ivSend = (ImageView) findViewById(R.id.ivSend);
        tVAward = (TextView) findViewById(R.id.tVAward);
        rlChat = (LinearLayout) findViewById(R.id.rlChat);
        iVProfile1 = (CircleImageView) findViewById(R.id.iVProfile1);
        tVName = (TextView) findViewById(R.id.tVName);
        tVName.setText(merchantName);

        ivSend.setOnClickListener(this);
        backIv.setOnClickListener(this);
        tVAward.setOnClickListener(this);

        setMerchantProfileImage();
        swipeLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getMessages();
            }
        });
    }

    private void setMerchantProfileImage() {
        Glide.with(mContext).load(merchantImage).asBitmap().centerCrop()
                .placeholder(R.drawable.profile_img)
                .error(R.drawable.profile_img)
                .into(iVProfile1);
    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.ivSend:
                String str = "";
                if (etChatType.getText().toString() != null) {
                    str = etChatType.getText().toString().trim();
                }
                if (!str.equalsIgnoreCase("") && !str.isEmpty()) {
                    chatMessage = etChatType.getText().toString();
                    sendMessages();
                }
                break;
            case R.id.backIv:
                if (notify) {
                    Intent main = new Intent(ChatActivity.this, MainActivity.class);
                    startActivity(main);
                    notify = false;
                }

                finish();
                break;

            case R.id.tVAward:
                awardDialog();
                break;
        }
    }

    private void getChatFromWebService() {

        if (!CheckNetworkState.isOnline(mContext)) {
            showToastMsg(mContext, getString(R.string.network_error));
            swipeLayout.setRefreshing(false);
            return;
        }

        showProgressDialog(mContext);

        try {
            final Call<ChatHistoryResponse> chatHistoryRequest = ((TechquiqApplication) this
                    .getApplicationContext()).getService().getHistoryChat(
                    merchantId,
                    String.valueOf(userId),
                    serviceId,
                    Utils.getDeviceId(this),
                    AppConstant.FCM_ID,
                    ApiParameter.DEVICE_TYPE_VALUE,
                    pageLimit,
                    pageNumber);

            Log.e(TAG, "Request : " + chatHistoryRequest.request().url());

            chatHistoryRequest.enqueue(new Callback<ChatHistoryResponse>() {

                @Override
                public void onResponse(Call<ChatHistoryResponse> call, Response<ChatHistoryResponse> response) {

                    hideProgressDialog();

                    Log.e(TAG, "Response : " + new Gson().toJson(response.body()));

                    ChatHistoryResponse chatHistoryResponse = response.body();

                    if (chatHistoryResponse != null && chatHistoryResponse.getChats() != null) {

                        if (chatHistoryResponse.getResponseCode().equalsIgnoreCase("0")) {

                            swipeLayout.setRefreshing(false);

                            getChatFromDb();

                        } else {

                            /**
                             * Insert into database
                             */
                            for (int i = 0; i < chatHistoryResponse.getChats().size(); i++) {
                                chatHistoryResponse.getChats().get(i).setService_id(serviceId);
                                chatHistoryResponse.getChats().get(i).setMerchant_id(merchantId);
                                chatHistoryResponse.getChats().get(i).setReadMsg(true);
                                chatHistoryResponse.getChats().get(i).setSent(true);
                                dbHelper.insertChatHistory(chatHistoryResponse.getChats().get(i));
                            }

                            getChatFromDb();
                        }

                    } else {

                        getChatFromDb();

                    }
                }

                @Override
                public void onFailure(Call<ChatHistoryResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            hideProgressDialog();
            e.printStackTrace();
        }
    }

    private void awardDialog() {
        // custom dialog
        dialog = new Dialog(mContext, R.style.Theme_Dialog);
        RatingBar ratingBar;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_award);
        dialog.show();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        // set the custom dialog components - text, image and button
        final TextView tvYes = (TextView) dialog.findViewById(R.id.tvYes);
        final TextView tvCancel = (TextView) dialog.findViewById(R.id.tvCancel);
        TextView tvAwardMsg = (TextView) dialog.findViewById(R.id.tvAwardMsg);

        tvAwardMsg.setText(getResources().getString(R.string.award_dialog_msg, merchantName));

        tvYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getBidDetail();

            }

        });
        tvCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }

        });

    }

    private void getBidDetail() {
        showProgressDialog(this);
        try {
            final LoginResponse.Users userDetail = Utils.readUserDetail(this);
            final Call<BidDetailResponse> bidServiceRequest = ((TechquiqApplication) this
                    .getApplicationContext()).getService().getBid(
                    userDetail.getUserId(),
                    Utils.getDeviceId(this),
                    AppConstant.FCM_ID,
                    ApiParameter.DEVICE_TYPE_VALUE,
                    bidId);

            Log.e(TAG, "Request : " + bidServiceRequest.request().url());

            bidServiceRequest.enqueue(new Callback<BidDetailResponse>() {
                @Override
                public void onResponse(Call<BidDetailResponse> call, Response<BidDetailResponse> response) {
                    hideProgressDialog();
                    if (response == null) {
                        return;
                    }
                    Log.e(TAG, response.toString());

                    BidDetailResponse bidResponse = response.body();

                    if (bidResponse == null) {
                        showToastMsg(mContext, getResources().getString(R.string.server_error));
                        return;
                    }
                    Log.e(TAG, "Response : " + new Gson().toJson(bidResponse));
                    if (bidResponse.getResponseCode() != null && bidResponse.getResponseCode().equalsIgnoreCase("0")) {
                        showToastMsg(ChatActivity.this, bidResponse.getResponseMessage());
                    } else {
                        dialog.dismiss();
                        ArrayList<BidDetailResponse.BidDetail> bidDetailResponses = bidResponse.getBidDetail();

                        Intent intent = new Intent(mContext, ChoosePaymentOptionActivity.class);
                        intent.putExtra("serviceId", bidDetailResponses.get(0).getServiceId());
                        intent.putExtra("merchantId", bidDetailResponses.get(0).getMerchantId());
                        intent.putExtra("bidId", bidDetailResponses.get(0).getBidId());
                        intent.putExtra("primaryDescription", title);
                        intent.putExtra("totalAmount", bidDetailResponses.get(0).getServicePrice());
                        intent.putExtra("shippingAddress", bidDetailResponses.get(0).getUserAddress());
                        startActivity(intent);
                        //tVAward.setVisibility(View.GONE);
                    }

                }

                @Override
                public void onFailure(Call<BidDetailResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void sendOfflineMessage(Chat chat) {
        JSONObject jsonObject = new JSONObject();

        try {
            jsonObject.put("message", chat.getMessage());
            jsonObject.put("sent_to", chat.getMerchant_id());
            jsonObject.put("sent_by", chat.getSent_by());
            jsonObject.put("service_id", chat.getService_id());
            jsonObject.put("timestamp", chat.getTimestamp());
            jsonObject.put("msg_unique_id", chat.getMsg_unique_id());
            //jsonObject.put("date_created", currentDateandTime);
            etChatType.setText("");
        } catch (Exception e) {
            e.printStackTrace();
        }

        Log.e(TAG, jsonObject.toString());

        nodeCommunicator.sendMessageToNode(1, jsonObject, this);
    }

    private void sendMessages() {
        Chat chat = new Chat();
        chat.setMessage(chatMessage.trim());
        chat.setSent_by(Integer.parseInt(userId));
        chat.setSent_to(Integer.parseInt(merchantId));
        chat.setService_id(serviceId);
        chat.setMerchant_id(merchantId);
        chat.setSent(false);
        String uniqueId = Utils.getUniqueId();
        chat.setMsg_unique_id(uniqueId);
        chat.setReadMsg(true);
        chat.setAprove_status(AppConstant.CHAT_PENDING);

        /**
         * Set created date and timestamp from the below
         */
        Date date = new Date();
        String utcDate = Utils.getDateInUTC(Utils.serverFormatWithZone, date);
        chat.setDate_created(utcDate);
        chat.setTimestamp(date.getTime());

        dbHelper.insertChatHistory(chat);

        String localDate = Utils.getRequiredFormatDate(Utils.serverFormatWithZone,
                Utils.requiredFormat, utcDate);
        chat.setDate_created(utcDate);
        chatHistoryList.add(chat);

        setAdapter();

        JSONObject jsonObject = new JSONObject();

        try {
            String messageSend = etChatType.getText().toString();
            jsonObject.put("message", messageSend);
            jsonObject.put("sent_to", merchantId);
            jsonObject.put("sent_by", userId);
            jsonObject.put("service_id", serviceId);
            jsonObject.put("timestamp", date.getTime());
            jsonObject.put("msg_unique_id", uniqueId);
            jsonObject.put("date_created", utcDate);
            etChatType.setText("");
        } catch (Exception e) {
            e.printStackTrace();
        }

        Log.e(TAG, jsonObject.toString());

        nodeCommunicator.sendMessageToNode(1, jsonObject, this);
    }

    public BroadcastReceiver getOwnMessageBroadCastRec = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            if (intent != null && intent.getExtras() != null) {

                switch (intent.getAction()) {
                    case AppConstant.UPDATE_CHAT_OWN_MSG:
                        String msg = intent.getExtras().getString("bean");
                        Gson gson = new Gson();
                        SendOwnMessageBean message1 = gson.fromJson(msg, SendOwnMessageBean.class);
                        if (message1.getResponseCode().equalsIgnoreCase("1")) {
                            dbHelper.updateChatHistoryMsg(message1.getChat());
                            rvChatList.scrollToPosition(chatAdapter.getItemCount() - 1);
                        } else {
                            Log.e(TAG, message1.getResponseMessage());
                        }
                        break;

                    case AppConstant.UPDATE_CHAT_RECEIVE_MSG:
                        try {
                            Utils.callOnRecivedChatMsg(intent, mContext, false, chatHistoryList);
                            rvChatList.scrollToPosition(chatAdapter.getItemCount() - 1);
                        } catch (Exception e) {
                            e.printStackTrace();
                            break;
                        }
                        break;
                }
            }
        }
    };


    private void startChatReciver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(AppConstant.CHAT_ACTION);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(AppConstant.UPDATE_CHAT_OWN_MSG);
        intentFilter.addAction(AppConstant.UPDATE_CHAT_RECEIVE_MSG);
        intentFilter.addAction(AppConstant.UPDATE_CHAT_HISTORY);
        LocalBroadcastManager.getInstance(this).registerReceiver(getOwnMessageBroadCastRec, intentFilter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(getOwnMessageBroadCastRec);
    }

    private void getMessages() {
        if (CheckNetworkState.isOnline(mContext)) {
            getChatFromWebService();
        } else {
            getChatFromDb();
        }
    }

    private void getChatFromDb() {


        List<Chat> localList = dbHelper.getChatHistoryFromDB(serviceId, merchantId, pageNumber, pageLimit);

        if (localList != null && localList.size() > 0) {
            AsyncTask.execute(new Runnable() {
                @Override
                public void run() {
                    dbHelper.updateMessageAsRead(serviceId, merchantId);
                }
            });
        }

        if (chatHistoryList != null && chatHistoryList.size() > 0) {
            chatHistoryList.addAll(0, localList);
            rvChatList.scrollToPosition(localList.size() + 2);
        } else {
            chatHistoryList = localList;
        }

        setAdapter();


        if (localList != null && localList.size() > 0) {
            pageNumber++;
        }

    }


    private void removeDuplicity() {

        Object[] st = chatHistoryList.toArray();
        for (Object s : st) {
            if (chatHistoryList.indexOf(s) != chatHistoryList.lastIndexOf(s)) {
                chatHistoryList.remove(chatHistoryList.lastIndexOf(s));
            }
        }
    }

    public void setAdapter() {

        removeDuplicity();

        if (chatAdapter == null) {
            if (chatHistoryList != null && chatHistoryList.size() > 0) {
                chatAdapter = new ChatAdapter(mContext, chatHistoryList);
                rvChatList.setLayoutManager(new LinearLayoutManager(this));
                rvChatList.setItemAnimator(new DefaultItemAnimator());
                rvChatList.setAdapter(chatAdapter);
                rvChatList.scrollToPosition(chatAdapter.getItemCount() - 1);
            }
        } else {
            chatAdapter.notifyDataSetChanged();
        }

        /*if (chatHistoryList != null && chatHistoryList.size() > 0) {
            timestamp = chatHistoryList.get(0).getTimestamp();
            pageNumber++;
        }*/

        swipeLayout.setRefreshing(false);

    }

    public void onResume() {
        super.onResume();
        if (awardStatus != null && awardStatus.equalsIgnoreCase("1")) {
            tVAward.setVisibility(View.VISIBLE);
            tVAward.setText(mContext.getString(R.string.awarded));
            tVAward.setEnabled(false);
            rlChat.setVisibility(View.GONE);

        } else {
            tVAward.setVisibility(View.VISIBLE);
            tVAward.setText(mContext.getString(R.string.award));
            rlChat.setVisibility(View.VISIBLE);
        }

    }


}
