package com.cdn.techquiq.consumer.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.activity.MainActivity;
import com.cdn.techquiq.consumer.adapter.InboxAdapter;
import com.cdn.techquiq.consumer.model.InboxListResponse;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;
import com.google.gson.Gson;
import com.marshalchen.ultimaterecyclerview.UltimateRecyclerView;

import java.net.SocketTimeoutException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by kajalsoni on 3/2/17.
 */

public class InboxFragment extends BaseFragment {

    private static final String TAG = InboxFragment.class.getSimpleName();

    private UltimateRecyclerView recyclerView;
    private InboxAdapter messageAdapter;

    private ArrayList<InboxListResponse.InboxList> inboxList;
    private int limit;
    private int currentOffset;
    private int totalRecord;
    private String keyword;
    private TextView noInboxMsgTv;

    private LinearLayoutManager linearLayoutManager;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_message, null);
        setTitleText(getString(R.string.txt_message_title));

        recyclerView = (UltimateRecyclerView) view.findViewById(R.id.messageList);
        recyclerView.setHasFixedSize(false);
        noInboxMsgTv = (TextView) view.findViewById(R.id.text_no_product);
        inboxList = null;
        linearLayoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(linearLayoutManager);

        recyclerView.setLoadMoreView(LayoutInflater.from(getActivity())
                .inflate(R.layout.custom_bottom_progressbar, null));

        return view;
    }

    public void webServiceCall() {
        limit = AppConstant.MESSAGE_LIMIT;
        currentOffset = 0;
        totalRecord = 0;
        keyword = "";
        searchProduct(currentOffset, false, keyword);
        productLoadMore();
    }

    @Override
    public void onResume() {
        super.onResume();
        topAndBelowTab();
        webServiceCall();
    }

    private void topAndBelowTab() {
        ((MainActivity) getActivity()).hideBackBtn(true);
        ((MainActivity) getActivity()).hideCartButton(true);
        ((MainActivity) getActivity()).hideSearchButton(true);
        ((MainActivity) getActivity()).hideSettingButton(true);
        ((MainActivity) getActivity()).hideBelowTabBar(false);
    }

    public void searchProduct(int offset, final boolean isLoadMore, String keyword) {
        try {
            if (!CheckNetworkState.isOnline(getActivity())) {
                if (!isLoadMore) {
                    noInboxMsgTv.setVisibility(View.VISIBLE);
                    noInboxMsgTv.setText(getActivity().getString(R.string.network_error));
                    recyclerView.setVisibility(View.GONE);
                } else {
                    showToastMsg(getActivity(), getActivity().getString(R.string.network_error));
                }
                return;
            }

            this.keyword = keyword;
            if (!isLoadMore) {
                if (!showProgressDialog(getActivity())) {
                    return;
                }
            }

            final LoginResponse.Users userDetail = Utils.readUserDetail(getActivity());
            Call<InboxListResponse> serviceCategories = ((TechquiqApplication) getActivity()
                    .getApplicationContext()).getService().getMessageList(
                    userDetail.getUserId(),
                    Utils.getDeviceId(getActivity()),
                    ApiParameter.DEVICE_TYPE_VALUE,
                    AppConstant.FCM_ID,
                    "",
                    limit,
                    offset, 0,
                    keyword);

            Log.e(TAG, "Request : " + serviceCategories.request().url());

            serviceCategories.enqueue(new Callback<InboxListResponse>() {
                @Override
                public void onResponse(Call<InboxListResponse> call, Response<InboxListResponse> response) {
                    if (response == null) {
                        showToastMsg(getContext(), getString(R.string.server_error));
                        return;
                    }

                    if (!isLoadMore) {
                        hideProgressDialog();
                    }

                    Log.e(TAG, "Categories Response : " + new Gson().toJson(response.body()));
                    InboxListResponse inboxResponse = response.body();
                    if (inboxResponse == null) {
                        showToastMsg(getContext(), getString(R.string.server_error));
                        setErrorMessage(getString(R.string.server_error));
                        return;
                    }
                    Log.e(TAG, "Total Service " + String.valueOf(totalRecord));
                    int responseStatusCode = inboxResponse.getResponseStatusCode();
                    if (responseStatusCode == AppConstant.PARAM_MISSING) {
                        showToastMsg(getContext(), getString(R.string.ws_param_missing));
                    } else if (responseStatusCode == AppConstant.NO_DATA_FOUND) {
                        setErrorMessage(getString(R.string.ws_no_inbox_data_found));
                    } else if (responseStatusCode == AppConstant.UNKNOWN_ERROR) {
                        setErrorMessage(getString(R.string.ws_unkonwn_error));
                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        totalRecord = inboxResponse.getTotal_service();
                        if (inboxResponse.getResponseCode().equalsIgnoreCase("0")) {
                            if (!isLoadMore) {
                                setErrorMessage(getResources().getString(R.string.ws_no_inbox_data_found));
                                ((MainActivity) getActivity()).hideSearchButton(true);
                            } else {
                                ((MainActivity) getActivity()).hideSearchButton(false);
                                showToastMsg(getActivity(), response.body().getResponseMessage());
                            }
                            return;
                        } else {
                            ((MainActivity) getActivity()).hideSearchButton(false);
                            recyclerView.setVisibility(View.VISIBLE);
                            noInboxMsgTv.setVisibility(View.GONE);
                        }
                        if (isLoadMore) {
                            if (inboxList != null) {
                                int offset = inboxList.size();
                                for (int i = 0; i < inboxResponse.getInboxList().size(); i++) {
                                    inboxList.add(offset, inboxResponse.getInboxList().get(i));
                                    offset++;
                                }
                                messageAdapter.notifyDataSetChanged();
                            }
                        } else {
                            inboxList = inboxResponse.getInboxList();
                            if (inboxList != null && inboxList.size() > 0) {
                                messageAdapter = new InboxAdapter(getActivity(), inboxList);
                                recyclerView.setAdapter(messageAdapter);
                            }
                        }
                    } else {
                        showToastMsg(getContext(), inboxResponse.getResponseMessage());
                    }


                }

                @Override
                public void onFailure(Call<InboxListResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        setErrorMessage(getString(R.string.connection_timeout));
                        return;
                    }
                    setErrorMessage(getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setErrorMessage(String msg) {
        noInboxMsgTv.setVisibility(View.VISIBLE);
        noInboxMsgTv.setText(msg);
        recyclerView.setVisibility(View.GONE);
    }

    private void productLoadMore() {

        recyclerView.reenableLoadmore();
        recyclerView.setOnLoadMoreListener(new UltimateRecyclerView.OnLoadMoreListener() {
            @Override
            public void loadMore(int itemsCount, int maxLastVisiblePosition) {
                try {
                    if (totalRecord <= inboxList.size()) {
                        recyclerView.disableLoadmore();
                    } else {
                        currentOffset = currentOffset + limit;
                        searchProduct(currentOffset, true, keyword);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void notifyData() {
        if (recyclerView != null && messageAdapter != null) {
            messageAdapter.notifyDataSetChanged();
        }
    }
}
