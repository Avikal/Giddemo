package com.cdn.techquiq.consumer.socket;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import org.json.JSONObject;

//import com.example.facebook.android.Utility;
//Utility.resultedJson

public class SocketIOManager implements IOCallback {
    static final String TAG = "SocketIOManager";
    private static Handler sHandler = null;
    private static SocketIO mSocket = null;
    static int a = 0;

    public SocketIOManager(Handler handler) {
        sHandler = handler;
    }

    public SocketIO connect(String url) {
        if (mSocket != null) {
            return mSocket;
        }
        try {
            mSocket = new SocketIO(url);
            mSocket.connect(this);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return mSocket;
    }

    public void disconnect() {
        if (mSocket != null) {
            mSocket.disconnect();
            mSocket = null;
        }
    }

    private boolean isHandler() {
        return sHandler != null ? true : false;
    }

    @Override
    public void onDisconnect() {
        Log.v(TAG, "Connection terminated.");
        if (isHandler()) {
            Message msg = sHandler.obtainMessage(SOCKETIO_DISCONNECT);
            sHandler.sendMessage(msg);
  /*  Intent i =new Intent(AppController.getInstance().getApplicationContext(), CdnchatService.class);
    i.setAction("disconnect");
    AppController.getInstance().getApplicationContext().startService(i);
*/
        }
    }

    @Override
    public void onConnect() {
        Log.v(TAG, "Connection established");
        if (isHandler()) {
            Message msg = sHandler.obtainMessage(SOCKETIO_CONNECT);
            sHandler.sendMessage(msg);
        }
    }

    @Override
    public void onMessage(String data, IOAcknowledge ack) {
        Log.v(TAG, "Server said String: " + data);
        if (isHandler()) {
            Message msg = sHandler.obtainMessage(SOCKETIO_MESSAGE, data);
            sHandler.sendMessage(msg);
        }
    }

    @Override
    public void onMessage(JSONObject json, IOAcknowledge ack) {
        Log.v(TAG, "Server said:" + json.toString());
        if (isHandler()) {
            Message msg = sHandler.obtainMessage(SOCKETIO_JSON_MESSAGE, json.toString());
            sHandler.sendMessage(msg);
        }
    }

    @Override
    public void on(String event, IOAcknowledge ack, Object... args) {
        Log.e(TAG, "Server triggered event '" + event + "'");
        if (event.equals("message")) {
            onMessage((JSONObject) args[0], null);
            Log.v(TAG, "Server triggered event '" + event + "'" + (JSONObject) args[0]);
        } else if (event.equalsIgnoreCase("setMessageHistory")) {
            Log.e(TAG, "setmessage res");
            if (isHandler()) {
                Message msg = sHandler.obtainMessage(SOCKETIO_MESSAGEHISTORY, args[0]);
                sHandler.sendMessage(msg);
            }
        }
        else if (event.equalsIgnoreCase("")) {
            Log.e(TAG, "setmessage res");
            if (isHandler()) {
                Message msg = sHandler.obtainMessage(SOCKETIO_JOINCHAT, args[0]);
                sHandler.sendMessage(msg);
            }
        }

        else if (event.equalsIgnoreCase("getData")) {
            Log.e(TAG, "chatNewMessage zone node messages ");
            if (isHandler()) {
                Message msg = sHandler.obtainMessage(SOCKETIO_CHATMESSAGE, args[0]);
                sHandler.sendMessage(msg);
            }
        }

        else if (event.equalsIgnoreCase("new_message")) {
            Log.e(TAG, "Message Receive");
            if (isHandler()) {
                Message msg = sHandler.obtainMessage(SOCKETIO_MESSAGE_RECEIVE, args[0]);
                sHandler.sendMessage(msg);
                JSONObject product = (JSONObject) args[0];
                Log.d("Receiver Msg", product.toString());

            }
        }

        else if (event.equalsIgnoreCase("send_to_admin")) {
            Log.e(TAG, "Message Receive");
            if (isHandler()) {
                Message msg = sHandler.obtainMessage(SOCKETIO_RECVIE_OWNMSG, args[0]);
                sHandler.sendMessage(msg);
                JSONObject product = (JSONObject) args[0];
                Log.d("Sender Msg", product.toString());

            }
        }


    }

    @Override
    public void onError(SocketIOException socketIOException) {
        Log.v(TAG, "an Error occured");

        if (isHandler()) {
            Message msg = sHandler.obtainMessage(SOCKETIO_ERROR);
            sHandler.sendMessage(msg);
        }
        socketIOException.printStackTrace();
    }

    public static final int SOCKETIO_DISCONNECT = 0;
    public static final int SOCKETIO_CONNECT = 1;
    public static final int SOCKETIO_HERTBEAT = 2;
    public static final int SOCKETIO_MESSAGE = 3;
    public static final int SOCKETIO_JSON_MESSAGE = 4;
    public static final int SOCKETIO_EVENT = 5;
    public static final int SOCKETIO_ACK = 6;
    public static final int SOCKETIO_ERROR = 7;
    public static final int SOCKETIO_CHATMESSAGE = 8;
    public static final int SOCKETIO_BEACONMESSAGE = 10;
    public static final int SOCKETIO_MESSAGES = 20;
    public static final int SOCKETIO_JOINCHAT = 50;
    public static final int SOCKETIO_MESSAGEHISTORY = 51;

    public static final int SOCKETIO_RECVIE_OWNMSG = 54;

    public static final int SOCKETIO_MESSAGE_RECEIVE = 52;

}
