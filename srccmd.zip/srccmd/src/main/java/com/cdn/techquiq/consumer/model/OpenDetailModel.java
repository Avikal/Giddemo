package com.cdn.techquiq.consumer.model;

/**
 * Created by avikaljain on 23/3/17.
 */
public class OpenDetailModel {
    int circleViewer;
    private String name;
    private String description;
    private String price;

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    int arrow;

    public OpenDetailModel() {
    }

    public OpenDetailModel(int circleViewer, String name, String description, int arrow) {
        this.circleViewer = circleViewer;
        this.name = name;
        this.description = description;
        this.arrow = arrow;

    }

    public int getCircleViewer() {
        return circleViewer;
    }

    public void setCircleViewer(int circleViewer) {
        this.circleViewer = circleViewer;
    }

    public int getArrow() {
        return arrow;
    }

    public void setArrow(int arrow) {
        this.arrow = arrow;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


}

