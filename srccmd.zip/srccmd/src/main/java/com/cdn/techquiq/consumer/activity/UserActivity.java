package com.cdn.techquiq.consumer.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.SerializationUtils;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.adapter.UserAdapter;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.UserResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.google.gson.Gson;
import com.marshalchen.ultimaterecyclerview.UltimateRecyclerView;
import com.miguelcatalan.materialsearchview.MaterialSearchView;

import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by avikaljain on 7/4/17.
 */

public class UserActivity extends BaseActivity {

    private String TAG = UserActivity.class.getSimpleName();


    private UltimateRecyclerView recyclerView;
    private UserAdapter mAdapter;
    private ImageView backIv;
    private TextView titleTv;

    private Bundle bundle;
    private String title;
    private String serviceId;
    private TextView noInboxMsgTv;

    private int limit;
    private int currentOffset;
    private int totalRecord;
    private String keyword;

    /**
     * Search declearation
     */
    private List<UserResponse.UserInfo> userList = new ArrayList<>();
    List<UserResponse.UserInfo> cloneList;
    private ImageView searchIcon;
    private MaterialSearchView searchView;
    public static final int REQUEST_FOR_FILTER = 1;
    private LinearLayoutManager linearLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
        setUpUI();
        callWebService();
    }

    private void setUpUI() {

        topAndBelowTab();

        bundle = getIntent().getExtras();
        if (bundle != null) {
            title = bundle.getString("title");
            title = Utils.decodeString(title);
            serviceId = bundle.getString("serviceId");
        }
        recyclerView = (UltimateRecyclerView) findViewById(R.id.userList);
        titleTv = (TextView) findViewById(R.id.titleTv);
        backIv = (ImageView) findViewById(R.id.backIv);
        titleTv.setText(title);
        backIv.setOnClickListener(this);
        noInboxMsgTv = (TextView) findViewById(R.id.text_no_product);

        linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setLoadMoreView(LayoutInflater.from(this)
                .inflate(R.layout.custom_bottom_progressbar, null));


    }

    public void topAndBelowTab() {
        searchView = (MaterialSearchView) findViewById(R.id.search_view);
        searchIcon = (ImageView) findViewById(R.id.searchIcon);
        findViewById(R.id.backIv).setVisibility(View.VISIBLE);
        findViewById(R.id.sliderIv).setVisibility(View.GONE);
        findViewById(R.id.cartIv).setVisibility(View.GONE);
        findViewById(R.id.cartCountTitleLayout).setVisibility(View.GONE);
        searchIcon.setVisibility(View.VISIBLE);
        searchIcon.setOnClickListener(this);
        findViewById(R.id.settingIv).setVisibility(View.GONE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == MaterialSearchView.REQUEST_VOICE && resultCode == RESULT_OK) {
            ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (matches != null && matches.size() > 0) {
                String searchWrd = matches.get(0);
                if (!TextUtils.isEmpty(searchWrd)) {
                    searchView.setQuery(searchWrd, false);
                }
            }
            return;
        } else if (requestCode == REQUEST_FOR_FILTER && resultCode == RESULT_OK) {
            Fragment frg = getSupportFragmentManager().findFragmentById(R.id.fragment_container);
            final FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.detach(frg);
            ft.attach(frg);
            ft.commitAllowingStateLoss();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void callWebService() {
        limit = 10;
        currentOffset = 0;
        totalRecord = 0;
        keyword = "";
        getUserList(currentOffset, false, keyword);
        loadMore();
    }

    /**
     * Below methods is used for search functionality
     */
    public void closeSearchView() {
        if (searchView.isSearchOpen()) {
            searchView.closeSearch();
        }
    }

    private void openSearchView() {
        if (!searchView.isSearchOpen()) {
            searchView.showSearch();
        }
    }


    private void searchFunctionality() {

        openSearchView();

        searchView.setOnQueryTextListener(new MaterialSearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                keyword = query;
                searchView.clearFocus();
                filterList(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });

        searchView.setOnSearchViewListener(new MaterialSearchView.SearchViewListener() {
            @Override
            public void onSearchViewShown() {

            }

            @Override
            public void onSearchViewClosed() {
                filterList("");
                recyclerView.setVisibility(View.VISIBLE);
                noInboxMsgTv.setVisibility(View.GONE);
            }
        });
    }

    private void filterList(String query) {
        query = query.toLowerCase();
        boolean isClear = false;


        if (userList != null) {

            ArrayList<UserResponse.UserInfo.UserImage> userImages = userList.get(0).getUserImages();
            ArrayList<UserResponse.UserInfo.UserImage> searchUserImages = new ArrayList<>();

            for (int i = 0; i < userImages.size(); i++) {
                if ((userImages.get(i).getFirst_name().toLowerCase() + " " + userImages.get(i).getLast_name())
                        .contains(query)) {
                    if (!isClear) {
                        isClear = true;
                        cloneList.get(0).getUserImages().clear();
                        searchUserImages = new ArrayList<>();
                    }
                    searchUserImages.add(userImages.get(i));
                }
            }
            if (searchUserImages.size() > 0) {
                cloneList.get(0).setUserImages(searchUserImages);
                mAdapter.notifyDataSetChanged();
                recyclerView.setVisibility(View.VISIBLE);
                noInboxMsgTv.setVisibility(View.GONE);
            } else {
                recyclerView.setVisibility(View.GONE);
                noInboxMsgTv.setVisibility(View.VISIBLE);
                noInboxMsgTv.setText(getResources().getString(R.string.no_user_available));
            }

        }
    }

    private void loadMore() {
        recyclerView.reenableLoadmore();
        recyclerView.setOnLoadMoreListener(new UltimateRecyclerView.OnLoadMoreListener() {
            @Override
            public void loadMore(int itemsCount, int maxLastVisiblePosition) {
                try {
                    if (totalRecord <= userList.size()) {
                        recyclerView.disableLoadmore();
                    } else {
                        currentOffset = currentOffset + limit;
                        getUserList(currentOffset, true, keyword);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void getUserList(int offset, final boolean isLoadMore, String keyword) {
        try {
            this.keyword = keyword;
            if (!isLoadMore) {
                if (!showProgressDialog(this)) {
                    showToastMsg(mContext, getString(R.string.network_error));
//                    noInboxMsgTv.setText(getString(R.string.network_error));
//                    noInboxMsgTv.setVisibility(View.VISIBLE);
                    return;
                }
            }
            final LoginResponse.Users userDetail = Utils.readUserDetail(this);

            Call<UserResponse> userResponse = ((TechquiqApplication) this
                    .getApplicationContext()).getService().getMerchantList(
                    userDetail.getUserId(),
                    Utils.getDeviceId(this),
                    ApiParameter.DEVICE_TYPE_VALUE,
                    AppConstant.FCM_ID,
                    serviceId,
                    limit,
                    offset,
                    keyword
            );

            Log.e(TAG, "Request : " + userResponse.request().url());

            userResponse.enqueue(new Callback<UserResponse>() {
                @Override
                public void onResponse(Call<UserResponse> call, Response<UserResponse> response) {
                    hideProgressDialog();
                    if (response == null) {
                        return;
                    }
                    if (!isLoadMore) {
                        hideProgressDialog();
                    }

                    Log.e(TAG, "User Response : " + new Gson().toJson(response.body()));
                    UserResponse userResponse = response.body();
                    if (userResponse.getResponseCode().equalsIgnoreCase("0")) {
                        setErrorMsg(getResources().getString(R.string.no_service_found));

                        showToastMsg(UserActivity.this, response.body().getResponseMessage());
                        return;
                    } else if (userResponse.getResponseCode().equalsIgnoreCase("1")) {
                        userList = userResponse.getUserInfo();
                        String totalProposal = userList.get(0).getTotal_proposal();
                        if (totalProposal != null && !totalProposal.isEmpty() && totalProposal.equalsIgnoreCase("0")) {
                            setErrorMsg(getResources().getString(R.string.no_user_available));
                        } else {
                            recyclerView.setVisibility(View.VISIBLE);
                            noInboxMsgTv.setVisibility(View.GONE);

                            if (isLoadMore) {
                                if (userList != null) {
                                    int offset = userList.size();
                                    for (int i = 0; i < userResponse.getUserInfo().size(); i++) {
                                        userList.add(offset, userResponse.getUserInfo().get(i));
                                        offset++;
                                    }
                                    cloneList = SerializationUtils.cloneObject(userList);
                                    mAdapter.notifyDataSetChanged();
                                }
                            } else {
                                cloneList = SerializationUtils.cloneObject(userList);
                                if (cloneList != null && cloneList.size() > 0) {
                                    mAdapter = new UserAdapter(UserActivity.this, cloneList);
                                    recyclerView.setAdapter(mAdapter);
                                    mAdapter.notifyDataSetChanged();
                                }
                            }

                        }
                    }
                }

                @Override
                public void onFailure(Call<UserResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        setErrorMsg(getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    setErrorMsg(getResources().getString(R.string.server_error));
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.backIv:
                finish();
                break;

            case R.id.searchIcon:
                searchFunctionality();
                break;
        }
    }

    private void setErrorMsg(String msg) {
        noInboxMsgTv.setVisibility(View.VISIBLE);
        noInboxMsgTv.setText(msg);
        recyclerView.setVisibility(View.GONE);
    }

    /**
     * Below method is used for chat
     */
    public BroadcastReceiver getOwnMessageBroadCastRec = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            if (intent != null && intent.getExtras() != null) {

                switch (intent.getAction()) {
                    case AppConstant.UPDATE_CHAT_OWN_MSG:

                        break;

                    case AppConstant.UPDATE_CHAT_RECEIVE_MSG:
                        Utils.callOnRecivedChatMsg(intent, mContext, false, null);
                        break;

                    case AppConstant.UPDATE_CHAT_HISTORY:

                        break;

                }
            }
        }
    };

    private void startChatReciver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(AppConstant.CHAT_ACTION);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(AppConstant.UPDATE_CHAT_OWN_MSG);
        intentFilter.addAction(AppConstant.UPDATE_CHAT_RECEIVE_MSG);
        intentFilter.addAction(AppConstant.UPDATE_CHAT_HISTORY);
        LocalBroadcastManager.getInstance(this).registerReceiver(getOwnMessageBroadCastRec, intentFilter);
    }

    public void notifyList() {
        if (mAdapter != null) {
            mAdapter.notifyDataSetChanged();
        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        notifyList();
    }

    @Override
    protected void onResume() {
        super.onResume();
        startChatReciver();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopChatReciever();
    }

    public void stopChatReciever() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(getOwnMessageBroadCastRec);
    }

}
