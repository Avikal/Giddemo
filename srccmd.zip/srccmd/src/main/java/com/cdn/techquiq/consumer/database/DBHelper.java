package com.cdn.techquiq.consumer.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.LogUtils;
import com.cdn.techquiq.consumer.Utils.SharedPrefrence;
import com.j256.ormlite.android.apptools.OrmLiteSqliteOpenHelper;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.stmt.DeleteBuilder;
import com.j256.ormlite.stmt.QueryBuilder;
import com.j256.ormlite.stmt.UpdateBuilder;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.table.TableUtils;

import java.sql.SQLException;
import java.util.Collections;
import java.util.List;

/**
 * Created by himanshurathore on 15/5/17.
 */
public class DBHelper extends OrmLiteSqliteOpenHelper {

    private static final String DATABASE_NAME = "consumer.db";
    private static final int DATABASE_VERSION = 1;
    private static DBHelper databaseHelper = null;
    public SQLiteDatabase sqLiteDatabase = null;

    public Dao<Chat, Integer> resultDao = null;
    public Dao<Filter, Integer> filterDao = null;
    public Dao<Notification, Integer> notificationsDao = null;
    private Context mContext;

    /**
     * this constructor will be used to intialize Database
     *
     * @param context
     */
    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        mContext = context;
        sqLiteDatabase = getWritableDatabase();
        try {
            resultDao = getDao(Chat.class);
            filterDao = getDao(Filter.class);
            notificationsDao = getDao(Notification.class);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static DBHelper getInstance(Context mContext) {
        if (databaseHelper == null) {
            Context applicationContext = mContext.getApplicationContext();
            databaseHelper = new DBHelper(applicationContext);
        }
        return databaseHelper;
    }


    /**
     * onCreate method will be called very first time to create the Tables
     *
     * @param database
     * @param connectionSource
     */

    @Override
    public void onCreate(SQLiteDatabase database, ConnectionSource connectionSource) {
        try {
            TableUtils.createTable(connectionSource, Chat.class);
            TableUtils.createTable(connectionSource, Filter.class);
            TableUtils.createTable(connectionSource, Notification.class);
        } catch (SQLException e) {
            LogUtils.LogE("Can't create database", "" + e);
            throw new RuntimeException(e);
        }
    }

    /**
     * onUpgrade will be used when we work on the updated version of the application,
     * to manipulate existing database at user end.
     *
     * @param database
     * @param connectionSource
     * @param oldVersion
     * @param newVersion
     */
    @Override
    public void onUpgrade(SQLiteDatabase database,
                          ConnectionSource connectionSource,
                          int oldVersion, int newVersion) {
        LogUtils.LogE("", "onUpgrade");
        try {
            TableUtils.dropTable(connectionSource, Chat.class, true);
            TableUtils.dropTable(connectionSource, Filter.class, true);
            TableUtils.dropTable(connectionSource, Notification.class, true);
            onCreate(database, connectionSource);
        } catch (SQLException e) {
            LogUtils.LogE("Can't drop database", e.getMessage());
            throw new RuntimeException(e);
        }
    }

    public void insertChatHistory(Chat chat) {
        try {
            resultDao.createOrUpdate(chat);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Chat> getChatHistoryFromDB(String serviceId, String merchantId,
                                           long offset, long limit) {
        try {
            QueryBuilder<Chat, Integer> qb = resultDao.queryBuilder();
            qb.where().eq("service_id", serviceId).and()
                    .eq("merchant_id", merchantId);
            qb.orderBy("timestamp", false);
            qb.orderBy("timestamp", true);
            qb.offset(offset * limit).limit(limit);
            List<Chat> chat = qb.query();
            Collections.reverse(chat);
            return chat;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public List<Chat> getOfflineMessage() {
        try {
            QueryBuilder<Chat, Integer> qb = resultDao.queryBuilder();
            qb.where().eq("isSent", false);
            //qb.orderBy("timestamp", true);
            return qb.query();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    public void updateChatHistoryMsg(Chat chat) {
        try {
            UpdateBuilder<Chat, Integer> ub = resultDao.updateBuilder();
            ub.where().eq("msg_unique_id", chat.getMsg_unique_id())
                    .and().eq("service_id", chat.getService_id())
                    .and().eq("merchant_id", chat.getSent_to());
            ub.updateColumnValue("id", chat.getId());
            ub.updateColumnValue("timestamp", chat.getTimestamp());
            ub.updateColumnValue("aprove_status", chat.getAprove_status());
            ub.updateColumnValue("date_created", chat.getDate_created());
            ub.updateColumnValue("isSent", true);
            ub.update();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Below methods is for unread count message
     */
    public void updateMessageAsRead(String serviceId, String merchantId) {
        try {
            if (resultDao == null) {
                resultDao = getDao(Chat.class);
            }
            UpdateBuilder<Chat, Integer> ub = resultDao.updateBuilder();
            ub.where().eq("service_id", serviceId).and()
                    .eq("merchant_id", merchantId).and()
                    .eq("readMsg", false);
            ub.updateColumnValue("readMsg", true);

            ub.update();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int getUnReadMessageCount() {
        try {
            QueryBuilder<Chat, Integer> qb = resultDao.queryBuilder();
            qb.where().eq("readMsg", false);
            int size = qb.query().size();
            return size;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }


    public int getUnReadMessageCountForService(String serviceId) {
        try {
            QueryBuilder<Chat, Integer> qb = resultDao.queryBuilder();
            qb.where().eq("service_id", serviceId).and()
                    .eq("readMsg", false);
            int size = qb.query().size();
            Log.e("Service Count", "" + size);
            return size;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public int getUnReadMessageCountForMerchant(String serviceId, String merchantId) {
        try {
            QueryBuilder<Chat, Integer> qb = resultDao.queryBuilder();
            qb.where().eq("service_id", serviceId).and()
                    .eq("merchant_id", merchantId)
                    .and().eq("readMsg", false);
            int size = qb.query().size();
            Log.e("merchant Count", "" + size);
            return size;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public void clearChatHistory() {
        try {
            TableUtils.clearTable(getConnectionSource(), Chat.class);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    /*----------------------------------------------------------------------------------------------------------------------*/

    public void insertProductFiler(int filterId, int itemId, boolean isSelected) {
        try {
            Filter filter = new Filter();
            filter.setFilterId(filterId);
            filter.setItemId(itemId);
            filter.setFilterItemId(filterId + "_" + itemId);
            filter.setSelected(isSelected);
            filterDao.createOrUpdate(filter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Filter> getSelectedFilterId() {
        try {
            QueryBuilder<Filter, Integer> qb = filterDao.queryBuilder();
            qb.where().eq("selected", true);
            List<Filter> filter = qb.query();
            return filter;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void clearAllProductFilter() {
        try {
            filterDao.deleteBuilder().delete();
            SharedPrefrence.getInstance(mContext).writePrefs(SharedPrefrence.filterJson, "");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int getDeactivatedFilterItem() {
        try {
            QueryBuilder<Filter, Integer> qb = filterDao.queryBuilder();
            qb.where().eq("active", false);
            return qb.query().size();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public void removeDeactivatedFilterItem() {
        try {
            DeleteBuilder<Filter, Integer> deleteBuilder = filterDao.deleteBuilder();
            deleteBuilder.where().eq("active", false);
            deleteBuilder.delete();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateFilterActiveStatus(int filterId, int itemId, boolean isActive) {
        try {
            UpdateBuilder<Filter, Integer> updateBuilder = filterDao.updateBuilder();
            updateBuilder.updateColumnValue("active", isActive).where()
                    .eq("filterId", filterId).and()
                    .eq("itemId", itemId);
            updateBuilder.update();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean isFilerApplied() {
        try {
            QueryBuilder<Filter, Integer> qb = filterDao.queryBuilder();
            qb.where().eq("selected", true);
            if (qb.query().size() > 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    /*-------------------------------Notification Type------------------------------*/

    /**
     * Insert new notification in DB
     *
     * @param notificationId   random generated id
     * @param notificationType notification type alert or chat
     */
    public void insertNotificationType(String notificationTypeId, int notificationId, String notificationType) {
        try {

            Notification notification = new Notification();
            notification.setNotificationTypeId(notificationTypeId);
            notification.setNotificationId(notificationId);
            notification.setNotificationType(notificationType);
            notificationsDao.createOrUpdate(notification);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Return alert type notification list
     *
     * @return
     */
    public List<Notification> getAlertNotification() {
        try {
            QueryBuilder<Notification, Integer> qb = notificationsDao.queryBuilder();
            qb.where().eq("notificationType", AppConstant.ALERT_NOTIFICATION);
            List<Notification> notifications = qb.query();
            return notifications;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Return chat type notification list
     *
     * @return
     */
    public List<Notification> getChatNotification() {
        try {
            QueryBuilder<Notification, Integer> qb = notificationsDao.queryBuilder();
            qb.where().eq("notificationType", AppConstant.CHAT_NOTIFICATION);
            List<Notification> notifications = qb.query();
            return notifications;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * After read notification delete the notification from DB
     *
     * @param notificationId
     */
    public void removeReadNotification(int notificationId) {
        try {
            DeleteBuilder<Notification, Integer> deleteAlertBuilder = notificationsDao.deleteBuilder();
            deleteAlertBuilder.where().eq("notificationId", notificationId);
            deleteAlertBuilder.delete();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
