package com.cdn.techquiq.consumer.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.Utils.NotificationUtils;
import com.cdn.techquiq.consumer.database.DBHelper;
import com.cdn.techquiq.consumer.database.Notification;

import java.util.List;

/**
 * Created by avikaljain on 12/6/17.
 */

public class AlertDetailActivity extends BaseActivity {
    private String TAG = AddressActivity.class.getSimpleName();

    private ImageView backIv;
    private TextView titleTv;

    private TextView tvDescription;
    private Bundle bundle;
    private String titleTxt;
    private String descriptionTxt;
    private ImageView ivNotification;
    private String image;
    private String date;
    private boolean isNotify;
    private int notificationId;
    private int alertCount;
    private String notificationTypeId;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alert_detail);
        bundle = getIntent().getExtras();
        if (bundle != null) {
            titleTxt = bundle.getString("title");
            descriptionTxt = bundle.getString("description");
            image = bundle.getString("image");
            date = bundle.getString("date");
            isNotify = bundle.getBoolean("notification");
            notificationId = bundle.getInt("notificationId");
            notificationTypeId = bundle.getString("notificationTypeId");
        }

        /**
         * Remove notification from notification tray using notification type and id
         */
        List<Notification> alertNotification = DBHelper.getInstance(mContext).getAlertNotification();
        NotificationUtils.clearNotifications(mContext, notificationId);
        DBHelper.getInstance(mContext).removeReadNotification(notificationId);

        setUpUI();
    }

    private void setUpUI() {
        titleTv = (TextView) findViewById(R.id.titleTv);
        titleTv.setText(getResources().getString(R.string.txt_alert_title));
        backIv = (ImageView) findViewById(R.id.backIv);
        tvDescription = (TextView) findViewById(R.id.tvDescription);
        titleTv.setText(titleTxt);
        tvDescription.setText(descriptionTxt);
        ivNotification = (ImageView) findViewById(R.id.ivNotification);
        Glide.with(mContext).load(image)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .crossFade()
                .placeholder(R.drawable.placeholder_1)
                .error(R.drawable.placeholder_1)
                .into(ivNotification);

        backIv.setOnClickListener(this);
        tvDescription.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.backIv:
                onBackPressed();
                break;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if (isNotify) {
            Intent main = new Intent(AlertDetailActivity.this, MainActivity.class);
            startActivity(main);
            isNotify = false;
        }
        finish();
    }
}
