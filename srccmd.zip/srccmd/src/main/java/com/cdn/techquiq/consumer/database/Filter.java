package com.cdn.techquiq.consumer.database;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;


@DatabaseTable(tableName = "product_filter")
public class Filter {

    @DatabaseField(id = true)
    public String filterItemId;

    @DatabaseField
    public int filterId;

    @DatabaseField
    public int itemId;

    @DatabaseField
    public boolean selected;

    @DatabaseField
    public boolean active;

    public String getFilterItemId() {
        return filterItemId;
    }

    public void setFilterItemId(String filterItemId) {
        this.filterItemId = filterItemId;
    }

    public int getFilterId() {
        return filterId;
    }

    public void setFilterId(int filterId) {
        this.filterId = filterId;
    }

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    @Override
    public boolean equals(Object object) {
        boolean isEqual = false;
        if (object != null && object instanceof Filter) {
            isEqual = (this.filterItemId.equals(((Filter) object).filterItemId));
        }
        return isEqual;
    }


}

