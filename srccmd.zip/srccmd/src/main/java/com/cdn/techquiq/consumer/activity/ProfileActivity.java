package com.cdn.techquiq.consumer.activity;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.BitmapImageViewTarget;
import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.SharedPrefrence;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.custom.Dialog.CountryDialog;
import com.cdn.techquiq.consumer.model.CityResponse;
import com.cdn.techquiq.consumer.model.CountryResponse;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.StateResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;
import com.google.gson.Gson;
import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEvent;
import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEventListener;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.SocketTimeoutException;
import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by akshaysoni on 3/2/17.
 */
public class ProfileActivity extends BaseActivity {

    private String TAG = ProfileActivity.class.getSimpleName();

    private TextView titleTv, changePasswordTv;
    private ImageView backIv, profileEditIcon, submitIv;
    private EditText firstNameEt, lastNameEt, contactEt, emailEt, addressEt, postalCodeEt;
    private CircleImageView profilePic;
    private Uri fileUri;
    private TextView selectCountryTv;
    private TextView selectStateTv;
    private TextView selectCityTv;
    private String selectedStateId;
    private String selectedCityId;
    private String selectedCountryId;
    private LinearLayout changePwdLayout;
    public LinearLayout editLayout;
    private ImageView cancelIv;
    private ImageView doneIv;
    private LoginResponse.Users userDetail;
    private boolean isEditShow;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_activity);

        setUpUI();
        hideKeyBoard();
        doUnEditable();
        getProfile();
    }

    public void setUpUI() {

        titleTv = (TextView) findViewById(R.id.titleTv);
        titleTv.setText(mContext.getString(R.string.txt_profile_title));
        backIv = (ImageView) findViewById(R.id.backIv);
        backIv.setOnClickListener(this);
        profileEditIcon = (ImageView) findViewById(R.id.profileEditIcon);
        profileEditIcon.setOnClickListener(this);
        profilePic = (CircleImageView) findViewById(R.id.profilePic);
        firstNameEt = (EditText) findViewById(R.id.firstNameEt);
        lastNameEt = (EditText) findViewById(R.id.lastNameEt);
        contactEt = (EditText) findViewById(R.id.contactEt);
        emailEt = (EditText) findViewById(R.id.emailEt);
        addressEt = (EditText) findViewById(R.id.addressEt);
        postalCodeEt = (EditText) findViewById(R.id.postalCodeEt);

        selectCountryTv = (TextView) findViewById(R.id.selectCountryTv);
        selectStateTv = (TextView) findViewById(R.id.selectStateTv);
        selectCityTv = (TextView) findViewById(R.id.selectCityTv);

        editLayout = (LinearLayout) findViewById(R.id.editLayout);
        changePwdLayout = (LinearLayout) findViewById(R.id.changePwdLayout);
        changePasswordTv = (TextView) findViewById(R.id.changePasswordTv);
        changePasswordTv.setOnClickListener(this);
        submitIv = (ImageView) findViewById(R.id.submitIv);
        submitIv.setOnClickListener(this);

        cancelIv = (ImageView) findViewById(R.id.cancelIv);
        cancelIv.setOnClickListener(this);

        doneIv = (ImageView) findViewById(R.id.doneIv);
        doneIv.setOnClickListener(this);

        selectCountryTv.setOnClickListener(this);
        selectStateTv.setOnClickListener(this);
        selectCityTv.setOnClickListener(this);

        firstNameEt.setEnabled(false);
        lastNameEt.setEnabled(false);
        contactEt.setEnabled(false);
        emailEt.setEnabled(false);
        addressEt.setEnabled(false);
        postalCodeEt.setEnabled(false);

        selectCountryTv.setEnabled(false);
        selectStateTv.setEnabled(false);
        selectCityTv.setEnabled(false);

        /**
         * Open Country picker dialog from the below code
         */
        addressEt.setOnEditorActionListener(new EditText.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_NEXT) {
                    getCountry();
                    return true; // Focus will do whatever you put in the logic.
                }
                return false;  // Focus will change according to the actionId
            }
        });


        /**
         * Open Country picker dialog from the below code
         */
        addressEt.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int keyCode, KeyEvent event) {
                if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    getCountry();
                    return true;
                }
                return false;
            }
        });

    }

    private void getProfile() {

        if (!CheckNetworkState.isOnline(mContext)) {
            showToastMsg(mContext, getString(R.string.network_error));
            return;
        }

        showProgressDialog(mContext);

        final LoginResponse.Users userDetail = Utils.readUserDetail(mContext);

        try {
            Call<LoginResponse> profileDetailRequest = ((TechquiqApplication) mContext
                    .getApplicationContext()).getService().getProfileDetail(
                    userDetail.getUserId(),
                    Utils.getDeviceId(mContext),
                    ApiParameter.DEVICE_TYPE_VALUE,
                    AppConstant.FCM_ID);

            Log.e(TAG, "" + profileDetailRequest.request().url());

            profileDetailRequest.enqueue(new Callback<LoginResponse>() {
                @Override
                public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                    hideProgressDialog();

                    if (response == null) {
                        showToastMsg(mContext, getString(R.string.server_error));
                        return;
                    }

                    LoginResponse loginResponse = response.body();

                    if (loginResponse == null) {
                        showToastMsg(mContext, getString(R.string.server_error));
                        return;
                    }

                    if (loginResponse.getResponseCode().equalsIgnoreCase("0")) {
                        showToastMsg(mContext, response.body().getResponseMessage());
                    } else if (loginResponse.getResponseCode().equalsIgnoreCase("1")) {
                        SharedPrefrence.getInstance(mContext).writeBooleanPrefs(SharedPrefrence.isLoggedIn, true);
                        Utils.writeUserDetail(mContext, loginResponse.getResult());
                        SharedPrefrence.getInstance(mContext)
                                .writeIntPrefs(SharedPrefrence.cartCount, loginResponse.getResult().getTotalCart());

                        setData();
                    }
                }

                @Override
                public void onFailure(Call<LoginResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setData() {
        userDetail = Utils.readUserDetail(this);
        if (userDetail != null) {
            firstNameEt.setText("" + userDetail.getFirst_name());
            lastNameEt.setText("" + userDetail.getLast_name());
            contactEt.setText("" + userDetail.getPhone());
            emailEt.setText("" + userDetail.getEmail());
            addressEt.setText("" + userDetail.getAddress());
            postalCodeEt.setText("" + userDetail.getPostalcode());

            selectedStateId = userDetail.getState();
            selectedCityId = userDetail.getCity();
            selectedCountryId = userDetail.getCountry();

            selectCountryTv.setText("" + userDetail.getCountryName());
            selectStateTv.setText("" + userDetail.getStateName());
            selectCityTv.setText("" + userDetail.getCityName());


            if (userDetail.getImage() == null || userDetail.getImage().equalsIgnoreCase("")) {
                Glide.with(mContext).load(userDetail.getImage()).asBitmap().centerCrop()
                        .placeholder(R.drawable.profile_img)
                        .error(R.drawable.profile_img)
                        .into(profilePic);
            } else {
                setProfileImage();
            }
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.backIv:
                finish();
                break;

            case R.id.profileEditIcon:
                checkPermission();
                break;

            case R.id.changePasswordTv:
                isEditShow = false;
                Intent cpIntent = new Intent(this, ChangePasswordActivity.class);
                startActivity(cpIntent);
                break;

            case R.id.submitIv:
                isEditShow = true;
                doEditable();
                break;

            case R.id.cancelIv:
                isEditShow = false;
                getProfile();
                doUnEditable();
                setProfileImage();
                break;

            case R.id.doneIv:

                if (isValidate()) {
                    doEditProfile();
                }

                break;

            case R.id.selectCountryTv:
                getCountry();
                break;

            case R.id.selectStateTv:
                getState();
                break;

            case R.id.selectCityTv:
                getCity();
                break;

        }
    }

    public void hideKeyBoard() {
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }

    public void doEditable() {
        firstNameEt.setEnabled(true);
        lastNameEt.setEnabled(true);
        contactEt.setEnabled(true);
        emailEt.setEnabled(false);
        emailEt.setAlpha(0.5f);
        addressEt.setEnabled(true);
        postalCodeEt.setEnabled(true);

        firstNameEt.setAlpha(1f);
        lastNameEt.setAlpha(1f);
        contactEt.setAlpha(1f);
        addressEt.setAlpha(1f);
        postalCodeEt.setAlpha(1f);

        selectCountryTv.setAlpha(1f);
        selectStateTv.setAlpha(1f);
        selectCityTv.setAlpha(1f);
        selectCountryTv.setEnabled(true);
        selectStateTv.setEnabled(true);
        selectCityTv.setEnabled(true);
        changePwdLayout.setVisibility(View.GONE);
        editLayout.setVisibility(View.VISIBLE);
        profileEditIcon.setVisibility(View.VISIBLE);
        submitIv.setVisibility(View.GONE);
        KeyboardVisibilityEvent.setEventListener(
                this,
                new KeyboardVisibilityEventListener() {
                    @Override
                    public void onVisibilityChanged(boolean isOpen) {
                        if (isOpen) {
                            editLayout.setVisibility(View.GONE);
                        } else {
                            if (isEditShow) {
                                editLayout.setVisibility(View.VISIBLE);
                            } else {
                                editLayout.setVisibility(View.GONE);
                            }

                        }
                    }
                });
    }

    public void doUnEditable() {
        isEditShow = false;
        firstNameEt.setEnabled(false);
        lastNameEt.setEnabled(false);
        contactEt.setEnabled(false);
        emailEt.setEnabled(false);
        emailEt.setAlpha(0.5f);
        selectCountryTv.setAlpha(0.5f);
        selectStateTv.setAlpha(0.5f);
        selectCityTv.setAlpha(0.5f);
        firstNameEt.setAlpha(0.5f);
        lastNameEt.setAlpha(0.5f);
        contactEt.setAlpha(0.5f);
        addressEt.setAlpha(0.5f);
        addressEt.setEnabled(false);

        postalCodeEt.setEnabled(false);
        postalCodeEt.setAlpha(0.5f);

        selectCountryTv.setEnabled(false);
        selectStateTv.setEnabled(false);
        selectCityTv.setEnabled(false);
        profileEditIcon.setVisibility(View.GONE);
        changePwdLayout.setVisibility(View.VISIBLE);
        editLayout.setVisibility(View.GONE);
        submitIv.setVisibility(View.VISIBLE);
    }

    private void setProfileImage() {
        if (userDetail.getImage() == null || userDetail.getImage().equalsIgnoreCase("")) {
            Glide.with(mContext).load(userDetail.getImage()).asBitmap().centerCrop()
                    .placeholder(R.drawable.placeholder_1)
                    .into(profilePic);
        } else {
            Glide.with(mContext).load(userDetail.getImage()).asBitmap().centerCrop()
                    .placeholder(R.drawable.profile_img)
                    .error(R.drawable.profile_img)
                    .into(new BitmapImageViewTarget(profilePic) {
                        @Override
                        protected void setResource(Bitmap resource) {
                            RoundedBitmapDrawable circularBitmapDrawable =
                                    RoundedBitmapDrawableFactory.create(mContext.getResources(), resource);
                            circularBitmapDrawable.setCircular(true);
                            profilePic.setImageDrawable(circularBitmapDrawable);
                        }
                    });
        }
    }

    private boolean isValidate() {
        if (firstNameEt.getText().toString().trim() == null || firstNameEt.getText().toString().trim().isEmpty()) {
            showToastMsg(mContext, mContext.getString(R.string.enter_first_name));
            return false;
        } else if (lastNameEt.getText().toString().trim() == null || lastNameEt.getText().toString().trim().isEmpty()) {
            showToastMsg(mContext, mContext.getString(R.string.enter_last_name));
            return false;
        } else if (contactEt.getText().toString().trim() == null || contactEt.getText().toString().trim().isEmpty()) {
            showToastMsg(mContext, mContext.getString(R.string.enter_contact_number));
            return false;
        } else if (contactEt.getText().toString().length() < 10) {
            showToastMsg(mContext, mContext.getString(R.string.contact_length_msg));
            return false;
        } else if (addressEt.getText().toString().trim() == null || addressEt.getText().toString().trim().isEmpty()) {
            showToastMsg(mContext, mContext.getString(R.string.enter_address));
            return false;
        } else if (selectCountryTv.getText().toString().trim() == null || selectCountryTv.getText().toString().trim().isEmpty() || selectCountryTv.getText().toString().equalsIgnoreCase(getResources().getString(R.string.select_country))) {
            showToastMsg(mContext, mContext.getString(R.string.select_country_msg));
            return false;
        } else if (selectStateTv.getText().toString().trim() == null || selectStateTv.getText().toString().trim().isEmpty() || selectStateTv.getText().toString().equalsIgnoreCase(getResources().getString(R.string.select_state))) {
            showToastMsg(mContext, mContext.getString(R.string.select_state_msg));
            return false;
        } else if (selectCityTv.getText().toString().trim() == null || selectCityTv.getText().toString().trim().isEmpty() || selectCityTv.getText().toString().equalsIgnoreCase(getResources().getString(R.string.select_city))) {
            showToastMsg(mContext, mContext.getString(R.string.select_city_msg));
            return false;
        } else if (postalCodeEt.getText().toString().trim() == null || postalCodeEt.getText().toString().trim().isEmpty()) {
            showToastMsg(mContext, mContext.getString(R.string.enter_postal_code));
            return false;
        } else if (postalCodeEt.getText().toString().length() < 5) {
            showToastMsg(mContext, mContext.getString(R.string.postal_code_length_msg));
            return false;
        } else {
            return true;
        }
    }

    private void getCountry() {

        if (!CheckNetworkState.isOnline(mContext)) {
            showToastMsg(mContext, getString(R.string.network_error));
            return;
        }

        showProgressDialog(mContext);

        try {
            Call<CountryResponse> countryRequest = ((TechquiqApplication) mContext
                    .getApplicationContext()).getService().getCountryService(
                    Utils.getDeviceId(mContext),
                    ApiParameter.DEVICE_TYPE_VALUE,
                    AppConstant.FCM_ID);

            countryRequest.enqueue(new Callback<CountryResponse>() {
                @Override
                public void onResponse(Call<CountryResponse> call, Response<CountryResponse> response) {
                    hideProgressDialog();
                    final ArrayList<CountryResponse.Country> countries = response.body().getResult();
                    if (countries != null && countries.size() > 0) {
                        final ArrayList<String> countryData = new ArrayList<String>();
                        for (int i = 0; i < countries.size(); i++) {
                            countryData.add(i, countries.get(i).getCountry_name());
                        }
                        final CountryDialog countryDialog = new CountryDialog(ProfileActivity.this,
                                mContext.getString(R.string.select_country), countryData);
                        countryDialog.setSearchEnable();
                        countryDialog.show();

                        countryDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialogInterface) {
                                if (countryDialog.getPosition() > -1 && countryDialog.isItemClick()) {
                                    selectedCountryId = countries.get(countryDialog.getPosition()).getCountry_id();
                                    selectCountryTv.setText(countries.get(countryDialog.getPosition()).getCountry_name());
                                    userDetail.setCountryName(countries.get(countryDialog.getPosition()).getCountry_name());
                                    selectStateTv.setText(mContext.getString(R.string.select_state));
                                    selectCityTv.setText(mContext.getString(R.string.select_city));
                                    selectedStateId = "";
                                    selectedCityId = "";
                                    selectCountryTv.setTextColor(getResources().getColor(R.color.black));

                                }
                            }
                        });
                    }
                }

                @Override
                public void onFailure(Call<CountryResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void getState() {

        if (!CheckNetworkState.isOnline(mContext)) {
            showToastMsg(mContext, getString(R.string.network_error));
            return;
        }

        if (selectedCountryId == null || selectedCountryId.isEmpty()) {
            return;
        }

        showProgressDialog(mContext);

        try {
            Call<StateResponse> stateRequest = ((TechquiqApplication) mContext
                    .getApplicationContext()).getService().getStateService(
                    selectedCountryId,
                    Utils.getDeviceId(mContext),
                    ApiParameter.DEVICE_TYPE_VALUE,
                    AppConstant.FCM_ID);

            stateRequest.enqueue(new Callback<StateResponse>() {
                @Override
                public void onResponse(Call<StateResponse> call, Response<StateResponse> response) {
                    hideProgressDialog();
                    final ArrayList<StateResponse.State> states = response.body().getResult();
                    if (states != null && states.size() > 0) {
                        ArrayList<String> stateData = new ArrayList<String>();
                        for (int i = 0; i < states.size(); i++) {
                            stateData.add(i, states.get(i).getState_name());
                        }
                        final CountryDialog stateDialog = new CountryDialog(ProfileActivity.this,
                                mContext.getString(R.string.select_state), stateData);
                        stateDialog.setSearchEnable();
                        stateDialog.show();


                        stateDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialogInterface) {
                                if (stateDialog.getPosition() > -1 && stateDialog.isItemClick()) {
                                    selectedStateId = states.get(stateDialog.getPosition()).getState_id();
                                    selectStateTv.setText(states.get(stateDialog.getPosition()).getState_name());
                                    userDetail.setStateName(states.get(stateDialog.getPosition()).getState_name());
                                    selectCityTv.setText(mContext.getString(R.string.select_city));
                                    selectedCityId = "";
                                    selectStateTv.setTextColor(getResources().getColor(R.color.black));
                                }
                            }
                        });
                    }
                }

                @Override
                public void onFailure(Call<StateResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void getCity() {

        if (!CheckNetworkState.isOnline(mContext)) {
            showToastMsg(mContext, getString(R.string.network_error));
            return;
        }

        if (selectedStateId == null || selectedStateId.isEmpty()) {
            return;
        }

        showProgressDialog(mContext);

        try {
            Call<CityResponse> cityRequest = ((TechquiqApplication) mContext
                    .getApplicationContext()).getService().getCityService(
                    selectedStateId,
                    Utils.getDeviceId(mContext),
                    ApiParameter.DEVICE_TYPE_VALUE,
                    AppConstant.FCM_ID);

            cityRequest.enqueue(new Callback<CityResponse>() {
                @Override
                public void onResponse(Call<CityResponse> call, Response<CityResponse> response) {
                    hideProgressDialog();

                    final ArrayList<CityResponse.City> cities = response.body().getResult();
                    if (cities != null && cities.size() > 0) {
                        ArrayList<String> cityData = new ArrayList<String>();
                        for (int i = 0; i < cities.size(); i++) {
                            cityData.add(i, cities.get(i).getCity_name());
                        }
                        final CountryDialog cityDialog = new CountryDialog(ProfileActivity.this,
                                mContext.getString(R.string.select_city), cityData);
                        cityDialog.setSearchEnable();
                        cityDialog.show();

                        cityDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialogInterface) {
                                if (cityDialog.getPosition() > -1 && cityDialog.isItemClick()) {
                                    selectedCityId = cities.get(cityDialog.getPosition()).getCity_id();
                                    selectCityTv.setText(cities.get(cityDialog.getPosition()).getCity_name());
                                    userDetail.setCityName(cities.get(cityDialog.getPosition()).getCity_name());
                                    selectCityTv.setTextColor(getResources().getColor(R.color.black));
                                }
                            }
                        });
                    }
                }

                @Override
                public void onFailure(Call<CityResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void doEditProfile() {
        try {
            if (!showProgressDialog(this)) {
                return;
            }

            final LoginResponse.Users userDetail = Utils.readUserDetail(this);

            File file = new File(getCacheDir(), "temp.jpg");
            RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file);
            MultipartBody.Part body = MultipartBody.Part.createFormData("image", file.getName(), requestFile);

            MediaType mediaType = MediaType.parse("text/plain");

            RequestBody userId = RequestBody.create(mediaType, "" + userDetail.getUserId());
            Log.e(TAG, "Request : " + userDetail.getUserId());
            RequestBody firstName = RequestBody.create(mediaType, "" + firstNameEt.getText().toString());
            RequestBody lastName = RequestBody.create(mediaType, "" + lastNameEt.getText().toString());
            RequestBody country = RequestBody.create(mediaType, "" + selectedCountryId);
            RequestBody state = RequestBody.create(mediaType, "" + selectedStateId);
            RequestBody city = RequestBody.create(mediaType, "" + selectedCityId);
            RequestBody address = RequestBody.create(mediaType, "" + addressEt.getText().toString());
            RequestBody postalCode = RequestBody.create(mediaType, "" + Integer.parseInt(postalCodeEt.getText().toString()));
            RequestBody phone = RequestBody.create(mediaType, "" + contactEt.getText().toString());
            RequestBody company = RequestBody.create(mediaType, "" + "company");
            RequestBody deviceId = RequestBody.create(mediaType, "" + Utils.getDeviceId(this));
            RequestBody deviceToken = RequestBody.create(mediaType, "" + ApiParameter.DEVICE_TYPE_VALUE);
            RequestBody deviceType = RequestBody.create(mediaType, "" + AppConstant.FCM_ID);

            Call<LoginResponse> editProfileReq;

            if (file.exists()) {
                editProfileReq = ((TechquiqApplication) getApplicationContext())
                        .getService().editProfile(body, userId, firstName, lastName, country,
                                state, city, address, postalCode, phone, company, deviceId, deviceToken, deviceType);
            } else {
                editProfileReq = ((TechquiqApplication) getApplicationContext())
                        .getService().editProfile1(userId, firstName, lastName, country,
                                state, city, address, postalCode, phone, company, deviceId, deviceToken, deviceType);
            }


            Log.e(TAG, "Request : " + editProfileReq.request().url());

            editProfileReq.enqueue(new Callback<LoginResponse>() {
                @Override
                public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                    hideProgressDialog();
                    Log.e(TAG, "Response : " + new Gson().toJson(response.body()));

                    Utils.writeUserDetail(mContext, response.body().getResult());
                    showToastMsg(ProfileActivity.this, getResources().getString(R.string.ws_profile_updated_success));
                    doUnEditable();
                }

                @Override
                public void onFailure(Call<LoginResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * check runtime permisiion
     */
    private void checkPermission() {
        new TedPermission(mContext)
                .setPermissionListener(new PermissionListener() {
                    @Override
                    public void onPermissionGranted() {
                        CropImage.startPickImageActivity(ProfileActivity.this);
                    }

                    @Override
                    public void onPermissionDenied(ArrayList arrayList) {

                    }
                })
                .setDeniedMessage(getResources().getString(R.string.permission))
                .setGotoSettingButton(false)
                .setPermissions(Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE)
                .check();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Bitmap bitmap = null;

        if (requestCode == CropImage.PICK_IMAGE_CHOOSER_REQUEST_CODE && resultCode == RESULT_OK) {
            Uri imageUri = CropImage.getPickImageResultUri(mContext, data);
            CropImage.activity(imageUri)
                    .setAutoZoomEnabled(false)
                    .setInitialCropWindowPaddingRatio(0)
                    .setRequestedSize(500, 500)
                    .setGuidelines(CropImageView.Guidelines.ON)
                    .start(this);
        } else if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE && resultCode == RESULT_OK) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            try {
                fileUri = result.getUri();
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), fileUri);
                createFileFromBitmap(bitmap);

                Glide.with(mContext).load(fileUri).asBitmap().centerCrop()
                        .into(new BitmapImageViewTarget(profilePic) {
                            @Override
                            protected void setResource(Bitmap resource) {
                                RoundedBitmapDrawable circularBitmapDrawable =
                                        RoundedBitmapDrawableFactory.create(mContext.getResources(), resource);
                                circularBitmapDrawable.setCircular(true);
                                profilePic.setImageDrawable(circularBitmapDrawable);
                            }
                        });
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
            showToastMsg(mContext, "Cropping failed");
        }


    }

    private void createFileFromBitmap(Bitmap myBitmap) {
        try {
            if (myBitmap == null) {
                return;
            }
            File f = new File(getCacheDir(), "temp.jpg");
            f.createNewFile();

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            myBitmap.compress(Bitmap.CompressFormat.PNG, 0 /*ignored for PNG*/, bos);
            byte[] bitmapdata = bos.toByteArray();

            FileOutputStream fos = new FileOutputStream(f);
            fos.write(bitmapdata);
            fos.flush();
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
