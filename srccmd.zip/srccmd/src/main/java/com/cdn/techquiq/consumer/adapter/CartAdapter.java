
package com.cdn.techquiq.consumer.adapter;

/**
 * Created by akshaysoni on 31/1/17.
 */

import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.SharedPrefrence;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.activity.AddressActivity;
import com.cdn.techquiq.consumer.activity.BaseActivity;
import com.cdn.techquiq.consumer.activity.CartActivity;
import com.cdn.techquiq.consumer.model.AddressResponse;
import com.cdn.techquiq.consumer.model.CartResponse;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;
import com.google.gson.Gson;

import java.net.SocketTimeoutException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.DataObjectHolder> {

    private String TAG = CartAdapter.class.getSimpleName();

    private Context mContext;
    private CartResponse.CartDetail cartDetail;
    private String addressDetail;
    private long mLastClickTime = 0;

    private class VIEW_TYPES {
        public static final int Normal = 1;
        public static final int Footer = 2;
    }


    public CartAdapter(Context context, CartResponse.CartDetail mCartDetail) {
        this.mContext = context;
        cartDetail = mCartDetail;
        getShippingAddress();
    }

    @Override
    public DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;

        switch (viewType) {
            case VIEW_TYPES.Normal:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_list_item, parent, false);
                break;
            case VIEW_TYPES.Footer:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_footer, parent, false);
                break;
            default:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_list_item, parent, false);
                break;
        }
        return new DataObjectHolder(view);


    }

    @Override
    public void onBindViewHolder(final DataObjectHolder holder, final int position) {
        if (getItemViewType(position) == VIEW_TYPES.Normal) {
            final CartResponse.CartDetail.Items items = cartDetail.getItemses().get(position);

            holder.nameTv.setText(items.getProduct_name_en());
            double price = items.getProduct_base_price();
            holder.amountTv.setText(AppConstant.CURRENCY_SYMBOL + " " + Utils.roundDecimal(String.valueOf(price)));
            holder.qtyTv.setText("" + items.getSelected_qty());

            holder.cancelBt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    removeItemFromCart(items.getItem_id());
                }
            });

            /**
             * Quantity
             */
            holder.minusTv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (SystemClock.elapsedRealtime() - mLastClickTime < 1000) {
                        return;
                    }
                    mLastClickTime = SystemClock.elapsedRealtime();

                    int quantity = Integer.parseInt(holder.qtyTv.getText().toString());
                    if (quantity == 1) {
                        return;
                    } else {
                        quantity = quantity - 1;
                        holder.qtyTv.setText("" + quantity);
                        cartUpdate(items, "" + quantity);
                    }
                }
            });

            holder.plusTv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (SystemClock.elapsedRealtime() - mLastClickTime < 1000) {
                        return;
                    }
                    mLastClickTime = SystemClock.elapsedRealtime();

                    int quantity = Integer.parseInt(holder.qtyTv.getText().toString());
                    if (quantity == items.getProduct_qty()) {
                        ((CartActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.product_count_msg, quantity));
                        return;
                    } else {
                        quantity = quantity + 1;
                        holder.qtyTv.setText("" + quantity);
                        cartUpdate(items, "" + quantity);
                    }
                }
            });


            ArrayList<CartResponse.CartDetail.Items.ProductImage> productImages = items.getProduct_images();
            if (productImages != null && productImages.size() > 0) {
                Glide.with(mContext).load(items.getProduct_images().get(0).getImage())
                        .thumbnail(0.5f)
                        .crossFade()
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .placeholder(R.drawable.placeholder_1)
                        .into(holder.productImg);
            }

        } else if (getItemViewType(position) == VIEW_TYPES.Footer) {

            holder.applyBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String promoCode = holder.promoCodeEt.getText().toString();
                    if (promoCode != null && !promoCode.isEmpty()) {
                        applyPromoCode(holder.promoCodeEt.getText().toString());
                    } else {
                        ((CartActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.enter_promo_code));
                    }
                }
            });

            holder.rlAddressContainer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(mContext, AddressActivity.class);
                    mContext.startActivity(intent);
                }
            });

            if (cartDetail.getPromo_code_id() != null && !cartDetail.getPromo_code_id().isEmpty()) {
                holder.offerLayout.setVisibility(View.VISIBLE);
                holder.discountPriceTv.setText(AppConstant.CURRENCY_SYMBOL + " " + cartDetail.getOffer_amount());
                holder.offerDescriptionTv.setText("");

                if (cartDetail.isOfferRemovable()) {
                    holder.removeOfferIv.setVisibility(View.VISIBLE);
                } else {
                    holder.removeOfferIv.setVisibility(View.GONE);
                }
                holder.removeOfferIv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        removeOffer(Integer.parseInt(cartDetail.getPromo_code_id()));
                    }
                });


                holder.offerTitleTv.setText(mContext.getString(R.string.applied_offfer) + " : "
                        + cartDetail.getPromo_code());
                holder.offerDescriptionTv.setText(cartDetail.getPromo_code_description());

            } else {
                holder.offerLayout.setVisibility(View.GONE);
            }

            if (addressDetail != null) {
                holder.tvShippingAddressDetail.setText(addressDetail);
            }
        }
    }

    public static class DataObjectHolder extends RecyclerView.ViewHolder {

        public TextView nameTv, amountTv, applyBtn, shippingAddressTv, offerTitleTv;
        public ImageView productImg, cancelBt, removeOfferIv;
        public View mparent;
        public TextView tvShippingAddressDetail;

        public LinearLayout rlAddressContainer;
        private EditText promoCodeEt;
        private TextView minusTv, plusTv, qtyTv, discountPriceTv, offerDescriptionTv;
        private LinearLayout offerLayout;

        public DataObjectHolder(View view) {
            super(view);
            mparent = view;
            nameTv = (TextView) view.findViewById(R.id.nameTv);
            productImg = (ImageView) view.findViewById(R.id.productImg);
            cancelBt = (ImageView) view.findViewById(R.id.cancelBt);
            removeOfferIv = (ImageView) view.findViewById(R.id.removeOfferIv);
            minusTv = (TextView) view.findViewById(R.id.minusTv);
            plusTv = (TextView) view.findViewById(R.id.plusTv);
            qtyTv = (TextView) view.findViewById(R.id.qtyTv);

            amountTv = (TextView) view.findViewById(R.id.amountTv);
            applyBtn = (TextView) view.findViewById(R.id.applyBtn);
            promoCodeEt = (EditText) view.findViewById(R.id.promoCodeEt);
            shippingAddressTv = (TextView) view.findViewById(R.id.shippingAddressTv);
            rlAddressContainer = (LinearLayout) view.findViewById(R.id.rlAddressContainer);
            tvShippingAddressDetail = (TextView) view.findViewById(R.id.tvShippingAddressDetail);

            offerLayout = (LinearLayout) view.findViewById(R.id.offerLayout);
            discountPriceTv =
                    (TextView) view.findViewById(R.id.discountPriceTv);
            offerDescriptionTv = (TextView) view.findViewById(R.id.offerDescriptionTv);
            offerTitleTv = (TextView) view.findViewById(R.id.offerTitleTv);
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (position == getItemCount() - 1) {
            return VIEW_TYPES.Footer;
        } else {
            return VIEW_TYPES.Normal;
        }
    }


    @Override
    public int getItemCount() {
        return cartDetail.getItemses().size() + 1;
    }

    private void removeItemFromCart(int itemCartID) {
        try {

            if (!CheckNetworkState.isOnline(mContext)) {
                ((BaseActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.network_error));
                return;
            }

            ((CartActivity) mContext).showProgressDialog(mContext);

            final LoginResponse.Users userDetail = Utils.readUserDetail(mContext);

            final Call<CartResponse> removeCartRequest = ((TechquiqApplication) mContext.getApplicationContext())
                    .getService().removeFromCart(
                            userDetail.getUserId(),
                            cartDetail.getCart_id(),
                            itemCartID,
                            Utils.getDeviceId(mContext),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID);

            Log.e(TAG, "Request cart item remove: " + removeCartRequest.request().url());

            removeCartRequest.enqueue(new Callback<CartResponse>() {
                @Override
                public void onResponse(Call<CartResponse> call, Response<CartResponse> response) {
                    ((CartActivity) mContext).hideProgressDialog();
                    Log.e(TAG, "Response cart item remove: " + new Gson().toJson(response.body()));

                    Utils.hideKeyBoard(mContext);

                    CartResponse removeCartResponse = response.body();
                    int responseStatusCode = removeCartResponse.getResponseStatusCode();
                    if (responseStatusCode == AppConstant.INVALID_CART_ID) {
                        Utils.updateCartId(mContext, removeCartResponse.getCart_id());
                        ((CartActivity) mContext).showToastMsg(mContext, mContext.getResources().getString(R.string.ws_invalid_cart_id));
                        ((CartActivity) mContext).getCartItems();
                        notifyDataSetChanged();
                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        SharedPrefrence.getInstance(mContext)
                                .writeIntPrefs(SharedPrefrence.cartCount,
                                        removeCartResponse.getCartDetail().getCart_count());
                        if (removeCartResponse.getResponseCode().equalsIgnoreCase("0")) {
                            ((CartActivity) mContext).showToastMsg(mContext, response.body().getResponseMessage());
                            return;
                        } else if (removeCartResponse.getResponseCode().equalsIgnoreCase("1")) {

                            Utils.updateCartId(mContext, removeCartResponse.getCartDetail().getCart_id());
                            ((CartActivity) mContext).showToastMsg(mContext, mContext.getResources().getString(R.string.item_removed));
                            if (cartDetail.getPromo_code_id() != null && !cartDetail.getPromo_code_id().isEmpty()) {
                                if (removeCartResponse.getCartDetail().getCart_count() < 1) {
//                                    removeOffer(Integer.parseInt(cartDetail.getPromo_code_id()));
                                }
                            }

                            ((CartActivity) mContext).setAdapter(removeCartResponse);


                        }
                    }
                }

                @Override
                public void onFailure(Call<CartResponse> call, Throwable t) {
                    ((CartActivity) mContext).hideProgressDialog();
                    Utils.hideKeyBoard(mContext);

                    if (t instanceof SocketTimeoutException) {
                        ((CartActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.connection_timeout));
                        return;
                    }
                    ((CartActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void getShippingAddress() {
        ((CartActivity) mContext).showProgressDialog(mContext);
        try {
            final LoginResponse.Users userDetail = Utils.readUserDetail(mContext);
            Call<AddressResponse> shippingAddressRequest = ((TechquiqApplication) mContext
                    .getApplicationContext()).getService().getShippingAddress(
                    userDetail.getUserId(),
                    Utils.getDeviceId(mContext),
                    AppConstant.FCM_ID,
                    ApiParameter.DEVICE_TYPE_VALUE
            );

            Log.e(TAG, "Request Address: " + shippingAddressRequest.request().url());

            shippingAddressRequest.enqueue(new Callback<AddressResponse>() {
                @Override
                public void onResponse(Call<AddressResponse> call, Response<AddressResponse> response) {
                    ((CartActivity) mContext).hideProgressDialog();

                    Log.e(TAG, "Response Address: " + new Gson().toJson(response.body()));
                    Log.e(TAG, response.toString());
                    AddressResponse registrationResponse = response.body();

                    if (registrationResponse.getResponseCode() != null && registrationResponse.getResponseCode().equalsIgnoreCase("0")) {
                        ((CartActivity) mContext).showToastMsg(mContext, response.body().getResponseMessage());
                        return;
                    } else if (registrationResponse.getResponseCode() != null && registrationResponse.getResponseCode().equalsIgnoreCase("1")) {
                        ArrayList<AddressResponse.AddressDetail> shippingResult = registrationResponse.getAddressDetail();
                        for (int i = 0; i < shippingResult.size(); i++) {
                            if (shippingResult.get(i).getAddressType().equalsIgnoreCase("1")) {
                                String address = shippingResult.get(i).getAddress();
                                String city = shippingResult.get(i).getCityName();
                                String state = shippingResult.get(i).getStateName();
                                String country = shippingResult.get(i).getCountryName();
                                addressDetail = shippingResult.get(i).getFirstName() + " " + shippingResult.get(i).getLastName() + " " + address + ", " + city + ", " + state + ", " + country;
                                notifyDataSetChanged();
                            }
                        }
                    }

                }

                @Override
                public void onFailure(Call<AddressResponse> call, Throwable t) {
                    ((CartActivity) mContext).hideProgressDialog();

                    if (t instanceof SocketTimeoutException) {
                        ((CartActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.connection_timeout));
                        return;
                    }
                    ((CartActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    private void cartUpdate(CartResponse.CartDetail.Items items, String quantity) {
        try {
            ((CartActivity) mContext).showProgressDialog(mContext);

            final LoginResponse.Users userDetail = Utils.readUserDetail(mContext);

            Call<CartResponse> validateCartRequest = ((TechquiqApplication) mContext.getApplicationContext())
                    .getService().updateCartItem(userDetail.getUserId(),
                            items.getProduct_id(),
                            Integer.parseInt(quantity),
                            items.getProduct_base_price(),
                            items.getItem_id(),
                            cartDetail.getCart_id(),
                            Utils.getDeviceId(mContext),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID);

            Log.e(TAG, "Request Cart Update: " + validateCartRequest.request().url());

            validateCartRequest.enqueue(new Callback<CartResponse>() {
                @Override
                public void onResponse(Call<CartResponse> call, Response<CartResponse> response) {
                    ((CartActivity) mContext).hideProgressDialog();
                    Utils.hideKeyBoard(mContext);
                    Log.e(TAG, "Response Cart Update: " + new Gson().toJson(response.body()));
                    CartResponse cartResponse = response.body();
                    int responseStatusCode = cartResponse.getResponseStatusCode();
                    if (responseStatusCode == AppConstant.INVALID_CART_ID) {
                        Utils.updateCartId(mContext, cartResponse.getCart_id());
                        ((CartActivity) mContext).showToastMsg(mContext, mContext.getResources().getString(R.string.ws_invalid_cart_id));
                        ((CartActivity) mContext).getCartItems();
                        notifyDataSetChanged();
                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        if (cartResponse.getResponseCode().equalsIgnoreCase("1")) {
                            ((CartActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.ws_cart_update));
                            Utils.updateCartId(mContext, cartResponse.getCartDetail().getCart_id());
                            ((CartActivity) mContext).setAdapter(cartResponse);
                        }
                    }
                }

                @Override
                public void onFailure(Call<CartResponse> call, Throwable t) {
                    ((CartActivity) mContext).hideProgressDialog();
                    Utils.hideKeyBoard(mContext);
                    if (t instanceof SocketTimeoutException) {
                        ((CartActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.connection_timeout));
                        return;
                    }
                    ((CartActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.server_error));

                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void applyPromoCode(String promoCode) {
        try {
            ((CartActivity) mContext).showProgressDialog(mContext);

            final LoginResponse.Users userDetail = Utils.readUserDetail(mContext);

            final Call<CartResponse> promoRequest = ((TechquiqApplication) mContext.getApplicationContext())
                    .getService().applyPromoCode(
                            userDetail.getUserId(),
                            Utils.getDeviceId(mContext),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID,
                            cartDetail.getCart_id(),
                            promoCode);

            Log.e(TAG, "Request : " + promoRequest.request().url());

            promoRequest.enqueue(new Callback<CartResponse>() {
                @Override
                public void onResponse(Call<CartResponse> call, Response<CartResponse> response) {
                    ((CartActivity) mContext).hideProgressDialog();
                    if (response == null) {
                        ((CartActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.server_error));
                        return;
                    }
                    Log.e(TAG, "Response : " + new Gson().toJson(response.body()));

                    Utils.hideKeyBoard(mContext);

                    CartResponse cartResponse = response.body();

                    if (cartResponse != null) {
                        int responseStatusCode = cartResponse.getResponseStatusCode();
                        if (responseStatusCode == AppConstant.INVALID_CART_ID) {
                            Utils.updateCartId(mContext, cartResponse.getCart_id());
                            ((CartActivity) mContext).showToastMsg(mContext, mContext.getResources().getString(R.string.ws_invalid_cart_id));
                            ((CartActivity) mContext).getCartItems();
                            notifyDataSetChanged();
                        } else if (responseStatusCode == AppConstant.INVALID_PROMO_CODE) {
                            ((CartActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.ws_invaild_promo_code));
                        } else if (responseStatusCode == AppConstant.PROMO_CODE_ALREADY_APPLIED) {
                            ((CartActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.ws_promo_codo_already_applied));
                        } else if (responseStatusCode == AppConstant.PROMO_CODE_CAN_NOT_APPLIED) {
                            ((CartActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.ws_promo_code_cant_applied));
                        } else if (responseStatusCode == AppConstant.SUCCESS) {
                            ((CartActivity) mContext).showToastMsg(mContext, cartResponse.getResponseMessage());
                            ((CartActivity) mContext).setAdapter(cartResponse);
                        } else {
                            ((CartActivity) mContext).showToastMsg(mContext, cartResponse.getResponseMessage());
                        }


                    }

                }

                @Override
                public void onFailure(Call<CartResponse> call, Throwable t) {
                    ((CartActivity) mContext).hideProgressDialog();
                    Utils.hideKeyBoard(mContext);
                    if (t instanceof SocketTimeoutException) {
                        ((CartActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.connection_timeout));
                        return;
                    }
                    ((CartActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void removeOffer(int promoCodeId) {
        try {
            ((CartActivity) mContext).showProgressDialog(mContext);

            final LoginResponse.Users userDetail = Utils.readUserDetail(mContext);

            Call<CartResponse> validateCartRequest = ((TechquiqApplication) mContext.getApplicationContext())
                    .getService().removeOffer(userDetail.getUserId(),
                            userDetail.getCartId(),
                            promoCodeId,
                            Utils.getDeviceId(mContext),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID);

            Log.e(TAG, "Request remove offer: " + validateCartRequest.request().url());

            validateCartRequest.enqueue(new Callback<CartResponse>() {
                @Override
                public void onResponse(Call<CartResponse> call, Response<CartResponse> response) {
                    ((CartActivity) mContext).hideProgressDialog();

                    Log.e(TAG, "Response remove offer: " + new Gson().toJson(response.body()));

                    Utils.hideKeyBoard(mContext);

                    CartResponse cartResponse = response.body();
                    int responseStatusCode = cartResponse.getResponseStatusCode();
                    if (responseStatusCode == AppConstant.INVALID_CART_ID) {
                        Utils.updateCartId(mContext, cartResponse.getCart_id());
                        ((CartActivity) mContext).showToastMsg(mContext, mContext.getResources().getString(R.string.ws_invalid_cart_id));
                        ((CartActivity) mContext).getCartItems();
                        notifyDataSetChanged();
                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        if (cartDetail.getPromo_code_id() != null && !cartDetail.getPromo_code_id().isEmpty()) {
                            if (cartResponse.getCartDetail() != null) {
                                if (cartResponse.getCartDetail().getCart_count() > 0) {
                                    ((CartActivity) mContext).showToastMsg(mContext, cartResponse.getResponseMessage());
                                }
                            }

                        }
                        if (cartResponse.getCartDetail() != null &&
                                cartResponse.getCartDetail().getCart_id() != null) {
                            ((CartActivity) mContext).setAdapter(cartResponse);
                            Utils.updateCartId(mContext, cartResponse.getCartDetail().getCart_id());
                        }
                    } else {
                        ((CartActivity) mContext).showToastMsg(mContext, cartResponse.getResponseMessage());
                    }


                }

                @Override
                public void onFailure(Call<CartResponse> call, Throwable t) {
                    ((CartActivity) mContext).hideProgressDialog();
                    Utils.hideKeyBoard(mContext);
                    if (t instanceof SocketTimeoutException) {
                        ((CartActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.connection_timeout));
                        return;
                    }
                    ((CartActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getAddressDetail() {
        return addressDetail;
    }

}
