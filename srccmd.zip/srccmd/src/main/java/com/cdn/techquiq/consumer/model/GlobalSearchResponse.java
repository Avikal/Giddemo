package com.cdn.techquiq.consumer.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by avikaljain on 8/5/17.
 */

public class GlobalSearchResponse extends BaseResponse {

    @SerializedName("Result")
    private ArrayList<SearchDetail> searchDetail;

    public ArrayList<SearchDetail> getSearchDetail() {
        return searchDetail;
    }

    public void setSearchDetail(ArrayList<SearchDetail> searchDetail) {
        this.searchDetail = searchDetail;
    }

    @SerializedName("Total")
    private int Total;

    public int getTotal() {
        return Total;
    }

    public void setTotal(int total) {
        Total = total;
    }

    public class SearchDetail {
        @SerializedName("id")
        private String id;

        @SerializedName("name")
        private String name;

        @SerializedName("data_type")
        private String dataType;

        @SerializedName("service_awarded")
        private String serviceAwarded;

        public String getServiceAwarded() {
            return serviceAwarded;
        }

        public void setServiceAwarded(String serviceAwarded) {
            this.serviceAwarded = serviceAwarded;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getDataType() {
            return dataType;
        }

        public void setDataType(String dataType) {
            this.dataType = dataType;
        }
    }
}
