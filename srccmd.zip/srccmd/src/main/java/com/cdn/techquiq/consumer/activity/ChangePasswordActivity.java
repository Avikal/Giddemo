package com.cdn.techquiq.consumer.activity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.model.ChangepasswordResponse;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;

import java.net.SocketTimeoutException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by kajalsoni on 31/1/17.
 */
public class ChangePasswordActivity extends BaseActivity {

    private String TAG = ChangePasswordActivity.class.getSimpleName();

    private EditText oldPasswordEt, newPasswordEt, confirmNewPasswordEt;
    private TextView titleTv;
    private ImageView backIv;

    private ImageView cancelIv;
    private ImageView doneIv;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.change_password_activity);

        mContext = this;
        setUpUI();
    }

    private void setUpUI() {
        backIv = (ImageView) findViewById(R.id.backIv);
        backIv.setOnClickListener(this);
        titleTv = (TextView) findViewById(R.id.titleTv);
        titleTv.setText(mContext.getResources().getString(R.string.change_password));
        oldPasswordEt = (EditText) findViewById(R.id.oldpasswordEt);
        newPasswordEt = (EditText) findViewById(R.id.newPasswordEt);
        confirmNewPasswordEt = (EditText) findViewById(R.id.confirmNewPasswordEt);
        cancelIv = (ImageView) findViewById(R.id.cancelIv);
        doneIv = (ImageView) findViewById(R.id.doneIv);
        doneIv.setOnClickListener(this);
        cancelIv.setOnClickListener(this);
    }


    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.doneIv:
                Utils.hideKeyBoard(mContext);
                if (isValidate()) {
                    doChangePassword();
                }
                break;

            case R.id.backIv:
                finish();
                break;
            case R.id.cancelIv:
                finish();
                break;
        }
    }

    private boolean isValidate() {
        if (oldPasswordEt.getText().toString().isEmpty()) {
            showToastMsg(mContext, mContext.getString(R.string.enter_old_password));
            return false;
        } else if (newPasswordEt.getText().toString().isEmpty()) {
            showToastMsg(mContext, mContext.getString(R.string.enter_new_password));
            return false;
        } else if (newPasswordEt.getText().toString().length() < 6 || newPasswordEt.getText().toString().length() > 20) {
            showToastMsg(mContext, mContext.getString(R.string.password_length_msg));
            return false;
        } else if (confirmNewPasswordEt.getText().toString().isEmpty()) {
            showToastMsg(mContext, mContext.getString(R.string.enter_confirm_new_password));
            return false;
        } else if (confirmNewPasswordEt.getText().toString().length() < 6 || confirmNewPasswordEt.getText().toString().length() > 20) {
            showToastMsg(mContext, mContext.getString(R.string.password_length_msg));
            return false;
        } else if (!newPasswordEt.getText().toString().equals(confirmNewPasswordEt.getText().toString())) {
            showToastMsg(mContext, mContext.getString(R.string.enter_same_password_change));
            return false;
        } else if (oldPasswordEt.getText().toString().equals(newPasswordEt.getText().toString())) {
            showToastMsg(mContext, mContext.getString(R.string.old_new_same));
            return false;
        } else {
            return true;
        }
    }

    private void doChangePassword() {

        if (!CheckNetworkState.isOnline(mContext)) {
            showToastMsg(mContext, getString(R.string.network_error));
            return;
        }

        showProgressDialog(mContext);

        final LoginResponse.Users userDetail = Utils.readUserDetail(mContext);

        try {
            Call<ChangepasswordResponse> changePwdReq = ((TechquiqApplication) mContext
                    .getApplicationContext()).getService().changePasswordService(
                    userDetail.getUserId(),
                    oldPasswordEt.getText().toString(),
                    newPasswordEt.getText().toString(),
                    Utils.getDeviceId(mContext),
                    ApiParameter.DEVICE_TYPE_VALUE,
                    AppConstant.FCM_ID);

            changePwdReq.enqueue(new Callback<ChangepasswordResponse>() {
                @Override
                public void onResponse(Call<ChangepasswordResponse> call, Response<ChangepasswordResponse> response) {
                    hideProgressDialog();
                    if (response == null) {
                        showToastMsg(mContext, getString(R.string.server_error));
                        return;
                    }
                    ChangepasswordResponse changepasswordResponse = response.body();
                    int responseStatusCode = changepasswordResponse.getResponseStatusCode();
                    if (responseStatusCode == AppConstant.PARAM_MISSING) {
                        showToastMsg(mContext, getString(R.string.ws_param_missing));
                    } else if (responseStatusCode == AppConstant.WRONG_EXISTING_PASSWORD) {
                        showToastMsg(mContext, getString(R.string.ws_wrong_exisiting_password));
                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        if (changepasswordResponse.getResponseCode().equalsIgnoreCase("0")) {
                            showToastMsg(mContext, response.body().getResponseMessage());
                        } else {
                            Log.e(TAG, response.body().getResponseCode());
                            finish();
                            showToastMsg(mContext, getString(R.string.ws_password_updated));
                        }
                    } else {
                        showToastMsg(mContext, response.body().getResponseMessage());
                    }

                }

                @Override
                public void onFailure(Call<ChangepasswordResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /*private void msgDialog(String msg) {
        new AlertDialog.Builder(mContext)
                .setTitle(mContext.getString(R.string.app_name))
                .setMessage(msg)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        finish();
                    }
                })
                *//*.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })*//*
                .setIcon(R.drawable.app_logo)
                .setCancelable(false)
                .show();
    }*/

}
