package com.cdn.techquiq.consumer.model;

/**
 * Created by avikaljain on 6/5/17.
 */

public class MerchantAwardResponse extends BaseResponse {
}
