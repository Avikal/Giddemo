package com.cdn.techquiq.consumer.widget;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.Button;

import com.cdn.techquiq.consumer.Utils.Utils;

/**
 * Created by avikaljain on 2/3/17.
 */

public class RegularButtonView extends Button {

    public RegularButtonView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    public RegularButtonView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public RegularButtonView(Context context) {
        super(context);
        init();
    }

    private void init() {
        if (!isInEditMode()) {

            Typeface tf = null;
            if (Utils.getLocale().equalsIgnoreCase("EN")) {
                tf = Utils.robotoRegular;
                if (tf != null) {
                    setTypeface(tf);
                }
            }
        }
    }
}
