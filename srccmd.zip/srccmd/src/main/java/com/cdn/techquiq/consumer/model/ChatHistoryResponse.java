package com.cdn.techquiq.consumer.model;

import com.cdn.techquiq.consumer.database.Chat;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by avikaljain on 2/5/17.
 */

public class ChatHistoryResponse extends BaseResponse {

    @SerializedName("Result")
    private ArrayList<Chat> chats;

    @SerializedName("TotalChat")
    private int TotalChat;

    @SerializedName("currentOffset")
    private int currentOffset;

    @SerializedName("previous_offset")
    private int previous_offset;

    public ArrayList<Chat> getChats() {
        return chats;
    }

    public void setChats(ArrayList<Chat> chats) {
        this.chats = chats;
    }

    public int getTotalChat() {
        return TotalChat;
    }

    public void setTotalChat(int totalChat) {
        TotalChat = totalChat;
    }

    public int getCurrentOffset() {
        return currentOffset;
    }

    public void setCurrentOffset(int currentOffset) {
        this.currentOffset = currentOffset;
    }

    public int getPrevious_offset() {
        return previous_offset;
    }

    public void setPrevious_offset(int previous_offset) {
        this.previous_offset = previous_offset;
    }
}
