package com.cdn.techquiq.consumer.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by avikaljain on 21/4/17.
 */

public class InboxListResponse extends BaseResponse {

    @SerializedName("Result")
    private ArrayList<InboxList> inboxList;

    public ArrayList<InboxList> getInboxList() {
        return inboxList;
    }

    public void setInboxList(ArrayList<InboxList> inboxList) {
        this.inboxList = inboxList;
    }

    @SerializedName("Total_service")
    private int total_service;

    public int getTotal_service() {
        return total_service;
    }

    public void setTotal_service(int total_service) {
        this.total_service = total_service;
    }

    public class InboxList implements Serializable {


        @SerializedName("id")
        private String id;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        @SerializedName("name")
        private String name;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        @SerializedName("description")
        private String description;

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        @SerializedName("date")
        private String date;

        public String getDate() {
            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }

        @SerializedName("images")
        private ArrayList<ImageList> images;

        public ArrayList<ImageList> getImages() {
            return images;
        }

        public void setImages(ArrayList<ImageList> images) {
            this.images = images;
        }

        @SerializedName("total_proposal")
        private String total_proposal;

        public String getTotal_proposal() {
            return total_proposal;
        }

        public void setTotal_proposal(String total_proposal) {
            this.total_proposal = total_proposal;
        }

        @SerializedName("proposal_data")
        private ArrayList<ProposalData> proposal_data;

        public ArrayList<ProposalData> getProposal_data() {
            return proposal_data;
        }

        public void setProposal_data(ArrayList<ProposalData> proposal_data) {
            this.proposal_data = proposal_data;
        }

        public class ImageList {

            @SerializedName("image")
            private String image;

            public String getImage() {
                return image;
            }

            public void setImage(String image) {
                this.image = image;
            }
        }

        public class ProposalData {

        }
    }
}
