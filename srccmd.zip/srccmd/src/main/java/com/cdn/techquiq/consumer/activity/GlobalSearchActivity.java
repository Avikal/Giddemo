package com.cdn.techquiq.consumer.activity;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.adapter.SearchAdapter;
import com.cdn.techquiq.consumer.model.GlobalSearchResponse;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.google.gson.Gson;

import java.net.SocketTimeoutException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by avikaljain on 8/5/17.
 */

public class GlobalSearchActivity extends BaseActivity {

    private String TAG = GlobalSearchActivity.class.getSimpleName();

    private EditText etSearch;
    private ImageView ivSearchArrow;
    private RecyclerView recyclerView;

    private ImageView backIv;
    private TextView titleTv;

    private TextView noProductTv;
    private int limit;
    private int currentOffset;
    private int totalRecord;
    private String keyword;

    private SearchAdapter searchAdapter;

    private ArrayList<GlobalSearchResponse.SearchDetail> searchList;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        setUpUi();
    }

    private void setUpUi() {

        titleTv = (TextView) findViewById(R.id.titleTv);
        backIv = (ImageView) findViewById(R.id.backIv);
        etSearch = (EditText) findViewById(R.id.etSearch);
        ivSearchArrow = (ImageView) findViewById(R.id.ivSearchArrow);
        recyclerView = (RecyclerView) findViewById(R.id.searchList);
        noProductTv = (TextView) findViewById(R.id.tvPaymentND);

        titleTv.setText(getResources().getString(R.string.search_title));
        backIv.setOnClickListener(this);
        ivSearchArrow.setOnClickListener(this);

        etSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    etSearch.clearFocus();
                    Utils.hideKeyBoard(GlobalSearchActivity.this);
                    serviceCall();
                    return true;
                }
                return false;
            }
        });

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.backIv:
                finish();
                break;

            case R.id.ivSearchArrow:
                Utils.hideKeyBoard(this);
                checkSearch();
                break;

        }
    }


    private void checkSearch() {
        String str = "";
        if (etSearch.getText().toString() != null) {
            str = etSearch.getText().toString().trim();
        } else {
            showToastMsg(mContext, getString(R.string.enter_search_keyword));
        }

        if (!str.equalsIgnoreCase("") && !str.isEmpty()) {
            serviceCall();
        } else {
            showToastMsg(mContext, getString(R.string.enter_search_keyword));
        }
    }

    private void serviceCall() {
        limit = 10;
        currentOffset = 0;
        totalRecord = 0;
        keyword = "";
        getSearchResult(currentOffset, false, keyword);
    }

    private void getSearchResult(int offset, final boolean isLoadMore, String keyword) {
        try {
            this.keyword = keyword;
            if (!isLoadMore) {
                if (!showProgressDialog(GlobalSearchActivity.this)) {
                    noProductTv.setText(getString(R.string.network_error));
                    noProductTv.setVisibility(View.VISIBLE);
                    return;
                }
            }

            final LoginResponse.Users userDetail = Utils.readUserDetail(GlobalSearchActivity.this);

            Call<GlobalSearchResponse> searchRequest = ((TechquiqApplication) this.getApplicationContext())
                    .getService().getGlobalSearch(userDetail.getUserId(),
                            Utils.getDeviceId(GlobalSearchActivity.this),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID,
                            etSearch.getText().toString());

            Log.e(TAG, "Request : " + searchRequest.request().url());

            searchRequest.enqueue(new Callback<GlobalSearchResponse>() {
                @Override
                public void onResponse(Call<GlobalSearchResponse> call, Response<GlobalSearchResponse> response) {

                    if (response == null) {
                        showToastMsg(mContext, getString(R.string.server_error));
                        return;
                    }

                    if (!isLoadMore) {
                        hideProgressDialog();
                    }

                    GlobalSearchResponse globalSearchResponse = response.body();
                    if (globalSearchResponse == null) {
                        showToastMsg(mContext, getString(R.string.server_error));
                        return;
                    }
                    Log.e(TAG, "Response : " + new Gson().toJson(globalSearchResponse));
                    totalRecord = globalSearchResponse.getTotal();
                    Log.e(TAG, String.valueOf(totalRecord));
                    if (globalSearchResponse.getResponseCode().equalsIgnoreCase("0")) {
                        noProductTv.setVisibility(View.VISIBLE);
                        noProductTv.setText(getResources().getString(R.string.ws_search_result));
                        recyclerView.setVisibility(View.GONE);
                        return;
                    } else {
                        recyclerView.setVisibility(View.VISIBLE);
                        noProductTv.setVisibility(View.GONE);
                    }


                    if (isLoadMore) {
                        if (searchList != null) {
                            int offset = searchList.size();
                            for (int i = 0; i < globalSearchResponse.getSearchDetail().size(); i++) {
                                searchList.add(offset, globalSearchResponse.getSearchDetail().get(i));
                                offset++;
                            }

                            searchAdapter.notifyDataSetChanged();
                        }
                    } else {
                        searchList = globalSearchResponse.getSearchDetail();
                        if (searchList != null && searchList.size() > 0) {
                            searchAdapter = new SearchAdapter(GlobalSearchActivity.this, searchList);
                            //recyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), R.drawable.seprator_drawer));
                            recyclerView.setAdapter(searchAdapter);
                            recyclerView.setLayoutManager(new LinearLayoutManager(GlobalSearchActivity.this));

                        }
                    }


                }

                @Override
                public void onFailure(Call<GlobalSearchResponse> call, Throwable t) {
                    hideProgressDialog();
                    noProductTv.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.GONE);
                    if (t instanceof SocketTimeoutException) {
                        noProductTv.setText(getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    noProductTv.setText(getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
