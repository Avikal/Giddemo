package com.cdn.techquiq.consumer.model;

import com.cdn.techquiq.consumer.Utils.Utils;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by avikaljain on 8/5/17.
 */

public class PaymentResponse extends BaseResponse {


    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    @SerializedName("Total")

    private int total;
    @SerializedName("Result")
    private ArrayList<PaymentDetails> paymentDetails;

    public ArrayList<PaymentDetails> getPaymentDetails() {
        return paymentDetails;
    }

    public void setPaymentDetails(ArrayList<PaymentDetails> paymentDetails) {
        this.paymentDetails = paymentDetails;
    }

    public class PaymentDetails {
        private String id;
        private String product_name_en;
        private String product_name_ar;
        private String price;
        private String order_id;
        private String date;
        private String time;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getProduct_name_en() {
            return product_name_en;
        }

        public void setProduct_name_en(String product_name_en) {
            this.product_name_en = product_name_en;
        }

        public String getProduct_name_ar() {
            return product_name_ar;
        }

        public void setProduct_name_ar(String product_name_ar) {
            this.product_name_ar = product_name_ar;
        }

        public String getPrice() {
            if (price == null || price.isEmpty()) {
                return "0.0";
            }
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public String getOrder_id() {
            return order_id;
        }

        public void setOrder_id(String order_id) {
            this.order_id = order_id;
        }

        public String getDate() {
            return date;
        }

        public String getTime() {
            return time;
        }

        public void setTime(String time) {
            this.time = time;
        }

        public void setDate(String date) {
            this.date = date;
        }

        public String getName() {
            if (Utils.getLocale().equalsIgnoreCase("ar")) {
                return getProduct_name_ar();
            } else {
                return getProduct_name_en();
            }
        }

    }
}
