package com.cdn.techquiq.consumer.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.activity.ReviewDetailActivity;
import com.cdn.techquiq.consumer.model.ReviewResponse;
import com.marshalchen.ultimaterecyclerview.UltimateRecyclerviewViewHolder;
import com.marshalchen.ultimaterecyclerview.UltimateViewAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by avikaljain on 9/5/17.
 */
public class ReviewAdapter extends UltimateViewAdapter {


    private List<ReviewResponse.UserReviews> reviewsList;

    private Context mContext;
    private LayoutInflater mLayoutInflater;
    private ReviewResponse reviewResponse;
    public int productId;
    public int merchantReviewId;

    public ReviewAdapter(Context mContext, ArrayList<ReviewResponse.UserReviews> reviewsList, ReviewResponse reviewResponse, int productId, int merchantReviewId) {
        this.mContext = mContext;
        this.reviewsList = reviewsList;
        this.reviewResponse = reviewResponse;
        this.productId = productId;
        this.merchantReviewId = merchantReviewId;
        mLayoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }


    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
        if (reviewsList.size() == position) {
            Log.e("RETURN POSITION", "" + position);
            return;
        }
        final ReviewResponse.UserReviews userDetail = reviewsList.get(position);
        if (position < getItemCount() && (customHeaderView != null ? position <= reviewsList.size() : position < reviewsList.size()) && (customHeaderView != null ? position > 0 : true)) {

            ((ViewHolderReview) holder).tvUserName.setText(userDetail.getUserFirstName() + " " + userDetail.getUserLastName());
            ((ViewHolderReview) holder).tvReviewDes.setText(userDetail.getReview());
            ((ViewHolderReview) holder).reviewRating.setRating(Float.parseFloat(userDetail.getRating()));


            ((ViewHolderReview) holder).openContainer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (productId != 0) {
                        Intent intent = new Intent(mContext, ReviewDetailActivity.class);
                        intent.putExtra("merchantReview", userDetail.getReview());
                        intent.putExtra("ratingType", userDetail.getRatingType());
                        mContext.startActivity(intent);
                    } else if (merchantReviewId != 0) {
                        String merchantName = reviewResponse.getMerchantInfo().getMerchantFirstName() + " "
                                + reviewResponse.getMerchantInfo().getMerchantLastName();
                        Intent intent = new Intent(mContext, ReviewDetailActivity.class);
                        intent.putExtra("merchantName", merchantName);
                        intent.putExtra("merchantImage", reviewResponse.getMerchantInfo().getMerchantImage());
                        intent.putExtra("merchantRating", reviewResponse.getAverageRating());
                        intent.putExtra("merchantReview", userDetail.getReview());
                        intent.putExtra("ratingType", userDetail.getRatingType());
                        mContext.startActivity(intent);
                    }
                }
            });
        }
    }

    @Override
    public int getAdapterItemCount() {
        return reviewsList.size();
    }

    @Override
    public RecyclerView.ViewHolder newFooterHolder(View view) {
        return new UltimateRecyclerviewViewHolder<>(view);
    }

    @Override
    public RecyclerView.ViewHolder newHeaderHolder(View view) {
        return new UltimateRecyclerviewViewHolder<>(view);
    }

    @Override
    public UltimateRecyclerviewViewHolder onCreateViewHolder(ViewGroup parent) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_review, parent, false);
        ReviewAdapter.ViewHolderReview vh = new ReviewAdapter.ViewHolderReview(v);
        return vh;
    }


    public void insert(String string, int position) {
        insertInternal(reviewsList, string, position);
    }

    public void remove(int position) {
        removeInternal(reviewsList, position);
    }

    public void clear() {
        clearInternal(reviewsList);
    }


    public void swapPositions(int from, int to) {
        swapPositions(reviewsList, from, to);
    }


    @Override
    public long generateHeaderId(int position) {
        // URLogs.d("position--" + position + "   " + getItem(position));
        if (getItem(position).length() > 0)
            return getItem(position).charAt(0);
        else return -1;
    }

    @Override
    public RecyclerView.ViewHolder onCreateHeaderViewHolder(ViewGroup viewGroup) {
        return null;
    }

    @Override
    public void onBindHeaderViewHolder(RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    public void onItemMove(int fromPosition, int toPosition) {
        if (fromPosition > 0 && toPosition > 0) {
            swapPositions(fromPosition, toPosition);
            super.onItemMove(fromPosition, toPosition);
        }
    }

    @Override
    public void onItemDismiss(int position) {
        if (position > 0) {
            remove(position);
            notifyDataSetChanged();
            super.onItemDismiss(position);
        }

    }

    public void setOnDragStartListener(OnStartDragListener dragStartListener) {
        mDragStartListener = dragStartListener;

    }

    class ViewHolderReview extends UltimateRecyclerviewViewHolder {

        public TextView tvUserName;
        public TextView tvReviewDes;
        public RatingBar reviewRating;
        View mparent;
        RelativeLayout openContainer;

        public ViewHolderReview(View view) {
            super(view);
            mparent = view;
            tvUserName = (TextView) view.findViewById(R.id.tvUserName);
            tvReviewDes = (TextView) view.findViewById(R.id.tvReviewDes);
            reviewRating = (RatingBar) view.findViewById(R.id.reviewRating);
            openContainer = (RelativeLayout) view.findViewById(R.id.openContainer);
        }

        @Override
        public void onItemSelected() {
            itemView.setBackgroundColor(Color.LTGRAY);
        }

        @Override
        public void onItemClear() {
            itemView.setBackgroundColor(0);
        }
    }

    public String getItem(int position) {
        if (customHeaderView != null)
            position--;

        if (position >= 0 && position < reviewsList.size())
            return String.valueOf(reviewsList.get(position));
        else return "";
    }
}