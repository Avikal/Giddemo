package com.cdn.techquiq.consumer.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.activity.AlertDetailActivity;
import com.cdn.techquiq.consumer.model.AlertResponse;

import java.util.ArrayList;

/**
 * Created by akshaysoni on 29/1/16.
 */
public class OfferAdapter extends PagerAdapter {

    private LayoutInflater inflater = null;

    public Context mContext;
    private ArrayList<AlertResponse.AlertList> alertList;

    public OfferAdapter(Context c, ArrayList<AlertResponse.AlertList> alertList) {
        inflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.mContext = c;
        this.alertList = alertList;
    }

    @Override
    public int getCount() {
        return alertList.size();
    }


    @Override
    public Object instantiateItem(ViewGroup parent, int position) {
        final AlertResponse.AlertList alertBean = alertList.get(position);
        String type = alertBean.getType();
        View convertView = inflater.inflate(R.layout.offer_item, parent, false);
        RelativeLayout mainContainer = (RelativeLayout) convertView.findViewById(R.id.mainContainer);
        TextView offerTitle = (TextView) convertView.findViewById(R.id.offerTitle);
        TextView offerDesc = (TextView) convertView.findViewById(R.id.offerDesc);
        if (type != null && !type.isEmpty() && type.equalsIgnoreCase("Offer")) {
            ((ViewGroup) parent).addView(convertView, 0);
            offerTitle.setText(alertBean.getName());
            offerDesc.setText(alertBean.getDescription());
            mainContainer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(mContext, AlertDetailActivity.class);
                    intent.putExtra("title", alertBean.getName());
                    intent.putExtra("description", alertBean.getDescription());
                    intent.putExtra("image", alertBean.getImage());
                    mContext.startActivity(intent);
                }
            });

        } else {
            offerTitle.setText(mContext.getString(R.string.text_no_offer));
        }

        return convertView;
    }

    @Override
    public void destroyItem(View arg0, int arg1, Object arg2) {
        ((ViewPager) arg0).removeView((View) arg2);
    }

    @Override
    public boolean isViewFromObject(View arg0, Object arg1) {
        return arg0 == ((View) arg1);
    }

    @Override
    public Parcelable saveState() {
        return null;
    }

}