package com.cdn.techquiq.consumer.netcomm;

/**
 * Created by devendrasahu on 13/2/17.
 */
public interface WebApi {

    /**
     * Users
     */
    String REQUEST_LOGIN = "users/login";
    String REQUEST_REGISTRATION = "users/register";
    String REQUEST_GET_COUNTRY = "users/country";
    String REQUEST_GET_STATE = "users/state";
    String REQUEST_GET_CITY = "users/city";
    String REQUEST_CHANGE_PASSWORD = "users/change_password";
    String REQUEST_FORGET_PASSWORD = "users/forgot_password";
    String REQUEST_EDIT_PROFILE = "users/update_profile";
    String REQUEST_LOGOUT = "users/logout";


    /**
     * Products
     */
    String REQUEST_PRODUCT_LIST = "products/product";
    String REQUEST_PRODUCT_SEARCH = "products/search";
    String REQUEST_PRODUCT_FILTER = "products/filter";
    String REQUEST_PRODUCT_CATEGORIES = "products/categories";


    /**
     * cart
     */
    String REQUEST_CART_ADD = "cart/add";
    String REQUEST_CART_DETAIL = "cart/details";
    String REQUEST_CART_REMOVE = "cart/remove";
    String REQUEST_CART_VALIDATE = "cart/validate";
    String REQUEST_CART_UPDATE = "cart/update";
    String REQUEST_PROMO_CODE = "cart/promo_code";
    String REQUEST_REMOVE_PROMO_CODE = "cart/remove_promo_code";

    /**
     * Address
     */
    String REQUEST_GET_ADDRESS = "address/details";
    String REQUEST_ADD_ADDRESS = "address/add";
    String REQUEST_MAKE_DELIVERY_ADDRESS = "address/makeDeliverAddress";
    String REQUEST_EDIT_ADDRESS = "address/edit";
    String REQUEST_DELETE_ADDRESS = "address/delete";

    /**
     * Service
     */
    String REQUEST_SERVICE_DETAIL = "service/details";
    String REQUEST_SERVICE_CATEGORIES = "service/categories";
    String REQUEST_SERVICE_SUB_CATEGORIES = "service/subcategories";
    String REQUEST_ADD_SERVICE = "service/add";
    String REQUEST_AWARD_MERCHANT = "service/awardToMerchant";
    String REQUEST_SERVICE_DELETE = "service/delete";
    String REQUEST_UPDATE_SERVICE_STATUS = "service/updateStatus";

    /**
     * Order
     */
    String REQUEST_SERVICE_PAY = "order/serviceAdd";
    String REQUEST_ORDER_ADD = "order/add";
    String REQUEST_ORDER_HISTORY = "order/history";
    String REQUEST_UPDATE_ORDER_STATUS = "order/updateStatus";

    /**
     * Extra
     */

    String REQUEST_PAYMENT = "payment/detail";
    String REQUEST_GLOBAL_SEARCH = "search/glabal";
    String REQUEST_BRAINTREE_TOKEN = "braintree/getClientToken";
    String REQUEST_INBOX_SERVICE = "inbox/message";
    String REQUEST_CHAT_HISTORY = "chat/user_conversation";

    /**
     * Rating
     */
    String REQUEST_GET_PRODUCT_RATING = "rating/get_product_rating";
    String REQUEST_GET_MERCHANT_RATING = "rating/get_merchant_rating";
    String REQUEST_RATE_ON_PRODUCT = "rating/rate_product";
    String REQUEST_RATE_ON_MERCHANT = "rating/rate_merchant";
    String REQUEST_GET_USER_PRODUCT_RATING = "rating/get_user_product_rating";
    String REQUEST_GET_USER_MERCHANT_RATING = "rating/get_user_merchant_rating";
    String REQUEST_RATE_ON_SERVICE = "rating/rate_service";
    String REQUEST_GET_SERVICE_RATING = "rating/get_service_rating";


    /**
     * Get Profile Detail
     */
    String REQUEST_GET_PROFILE = "users/get_profile_detail";

    /**
     * Contact to us
     */
    String REQUEST_CONTACT = "contact/admin";
    String REQUEST_ALERT = "notification/details";

    /**
     * Notification Status for notification on and off
     */
    String REQUEST_GET_NOTIFICATION_STATUS = "notification/getNotificationStatus";
    String REQUEST_NOTIFICATION_UPDATE = "notification/updateStatus";

    /**
     * For total open proposal count
     */
    String REQUEST_GET_PROPOSAL_COUNT = "service/getProposalCount";

    /**
     * For report to merchant and get merchant report
     */

    String REQUEST_GET_REPORT = "abuse/get_merchant_abuse";
    String REQUEST_ABUSE_REPORT = "abuse/abuse_merchant";

    /**
     * For gating bid detail of particular service
     */
    String REQUEST_BID_DETAIL = "service/awarded_merchant_detail";

}


