package com.cdn.techquiq.consumer;

import android.content.Context;
import android.support.multidex.MultiDex;
import android.support.multidex.MultiDexApplication;
import com.cdn.techquiq.consumer.netcomm.SelfSignInClient;
import com.cdn.techquiq.consumer.netcomm.WebApi;
import com.cdn.techquiq.consumer.netcomm.WebServices;
import com.crashlytics.android.Crashlytics;
//import com.facebook.stetho.Stetho;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import io.fabric.sdk.android.Fabric;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class TechquiqApplication extends MultiDexApplication {

    private static Context mContext;
    static TechquiqApplication appInstance;
    private Retrofit retrofit;
    private WebServices service;

    public static TechquiqApplication getAppInstance() {
        return appInstance;
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        appInstance = TechquiqApplication.this;
        mContext = this.getApplicationContext();

        Fabric.with(this, new Crashlytics());

        retrofit = getClient(AppSettings.URL);
        service = retrofit.create(WebServices.class);
        //Stetho.initializeWithDefaults(this);
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        System.gc();
    }

    public WebServices getService() {
        return service;
    }

    public void setService(WebServices service) {
        this.service = service;
    }

    private Retrofit getClient(String baseUrl) {
        if (retrofit == null) {

            Gson gson = new GsonBuilder()
                    .setLenient()
                    .create();

            retrofit = new Retrofit.Builder()
                    .baseUrl(baseUrl)
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .client(new SelfSignInClient(mContext).getOkHttpClient())
                    .build();

        }
        return retrofit;
    }

    /*public static Context getAppContext() {
        return mContext;
    }

    private void getSHA() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(
                    getPackageName(), PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                Log.d("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT));
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
    }*/
}
