package com.cdn.techquiq.consumer.widget;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;

import com.cdn.techquiq.consumer.Utils.Utils;


/**
 * Created by kajalsoni on 28/1/17.
 * custom TextView to show Regular style Text
 */
public class RegularTextViewAllCaps extends TextView {

    public RegularTextViewAllCaps(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    public RegularTextViewAllCaps(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public RegularTextViewAllCaps(Context context) {
        super(context);
        init();
    }

    private void init() {
        if (!isInEditMode()) {
            Typeface tf = null;
            if (Utils.getLocale().equalsIgnoreCase("EN")) {
                tf = Utils.robotoRegular;
                if (tf != null) {
                    setTypeface(tf);
                }
            }
        }
    }

    @Override
    public void setText(CharSequence text, BufferType type) {
        if (text != null) {
            super.setText(text.toString().toUpperCase(), type);
        }
    }

}