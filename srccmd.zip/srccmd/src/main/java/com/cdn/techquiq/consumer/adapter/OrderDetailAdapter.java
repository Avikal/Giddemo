
package com.cdn.techquiq.consumer.adapter;

/**
 * Created by akshaysoni on 31/1/17.
 */

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.activity.OrderDetailActivity;
import com.cdn.techquiq.consumer.activity.ProductDetailActivity;
import com.cdn.techquiq.consumer.model.OrderHistoryResponse;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;

public class OrderDetailAdapter extends RecyclerView.Adapter<OrderDetailAdapter.DataObjectHolder> {

    private String TAG = OrderDetailAdapter.class.getSimpleName();

    private Context mContext;
    private OrderHistoryResponse.OrderList orderLists;

    private class VIEW_TYPES {
        public static final int Normal = 1;
        public static final int Footer = 2;
    }


    public OrderDetailAdapter(Context context, OrderHistoryResponse.OrderList orderLists) {
        this.mContext = context;
        this.orderLists = orderLists;
    }

    @Override
    public DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;

        switch (viewType) {
            case VIEW_TYPES.Normal:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.order_detail_list_item, parent, false);
                break;
            case VIEW_TYPES.Footer:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.my_order_footer, parent, false);
                break;
            default:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.order_detail_list_item, parent, false);
                break;
        }
        return new DataObjectHolder(view);


    }

    @Override
    public void onBindViewHolder(final DataObjectHolder holder, final int position) {
        if (getItemViewType(position) == VIEW_TYPES.Normal) {

            final OrderHistoryResponse.OrderList.OrderDetail orderDetails = orderLists.getOrderDetail().get(position);
            holder.nameTv.setText(orderDetails.getProductName());
            holder.amountTv.setText(AppConstant.CURRENCY_SYMBOL + " " + orderDetails.getProductBasePrice());
            holder.qtyTv.setText("QTY" + orderDetails.getSelectedQty());

            if (orderDetails.getProductImages().size() > 0) {
                Glide.with(mContext).load(orderDetails.getProductImages().get(0).getImage())
                        .thumbnail(0.5f)
                        .crossFade()
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .placeholder(R.drawable.placeholder_1)
                        .into(holder.productImg);
            }


            holder.llItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (!CheckNetworkState.isOnline(mContext)) {
                        ((OrderDetailActivity) mContext).showToastMsg(mContext, mContext.getResources()
                                .getString(R.string.network_error));
                        return;
                    }

                    try {
                        Intent intent = new Intent(mContext, ProductDetailActivity.class);
                        Bundle mBundle = new Bundle();
                        mBundle.putInt("productId", Integer.parseInt(orderDetails.getProduct_id()));
                        mBundle.putBoolean("isReview", orderLists.isWriteReview());
                        mBundle.putBoolean("isProduct", false);
                        intent.putExtras(mBundle);
                        mContext.startActivity(intent);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });


        } else if (getItemViewType(position) == VIEW_TYPES.Footer) {
            holder.tvShippingAddressDetail.setText(orderLists.getShippingAddress());
            holder.tvOrderStatus.setText(orderLists.getOrderStatus());
            holder.tvPaymentMode.setText(orderLists.getPaymentMode());
            holder.tvOrderDate.setText(orderLists.getCreatedDate());
            holder.tvOrderId.setText(orderLists.getId());
            if (orderLists.getPromoCode() == null) {
                holder.layoutOffer.setVisibility(View.GONE);
            } else {
                holder.layoutOffer.setVisibility(View.VISIBLE);
                holder.offerTitleTv.setText(mContext.getResources().getString(R.string.offer_applied)
                        + " : " + orderLists.getPromoCode());
                holder.offerDescriptionTv.setText(orderLists.getPromoCodeDescription());
                holder.discountPriceTv.setText(AppConstant.CURRENCY_SYMBOL + " " + orderLists.getOfferAmount());

            }

        }
    }

    public class DataObjectHolder extends RecyclerView.ViewHolder {

        ImageView productImg;
        TextView nameTv, amountTv, qtyTv, tvShippingAddressDetail;
        LinearLayout llItem;

        public TextView offerTitleTv;
        public TextView offerDescriptionTv;
        public TextView discountPriceTv;

        public LinearLayout layoutOffer;
        public TextView tvOrderStatus;

        public TextView tvPaymentMode;
        public TextView tvOrderId;
        public TextView tvOrderDate;

        public DataObjectHolder(View view) {
            super(view);
            nameTv = (TextView) view.findViewById(R.id.nameTv);
            amountTv = (TextView) view.findViewById(R.id.amountTv);
            qtyTv = (TextView) view.findViewById(R.id.qtyTv);
            productImg = (ImageView) view.findViewById(R.id.productImg);
            tvShippingAddressDetail = (TextView) view.findViewById(R.id.tvShippingAddressDetail);
            llItem = (LinearLayout) view.findViewById(R.id.llItem);

            offerTitleTv = (TextView) view.findViewById(R.id.offerTitleTv);
            offerDescriptionTv = (TextView) view.findViewById(R.id.offerDescriptionTv);
            discountPriceTv = (TextView) view.findViewById(R.id.discountPriceTv);
            layoutOffer = (LinearLayout) view.findViewById(R.id.layoutOffer);
            tvOrderStatus = (TextView) view.findViewById(R.id.tvOrderStatus);

            tvPaymentMode = (TextView) view.findViewById(R.id.tvPaymentMode);
            tvOrderId = (TextView) view.findViewById(R.id.tvOrderId);
            tvOrderDate = (TextView) view.findViewById(R.id.tvOrderDate);
        }

    }

    @Override
    public int getItemViewType(int position) {
        if (position == orderLists.getOrderDetail().size()) {
            return VIEW_TYPES.Footer;
        } else {
            return VIEW_TYPES.Normal;
        }
    }


    @Override
    public int getItemCount() {
        return orderLists.getOrderDetail().size() + 1;
    }


}
