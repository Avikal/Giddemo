package com.cdn.techquiq.consumer.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.SharedPrefrence;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.model.CartResponse;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.OrderResponse;
import com.cdn.techquiq.consumer.model.ServiceOrderResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;
import com.google.gson.Gson;

import java.net.SocketTimeoutException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by akshaysoni on 3/2/17.
 */
public class ChoosePaymentOptionActivity extends BaseActivity {

    private String TAG = ChoosePaymentOptionActivity.class.getSimpleName();

    private static final int REQUEST_BRAINTREE_PAYMENT = 3;
    private static final int CARD_PAYMENT_REQUEST_CODE = 1;

    private static final int CASH_ON_DELIVERY = 1;
    private static final int CARD_PAYMENT = 3;


    int cartId;
    private TextView titleTv;
    private ImageView backIv;
    private LinearLayout rlCardContainer;

    private Bundle bundle;
    private String totalAmount;

    private TextView tvPaymentAmount;
    private String primaryDescription;
    private String shippingAddress;

    private String merchantId;
    private String serviceId;
    private String bidId;
    private String orderId;


    @Nullable
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        bundle = getIntent().getExtras();
        if (bundle != null) {
            cartId = bundle.getInt("cartId");
            if (cartId == 0) {
                merchantId = bundle.getString("merchantId");
                serviceId = bundle.getString("serviceId");
                bidId = bundle.getString("bidId");
                orderId = bidId;


            } else {
                orderId = String.valueOf(cartId);
            }
            primaryDescription = bundle.getString("primaryDescription");
            shippingAddress = bundle.getString("shippingAddress");
            totalAmount = bundle.getString("totalAmount");

        }

        setUpUI();
    }

    private void setUpUI() {
        titleTv = (TextView) findViewById(R.id.titleTv);
        titleTv.setText(mContext.getString(R.string.payment));
        backIv = (ImageView) findViewById(R.id.backIv);
        rlCardContainer = (LinearLayout) findViewById(R.id.rlCardContainer);
        tvPaymentAmount = (TextView) findViewById(R.id.tvPaymentAmount);
        tvPaymentAmount.setText(AppConstant.CURRENCY_SYMBOL + " " + totalAmount);
        rlCardContainer.setOnClickListener(this);
        backIv.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.backIv:
                finish();
                break;
            case R.id.rlCardContainer:
                if (CheckNetworkState.isOnline(mContext)) {
                    Intent intent = new Intent(ChoosePaymentOptionActivity.this, PaymentByCardActivity.class);
                    intent.putExtra("cartId", cartId);
                    intent.putExtra("shippingAddress", shippingAddress);
                    intent.putExtra("totalAmount", totalAmount);
                    intent.putExtra("primaryDescription", primaryDescription);
                    startActivityForResult(intent, CARD_PAYMENT_REQUEST_CODE);
                } else {
                    showToastMsg(mContext, getResources().getString(R.string.network_error));
                }
                break;
        }
    }


    private void validateCart(final int paymentMode, final String nonce) {
        try {
            if (!CheckNetworkState.isOnline(mContext)) {
                showToastMsg(mContext, getString(R.string.network_error));
                return;
            }

            if (!showProgressDialog(mContext)) {
                return;
            }

            final LoginResponse.Users userDetail = Utils.readUserDetail(this);
            final Call<CartResponse> validateCartRequest = ((TechquiqApplication) mContext.getApplicationContext())
                    .getService().cardValidate(
                            userDetail.getUserId(),
                            cartId,
                            Utils.getDeviceId(this),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID);

            Log.e(TAG, "Request : " + validateCartRequest.request().url());

            validateCartRequest.enqueue(new Callback<CartResponse>() {
                @Override
                public void onResponse(Call<CartResponse> call, Response<CartResponse> response) {
                    hideProgressDialog();


                    if (response == null) {
                        showToastMsg(mContext, getString(R.string.server_error));
                        return;
                    }
                    CartResponse validateCartResponse = response.body();

                    if (validateCartResponse == null) {
                        showToastMsg(mContext, getString(R.string.server_error));
                        return;
                    }

                    Log.e(TAG, "Response : " + new Gson().toJson(validateCartResponse));
                    int responseStatusCode = validateCartResponse.getResponseStatusCode();
                    if (responseStatusCode == AppConstant.PRODUCT_OUT_OF_STOCK) {
                        Utils.writeUserDetail(ChoosePaymentOptionActivity.this, userDetail);
                        SharedPrefrence.getInstance(ChoosePaymentOptionActivity.this).writeIntPrefs(SharedPrefrence.cartCount, 0);
                        showToastMsg(mContext, getString(R.string.ws_product_out_of_stock));
                        finish();
                    } else if (responseStatusCode == AppConstant.CART_AMT_CHANGED) {
                        showToastMsg(mContext, getString(R.string.ws_cart_amount_changed));
                        finish();
                    } else if (responseStatusCode == AppConstant.UNKNOWN_ERROR) {
                        showToastMsg(mContext, getString(R.string.ws_unkonwn_error));
                    } else if (responseStatusCode == AppConstant.INVALID_CART_ID) {
                        Utils.updateCartId(mContext, validateCartResponse.getCart_id());
//                        showToastMsg(mContext, getResources().getString(R.string.ws_invalid_cart_id));
                        finish();
                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        if (validateCartResponse.getResponseCode().equalsIgnoreCase("1")) {
                            Utils.updateCartId(mContext, validateCartResponse.getCartDetail().getCart_id());
                            payProduct(paymentMode, nonce);
                        } else {
                            showToastMsg(mContext, validateCartResponse.getResponseMessage());
                        }
                    } else {
                        showToastMsg(mContext, validateCartResponse.getResponseMessage());
                    }

                }

                @Override
                public void onFailure(Call<CartResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                    Log.e(TAG, "Error : " + t.getMessage());
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void payProduct(int paymentMode, String nonce) {
        try {
            if (!CheckNetworkState.isOnline(mContext)) {
                showToastMsg(mContext, getString(R.string.network_error));
                return;
            }

            if (!showProgressDialog(mContext)) {
                return;
            }
            final LoginResponse.Users userDetail = Utils.readUserDetail(this);
            Call<OrderResponse> userResponse = ((TechquiqApplication) this
                    .getApplicationContext()).getService().sendOder(
                    userDetail.getUserId(),
                    Utils.getDeviceId(this),
                    ApiParameter.DEVICE_TYPE_VALUE,
                    AppConstant.FCM_ID,
                    cartId,
                    paymentMode,
                    "",
                    shippingAddress,
                    nonce);

            Log.e(TAG, "Request : " + userResponse.request().url());
            userResponse.enqueue(new Callback<OrderResponse>() {
                @Override
                public void onResponse(Call<OrderResponse> call, Response<OrderResponse> response) {
                    hideProgressDialog();

                    if (response == null) {
                        return;
                    }
                    Log.e(TAG, "Response : " + new Gson().toJson(response.body()));

                    OrderResponse orderResponse = response.body();
                    if (orderResponse.getResponseCode() != null && orderResponse.getResponseCode().equalsIgnoreCase("0")) {
                        showToastMsg(ChoosePaymentOptionActivity.this, orderResponse.getResponseMessage());
                    } else if (orderResponse.getResponseCode() != null && orderResponse.getResponseCode().equalsIgnoreCase("1")) {
                        OrderResponse.OrderResult orderResult = orderResponse.getOrderResult();

                        int cartCount = Integer.parseInt(orderResult.getCartId());
                        userDetail.setCartId(cartCount);

                        Utils.writeUserDetail(ChoosePaymentOptionActivity.this, userDetail);
                        SharedPrefrence.getInstance(ChoosePaymentOptionActivity.this).writeIntPrefs(SharedPrefrence.cartCount, 0);
//                        showToastMsg(ChoosePaymentOptionActivity.this, orderResponse.getResponseMessage());
                        MainActivity.mainStacks.get(AppConstant.TAB_PRODUCT).clear();
                        MainActivity.mainCurrentTab = AppConstant.TAB_PRODUCT;

                        Intent intent = new Intent(ChoosePaymentOptionActivity.this, MainActivity.class);
                        startActivity(intent);
                        finishAffinity();
                        showToastMsg(ChoosePaymentOptionActivity.this, getResources().getString(R.string.ws_order_placed_successfully));
                    }
                }

                @Override
                public void onFailure(Call<OrderResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CARD_PAYMENT_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                String tokenId = data.getStringExtra("tokenId");
                Log.e(TAG, "Stripe Token id " + tokenId);
                if (cartId == 0) {
                    servicePay(CARD_PAYMENT, tokenId);
                } else {
                    validateCart(CARD_PAYMENT, tokenId);
                }
            }
        }
    }

    private void servicePay(int paymentMode, String nonce) {
        showProgressDialog(ChoosePaymentOptionActivity.this);
        try {
            if (!CheckNetworkState.isOnline(ChoosePaymentOptionActivity.this)) {
                showToastMsg(this, getString(R.string.network_error));
                return;
            }

            final LoginResponse.Users userDetail = Utils.readUserDetail(this);

            Call<ServiceOrderResponse> userResponse = ((TechquiqApplication) this
                    .getApplicationContext()).getService().servicePay(
                    userDetail.getUserId(),
                    Utils.getDeviceId(this),
                    ApiParameter.DEVICE_TYPE_VALUE,
                    AppConstant.FCM_ID,
                    paymentMode, "",
                    shippingAddress,
                    nonce,
                    Integer.parseInt(merchantId), Integer.parseInt(serviceId), Integer.parseInt(bidId));

            Log.e(TAG, "Request : " + userResponse.request().url());

            userResponse.enqueue(new Callback<ServiceOrderResponse>() {
                @Override
                public void onResponse(Call<ServiceOrderResponse> call, Response<ServiceOrderResponse> response) {
                    hideProgressDialog();

                    if (response == null) {
                        showToastMsg(mContext, getResources().getString(R.string.server_error));
                        return;
                    }
                    Log.e(TAG, "Response : " + new Gson().toJson(response.body()));

                    ServiceOrderResponse orderResponse = response.body();
                    if (orderResponse == null) {
                        showToastMsg(mContext, getResources().getString(R.string.server_error));
                    }
                    int responseStatusCode = orderResponse.getResponseStatusCode();
                    if (responseStatusCode == AppConstant.SUCCESS) {
                        if (orderResponse.getResponseCode() != null && orderResponse.getResponseCode().equalsIgnoreCase("0")) {
                            showToastMsg(ChoosePaymentOptionActivity.this, orderResponse.getResponseMessage());
                        } else if (orderResponse.getResponseCode() != null && orderResponse.getResponseCode().equalsIgnoreCase("1")) {
                            showToastMsg(ChoosePaymentOptionActivity.this, orderResponse.getResponseMessage());
                            ChatActivity.awardStatus = "1";
                            Intent intent = new Intent("finish_activity");
                            sendBroadcast(intent);
                            finish();
                        }
                    } else {
                        showToastMsg(mContext, orderResponse.getResponseMessage());
                    }

                }

                @Override
                public void onFailure(Call<ServiceOrderResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
