package com.cdn.techquiq.consumer.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.fragment.CreateFragment;
import com.cdn.techquiq.consumer.model.ServiceImage;

import java.util.ArrayList;

/**
 * Created by avikaljain on 17/4/17.
 */

public class CreateImageAdapter extends RecyclerView.Adapter<CreateImageAdapter.MyViewHolder> {

    private ArrayList<ServiceImage> serviceImageArrayList;
    Context mContext;
    LayoutInflater mLayoutInflater;
    private CreateFragment createFragment;


    public class MyViewHolder extends RecyclerView.ViewHolder {

        public ImageView serviceImage;
        public ImageView ivCancel;

        public MyViewHolder(View view) {
            super(view);

            serviceImage = (ImageView) view.findViewById(R.id.ivService);
            ivCancel = (ImageView) view.findViewById(R.id.ivCancel);

        }
    }

    public CreateImageAdapter(Context context, ArrayList<ServiceImage> serviceImageArrayList, CreateFragment fragment) {
        this.mContext = context;
        this.serviceImageArrayList = serviceImageArrayList;
        this.createFragment = fragment;
        mLayoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public CreateImageAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mLayoutInflater
                .inflate(R.layout.list_create_service, parent, false);
        return new CreateImageAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final CreateImageAdapter.MyViewHolder holder, final int position) {
        final ServiceImage serviceBean = serviceImageArrayList.get(position);

        Glide.with(mContext).load(serviceBean.getUri()).asBitmap().fitCenter()
                .into(holder.serviceImage);

        holder.ivCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                serviceImageArrayList.remove(position);
                CreateFragment.addedImageCount -= 1;
                createFragment.checkImageCount();
                notifyDataSetChanged();
            }
        });


    }


    @Override
    public int getItemCount() {
        return serviceImageArrayList.size();
    }
}
