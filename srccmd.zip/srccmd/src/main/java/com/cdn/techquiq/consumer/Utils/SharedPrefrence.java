package com.cdn.techquiq.consumer.Utils;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * @author akshay soni
 */
public class SharedPrefrence {

    private static SharedPreferences _sPrefs = null;
    private static SharedPreferences.Editor _editor = null;
    private static final String GS_PREFS_NAME = "GS_SHARED_PREFS";
    private static SharedPrefrence _instance = null;


    /**
     * App prefrences
     */
    public static final String isLoggedIn = "isLoggedIn";
    public static final String userDetail = "userDetail";
    public static final String cartCount = "cartCount";
    public static final String brainToken = "brainToken";
    public static final String pushToken = "pushToken";
    public static final String sound = "sound";
    public static final String showPreview = "showPreview";
    public static final String filterJson = "filterJson";

    public SharedPrefrence() {
    }

    private SharedPrefrence(Context context) {
        _sPrefs = context.getSharedPreferences(GS_PREFS_NAME,
                Context.MODE_PRIVATE);
    }

    public static SharedPrefrence getInstance(Context context) {
        if (_instance == null) {
            _instance = new SharedPrefrence(context);
        }
        return _instance;
    }

    public String readPrefs(String pref_name) {
        return _sPrefs.getString(pref_name, "");
    }

    public void writePrefs(String pref_name, String pref_val) {
        _editor = _sPrefs.edit();
        _editor.putString(pref_name, pref_val);
        _editor.commit();
    }

    public void clearPrefs() {
        _editor = _sPrefs.edit();
        _editor.clear();
        _editor.commit();
    }

    public boolean readBooleanPrefs(String pref_name) {
        return _sPrefs.getBoolean(pref_name, false);
    }

    public void writeBooleanPrefs(String pref_name, boolean pref_val) {
        _editor = _sPrefs.edit();
        _editor.putBoolean(pref_name, pref_val);
        _editor.commit();
    }

    public int readIntPrefs(String pref_name) {
        return _sPrefs.getInt(pref_name, 0);
    }

    public void writeIntPrefs(String pref_name, int pref_val) {
        _editor = _sPrefs.edit();
        _editor.putInt(pref_name, pref_val);
        _editor.commit();
    }

    public float readFloatPrefs(String pref_name) {
        return _sPrefs.getFloat(pref_name, 0);
    }

    public void writeFlatPrefs(String pref_name, float pref_val) {
        _editor = _sPrefs.edit();
        _editor.putFloat(pref_name, pref_val);
        _editor.commit();
    }

    public void removePref(String pref_name) {
        _editor = _sPrefs.edit();
        _editor.remove(pref_name);
        _editor.commit();
    }


}
