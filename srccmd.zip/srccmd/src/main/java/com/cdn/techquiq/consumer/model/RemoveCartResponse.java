package com.cdn.techquiq.consumer.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by kajalsoni on 6/2/17.
 */
public class RemoveCartResponse extends BaseResponse {

    @SerializedName("Result")
    ArrayList<CartDetail> cartDetails;

    public ArrayList<CartDetail> getCartDetails() {
        return cartDetails;
    }

    public void setCartDetails(ArrayList<CartDetail> cartDetails) {
        this.cartDetails = cartDetails;
    }

    public class CartDetail implements Serializable {

        public ArrayList<CartItem> getCartItems() {
            return cartItems;
        }

        public void setCartItems(ArrayList<CartItem> cartItems) {
            this.cartItems = cartItems;
        }

        @SerializedName("items")
        ArrayList<CartItem> cartItems;

        public class CartItem implements Serializable {


            @SerializedName("item_id")
            String item_id;

            @SerializedName("product_id")
            String product_id;

            @SerializedName("product_name_en")
            String product_name_en;

            @SerializedName("product_name_ar")
            String product_name_ar;

            @SerializedName("category_id")
            String category_id;

            @SerializedName("category_name_en")
            String category_name_en;

            @SerializedName("category_name_ar")
            String category_name_ar;

            @SerializedName("product_qty")
            String product_qty;

            @SerializedName("product_base_price")
            String product_base_price;

            @SerializedName("product_total_price")
            String product_total_price;

            public String getItem_id() {
                return item_id;
            }

            public void setItem_id(String item_id) {
                this.item_id = item_id;
            }

            public String getProduct_id() {
                return product_id;
            }

            public void setProduct_id(String product_id) {
                this.product_id = product_id;
            }

            public String getProduct_name_en() {
                return product_name_en;
            }

            public void setProduct_name_en(String product_name_en) {
                this.product_name_en = product_name_en;
            }

            public String getProduct_name_ar() {
                return product_name_ar;
            }

            public void setProduct_name_ar(String product_name_ar) {
                this.product_name_ar = product_name_ar;
            }

            public String getCategory_id() {
                return category_id;
            }

            public void setCategory_id(String category_id) {
                this.category_id = category_id;
            }

            public String getCategory_name_en() {
                return category_name_en;
            }

            public void setCategory_name_en(String category_name_en) {
                this.category_name_en = category_name_en;
            }

            public String getCategory_name_ar() {
                return category_name_ar;
            }

            public void setCategory_name_ar(String category_name_ar) {
                this.category_name_ar = category_name_ar;
            }

            public String getProduct_qty() {
                return product_qty;
            }

            public void setProduct_qty(String product_qty) {
                this.product_qty = product_qty;
            }

            public String getProduct_base_price() {
                return product_base_price;
            }

            public void setProduct_base_price(String product_base_price) {
                this.product_base_price = product_base_price;
            }

            public String getProduct_total_price() {
                return product_total_price;
            }

            public void setProduct_total_price(String product_total_price) {
                this.product_total_price = product_total_price;
            }
        }
    }


}
