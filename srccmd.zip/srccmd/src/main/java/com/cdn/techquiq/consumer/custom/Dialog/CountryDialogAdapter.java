package com.cdn.techquiq.consumer.custom.Dialog;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;

import java.util.ArrayList;

/**
 * Created by bhushanvyas on 24/2/16.
 */
public class CountryDialogAdapter extends BaseAdapter {
    private ArrayList<CountryDialog.TextWithPosition> data;
    private Context mcontext;
    private LayoutInflater inflater;

    public CountryDialogAdapter(Context context, ArrayList<CountryDialog.TextWithPosition> data) {
        this.data = data;
        mcontext = context;
        inflater = (LayoutInflater) mcontext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder {
        TextView textView;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder viewHolder;
        if (convertView == null) {
            viewHolder = new ViewHolder();
            convertView = View.inflate(mcontext, R.layout.spinner_list_item, null);
            viewHolder.textView = (TextView) convertView.findViewById(R.id.tv_tinted_spinner);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        viewHolder.textView.setText(data.get(position).getText());

        return convertView;
    }

}
