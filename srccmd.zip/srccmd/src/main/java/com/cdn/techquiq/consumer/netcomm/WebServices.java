package com.cdn.techquiq.consumer.netcomm;

import com.cdn.techquiq.consumer.model.AbuseReportResponse;
import com.cdn.techquiq.consumer.model.AddAddressResponse;
import com.cdn.techquiq.consumer.model.AddressResponse;
import com.cdn.techquiq.consumer.model.AlertResponse;
import com.cdn.techquiq.consumer.model.BaseResponse;
import com.cdn.techquiq.consumer.model.BidDetailResponse;
import com.cdn.techquiq.consumer.model.BrainTreeResponse;
import com.cdn.techquiq.consumer.model.CartResponse;
import com.cdn.techquiq.consumer.model.ChangepasswordResponse;
import com.cdn.techquiq.consumer.model.ChatHistoryResponse;
import com.cdn.techquiq.consumer.model.CityResponse;
import com.cdn.techquiq.consumer.model.ContactResponse;
import com.cdn.techquiq.consumer.model.CountryResponse;
import com.cdn.techquiq.consumer.model.DeleteServiceResponse;
import com.cdn.techquiq.consumer.model.FilterResponse;
import com.cdn.techquiq.consumer.model.ForgetPasswordResponse;
import com.cdn.techquiq.consumer.model.GlobalSearchResponse;
import com.cdn.techquiq.consumer.model.InboxListResponse;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.LogoutResponse;
import com.cdn.techquiq.consumer.model.MerchantAwardResponse;
import com.cdn.techquiq.consumer.model.NotificationResponse;
import com.cdn.techquiq.consumer.model.OrderHistoryResponse;
import com.cdn.techquiq.consumer.model.OrderResponse;
import com.cdn.techquiq.consumer.model.PaymentResponse;
import com.cdn.techquiq.consumer.model.ProductResponse;
import com.cdn.techquiq.consumer.model.ProposalCountResponse;
import com.cdn.techquiq.consumer.model.RatingResponse;
import com.cdn.techquiq.consumer.model.RegistrationResponse;
import com.cdn.techquiq.consumer.model.ReportSuccessResponse;
import com.cdn.techquiq.consumer.model.ReviewResponse;
import com.cdn.techquiq.consumer.model.ServiceAddResponse;
import com.cdn.techquiq.consumer.model.ServiceCategoriesResponse;
import com.cdn.techquiq.consumer.model.ServiceOrderResponse;
import com.cdn.techquiq.consumer.model.ServiceResponse;
import com.cdn.techquiq.consumer.model.StateResponse;
import com.cdn.techquiq.consumer.model.SubCategoriesResponse;
import com.cdn.techquiq.consumer.model.UserResponse;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;

/**
 * Created by kajalsoni on 30/1/17.
 */

public interface WebServices {

    @FormUrlEncoded
    @POST(WebApi.REQUEST_LOGIN)
    Call<LoginResponse> loginService(@Field(value = ApiParameter.EMAIL, encoded = true) String email,
                                     @Field(ApiParameter.PASSWORD) String password,
                                     @Field(ApiParameter.DEVICE_ID) String deviceId,
                                     @Field(ApiParameter.DEVICE_TYPE) String device_type,
                                     @Field(ApiParameter.DEVICE_TOKEN) String devicetoken);

    @FormUrlEncoded
    @POST(WebApi.REQUEST_FORGET_PASSWORD)
    Call<ForgetPasswordResponse> forgetPasswordService(@Field(ApiParameter.EMAIL) String email,
                                                       @Field(ApiParameter.DEVICE_ID) String deviceId,
                                                       @Field(ApiParameter.DEVICE_TYPE) String device_type,
                                                       @Field(ApiParameter.DEVICE_TOKEN) String devicetoken);

    @FormUrlEncoded
    @POST(WebApi.REQUEST_CHANGE_PASSWORD)
    Call<ChangepasswordResponse> changePasswordService(@Field(ApiParameter.USER_ID) int user_id,
                                                       @Field(ApiParameter.OLD_PASSWORD) String old_password,
                                                       @Field(ApiParameter.NEW_PASSWORD) String new_password,
                                                       @Field(ApiParameter.DEVICE_ID) String deviceId,
                                                       @Field(ApiParameter.DEVICE_TYPE) String device_type,
                                                       @Field(ApiParameter.DEVICE_TOKEN) String devicetoken);


    @GET(WebApi.REQUEST_GET_COUNTRY)
    Call<CountryResponse> getCountryService(@Query(ApiParameter.DEVICE_ID) String deviceId,
                                            @Query(ApiParameter.DEVICE_TYPE) String device_type,
                                            @Query(ApiParameter.DEVICE_TOKEN) String devicetoken);

    @GET(WebApi.REQUEST_GET_STATE)
    Call<StateResponse> getStateService(@Query(ApiParameter.COUNTRY_ID) String country_id,
                                        @Query(ApiParameter.DEVICE_ID) String deviceId,
                                        @Query(ApiParameter.DEVICE_TYPE) String device_type,
                                        @Query(ApiParameter.DEVICE_TOKEN) String devicetoken);

    @GET(WebApi.REQUEST_GET_CITY)
    Call<CityResponse> getCityService(@Query(ApiParameter.STATE_ID) String state_id,
                                      @Query(ApiParameter.DEVICE_ID) String deviceId,
                                      @Query(ApiParameter.DEVICE_TYPE) String device_type,
                                      @Query(ApiParameter.DEVICE_TOKEN) String devicetoken);

    @GET(WebApi.REQUEST_REGISTRATION)
    Call<RegistrationResponse> registrationService(@Query(ApiParameter.EMAIL) String email,
                                                   @Query(ApiParameter.PASSWORD) String password,
                                                   @Query(ApiParameter.USER_NAME) String username,
                                                   @Query(ApiParameter.FIRST_NAME) String first_name,
                                                   @Query(ApiParameter.LAST_NAME) String last_name,
                                                   @Query(ApiParameter.COUNTRY) String country,
                                                   @Query(ApiParameter.STATE) String state,
                                                   @Query(ApiParameter.CITY) String city,
                                                   @Query(ApiParameter.ADDRESS) String address,
                                                   @Query(ApiParameter.POSTAL_CODE) int postcode,
                                                   @Query(ApiParameter.PHONE) String phone,
                                                   @Query(ApiParameter.DEVICE_ID) String deviceId,
                                                   @Query(ApiParameter.DEVICE_TOKEN) String devicetoken,
                                                   @Query(ApiParameter.DEVICE_TYPE) String device_type);

    @GET(WebApi.REQUEST_CART_ADD)
    Call<CartResponse> addToCartService(@Query(ApiParameter.USER_ID) int userId,
                                        @Query(ApiParameter.CART_ID) int cartId,
                                        @Query(ApiParameter.PRODUCT_ID) int productId,
                                        @Query(ApiParameter.PRODUCT_QTY) String productQuantity,
                                        @Query(ApiParameter.PRODUCT_BASE_PRICE) String productBasePrice,
                                        @Query(ApiParameter.DEVICE_ID) String deviceId,
                                        @Query(ApiParameter.DEVICE_TYPE) String device_type,
                                        @Query(ApiParameter.DEVICE_TOKEN) String devicetoken);


    @GET(WebApi.REQUEST_CART_DETAIL)
    Call<CartResponse> getCartDetail(@Query(ApiParameter.USER_ID) int userId,
                                     @Query(ApiParameter.CART_ID) int cartId,
                                     @Query(ApiParameter.DEVICE_ID) String deviceId,
                                     @Query(ApiParameter.DEVICE_TYPE) String device_type,
                                     @Query(ApiParameter.DEVICE_TOKEN) String devicetoken);

    @GET(WebApi.REQUEST_CART_REMOVE)
    Call<CartResponse> removeFromCart(@Query(ApiParameter.USER_ID) int userId,
                                      @Query(ApiParameter.CART_ID) int cartId,
                                      @Query(ApiParameter.CART_ITEM_ID) int cartItemId,
                                      @Query(ApiParameter.DEVICE_ID) String deviceId,
                                      @Query(ApiParameter.DEVICE_TYPE) String device_type,
                                      @Query(ApiParameter.DEVICE_TOKEN) String devicetoken);


    @Multipart
    @POST(WebApi.REQUEST_EDIT_PROFILE)
    Call<LoginResponse> editProfile(@Part MultipartBody.Part image,
                                    @Part(ApiParameter.USER_ID) RequestBody userId,
                                    @Part(ApiParameter.FIRST_NAME) RequestBody firstName,
                                    @Part(ApiParameter.LAST_NAME) RequestBody lastName,
                                    @Part(ApiParameter.COUNTRY) RequestBody country,
                                    @Part(ApiParameter.STATE) RequestBody state,
                                    @Part(ApiParameter.CITY) RequestBody city,
                                    @Part(ApiParameter.ADDRESS) RequestBody address,
                                    @Part(ApiParameter.POSTAL_CODE) RequestBody postalCode,
                                    @Part(ApiParameter.PHONE) RequestBody phone,
                                    @Part(ApiParameter.COMPANY) RequestBody company,
                                    @Part(ApiParameter.DEVICE_ID) RequestBody deviceId,
                                    @Part(ApiParameter.DEVICE_TOKEN) RequestBody devicetoken,
                                    @Part(ApiParameter.DEVICE_TYPE) RequestBody deviceType);

    @Multipart
    @POST(WebApi.REQUEST_EDIT_PROFILE)
    Call<LoginResponse> editProfile1(/*@Part MultipartBody.Part image,*/
                                     @Part(ApiParameter.USER_ID) RequestBody userId,
                                     @Part(ApiParameter.FIRST_NAME) RequestBody firstName,
                                     @Part(ApiParameter.LAST_NAME) RequestBody lastName,
                                     @Part(ApiParameter.COUNTRY) RequestBody country,
                                     @Part(ApiParameter.STATE) RequestBody state,
                                     @Part(ApiParameter.CITY) RequestBody city,
                                     @Part(ApiParameter.ADDRESS) RequestBody address,
                                     @Part(ApiParameter.POSTAL_CODE) RequestBody postalCode,
                                     @Part(ApiParameter.PHONE) RequestBody phone,
                                     @Part(ApiParameter.COMPANY) RequestBody company,
                                     @Part(ApiParameter.DEVICE_ID) RequestBody deviceId,
                                     @Part(ApiParameter.DEVICE_TOKEN) RequestBody devicetoken,
                                     @Part(ApiParameter.DEVICE_TYPE) RequestBody deviceType);


    @GET(WebApi.REQUEST_CART_VALIDATE)
    Call<CartResponse> cardValidate(@Query(ApiParameter.USER_ID) int userId,
                                    @Query(ApiParameter.CART_ID) int cartId,
                                    @Query(ApiParameter.DEVICE_ID) String deviceId,
                                    @Query(ApiParameter.DEVICE_TYPE) String device_type,
                                    @Query(ApiParameter.DEVICE_TOKEN) String devicetoken);

    @GET(WebApi.REQUEST_CART_UPDATE)
    Call<CartResponse> updateCartItem(@Query(ApiParameter.USER_ID) int userId,
                                      @Query(ApiParameter.PRODUCT_ID) int productId,
                                      @Query(ApiParameter.PRODUCT_QTY) int productQty,
                                      @Query(ApiParameter.PRODUCT_BASE_PRICE) double productBasePrice,
                                      @Query(ApiParameter.CART_ITEM_ID) int cartItemId,
                                      @Query(ApiParameter.CART_ID) int cartId,
                                      @Query(ApiParameter.DEVICE_ID) String deviceId,
                                      @Query(ApiParameter.DEVICE_TYPE) String device_type,
                                      @Query(ApiParameter.DEVICE_TOKEN) String devicetoken);

    @GET(WebApi.REQUEST_PRODUCT_LIST)
    Call<ProductResponse> productListService(@Query(ApiParameter.USER_ID) int userId,
                                             @Query(ApiParameter.DEVICE_ID) String deviceId,
                                             @Query(ApiParameter.DEVICE_TOKEN) String devicetoken,
                                             @Query(ApiParameter.DEVICE_TYPE) String device_type,
                                             @Query(ApiParameter.LIMIT) int limit,
                                             @Query(ApiParameter.OFFSET) int offset,
                                             @Query(ApiParameter.PRODUCT_ID) int productId);

    @GET(WebApi.REQUEST_PRODUCT_SEARCH)
    Call<ProductResponse> doSearchProduct(@Query(ApiParameter.USER_ID) int userId,
                                          @Query(ApiParameter.DEVICE_ID) String deviceId,
                                          @Query(ApiParameter.DEVICE_TYPE) String device_type,
                                          @Query(ApiParameter.DEVICE_TOKEN) String devicetoken,
                                          @Query(ApiParameter.LIMIT) int limit,
                                          @Query(ApiParameter.OFFSET) int offset,
                                          @Query(ApiParameter.PRODUCT_ID) int productId,
                                          @Query(ApiParameter.KEYWORD) String keyword,
                                          @Query(ApiParameter.FILTER) String filter);

    @GET(WebApi.REQUEST_LOGOUT)
    Call<LogoutResponse> doLogout(@Query(ApiParameter.USER_ID) int userId,
                                  @Query(ApiParameter.DEVICE_ID) String deviceId,
                                  @Query(ApiParameter.DEVICE_TOKEN) String devicetoken,
                                  @Query(ApiParameter.DEVICE_TYPE) String device_type);

    @GET(WebApi.REQUEST_PROMO_CODE)
    Call<CartResponse> applyPromoCode(@Query(ApiParameter.USER_ID) int userId,
                                      @Query(ApiParameter.DEVICE_ID) String deviceId,
                                      @Query(ApiParameter.DEVICE_TYPE) String device_type,
                                      @Query(ApiParameter.DEVICE_TOKEN) String devicetoken,
                                      @Query(ApiParameter.CART_ID) int cartId,
                                      @Query(ApiParameter.PROMO_CODE) String promoCode);


    @GET(WebApi.REQUEST_PRODUCT_FILTER)
    Call<FilterResponse> getFilter(@Query(ApiParameter.USER_ID) int userId,
                                   @Query(ApiParameter.DEVICE_ID) String deviceId,
                                   @Query(ApiParameter.DEVICE_TOKEN) String devicetoken,
                                   @Query(ApiParameter.DEVICE_TYPE) String device_type);

    @GET(WebApi.REQUEST_REMOVE_PROMO_CODE)
    Call<CartResponse> removeOffer(@Query(ApiParameter.USER_ID) int userId,
                                   @Query(ApiParameter.CART_ID) int cartId,
                                   @Query(ApiParameter.PROMO_CODE_ID) int promoCodeId,
                                   @Query(ApiParameter.DEVICE_ID) String deviceId,
                                   @Query(ApiParameter.DEVICE_TYPE) String device_type,
                                   @Query(ApiParameter.DEVICE_TOKEN) String devicetoken);

    /*    @GET(WebApi.REQUEST_GET_ADDRESS)
        Call*/
    @FormUrlEncoded
    @POST(WebApi.REQUEST_ADD_ADDRESS)
    Call<AddAddressResponse> addAddress(@Field(ApiParameter.USER_ID) int userId,
                                        @Field(ApiParameter.DEVICE_ID) String deviceID,
                                        @Field(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                        @Field(ApiParameter.DEVICE_TYPE) String deviceType,
                                        @Field(ApiParameter.FIRST_NAME) String firstName,
                                        @Field(ApiParameter.LAST_NAME) String lastName,
                                        @Field(ApiParameter.COUNTRY_ID) String countryId,
                                        @Field(ApiParameter.STATE_ID) String stateId,
                                        @Field(ApiParameter.CITY_ID) String cityID,
                                        @Field(ApiParameter.ADDRESS) String address,
                                        @Field(ApiParameter.POSTAL_CODE_ADD) int postalCode);


    @GET(WebApi.REQUEST_GET_ADDRESS)
    Call<AddressResponse> getShippingAddress(@Query(ApiParameter.USER_ID) int userId,
                                             @Query(ApiParameter.DEVICE_ID) String deviceId,
                                             @Query(ApiParameter.DEVICE_TOKEN) String devicetoken,
                                             @Query(ApiParameter.DEVICE_TYPE) String device_type);

    @FormUrlEncoded
    @POST(WebApi.REQUEST_MAKE_DELIVERY_ADDRESS)
    Call<AddressResponse> setDeliveryAddress(@Field(ApiParameter.USER_ID) int userId,
                                             @Field(ApiParameter.ADDRESS_ID) String addressID,
                                             @Field(ApiParameter.DEVICE_ID) String deviceId,
                                             @Field(ApiParameter.DEVICE_TOKEN) String devicetoken,
                                             @Field(ApiParameter.DEVICE_TYPE) String device_type);

    @FormUrlEncoded
    @POST(WebApi.REQUEST_EDIT_ADDRESS)
    Call<AddAddressResponse> editAddress(@Field(ApiParameter.USER_ID) int userId,
                                         @Field(ApiParameter.ADDRESS_ID) String addressId,
                                         @Field(ApiParameter.DEVICE_ID) String deviceID,
                                         @Field(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                         @Field(ApiParameter.DEVICE_TYPE) String deviceType,
                                         @Field(ApiParameter.FIRST_NAME) String firstName,
                                         @Field(ApiParameter.LAST_NAME) String lastName,
                                         @Field(ApiParameter.COUNTRY_ID) String countryId,
                                         @Field(ApiParameter.STATE_ID) String stateId,
                                         @Field(ApiParameter.CITY_ID) String cityID,
                                         @Field(ApiParameter.ADDRESS) String address,
                                         @Field(ApiParameter.POSTAL_CODE_ADD) String postalCode);

    @FormUrlEncoded
    @POST(WebApi.REQUEST_DELETE_ADDRESS)
    Call<AddressResponse> deleteAddress(@Field(ApiParameter.DEVICE_ID) String deviceID,
                                        @Field(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                        @Field(ApiParameter.DEVICE_TYPE) String deviceType,
                                        @Field(ApiParameter.USER_ID) int userId,
                                        @Field(ApiParameter.ADDRESS_ID) String addressId);

    /**
     * @param userId
     * @param deviceId
     * @param deviceToken
     * @param deviceType
     * @param limit
     * @param offset
     * @param c_filter    0 for open section, 1 for awarded section,
     * @param servicId    this is for open detail screen
     * @param keyword
     * @return
     */
    @GET(WebApi.REQUEST_SERVICE_DETAIL)
    Call<ServiceResponse> getServiceList(@Query(ApiParameter.USER_ID) int userId,
                                         @Query(ApiParameter.DEVICE_ID) String deviceId,
                                         @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                         @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                         @Query(ApiParameter.LIMIT) int limit,
                                         @Query(ApiParameter.OFFSET) int offset,
                                         @Query(ApiParameter.C_FILTER_TYPE) int c_filter,
                                         @Query(ApiParameter.SERVICE_ID) String servicId,
                                         @Query(ApiParameter.KEYWORD) String keyword);

    @GET(WebApi.REQUEST_SERVICE_CATEGORIES)
    Call<ServiceCategoriesResponse> getServiceCategories(@Query(ApiParameter.USER_ID) int userId,
                                                         @Query(ApiParameter.DEVICE_ID) String deviceId,
                                                         @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                                         @Query(ApiParameter.DEVICE_TYPE) String deviceType);

    @GET(WebApi.REQUEST_SERVICE_SUB_CATEGORIES)
    Call<SubCategoriesResponse> getSubCategories(@Query(ApiParameter.CATEGORY_ID) String categoryId,
                                                 @Query(ApiParameter.USER_ID) int userId,
                                                 @Query(ApiParameter.DEVICE_ID) String deviceId,
                                                 @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                                 @Query(ApiParameter.DEVICE_TYPE) String deviceType);


    @Multipart
    @POST(WebApi.REQUEST_ADD_SERVICE)
    Call<ServiceAddResponse> addService(@Part(ApiParameter.USER_ID) RequestBody userId,
                                        @Part(ApiParameter.DEVICE_ID) RequestBody deviceId,
                                        @Part(ApiParameter.DEVICE_TOKEN) RequestBody deviceToken,
                                        @Part(ApiParameter.DEVICE_TYPE) RequestBody deviceType,
                                        @Part(ApiParameter.SUBJECT) RequestBody subject,
                                        @Part(ApiParameter.CATEGORY_ID) RequestBody categoryId,
                                        @Part(ApiParameter.SUB_CATEGORY_ID) RequestBody subCategoryId,
                                        @Part(ApiParameter.DESCRIPTION) RequestBody description,
                                        @Part(ApiParameter.PICKUP_ADDRESS) RequestBody pickup_address,
                                        @Part MultipartBody.Part image[]);


    @GET(WebApi.REQUEST_INBOX_SERVICE)
    Call<InboxListResponse> getMessageList(@Query(ApiParameter.USER_ID) int userId,
                                           @Query(ApiParameter.DEVICE_ID) String deviceId,
                                           @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                           @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                           @Query(ApiParameter.SERVICE_ID) String serviceId,
                                           @Query(ApiParameter.LIMIT) int limit,
                                           @Query(ApiParameter.OFFSET) int offset,
                                           @Query(ApiParameter.C_FILTER_TYPE) int c_filterr,
                                           @Query(ApiParameter.KEYWORD) String keyword);


    @GET(WebApi.REQUEST_INBOX_SERVICE)
    Call<UserResponse> getMerchantList(@Query(ApiParameter.USER_ID) int userId,
                                       @Query(ApiParameter.DEVICE_ID) String deviceId,
                                       @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                       @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                       @Query(ApiParameter.SERVICE_ID) String serviceId,
                                       @Query(ApiParameter.LIMIT) int limit,
                                       @Query(ApiParameter.OFFSET) int offset,
                                       @Query(ApiParameter.KEYWORD) String keyword);

    @GET(WebApi.REQUEST_ORDER_ADD)
    Call<OrderResponse> sendOder(@Query(ApiParameter.USER_ID) int userId,
                                 @Query(ApiParameter.DEVICE_ID) String deviceId,
                                 @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                 @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                 @Query(ApiParameter.CART_ID) int cartId,
                                 @Query(ApiParameter.PAYMENT_MODE) int paymentMode,
                                 @Query(ApiParameter.TRANSACTION) String transaction,
                                 @Query(ApiParameter.SHIPPING_ADDRESS) String shipping_address,
                                 @Query(ApiParameter.BRAINTREE_NONCE) String payment_method_nonce);

    @GET(WebApi.REQUEST_CHAT_HISTORY)
    Call<ChatHistoryResponse> getHistoryChat(@Query(ApiParameter.MERCHANT_ID) String merchantId,
                                             @Query(ApiParameter.USER_ID) String userId,
                                             @Query(ApiParameter.SERVICE_ID) String serviceId,
                                             @Query(ApiParameter.DEVICE_ID) String deviceId,
                                             @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                             @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                             /*@Query(ApiParameter.TIMESTAMP) long timestamp,
                                             @Query(ApiParameter.MESSAGE_ID) int message_id,*/
                                             @Query(ApiParameter.LIMIT) long limit,
                                             @Query(ApiParameter.OFFSET) int offset);


    @FormUrlEncoded
    @POST(WebApi.REQUEST_AWARD_MERCHANT)
    Call<MerchantAwardResponse> awardMerchant(@Field(ApiParameter.USER_ID) int userId,
                                              @Field(ApiParameter.DEVICE_ID) String deviceId,
                                              @Field(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                              @Field(ApiParameter.DEVICE_TYPE) String deviceType,
                                              @Field(ApiParameter.SERVICE_ID) String serviceId,
                                              @Field(ApiParameter.MERCHANT_ID) String merchantId);


    @GET(WebApi.REQUEST_PAYMENT)
    Call<PaymentResponse> getPaymentList(@Query(ApiParameter.USER_ID) int userId,
                                         @Query(ApiParameter.DEVICE_ID) String deviceId,
                                         @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                         @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                         @Query(ApiParameter.LIMIT) int limit,
                                         @Query(ApiParameter.OFFSET) int offset,
                                         @Query(ApiParameter.KEYWORD) String keyword);


    @GET(WebApi.REQUEST_GLOBAL_SEARCH)
    Call<GlobalSearchResponse> getGlobalSearch(@Query(ApiParameter.USER_ID) int userId,
                                               @Query(ApiParameter.DEVICE_ID) String deviceId,
                                               @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                               @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                               @Query(ApiParameter.FILTER_DATA) String filterdata/*,
                                               @Query(ApiParameter.LIMIT) int limit,
                                               @Query(ApiParameter.OFFSET) int offset*/);


    @GET(WebApi.REQUEST_BRAINTREE_TOKEN)
    Call<BrainTreeResponse> getBrainTreeToken(@Query(ApiParameter.USER_ID) int userId,
                                              @Query(ApiParameter.DEVICE_ID) String deviceId,
                                              @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                              @Query(ApiParameter.DEVICE_TYPE) String deviceType);


    @GET(WebApi.REQUEST_SERVICE_DELETE)
    Call<DeleteServiceResponse> deleteServices(@Query(ApiParameter.USER_ID) int userId,
                                               @Query(ApiParameter.DEVICE_ID) String deviceId,
                                               @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                               @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                               @Query(ApiParameter.SERVICE_ID) int serviceId);


    @GET(WebApi.REQUEST_SERVICE_PAY)
    Call<ServiceOrderResponse> servicePay(@Query(ApiParameter.USER_ID) int userId,
                                          @Query(ApiParameter.DEVICE_ID) String deviceId,
                                          @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                          @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                          @Query(ApiParameter.PAYMENT_MODE) int paymentMode,
                                          @Query(ApiParameter.TRANSACTION) String transaction,
                                          @Query(ApiParameter.SHIPPING_ADDRESS) String shipping_address,
                                          @Query(ApiParameter.BRAINTREE_NONCE) String payment_method_nonce,
                                          @Query(ApiParameter.MERCHANT_ID) int merchantId,
                                          @Query(ApiParameter.SERVICE_ID) int serviceId,
                                          @Query(ApiParameter.BID_ID) int bidId);


    @GET(WebApi.REQUEST_UPDATE_SERVICE_STATUS)
    Call<BaseResponse> updateServiceStatus(@Query(ApiParameter.USER_ID) int userId,
                                           @Query(ApiParameter.DEVICE_ID) String deviceId,
                                           @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                           @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                           @Query(ApiParameter.ORDER_ID) String orderId,
                                           @Query(ApiParameter.MERCHANT_ID) String merchantId,
                                           @Query(ApiParameter.SERVICE_ID) String serviceId);


    @GET(WebApi.REQUEST_ORDER_HISTORY)
    Call<OrderHistoryResponse> orderHistory(@Query(ApiParameter.USER_ID) int userId,
                                            @Query(ApiParameter.DEVICE_ID) String deviceId,
                                            @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                            @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                            @Query(ApiParameter.ORDER_ID) String orderId,
                                            @Query(ApiParameter.KEYWORD) String keyword,
                                            @Query(ApiParameter.LIMIT) int limit,
                                            @Query(ApiParameter.OFFSET) int offset);

    @GET(WebApi.REQUEST_UPDATE_ORDER_STATUS)
    Call<BaseResponse> updateOrderStatus(@Query(ApiParameter.USER_ID) int userId,
                                         @Query(ApiParameter.DEVICE_ID) String deviceId,
                                         @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                         @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                         @Query(ApiParameter.ORDER_ID) String orderId,
                                         @Query(ApiParameter.MERCHANT_ID) String merchantId);


    @GET(WebApi.REQUEST_RATE_ON_PRODUCT)
    Call<RatingResponse> rateOnProduct(@Query(ApiParameter.USER_ID) int userId,
                                       @Query(ApiParameter.DEVICE_ID) String deviceId,
                                       @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                       @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                       @Query(ApiParameter.PRODUCT_ID) String productId,
                                       @Query(ApiParameter.MERCHANT_ID) String merchantId,
                                       @Query(ApiParameter.RATING) float rating,
                                       @Query(ApiParameter.MESSAGE) String message);

    @GET(WebApi.REQUEST_RATE_ON_MERCHANT)
    Call<RatingResponse> rateOnMerchant(@Query(ApiParameter.USER_ID) int userId,
                                        @Query(ApiParameter.DEVICE_ID) String deviceId,
                                        @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                        @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                        @Query(ApiParameter.MERCHANT_ID) String merchantId,
                                        @Query(ApiParameter.RATING) float rating,
                                        @Query(ApiParameter.MESSAGE) String message);


    @GET(WebApi.REQUEST_RATE_ON_SERVICE)
    Call<RatingResponse> rateOnService(@Query(ApiParameter.USER_ID) int userId,
                                       @Query(ApiParameter.DEVICE_ID) String deviceId,
                                       @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                       @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                       @Query(ApiParameter.MERCHANT_ID) String merchantId,
                                       @Query(ApiParameter.SERVICE_ID) String serviceId,
                                       @Query(ApiParameter.RATING) float rating,
                                       @Query(ApiParameter.MESSAGE) String message);


    @GET(WebApi.REQUEST_GET_PRODUCT_RATING)
    Call<ReviewResponse> getProductRatings(@Query(ApiParameter.USER_ID) int userId,
                                           @Query(ApiParameter.DEVICE_ID) String deviceId,
                                           @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                           @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                           @Query(ApiParameter.PRODUCT_ID) int productId,
                                           @Query(ApiParameter.MERCHANT_ID) int merchantId,
                                           @Query(ApiParameter.LIMIT) int limit,
                                           @Query(ApiParameter.OFFSET) int offset);

    @GET(WebApi.REQUEST_GET_MERCHANT_RATING)
    Call<ReviewResponse> getMerchantRatings(@Query(ApiParameter.USER_ID) int userId,
                                            @Query(ApiParameter.DEVICE_ID) String deviceId,
                                            @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                            @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                            @Query(ApiParameter.MERCHANT_ID) int merchantId,
                                            @Query(ApiParameter.LIMIT) int limit,
                                            @Query(ApiParameter.OFFSET) int offset);


    @GET(WebApi.REQUEST_GET_PROFILE)
    Call<LoginResponse> getProfileDetail(@Query(ApiParameter.USER_ID) int userId,
                                         @Query(ApiParameter.DEVICE_ID) String deviceId,
                                         @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                         @Query(ApiParameter.DEVICE_TOKEN) String deviceToken);

    @GET(WebApi.REQUEST_GET_USER_PRODUCT_RATING)
    Call<RatingResponse> getUserProductRating(@Query(ApiParameter.USER_ID) int userId,
                                              @Query(ApiParameter.DEVICE_ID) String deviceId,
                                              @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                              @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                              @Query(ApiParameter.PRODUCT_ID) int productId);


    @GET(WebApi.REQUEST_GET_USER_MERCHANT_RATING)
    Call<RatingResponse> getUserMerchantRating(@Query(ApiParameter.USER_ID) int userId,
                                               @Query(ApiParameter.DEVICE_ID) String deviceId,
                                               @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                               @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                               @Query(ApiParameter.MERCHANT_ID) int merhantId);

    @GET(WebApi.REQUEST_GET_SERVICE_RATING)
    Call<RatingResponse> getServiceRating(@Query(ApiParameter.USER_ID) int userId,
                                          @Query(ApiParameter.DEVICE_ID) String deviceId,
                                          @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                          @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                          @Query(ApiParameter.MERCHANT_ID) int merhantId,
                                          @Query(ApiParameter.SERVICE_ID) int serviceId);


    /* @FormUrlEncoded*/
    @GET(WebApi.REQUEST_CONTACT)
    Call<ContactResponse> contactService(@Query(ApiParameter.USER_ID) int userId,
                                         @Query(ApiParameter.DEVICE_ID) String deviceID,
                                         @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                         @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                         @Query(ApiParameter.MESSAGE_SUBJECT) String subject,
                                         @Query(ApiParameter.MESSAGE_DESCRIPTION) String description);

    @GET(WebApi.REQUEST_ALERT)
    Call<AlertResponse> getAlert(@Query(ApiParameter.USER_ID) int userId,
                                 @Query(ApiParameter.DEVICE_ID) String deviceId,
                                 @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                 @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                 @Query(ApiParameter.LIMIT) int limit,
                                 @Query(ApiParameter.OFFSET) int offset,
                                 @Query(ApiParameter.KEYWORD) String keyword);

    @GET(WebApi.REQUEST_GET_NOTIFICATION_STATUS)
    Call<NotificationResponse> getNotificationStatus(@Query(ApiParameter.USER_ID) int userId,
                                                     @Query(ApiParameter.DEVICE_ID) String deviceId,
                                                     @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                                     @Query(ApiParameter.DEVICE_TYPE) String deviceType);

    @GET(WebApi.REQUEST_NOTIFICATION_UPDATE)
    Call<NotificationResponse> updateNotificationStatus(@Query(ApiParameter.USER_ID) int userId,
                                                        @Query(ApiParameter.DEVICE_ID) String deviceId,
                                                        @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                                        @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                                        @Query(ApiParameter.NOTIFICATION_STATUS) String notificationStatus);

    @GET(WebApi.REQUEST_GET_PROPOSAL_COUNT)
    Call<ProposalCountResponse> getProposalCount(@Query(ApiParameter.USER_ID) int userId,
                                                 @Query(ApiParameter.DEVICE_ID) String deviceId,
                                                 @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                                 @Query(ApiParameter.DEVICE_TYPE) String deviceType);


    @GET(WebApi.REQUEST_GET_REPORT)
    Call<AbuseReportResponse> getAbuseReport(@Query(ApiParameter.USER_ID) int userId,
                                             @Query(ApiParameter.DEVICE_ID) String deviceId,
                                             @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                             @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                             @Query(ApiParameter.MERCHANT_ID) int merchantId);

    @GET(WebApi.REQUEST_ABUSE_REPORT)
    Call<ReportSuccessResponse> doAbuseReport(@Query(ApiParameter.USER_ID) int userId,
                                              @Query(ApiParameter.DEVICE_ID) String deviceId,
                                              @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                              @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                              @Query(ApiParameter.MERCHANT_ID) int merchantId,
                                              @Query(ApiParameter.MESSAGE) String message);

    @GET(WebApi.REQUEST_BID_DETAIL)
    Call<BidDetailResponse> getBid(@Query(ApiParameter.USER_ID) int userId,
                                   @Query(ApiParameter.DEVICE_ID) String deviceId,
                                   @Query(ApiParameter.DEVICE_TOKEN) String deviceToken,
                                   @Query(ApiParameter.DEVICE_TYPE) String deviceType,
                                   @Query(ApiParameter.BID_ID) String bidId);
}

