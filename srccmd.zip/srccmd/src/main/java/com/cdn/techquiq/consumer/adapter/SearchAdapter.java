package com.cdn.techquiq.consumer.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.activity.AwardDetailActivity;
import com.cdn.techquiq.consumer.activity.OpenDetailActivity;
import com.cdn.techquiq.consumer.activity.ProductDetailActivity;
import com.cdn.techquiq.consumer.model.GlobalSearchResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by avikaljain on 8/5/17.
 */

public class SearchAdapter extends RecyclerView.Adapter<SearchAdapter.MyViewHolder> {


    private List<GlobalSearchResponse.SearchDetail> searchList;
    private Context mContext;
    private LayoutInflater mLayoutInflater;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView tvSearchName;
        View mparent;
        RelativeLayout openContainer;


        public MyViewHolder(View view) {
            super(view);
            mparent = view;
            tvSearchName = (TextView) view.findViewById(R.id.tvSearchName);


            openContainer = (RelativeLayout) view.findViewById(R.id.openContainer);

        }
    }

    public SearchAdapter(Context context, ArrayList<GlobalSearchResponse.SearchDetail> searchList) {
        this.mContext = context;
        this.searchList = searchList;
        mLayoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public SearchAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mLayoutInflater
                .inflate(R.layout.list_search, parent, false);
        return new SearchAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final SearchAdapter.MyViewHolder holder, final int position) {
        final GlobalSearchResponse.SearchDetail searchDetail = searchList.get(position);
        holder.tvSearchName.setText(searchDetail.getName());
        final String searchType = searchDetail.getDataType();

        holder.openContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (searchType != null && searchType.equalsIgnoreCase("service")) {

                    if (searchDetail.getServiceAwarded() != null && !searchDetail.getServiceAwarded().isEmpty() && searchDetail.getServiceAwarded().equalsIgnoreCase("1")) {
                        Intent intent = new Intent(mContext, AwardDetailActivity.class);
                        intent.putExtra("id", searchDetail.getId());
                        mContext.startActivity(intent);
                    } else {
                        Intent intent = new Intent(mContext, OpenDetailActivity.class);
                        intent.putExtra("id", searchDetail.getId());
                        mContext.startActivity(intent);
                    }

                } else {
                    Intent intent = new Intent(mContext, ProductDetailActivity.class);
                    Bundle mBundle = new Bundle();
                    mBundle.putInt("productId", Integer.parseInt(searchDetail.getId()));
                    mBundle.putBoolean("isProduct", true);
                    intent.putExtras(mBundle);
                    mContext.startActivity(intent);

                }

            }
        });


    }

    @Override
    public int getItemCount() {
        return searchList.size();
    }
}
