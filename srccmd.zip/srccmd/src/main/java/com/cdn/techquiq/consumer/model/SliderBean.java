package com.cdn.techquiq.consumer.model;

import android.graphics.drawable.Drawable;

/**
 * Created by kajalsoni on 31/1/17.
 */

public class SliderBean {

    String name;
    Drawable Image;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Drawable getImage() {
        return Image;
    }

    public void setImage(Drawable image) {
        Image = image;
    }

    public SliderBean(String name, Drawable image) {
        this.name = name;
        Image = image;
    }
}
