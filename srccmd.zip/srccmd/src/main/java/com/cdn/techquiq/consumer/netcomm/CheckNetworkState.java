package com.cdn.techquiq.consumer.netcomm;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class CheckNetworkState {

    /**
     * This class check network availability, either wifi of any mobile network.
     * It have one static method which return true or false.
     * If network available turn True otherwise false
     */
    public static boolean isOnline(Context context) {

        if (context != null) {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
            if (activeNetwork != null) { // connected to the internet
                if (activeNetwork.getType() == ConnectivityManager.TYPE_WIFI) {
                    return true;
                } else {
                    return activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

}

