package com.cdn.techquiq.consumer.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.adapter.SliderAdapter;
import com.cdn.techquiq.consumer.model.SliderBean;

import java.util.ArrayList;

public class FragmentNavDrawer extends BaseFragment {
    private RecyclerView recyclerView;
    private ActionBarDrawerToggle mDrawerToggle;
    private DrawerLayout mDrawerLayout;
    private SliderAdapter adapter;
    private View containerView;
    private FragmentDrawerListener drawerListener;
    private ArrayList<SliderBean> navdrawerArrayList = new ArrayList<>();
    private TextView tvVersion;

    public FragmentNavDrawer() {

    }

    public void setDrawerListener(FragmentDrawerListener listener) {
        this.drawerListener = listener;
    }

    @Override
    public void onResume() {
        super.onResume();

        adapter = new SliderAdapter(getActivity(), navdrawerArrayList);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // drawer labels
    }

    public void setIconList() {
        navdrawerArrayList.add(new SliderBean(getString(R.string.txt_search_title), ContextCompat.getDrawable(getActivity(), R.drawable.slider_item_search_selector)));
        navdrawerArrayList.add(new SliderBean(getString(R.string.txt_profile_title), ContextCompat.getDrawable(getActivity(), R.drawable.slider_item_profile_selector)));
        navdrawerArrayList.add(new SliderBean(getString(R.string.txt_cart_title), ContextCompat.getDrawable(getActivity(), R.drawable.slider_item_cart_selector)));
        navdrawerArrayList.add(new SliderBean(getString(R.string.setting), ContextCompat.getDrawable(getActivity(), R.drawable.slider_item_setting_selector)));
        navdrawerArrayList.add(new SliderBean(getString(R.string.payment), ContextCompat.getDrawable(getActivity(), R.drawable.slider_item_paymnet_selector)));
        navdrawerArrayList.add(new SliderBean(getString(R.string.txt_aboutUs_title), ContextCompat.getDrawable(getActivity(), R.drawable.slider_item_aboutus_selector)));
        navdrawerArrayList.add(new SliderBean(getString(R.string.txt_privacy_policy), ContextCompat.getDrawable(getActivity(), R.drawable.slider_item_aboutus_selector)));
        navdrawerArrayList.add(new SliderBean(getString(R.string.txt_faq), ContextCompat.getDrawable(getActivity(), R.drawable.slider_item_aboutus_selector)));
        navdrawerArrayList.add(new SliderBean(getString(R.string.txt_contact_us), ContextCompat.getDrawable(getActivity(), R.drawable.slider_item_aboutus_selector)));
        navdrawerArrayList.add(new SliderBean(getString(R.string.txt_logOut_title), ContextCompat.getDrawable(getActivity(), R.drawable.slider_item_logout_selector)));
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View layout = inflater.inflate(R.layout.fragment_navigation_drawer, container, false);

        recyclerView = (RecyclerView) layout.findViewById(R.id.drawerList);
        tvVersion = (TextView) layout.findViewById(R.id.tvVersion);
        tvVersion.setText(getResources().getString(R.string.version) + " " + Utils.appVersion(getActivity()));
        setIconList();


        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(getActivity(), recyclerView, new ClickListener() {
            @Override
            public void onClick(View view, int position) {
                drawerListener.onDrawerItemSelected(view, position);
                mDrawerLayout.closeDrawer(containerView);
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));

        return layout;
    }


    public void setUp(int fragmentId, DrawerLayout drawerLayout, final Toolbar toolbar) {
        containerView = getActivity().findViewById(fragmentId);
        mDrawerLayout = drawerLayout;


        mDrawerToggle = new ActionBarDrawerToggle(getActivity(), drawerLayout, toolbar, R.string.drawer_open, R.string.drawer_close) {
            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);

                getActivity().invalidateOptionsMenu();
            }

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);

                getActivity().invalidateOptionsMenu();
            }

            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                //  toolbar.setAlpha(1 - slideOffset / 2);
            }
        };
        mDrawerToggle.setDrawerIndicatorEnabled(false);

        mDrawerLayout.addDrawerListener(mDrawerToggle);
        mDrawerLayout.post(new Runnable() {
            @Override
            public void run() {
                mDrawerToggle.syncState();

            }
        });

    }

    public static interface ClickListener {
        public void onClick(View view, int position);

        public void onLongClick(View view, int position);
    }

    static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }


    }

    public interface FragmentDrawerListener {
        public void onDrawerItemSelected(View view, int position);
    }

    public void closeKeyboardForceFully() {

        View view = getActivity().getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }
}
