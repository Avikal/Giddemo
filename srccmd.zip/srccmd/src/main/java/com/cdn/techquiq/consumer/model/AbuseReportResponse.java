package com.cdn.techquiq.consumer.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by avikaljain on 23/6/17.
 */

public class AbuseReportResponse extends BaseResponse {

    @SerializedName("Result")
    private ArrayList<Report> reportList;

    public ArrayList<Report> getReportList() {
        return reportList;
    }

    public void setReportList(ArrayList<Report> reportList) {
        this.reportList = reportList;
    }

    public class Report {

        @SerializedName("id")
        private String id;

        @SerializedName("message")
        private String message;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }
}
