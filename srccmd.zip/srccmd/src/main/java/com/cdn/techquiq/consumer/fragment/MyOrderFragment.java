package com.cdn.techquiq.consumer.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.activity.MainActivity;
import com.cdn.techquiq.consumer.adapter.MyOrderAdapter;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.OrderHistoryResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;
import com.google.gson.Gson;
import com.marshalchen.ultimaterecyclerview.UltimateRecyclerView;

import java.net.SocketTimeoutException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by akshaysoni on 3/2/17.
 */
public class MyOrderFragment extends BaseFragment {

    private String TAG = MyOrderFragment.class.getSimpleName();
    private Context mContext;
    private UltimateRecyclerView myOrderList;
    private MyOrderAdapter myOrderAdapter;
    ArrayList<OrderHistoryResponse.OrderList> orderLists;

    private int limit;
    private int currentOffset;
    private int totalRecord;
    private String keyword;
    private TextView tvNoData;
    private LinearLayoutManager linearLayoutManager;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_my_order, null);
        mContext = getActivity();
        myOrderList = (UltimateRecyclerView) rootView.findViewById(R.id.myOrderList);
        myOrderList.setHasFixedSize(false);
        tvNoData = (TextView) rootView.findViewById(R.id.tvNoData);
        linearLayoutManager = new LinearLayoutManager(getContext());
        myOrderList.setLayoutManager(linearLayoutManager);

        myOrderList.setLoadMoreView(LayoutInflater.from(getActivity())
                .inflate(R.layout.custom_bottom_progressbar, null));
        return rootView;
    }

    public void topAndBelowTab() {
        if (getActivity() != null) {
            ((MainActivity) getActivity()).hideBackBtn(true);
            ((MainActivity) getActivity()).hideCartButton(false);
            ((MainActivity) getActivity()).hideSearchButton(true);
            ((MainActivity) getActivity()).hideSettingButton(true);
            ((MainActivity) getActivity()).hideBelowTabBar(false);
        }
    }

    public void callWebService() {
        orderLists = null;
        limit = AppConstant.MY_ORDER_LIMIT;
        currentOffset = 0;
        totalRecord = 0;
        keyword = "";

        getOrderHistory(currentOffset, false, keyword);

        productLoadMore();

    }

    public void getOrderHistory(int offset, final boolean isLoadMore, String keyword) {
        try {
            this.keyword = keyword;
            if (!CheckNetworkState.isOnline(getActivity())) {
                ((MainActivity) getActivity()).hideSearchButton(true);
                if (!isLoadMore) {
                    showLableAndHideList(getString(R.string.network_error));
                } else {
                    showToastMsg(getActivity(), getActivity().getString(R.string.network_error));
                }
                return;
            }

            if (!isLoadMore) {
                if (!showProgressDialog(getActivity())) {
                    return;
                }
            }

            final LoginResponse.Users userDetail = Utils.readUserDetail(getActivity());
            final Call<OrderHistoryResponse> orderHistoryRequest = ((TechquiqApplication) mContext.getApplicationContext())
                    .getService().orderHistory(userDetail.getUserId(),
                            Utils.getDeviceId(getActivity()),
                            AppConstant.FCM_ID,
                            ApiParameter.DEVICE_TYPE_VALUE,
                            null,//orderId for get the order detail
                            keyword, limit, offset);

            Log.e(TAG, "Request : " + orderHistoryRequest.request().url());

            orderHistoryRequest.enqueue(new Callback<OrderHistoryResponse>() {
                @Override
                public void onResponse(Call<OrderHistoryResponse> call, Response<OrderHistoryResponse> response) {
                    Log.e(TAG, "Response : " + new Gson().toJson(response.body()));

                    if (response == null) {
                        showToastMsg(getContext(), getString(R.string.server_error));
                        return;
                    }
                    if (!isLoadMore) {
                        hideProgressDialog();
                    }

                    OrderHistoryResponse orderHistoryResponse = response.body();

                    if (orderHistoryResponse == null) {
                        showToastMsg(getContext(), getString(R.string.server_error));
                        setErrorMessage(getString(R.string.server_error));
                        return;
                    }
                    if (orderHistoryResponse == null) {
                        return;
                    }
                    int responseStatusCode = orderHistoryResponse.getResponseStatusCode();

                    if (responseStatusCode == AppConstant.NO_DATA_FOUND) {
                        setErrorMessage(getResources().getString(R.string.ws_no_my_order_data_found));
                    } else if (responseStatusCode == AppConstant.UNKNOWN_ERROR) {
                        setErrorMessage(getResources().getString(R.string.ws_unkonwn_error));
                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        totalRecord = orderHistoryResponse.getTotalOrder();
                        if (orderHistoryResponse.getResponseCode().equalsIgnoreCase("0")) {
                            if (!isLoadMore) {
                                setErrorMessage(getResources().getString(R.string.ws_no_my_order_data_found));
                                ((MainActivity) getActivity()).hideSearchButton(true);
                            } else {
                                showToastMsg(getActivity(), response.body().getResponseMessage());
                            }
                            return;
                        } else {
                            ((MainActivity) getActivity()).hideSearchButton(false);
                            tvNoData.setVisibility(View.GONE);
                            myOrderList.setVisibility(View.VISIBLE);
                        }
                        if (isLoadMore) {
                            if (orderLists != null) {
                                int offset = orderLists.size();
                                for (int i = 0; i < orderHistoryResponse.getOrderLists().size(); i++) {
                                    orderLists.add(offset, orderHistoryResponse.getOrderLists().get(i));
                                    offset++;
                                }
                                myOrderAdapter.notifyDataSetChanged();
                            }
                        } else {
                            orderLists = orderHistoryResponse.getOrderLists();
                            if (orderLists != null && orderLists.size() > 0) {
                                setAdapter(orderLists);
                            }
                        }

                    } else {
                        showToastMsg(mContext, orderHistoryResponse.getResponseMessage());
                    }


                }

                @Override
                public void onFailure(Call<OrderHistoryResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        setErrorMessage(getString(R.string.connection_timeout));
                        return;
                    }
                    setErrorMessage(getString(R.string.server_error));
                    Log.e(TAG, "Error : " + t.getMessage());
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void showLableAndHideList(String msg) {
        myOrderList.setVisibility(View.GONE);
        tvNoData.setVisibility(View.VISIBLE);
        tvNoData.setText(msg);
    }

    private void productLoadMore() {

        if (myOrderList != null) {
            myOrderList.reenableLoadmore();
            myOrderList.setOnLoadMoreListener(new UltimateRecyclerView.OnLoadMoreListener() {
                @Override
                public void loadMore(int itemsCount, int maxLastVisiblePosition) {
                    try {
                        if (totalRecord <= orderLists.size()) {
                            myOrderList.disableLoadmore();
                        } else {
                            currentOffset = currentOffset + limit;
                            getOrderHistory(currentOffset, true, keyword);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    }

    public void enableLoadMore() {
        if (myOrderList != null) {
            myOrderList.reenableLoadmore();
        }
    }

    private void setAdapter(ArrayList<OrderHistoryResponse.OrderList> oderList) {
        myOrderAdapter = new MyOrderAdapter(getActivity(), oderList);
        myOrderList.setAdapter(myOrderAdapter);
    }

    private void setErrorMessage(String msg) {
        tvNoData.setVisibility(View.VISIBLE);
        tvNoData.setText(msg);
        myOrderList.setVisibility(View.GONE);
    }

}
