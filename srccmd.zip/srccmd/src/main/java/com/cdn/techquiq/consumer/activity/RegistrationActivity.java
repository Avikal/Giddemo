package com.cdn.techquiq.consumer.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.SharedPrefrence;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.custom.Dialog.CountryDialog;
import com.cdn.techquiq.consumer.model.CityResponse;
import com.cdn.techquiq.consumer.model.CountryResponse;
import com.cdn.techquiq.consumer.model.RegistrationResponse;
import com.cdn.techquiq.consumer.model.StateResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;

import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEvent;
import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEventListener;

import java.net.SocketTimeoutException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by akshaysoni on 30/1/17.
 */
public class RegistrationActivity extends BaseActivity {

    private String TAG = RegistrationActivity.class.getSimpleName();

    private EditText fnameEd, lnameEd, passwordEd, confirmPasswordEd, contactEd, emailEd, addressEd, postalcodeEd;
    private Button registerBtn;
    private ImageView backIv;
    private TextView titleTv;

    private String selectedCountryId = "";
    private String selectedStateId = "";
    private String selectedCityId = "";

    private TextView selectCountryTv;
    private TextView selectStateTv;
    private TextView selectCityTv;

    private TextView termsAndConditionTv;
    private CheckBox termsConditionCb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        mContext = this;

        setUpUI();

        KeyboardVisibilityEvent.setEventListener(
                this,
                new KeyboardVisibilityEventListener() {
                    @Override
                    public void onVisibilityChanged(boolean isOpen) {
                        if (isOpen) {
                            registerBtn.setVisibility(View.GONE);
                        } else {
                            registerBtn.setVisibility(View.VISIBLE);
                        }

                    }
                });
    }

    private void setUpUI() {
        titleTv = (TextView) findViewById(R.id.titleTv);
        titleTv.setText(mContext.getString(R.string.register));

        fnameEd = (EditText) findViewById(R.id.fnameEd);
        lnameEd = (EditText) findViewById(R.id.lnameEd);
        passwordEd = (EditText) findViewById(R.id.passwordEt);
        confirmPasswordEd = (EditText) findViewById(R.id.confirmpasswordEt);
        contactEd = (EditText) findViewById(R.id.contactEd);
        emailEd = (EditText) findViewById(R.id.emailEd);
        addressEd = (EditText) findViewById(R.id.addressEd);
        postalcodeEd = (EditText) findViewById(R.id.postalCodeEt);

        registerBtn = (Button) findViewById(R.id.registerBtn);
        backIv = (ImageView) findViewById(R.id.backIv);

        registerBtn.setOnClickListener(this);
        backIv.setOnClickListener(this);

        selectCountryTv = (TextView) findViewById(R.id.selectCountryTv);
        selectCountryTv.setOnClickListener(this);

        selectStateTv = (TextView) findViewById(R.id.selectStateTv);
        selectStateTv.setOnClickListener(this);
        selectCityTv = (TextView) findViewById(R.id.selectCityTv);
        selectCityTv.setOnClickListener(this);
        fnameEd.addTextChangedListener(mTextEditorWatcher);
        lnameEd.addTextChangedListener(mTextEditorWatcher);
        addressEd.addTextChangedListener(mTextEditorWatcherAddress);

        termsAndConditionTv = (TextView) findViewById(R.id.termsAndConditionTv);
        termsConditionCb = (CheckBox) findViewById(R.id.termsConditionCb);
        termsAndConditionTv.setOnClickListener(this);

        fnameEd.setFilters(new InputFilter[]{new InputFilter.LengthFilter(25)});
        lnameEd.setFilters(new InputFilter[]{new InputFilter.LengthFilter(25)});
        addressEd.setFilters(new InputFilter[]{new InputFilter.LengthFilter(150)});

        /**
         * Open Country picker dialog from the below code
         */
        addressEd.setOnEditorActionListener(new EditText.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_NEXT) {
                    getCountry();
                    return true; // Focus will do whatever you put in the logic.
                }
                return false;  // Focus will change according to the actionId
            }
        });


        /**
         * Open Country picker dialog from the below code
         */
        addressEd.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int keyCode, KeyEvent event) {
                if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    getCountry();
                    return true;
                }
                return false;
            }
        });

        checkFocus();
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.backIv:
                finish();
                break;
            case R.id.termsAndConditionTv:
                Intent intent = new Intent(this, PrivacyPolicyActivity.class);
                intent.putExtra("position", 1);
                startActivity(intent);
                break;

            case R.id.registerBtn:
                if (isValidate()) {
                    doRegistration();
                }
                break;

            case R.id.selectCountryTv:
                cursorCheck();
                getCountry();
                break;

            case R.id.selectStateTv:
                cursorCheck();
                getState();
                break;

            case R.id.selectCityTv:
                cursorCheck();
                getCity();

                break;

            /*case R.id.passwordshowIv:
                if (!isCheckedShowPass) {
                    showPassword(passwordEd);
                    isCheckedShowPass = true;
                } else {
                    hidePassword(passwordEd);
                    isCheckedShowPass = false;
                }
                break;
            case R.id.confirmpasswordshowIv:
                if (!isCheckedShowPassconfirm) {
                    showPassword(confirmPasswordEd);
                    isCheckedShowPassconfirm = true;
                } else {
                    hidePassword(confirmPasswordEd);
                    isCheckedShowPassconfirm = false;
                }
                break;*/
        }
    }

    /*private void showPassword(EditText editText) {
        editText.setTransformationMethod(null);
        editText.setSelection(editText.getText().length());
    }

    private void hidePassword(EditText editText) {
        editText.setTransformationMethod(new PasswordTransformationMethod());
        editText.setSelection(editText.getText().length());
    }*/


    private boolean isValidate() {
        if (emailEd.getText().toString().trim() == null || emailEd.getText().toString().trim().isEmpty()) {
            showToastMsg(mContext, mContext.getString(R.string.enter_email));
            return false;
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(emailEd.getText().toString()).matches()) {
            showToastMsg(mContext, mContext.getString(R.string.enter_valid_email));
            return false;
        } else if (passwordEd.getText().toString().trim() == null || passwordEd.getText().toString().trim().isEmpty()) {
            showToastMsg(mContext, mContext.getString(R.string.enter_password));
            return false;
        } else if (passwordEd.getText().toString().length() < 6 || passwordEd.getText().toString().length() > 20) {
            showToastMsg(mContext, mContext.getString(R.string.password_length_msg));
            return false;
        } else if (confirmPasswordEd.getText().toString().trim() == null || confirmPasswordEd.getText().toString().trim().isEmpty()) {
            showToastMsg(mContext, mContext.getString(R.string.enter_confirm_password));
            return false;
        } else if (confirmPasswordEd.getText().toString().length() < 6 || confirmPasswordEd.getText().toString().length() > 20) {
            showToastMsg(mContext, mContext.getString(R.string.password_length_msg));
            return false;
        } else if (!passwordEd.getText().toString().equals(confirmPasswordEd.getText().toString())) {
            showToastMsg(mContext, mContext.getString(R.string.enter_same_password));
            return false;
        } else if (fnameEd.getText().toString().trim() == null || fnameEd.getText().toString().trim().isEmpty()) {
            showToastMsg(mContext, mContext.getString(R.string.enter_first_name));
            return false;
        } else if (lnameEd.getText().toString().trim() == null || lnameEd.getText().toString().trim().isEmpty()) {
            showToastMsg(mContext, mContext.getString(R.string.enter_last_name));
            return false;
        } else if (contactEd.getText().toString().trim() == null || contactEd.getText().toString().trim().isEmpty()) {
            showToastMsg(mContext, mContext.getString(R.string.enter_contact_number));
            return false;
        } else if (contactEd.getText().toString().length() < 10) {
            showToastMsg(mContext, mContext.getString(R.string.contact_length_msg));
            return false;
        } else if (addressEd.getText().toString().trim() == null || addressEd.getText().toString().trim().isEmpty()) {
            showToastMsg(mContext, mContext.getString(R.string.enter_address));
            return false;
        } else if (selectCountryTv.getText().toString().trim() == null || selectCountryTv.getText().toString().trim().isEmpty() || selectCountryTv.getText().toString().equalsIgnoreCase(getResources().getString(R.string.select_country))) {
            showToastMsg(mContext, mContext.getString(R.string.select_country_msg));
            return false;
        } else if (selectStateTv.getText().toString().trim() == null || selectStateTv.getText().toString().trim().isEmpty() || selectStateTv.getText().toString().equalsIgnoreCase(getResources().getString(R.string.select_state))) {
            showToastMsg(mContext, mContext.getString(R.string.select_state_msg));
            return false;
        } else if (selectCityTv.getText().toString().trim() == null || selectCityTv.getText().toString().trim().isEmpty() || selectCityTv.getText().toString().equalsIgnoreCase(getResources().getString(R.string.select_city))) {
            showToastMsg(mContext, mContext.getString(R.string.select_city_msg));
            return false;
        } else if (postalcodeEd.getText().toString().trim() == null || postalcodeEd.getText().toString().trim().isEmpty()) {
            showToastMsg(mContext, mContext.getString(R.string.enter_postal_code));
            return false;
        } else if (postalcodeEd.getText().toString().length() < 5) {
            showToastMsg(mContext, mContext.getString(R.string.postal_code_length_msg));
            return false;
        } else if (!termsConditionCb.isChecked()) {
            showToastMsg(mContext, mContext.getString(R.string.select_terms_condition));
            return false;
        } else {
            return true;
        }

    }

    private void doRegistration() {

        if (!CheckNetworkState.isOnline(mContext)) {
            showToastMsg(mContext, getString(R.string.network_error));
            return;
        }

        showProgressDialog(mContext);
        String fcm_token = SharedPrefrence.getInstance(mContext).readPrefs(SharedPrefrence.pushToken);
        try {
            Call<RegistrationResponse> registrationRequest = ((TechquiqApplication) mContext
                    .getApplicationContext()).getService().registrationService(
                    emailEd.getText().toString(),
                    passwordEd.getText().toString(),
                    fnameEd.getText().toString(),
                    fnameEd.getText().toString(),
                    lnameEd.getText().toString(),
                    selectedCountryId,
                    selectedStateId,
                    selectedCityId,
                    addressEd.getText().toString(),
                    Integer.parseInt(postalcodeEd.getText().toString()),
                    contactEd.getText().toString(),
                    Utils.getDeviceId(mContext), ApiParameter.DEVICE_TYPE_VALUE,
                    fcm_token);
            Log.e(TAG, "Device ID " + Utils.getDeviceId(mContext));
            Log.e(TAG, "Device Token " + ApiParameter.DEVICE_TYPE_VALUE);
            Log.e(TAG, "Device Type " + AppConstant.FCM_ID);
            Log.e(TAG, "Request : " + registrationRequest.request().url());
            registrationRequest.enqueue(new Callback<RegistrationResponse>() {
                @Override
                public void onResponse(Call<RegistrationResponse> call, Response<RegistrationResponse> response) {
                    hideProgressDialog();

                    RegistrationResponse registrationResponse = response.body();
                    int responseStatusCode = registrationResponse.getResponseStatusCode();
                    if (responseStatusCode == AppConstant.PARAM_MISSING) {
                        showToastMsg(mContext, getString(R.string.ws_param_missing));
                    } else if (responseStatusCode == AppConstant.EMAIL_ALREADY_REGISTERED) {
                        showToastMsg(mContext, getString(R.string.ws_email_already_exist));

                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        if (registrationResponse.getResponseCode() != null && registrationResponse.getResponseCode().equalsIgnoreCase("0")) {
                            showToastMsg(RegistrationActivity.this, registrationResponse.getResponseMessage());
                            return;
                        } else if (registrationResponse.getResponseCode() != null && registrationResponse.getResponseCode().equalsIgnoreCase("1")) {
                            showToastMsg(mContext, mContext.getResources().getString(R.string.registration_success));
                            finish();
                        }
                    } else {
                        showToastMsg(mContext, registrationResponse.getResponseMessage());
                    }

                }

                @Override
                public void onFailure(Call<RegistrationResponse> call, Throwable t) {
                    hideProgressDialog();
                    Log.e(TAG, t.getMessage());
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void getCountry() {

        if (!CheckNetworkState.isOnline(mContext)) {
            showToastMsg(mContext, getString(R.string.network_error));
            return;
        }

        showProgressDialog(mContext);

        try {
            Call<CountryResponse> countryRequest = ((TechquiqApplication) mContext
                    .getApplicationContext()).getService().getCountryService(
                    Utils.getDeviceId(mContext),
                    ApiParameter.DEVICE_TYPE_VALUE,
                    AppConstant.FCM_ID);

            Log.e(TAG, "Request : " + countryRequest.request().url());

            countryRequest.enqueue(new Callback<CountryResponse>() {
                @Override
                public void onResponse(Call<CountryResponse> call, Response<CountryResponse> response) {
                    hideProgressDialog();

                    if (response == null) {
                        showToastMsg(mContext, getString(R.string.server_error));
                        return;
                    }

                    final ArrayList<CountryResponse.Country> countries = response.body().getResult();
                    if (countries != null && countries.size() > 0) {
                        final ArrayList<String> countryData = new ArrayList<String>();
                        for (int i = 0; i < countries.size(); i++) {
                            countryData.add(i, countries.get(i).getCountry_name());
                        }
                        final CountryDialog countryDialog = new CountryDialog(RegistrationActivity.this,
                                mContext.getString(R.string.select_country), countryData);
                        countryDialog.setSearchEnable();
                        countryDialog.show();

                        countryDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialogInterface) {
                                if (countryDialog.getPosition() > -1 && countryDialog.isItemClick()) {
                                    selectedCountryId = countries.get(countryDialog.getPosition()).getCountry_id();
                                    selectCountryTv.setText(countries.get(countryDialog.getPosition()).getCountry_name());
                                    selectStateTv.setText(mContext.getString(R.string.select_state));
                                    selectCityTv.setText(mContext.getString(R.string.select_city));
                                    selectedStateId = "";
                                    selectedCityId = "";
                                    selectCountryTv.setTextColor(getResources().getColor(R.color.black));
                                    Utils.hideKeyBoard(mContext);
                                }
                            }
                        });
                    }
                }

                @Override
                public void onFailure(Call<CountryResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void getState() {

        if (!CheckNetworkState.isOnline(mContext)) {
            showToastMsg(mContext, getString(R.string.network_error));
            return;
        }

        if (selectedCountryId == null || selectedCountryId.isEmpty()) {
            showToastMsg(mContext, mContext.getString(R.string.select_country_msg));
            return;
        }

        showProgressDialog(mContext);

        try {
            Call<StateResponse> stateRequest = ((TechquiqApplication) mContext
                    .getApplicationContext()).getService().getStateService(
                    selectedCountryId,
                    Utils.getDeviceId(mContext),
                    ApiParameter.DEVICE_TYPE_VALUE,
                    AppConstant.FCM_ID);

            Log.e(TAG, "Request : " + stateRequest.request().url());

            stateRequest.enqueue(new Callback<StateResponse>() {
                @Override
                public void onResponse(Call<StateResponse> call, Response<StateResponse> response) {
                    hideProgressDialog();

                    if (response == null) {
                        showToastMsg(mContext, getString(R.string.server_error));
                        return;
                    }

                    final ArrayList<StateResponse.State> states = response.body().getResult();
                    if (states != null && states.size() > 0) {
                        ArrayList<String> stateData = new ArrayList<String>();
                        for (int i = 0; i < states.size(); i++) {
                            stateData.add(i, states.get(i).getState_name());
                        }
                        final CountryDialog stateDialog = new CountryDialog(RegistrationActivity.this,
                                mContext.getString(R.string.select_state), stateData);
                        stateDialog.setSearchEnable();
                        stateDialog.show();


                        stateDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialogInterface) {
                                if (stateDialog.getPosition() > -1 && stateDialog.isItemClick()) {
                                    selectedStateId = states.get(stateDialog.getPosition()).getState_id();
                                    selectStateTv.setText(states.get(stateDialog.getPosition()).getState_name());
                                    selectCityTv.setText(mContext.getString(R.string.select_city));
                                    selectedCityId = "";
                                    selectStateTv.setTextColor(getResources().getColor(R.color.black));
                                }
                            }
                        });
                    }
                }

                @Override
                public void onFailure(Call<StateResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void getCity() {

        if (!CheckNetworkState.isOnline(mContext)) {
            showToastMsg(mContext, getString(R.string.network_error));
            return;
        }

        if (selectedStateId == null || selectedStateId.isEmpty()) {
            showToastMsg(mContext, getString(R.string.select_state_msg));
            return;
        }

        showProgressDialog(mContext);

        try {
            Call<CityResponse> cityRequest = ((TechquiqApplication) mContext
                    .getApplicationContext()).getService().getCityService(
                    selectedStateId,
                    Utils.getDeviceId(mContext),
                    ApiParameter.DEVICE_TYPE_VALUE,
                    AppConstant.FCM_ID);

            Log.e(TAG, "Request : " + cityRequest.request().url());

            cityRequest.enqueue(new Callback<CityResponse>() {
                @Override
                public void onResponse(Call<CityResponse> call, Response<CityResponse> response) {
                    hideProgressDialog();

                    if (response == null) {
                        showToastMsg(mContext, getString(R.string.server_error));
                        return;
                    }

                    final ArrayList<CityResponse.City> cities = response.body().getResult();
                    if (cities != null && cities.size() > 0) {
                        ArrayList<String> cityData = new ArrayList<String>();
                        for (int i = 0; i < cities.size(); i++) {
                            cityData.add(i, cities.get(i).getCity_name());
                        }
                        final CountryDialog cityDialog = new CountryDialog(RegistrationActivity.this,
                                mContext.getString(R.string.select_city), cityData);
                        cityDialog.setSearchEnable();
                        cityDialog.show();

                        cityDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialogInterface) {
                                if (cityDialog.getPosition() > -1 && cityDialog.isItemClick()) {
                                    selectedCityId = cities.get(cityDialog.getPosition()).getCity_id();
                                    selectCityTv.setText(cities.get(cityDialog.getPosition()).getCity_name());
                                    selectCityTv.setTextColor(getResources().getColor(R.color.black));
                                }
                            }
                        });
                    }
                }

                @Override
                public void onFailure(Call<CityResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private final TextWatcher mTextEditorWatcher = new TextWatcher() {
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        public void afterTextChanged(Editable s) {
            //This sets a textview to the current length
            if (s.length() >= 25) {
                showToastMsg(mContext, mContext.getResources().getString(R.string.error_msg_max));

            }

        }
    };
    private final TextWatcher mTextEditorWatcherAddress = new TextWatcher() {
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        public void afterTextChanged(Editable s) {
            //This sets a textview to the current length
            if (s.length() >= 150) {
                showToastMsg(mContext, mContext.getResources().getString(R.string.error_msg_max_address));
            }
        }
    };

    private void cursorCheck() {
        Utils.hideKeyBoard(this);
        emailEd.setCursorVisible(false);
        passwordEd.setCursorVisible(false);
        confirmPasswordEd.setCursorVisible(false);
        fnameEd.setCursorVisible(false);
        lnameEd.setCursorVisible(false);
        contactEd.setCursorVisible(false);
        addressEd.setCursorVisible(false);
        postalcodeEd.setCursorVisible(false);

    }

    private void checkFocus() {

        emailEd.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    Log.d("focus", "focus loosed");
                    // Do whatever you want here
                } else {
                    emailEd.setCursorVisible(true);
                    Log.d("focus", "focused");
                }
            }
        });

        passwordEd.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    Log.d("focus", "focus loosed");
                    // Do whatever you want here
                } else {
                    passwordEd.setCursorVisible(true);
                    Log.d("focus", "focused");
                }
            }
        });


        confirmPasswordEd.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    Log.d("focus", "focus loosed");
                    // Do whatever you want here
                } else {
                    confirmPasswordEd.setCursorVisible(true);
                    Log.d("focus", "focused");
                }
            }
        });

        fnameEd.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    Log.d("focus", "focus loosed");
                    // Do whatever you want here
                } else {
                    fnameEd.setCursorVisible(true);
                    Log.d("focus", "focused");
                }
            }
        });

        lnameEd.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    Log.d("focus", "focus loosed");
                    // Do whatever you want here
                } else {
                    lnameEd.setCursorVisible(true);
                    Log.d("focus", "focused");
                }
            }
        });


        contactEd.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    Log.d("focus", "focus loosed");
                    // Do whatever you want here
                } else {
                    contactEd.setCursorVisible(true);
                    Log.d("focus", "focused");
                }
            }
        });

        addressEd.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    Log.d("focus", "focus loosed");
                    // Do whatever you want here
                } else {
                    addressEd.setCursorVisible(true);
                    Log.d("focus", "focused");
                }
            }
        });


        postalcodeEd.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    Log.d("focus", "focus loosed");
                    // Do whatever you want here
                } else {
                    postalcodeEd.setCursorVisible(true);
                    Log.d("focus", "focused");
                }
            }
        });
    }
}
