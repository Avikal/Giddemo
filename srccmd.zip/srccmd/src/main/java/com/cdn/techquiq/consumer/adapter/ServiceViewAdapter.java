package com.cdn.techquiq.consumer.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.model.ServiceImage;

import java.util.ArrayList;

/**
 * Created by avikaljain on 17/4/17.
 */

public class ServiceViewAdapter extends RecyclerView.Adapter<ServiceViewAdapter.MyViewHolder> {

    private ArrayList<ServiceImage> serviceImageArrayList;
    Context mContext;
    LayoutInflater mLayoutInflater;


    public class MyViewHolder extends RecyclerView.ViewHolder {

        public ImageView serviceImage;
        public ImageView ivCancel;

        public MyViewHolder(View view) {
            super(view);

            serviceImage = (ImageView) view.findViewById(R.id.ivService);
            ivCancel = (ImageView) view.findViewById(R.id.ivCancel);
            ivCancel.setVisibility(View.GONE);

        }
    }

    public ServiceViewAdapter(Context context, ArrayList<ServiceImage> serviceImageArrayList) {
        this.mContext = context;
        this.serviceImageArrayList = serviceImageArrayList;
        mLayoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public ServiceViewAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mLayoutInflater
                .inflate(R.layout.service_image_list, parent, false);
        return new ServiceViewAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final ServiceViewAdapter.MyViewHolder holder, final int position) {
        final ServiceImage serviceBean = serviceImageArrayList.get(position);

        Glide.with(mContext).load(serviceBean.getFileName())
                .crossFade()
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .placeholder(R.drawable.placeholder_1)
                .error(R.drawable.placeholder_1)
                .into(holder.serviceImage);



    }


    @Override
    public int getItemCount() {
        return serviceImageArrayList.size();
    }
}
