package com.cdn.techquiq.consumer.model;

import android.net.Uri;

/**
 * Created by avikaljain on 17/4/17.
 */

public class ServiceImage {

    private Uri uri;

    private String fileName;

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Uri getUri() {
        return uri;
    }

    public void setUri(Uri uri) {
        this.uri = uri;
    }
}
