package com.cdn.techquiq.consumer.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by avikaljain on 11/5/17.
 */

public class BrainTreeResponse extends BaseResponse {

    @SerializedName("Result")
    private String brainTreeToken;

    public String getBrainTreeToken() {
        return brainTreeToken;
    }

    public void setBrainTreeToken(String brainTreeToken) {
        this.brainTreeToken = brainTreeToken;
    }
}
