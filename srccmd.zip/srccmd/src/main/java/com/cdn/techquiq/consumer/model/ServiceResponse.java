package com.cdn.techquiq.consumer.model;

import com.cdn.techquiq.consumer.Utils.Utils;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by avikaljain on 10/4/17.
 */

public class ServiceResponse extends BaseResponse {

    @SerializedName("Result")
    private ArrayList<ServiceDetail> serviceDetails;

    public ArrayList<ServiceDetail> getServiceDetails() {
        return serviceDetails;
    }

    public void setServiceDetails(ArrayList<ServiceDetail> serviceDetails) {
        this.serviceDetails = serviceDetails;
    }

    @SerializedName("Total_service")
    private int totalProduct;

    public int getTotalProduct() {
        return totalProduct;
    }

    public void setTotalProduct(int totalProduct) {
        this.totalProduct = totalProduct;
    }

    public class ServiceDetail implements Serializable {
        @SerializedName("id")
        private String id;

        public void setId(String id) {
            this.id = id;
        }

        public String getId() {

            return id;
        }

        @SerializedName("payment_status")
        private String paymentStatus;

        public String getPaymentStatus() {
            return paymentStatus;
        }

        public void setPaymentStatus(String paymentStatus) {
            this.paymentStatus = paymentStatus;
        }

        @SerializedName("service_status")

        private String serviceStatus;

        public String getServiceStatus() {
            return serviceStatus;
        }

        public void setServiceStatus(String serviceStatus) {
            this.serviceStatus = serviceStatus;
        }

        @SerializedName("parent_category_name_en")
        private String serviceCategoryEn;

        @SerializedName("parent_category_name_ar")
        private String serviceCategoryAr;

        @SerializedName("sub_category_name_en")
        private String serviceSubCategoryEn;

        @SerializedName("sub_category_name_ar")
        private String serviceSubCategoryAr;

        public void setCanUpdateReview(boolean canUpdateReview) {
            this.canUpdateReview = canUpdateReview;
        }

        public String getServiceCategoryEn() {
            return serviceCategoryEn;
        }

        public void setServiceCategoryEn(String serviceCategoryEn) {
            this.serviceCategoryEn = serviceCategoryEn;
        }

        public String getServiceCategoryAr() {

            return serviceCategoryAr;
        }

        public void setServiceCategoryAr(String serviceCategoryAr) {
            this.serviceCategoryAr = serviceCategoryAr;
        }

        public String getServiceCategory() {
            if (Utils.getLocale().equalsIgnoreCase("ar")) {
                return getServiceCategoryAr();
            } else {
                return getServiceCategoryEn();
            }
        }

        public String getServiceSubCategoryAr() {
            return serviceSubCategoryAr;
        }

        public void setServiceSubCategoryAr(String serviceSubCategoryAr) {
            this.serviceSubCategoryAr = serviceSubCategoryAr;
        }

        public String getServiceSubCategoryEn() {
            return serviceSubCategoryEn;
        }

        public void setServiceSubCategoryEn(String serviceSubCategoryEn) {
            this.serviceSubCategoryEn = serviceSubCategoryEn;
        }

        public String getServiceSubCategory() {
            if (Utils.getLocale().equalsIgnoreCase("ar")) {
                return getServiceSubCategoryAr();
            } else {
                return getServiceSubCategoryEn();
            }
        }

        @SerializedName("award_status")
        private String awardStatus;

        public String getAwardStatus() {
            return awardStatus;
        }

        public void setAwardStatus(String awardStatus) {
            this.awardStatus = awardStatus;
        }

        @SerializedName("name")
        private String name;

        public String getOrderId() {
            return orderId;
        }

        public void setOrderId(String orderId) {
            this.orderId = orderId;
        }

        @SerializedName("order_id")
        private String orderId;


        public boolean isCanUpdateReview() {
            return canUpdateReview;
        }

        @SerializedName("can_update_review")
        private boolean canUpdateReview;


        public String getTotalProposal() {
            return totalProposal;
        }

        public void setTotalProposal(String totalProposal) {
            this.totalProposal = totalProposal;
        }

        public ArrayList<SProductImage> getsProductImages() {

            return sProductImages;
        }

        public void setsProductImages(ArrayList<SProductImage> sProductImages) {
            this.sProductImages = sProductImages;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getDescription() {

            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getDate() {

            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }

        @SerializedName("description")
        private String description;

        @SerializedName("date")
        private String date;

        @SerializedName("total_proposal")
        private String totalProposal;

        @SerializedName("images")
        private ArrayList<SProductImage> sProductImages;

        @SerializedName("proposal_data")
        private ArrayList<ServiceProposalData> serviceProposal;

        public ArrayList<ServiceProposalData> getServiceProposal() {
            return serviceProposal;
        }

        public void setServiceProposal(ArrayList<ServiceProposalData> serviceProposal) {
            this.serviceProposal = serviceProposal;
        }

        public class SProductImage {
            @SerializedName("image")
            private String image;

            public String getImage() {
                return image;
            }

            public void setImage(String image) {
                this.image = image;
            }
        }

        public class ServiceProposalData {
            @SerializedName("user_id")
            private String user_id;

            public String getUser_id() {
                return user_id;
            }

            public void setUser_id(String user_id) {
                this.user_id = user_id;
            }

            @SerializedName("first_name")
            private String first_name;

            public String getFirst_name() {
                return first_name;
            }

            public void setFirst_name(String first_name) {
                this.first_name = first_name;
            }

            @SerializedName("last_name")
            private String last_name;

            public String getLast_name() {
                return last_name;
            }

            public void setLast_name(String last_name) {
                this.last_name = last_name;
            }

            @SerializedName("image")
            private String image;

            public String getImage() {
                return image;
            }

            public void setImage(String image) {
                this.image = image;
            }

            @SerializedName("service_price")
            private String service_price;

            public String getService_price() {
                if (service_price == null || service_price.isEmpty()) {
                    return "0";
                }
                return service_price;
            }

            public void setService_price(String service_price) {
                this.service_price = service_price;
            }

            @SerializedName("bid_id")
            private String bidId;

            public String getBidId() {
                return bidId;
            }

            public void setBidId(String bidId) {
                this.bidId = bidId;
            }

            @SerializedName("merchant_company")
            private String merchantCompany;

            public String getMerchantCompany() {
                return merchantCompany;
            }

            public void setMerchantCompany(String merchantCompany) {
                this.merchantCompany = merchantCompany;
            }

            @SerializedName("merchant_phone")
            public String merchantPhone;

            public String getMerchantPhone() {
                return merchantPhone;
            }

            public void setMerchantPhone(String merchantPhone) {
                this.merchantPhone = merchantPhone;
            }

            @SerializedName("email")
            private String email;

            @SerializedName("address")
            private String address;

            @SerializedName("AverageRating")
            private String AverageRating;

            public String getEmail() {
                return email;
            }

            public void setEmail(String email) {
                this.email = email;
            }

            public float getAverageRating() {

                try {
                    return Float.parseFloat(AverageRating);
                } catch (Exception e) {
                    return 0;
                }
            }

            public void setAverageRating(String averageRating) {
                AverageRating = averageRating;
            }

            public String getAddress() {

                return address;
            }

            public void setAddress(String address) {
                this.address = address;
            }

            @SerializedName("service_awarded")
            private String serviceAwarded;

            public String getServiceAwarded() {
                return serviceAwarded;
            }

            public void setServiceAwarded(String serviceAwarded) {
                this.serviceAwarded = serviceAwarded;
            }
        }
    }
}
