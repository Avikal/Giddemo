
package com.cdn.techquiq.consumer.adapter;

/**
 * Created by kajalsoni on 31/1/17.
 */

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.activity.MainActivity;
import com.cdn.techquiq.consumer.activity.ProductDetailActivity;
import com.cdn.techquiq.consumer.model.ProductResponse;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;

import java.util.ArrayList;
import java.util.List;

public class HomeProductAdapter extends RecyclerView.Adapter<HomeProductAdapter.MyViewHolder> {

    private List<ProductResponse.ProductDetail> productDetails;
    private Context mContext;
    private LayoutInflater mLayoutInflater;


    public HomeProductAdapter(Context context, ArrayList<ProductResponse.ProductDetail> productDetails) {
        this.mContext = context;
        this.productDetails = productDetails;
        mLayoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView nameTv;
        private ImageView productImage;
        private LinearLayout productLl;
        private RatingBar productRating;

        public MyViewHolder(View view) {
            super(view);
            nameTv = (TextView) view.findViewById(R.id.productName);
            productImage = (ImageView) view.findViewById(R.id.productImage);
            productLl = (LinearLayout) view.findViewById(R.id.productLl);
            productRating = (RatingBar) view.findViewById(R.id.productRating);
        }
    }


    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mLayoutInflater.inflate(R.layout.home_products_list_item, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

        final ProductResponse.ProductDetail productDetail = productDetails.get(position);
        holder.nameTv.setText(productDetail.getName());
        holder.productRating.setRating(Float.parseFloat(productDetail.getAverage_rating()));

        ArrayList<ProductResponse.ProductDetail.ProductImage> productImages = productDetail.getProductImages();
        if (productImages != null && productImages.size() > 0) {
            Glide.with(mContext).load(productImages.get(0).getImage())
                    .crossFade()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .placeholder(R.drawable.placeholder_1)
                    .into(holder.productImage);
        }

        holder.productLl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!CheckNetworkState.isOnline(mContext)) {
                    ((MainActivity) mContext).showToastMsg(mContext, mContext.getResources()
                            .getString(R.string.network_error));
                    return;
                }

                Intent intent = new Intent(mContext, ProductDetailActivity.class);
                Bundle mBundle = new Bundle();
                mBundle.putInt("productId", productDetail.getId());
                mBundle.putBoolean("isProduct", true);
                intent.putExtras(mBundle);
                mContext.startActivity(intent);


            }
        });
    }

    @Override
    public int getItemCount() {
        return productDetails.size();
    }
}
