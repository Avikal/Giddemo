package com.cdn.techquiq.consumer.model;

import com.cdn.techquiq.consumer.Utils.Utils;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class FilterResponse extends BaseResponse implements Serializable {

    @SerializedName("Result")
    private ArrayList<FilterResult> result;

    public ArrayList<FilterResult> getResult() {
        return result;
    }

    public void setResult(ArrayList<FilterResult> result) {
        this.result = result;
    }

    public class FilterResult implements Serializable{

        @SerializedName("filter_name_en")
        private String filter_name_en;

        @SerializedName("filter_name_ar")
        private String filter_name_ar;

        @SerializedName("filter_id")
        private int filter_id;

        @SerializedName("items")
        private ArrayList<Items> items;

        public String getFilter_name_en() {
            return filter_name_en;
        }

        public void setFilter_name_en(String filter_name_en) {
            this.filter_name_en = filter_name_en;
        }

        public String getFilter_name_ar() {
            return filter_name_ar;
        }

        public String getFilter_name() {
            if (Utils.getLocale().equalsIgnoreCase("ar")) {
                if (getFilter_name_ar() == null || getFilter_name_ar().isEmpty()) {
                    return getFilter_name_en();
                } else {
                    return getFilter_name_ar();
                }
            } else {
                return getFilter_name_en();
            }
        }

        public void setFilter_name_ar(String filter_name_ar) {
            this.filter_name_ar = filter_name_ar;
        }

        public int getFilter_id() {
            return filter_id;
        }

        public void setFilter_id(int filter_id) {
            this.filter_id = filter_id;
        }

        public ArrayList<Items> getItems() {
            return items;
        }

        public void setItems(ArrayList<Items> items) {
            this.items = items;
        }

        public class Items implements Serializable{

            @SerializedName("id")
            private int id;

            @SerializedName("name_en")
            private String name_en;

            @SerializedName("name_ar")
            private String name_ar;

            public String getName() {
                if (Utils.getLocale().equalsIgnoreCase("ar")) {
                    if (getName_ar() == null || getName_ar().isEmpty()) {
                        return getName_en();
                    } else {
                        return getName_ar();
                    }
                } else {
                    return getName_en();
                }
            }


            private boolean isSelected;

            public String getName_ar() {
                return name_ar;
            }

            public void setName_ar(String name_ar) {
                this.name_ar = name_ar;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getName_en() {
                return name_en;
            }

            public void setName_en(String name_en) {
                this.name_en = name_en;
            }

            public boolean isSelected() {
                return isSelected;
            }

            public void setSelected(boolean selected) {
                isSelected = selected;
            }

        }
    }

}
