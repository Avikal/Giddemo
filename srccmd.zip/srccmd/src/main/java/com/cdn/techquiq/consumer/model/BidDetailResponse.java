package com.cdn.techquiq.consumer.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by avikaljain on 4/7/17.
 */

public class BidDetailResponse extends BaseResponse {

    @SerializedName("Result")
    private ArrayList<BidDetail> bidDetail;

    public ArrayList<BidDetail> getBidDetail() {
        return bidDetail;
    }

    public void setBidDetail(ArrayList<BidDetail> bidDetail) {
        this.bidDetail = bidDetail;
    }

    public class BidDetail {
        @SerializedName("bid_id")
        private String bidId;

        public String getBidId() {
            return bidId;
        }

        public void setBidId(String bidId) {
            this.bidId = bidId;
        }

        @SerializedName("merchant_id")
        private String merchantId;

        public String getMerchantId() {
            return merchantId;
        }

        public void setMerchantId(String merchantId) {
            this.merchantId = merchantId;
        }

        @SerializedName("service_id")
        private String serviceId;

        public String getServiceId() {
            return serviceId;
        }

        public void setServiceId(String serviceId) {
            this.serviceId = serviceId;
        }

        @SerializedName("merchant_first_name")
        private String merchantFirstName;

        public String getMerchantFirstName() {
            return merchantFirstName;
        }

        public void setMerchantFirstName(String merchantFirstName) {
            this.merchantFirstName = merchantFirstName;
        }

        @SerializedName("merchant_last_name")
        private String merchantLastName;

        public String getMerchantLastName() {
            return merchantLastName;
        }

        public void setMerchantLastName(String merchantLastName) {
            this.merchantLastName = merchantLastName;
        }

        @SerializedName("email")
        private String merchantEmail;

        public String getMerchantEmail() {
            return merchantEmail;
        }

        public void setMerchantEmail(String merchantEmail) {
            this.merchantEmail = merchantEmail;
        }

        @SerializedName("service_price")
        private String servicePrice;

        public String getServicePrice() {
            return servicePrice;
        }

        public void setServicePrice(String servicePrice) {
            this.servicePrice = servicePrice;
        }

        @SerializedName("address")
        private String userAddress;

        public String getUserAddress() {
            return userAddress;
        }

        public void setUserAddress(String userAddress) {
            this.userAddress = userAddress;
        }
    }

}
