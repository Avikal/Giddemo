package com.cdn.techquiq.consumer.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v4.app.Fragment;
import android.view.View;

import com.cdn.techquiq.consumer.activity.MainActivity;
import com.cdn.techquiq.consumer.activity.ProductDetailActivity;
import com.cdn.techquiq.consumer.activity.ProfileActivity;


/**
 * this fragment is used as parent of all fragment
 * we put some common method that used in every fragment
 */
public class BaseFragment extends Fragment implements View.OnClickListener {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public boolean onBackPressed() {
        return false;
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {

    }

    private long mLastClickTime = 0;

    @Override
    public void onClick(View v) {
        // Preventing multiple clicks, using threshold of 1 second
        if (SystemClock.elapsedRealtime() - mLastClickTime < 1000) {
            return;
        }
        mLastClickTime = SystemClock.elapsedRealtime();

    }

    /**
     * following  methods are used to handel tool bar and action bar property
     *
     * @param text
     */
    protected void setTitleText(String text) {
        if(getActivity() instanceof  MainActivity) {
            ((MainActivity) getActivity()).setTitleText(text);
        }else if(getActivity() instanceof  ProductDetailActivity){
            ((ProductDetailActivity) getActivity()).setTitleText(text);
        }
    }

    /**
     * Use to show loading dialog.
     */
    protected boolean showProgressDialog(Context context) {

        if (getActivity() instanceof MainActivity) {
            return ((MainActivity) getActivity()).showProgressDialog(context);
        } else if (getActivity() instanceof ProfileActivity) {
            return ((ProfileActivity) getActivity()).showProgressDialog(context);
        } else if (getActivity() instanceof ProductDetailActivity) {
            return ((ProductDetailActivity) getActivity()).showProgressDialog(context);
        } else {
            return false;
        }
    }

    /**
     * Use to hide loading dialog.
     */
    protected void hideProgressDialog() {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).hideProgressDialog();
        } else if (getActivity() instanceof ProfileActivity) {
            ((ProfileActivity) getActivity()).hideProgressDialog();
        }else if (getActivity() instanceof ProductDetailActivity) {
            ((ProductDetailActivity) getActivity()).hideProgressDialog();
        }
    }

    protected void showToastMsg(Context mContext, String msg) {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).showToastMsg(mContext, msg);
        } else if (getActivity() instanceof ProfileActivity) {
            ((ProfileActivity) getActivity()).showToastMsg(mContext, msg);
        }else if (getActivity() instanceof ProductDetailActivity) {
            ((ProductDetailActivity) getActivity()).showToastMsg(mContext, msg);
        }
    }
}
