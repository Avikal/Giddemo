package com.cdn.techquiq.consumer.model;

/**
 * Created by akshaysoni on 30/1/17.
 */

public class BaseResponse {

    public String ResponseMessage;

    public String getResponseCode() {
        return ResponseCode;
    }

    public void setResponseCode(String responseCode) {
        ResponseCode = responseCode;
    }

    public String ResponseCode;

    public String getResponseMessage() {
        return ResponseMessage;
    }

    public void setResponseMessage(String responseMessage) {
        ResponseMessage = responseMessage;
    }

    public int ResponseStatusCode;

    public int getResponseStatusCode() {
        return ResponseStatusCode;
    }

    public void setResponseStatusCode(int responseStatusCode) {
        ResponseStatusCode = responseStatusCode;
    }
}
