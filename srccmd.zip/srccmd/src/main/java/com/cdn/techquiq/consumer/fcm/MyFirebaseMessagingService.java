package com.cdn.techquiq.consumer.fcm;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.NotificationUtils;
import com.cdn.techquiq.consumer.Utils.SharedPrefrence;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.activity.AlertDetailActivity;
import com.cdn.techquiq.consumer.activity.MainActivity;
import com.cdn.techquiq.consumer.database.DBHelper;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URLDecoder;
import java.util.Map;

/*
 * Created by avikaljain on 8/6/17.
 * this class use to receive messages and redirect into
 * intent services for store messages one by one linearly in db
 */
public class MyFirebaseMessagingService extends FirebaseMessagingService {
    private static final String TAG = "MyFirebaseMsgService";
    private Map<String, String> params;

    private NotificationUtils notificationUtils;

    private NotificationCompat.Builder notificationBuilder;
    private NotificationManager notificationManager;

    private int alertCount;
    private String message;
    private String notificationTitle;
    private String notificationTypeId;
    private String date;
    private String image;

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        if (remoteMessage.getData().size() > 0) {
            Log.e(TAG, "Data Payload: " + remoteMessage.getData().toString());
            try {
                params = remoteMessage.getData();
                Log.e(TAG, "FCM data: " + new JSONObject(params).toString());
                JSONObject json = new JSONObject(remoteMessage.getData().toString());
                handleDataMessage(json);
            } catch (Exception e) {
                Log.e(TAG, "Exception: " + e.getMessage());
            }
        }
    }

    private void handleDataMessage(JSONObject json) {
        Log.e(TAG, "push json: " + json.toString());
        try {

            notificationTypeId = json.getString("notification_id");
            notificationTypeId = URLDecoder.decode(notificationTypeId, "UTF-8");
            String messageEn = json.getString("message");
            messageEn = URLDecoder.decode(messageEn, "UTF-8");
            String messageAr = json.getString("message_ar");
            messageAr = URLDecoder.decode(messageAr, "UTF-8");

            String notificationEn = json.getString("notification_name");
            notificationEn = URLDecoder.decode(notificationEn, "UTF-8");

            String notificationAr = json.getString("notification_name_ar");
            notificationAr = URLDecoder.decode(notificationAr, "UTF-8");
            image = json.getString("image");
            image = URLDecoder.decode(image, "UTF-8");
            date = json.getString("date");
            date = URLDecoder.decode(date, "UTF-8");
            if (Utils.getLocale().equalsIgnoreCase("ar")) {
                message = messageAr;
                notificationTitle = notificationAr;
            } else {
                message = messageEn;
                notificationTitle = notificationEn;
            }
            Log.e(TAG, "message: " + message);
            if (SharedPrefrence.getInstance(getApplicationContext()).readBooleanPrefs(SharedPrefrence.showPreview)) {
                if (!NotificationUtils.isAppIsInBackground(getApplicationContext())) {
                    // app is in foreground, broadcast the push message
                    if (MainActivity.mainCurrentTab != null && !MainActivity.mainCurrentTab.isEmpty()
                            && MainActivity.mainCurrentTab.equalsIgnoreCase(AppConstant.TAB_ALERT)) {
                        Intent pushNotification = new Intent(AppConstant.PUSH_NOTIFICATION);
                        pushNotification.putExtra("message", message);
                        LocalBroadcastManager.getInstance(this).sendBroadcast(pushNotification);
                    } else {
                        sendNotification();
                    }
                } else {
                    // app is in background, show the notification in notification tray
                    if (SharedPrefrence.getInstance(getApplicationContext()).readBooleanPrefs(SharedPrefrence.showPreview)) {
                        MainActivity.mainCurrentTab = AppConstant.TAB_ALERT;
                        sendNotification();
                    }


                }
            }
        } catch (JSONException e) {
            Log.e(TAG, "Json Exception: " + e.getMessage());
        } catch (Exception e) {
            Log.e(TAG, "Exception: " + e.getMessage());
        }
    }

    private void sendNotification() {
        long time = System.currentTimeMillis();
        int notificationId = (int) time;
        Intent resultIntent = new Intent(getApplicationContext(), AlertDetailActivity.class);
        resultIntent.putExtra("title", notificationTitle);
        resultIntent.putExtra("description", message);
        resultIntent.putExtra("date", date);
        resultIntent.putExtra("image", image);
        resultIntent.putExtra("notification", true);
        resultIntent.putExtra("notificationId", notificationId);
        resultIntent.putExtra("notificationTypeId", notificationTypeId);

        DBHelper.getInstance(getApplicationContext()).insertNotificationType(notificationTypeId, notificationId, AppConstant.ALERT_NOTIFICATION);
        showNotificationMessage(getApplicationContext(), notificationTitle, message, date, resultIntent, image, notificationId);
        Intent pushNotification = new Intent(AppConstant.PUSH_NOTIFICATION);
        pushNotification.putExtra("count", alertCount);
        LocalBroadcastManager.getInstance(this).sendBroadcast(pushNotification);
    }

    /**
     * Showing notification with text only
     */
    private void showNotificationMessage(Context context, String title, String message, String timeStamp, Intent intent, String image, int notificationId) {
        notificationUtils = new NotificationUtils(context);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        notificationUtils.showNotificationMessage1(title, message, timeStamp, intent, image, notificationId);
    }
}
