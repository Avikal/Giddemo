package com.cdn.techquiq.consumer.model;

import com.cdn.techquiq.consumer.database.Chat;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Created by avikaljain on 3/5/17.
 */

public class SendOwnMessageBean implements Serializable {

    @SerializedName("Result")
    public Chat Chat;

    public Chat getChat() {
        return Chat;
    }

    public void setChat(Chat chat) {
        Chat = chat;
    }

    @SerializedName("ResponseMessage")
    public String ResponseMessage;

    public String getResponseMessage() {
        return ResponseMessage;
    }

    public void setResponseMessage(String responseMessage) {
        ResponseMessage = responseMessage;
    }

    @SerializedName("ResponseCode")
    public String ResponseCode;

    public String getResponseCode() {
        return ResponseCode;
    }

    public void setResponseCode(String responseCode) {
        ResponseCode = responseCode;
    }
}
