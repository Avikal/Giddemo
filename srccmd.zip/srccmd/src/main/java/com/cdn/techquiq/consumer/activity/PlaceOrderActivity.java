package com.cdn.techquiq.consumer.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;

/**
 * Created by avikaljain on 11/5/17.
 */

public class PlaceOrderActivity extends BaseActivity {

    private TextView titleTv;
    private ImageView backIv;

    private TextView tvPay;
    private TextView tvSavePay;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_order);

        setUpUI();
    }

    private void setUpUI() {
        titleTv = (TextView) findViewById(R.id.titleTv);
        titleTv.setText(mContext.getString(R.string.payment));
        backIv = (ImageView) findViewById(R.id.backIv);
        tvPay = (TextView) findViewById(R.id.tvPay);
        tvSavePay = (TextView) findViewById(R.id.tvSavePay);

        backIv.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.backIv:
                finish();
                break;
            case R.id.tvSavePay:
                break;
            case R.id.tvPay:
                break;
        }
    }
}
