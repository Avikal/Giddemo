package com.cdn.techquiq.consumer.activity;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.adapter.ReviewAdapter;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.ReviewResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.google.gson.Gson;
import com.marshalchen.ultimaterecyclerview.UltimateRecyclerView;

import java.net.SocketTimeoutException;
import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by avikaljain on 9/5/17.
 */

public class ReviewListActivity extends BaseActivity {

    private String TAG = ReviewListActivity.class.getSimpleName();

    private TextView tvMerchantName;
    private RatingBar merchantRating;
    private CircleImageView ivMerchantProfile;

    private UltimateRecyclerView recyclerView;
    private ImageView backIv;
    private TextView titleTv;
    private Bundle bundle;

    private TextView noProductTv;
    private int limit;
    private int currentOffset;
    private int totalRecord;
    private String keyword;

    private ReviewAdapter reviewAdapter;
    private ArrayList<ReviewResponse.UserReviews> reviewList;
    private LinearLayout mainContainer;
    private LinearLayoutManager linearLayoutManager;

    private int productId;
    private int merchantId;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review);

        setUpUi();

        serviceCall();
    }

    private void setUpUi() {

        bundle = getIntent().getExtras();
        if (bundle != null) {
            merchantId = bundle.getInt("merchantId", 0);
            productId = bundle.getInt("productId", 0);
        }

        tvMerchantName = (TextView) findViewById(R.id.tvMerchantName);
        merchantRating = (RatingBar) findViewById(R.id.merchantRating);
        ivMerchantProfile = (CircleImageView) findViewById(R.id.ivMerchantProfile);
        titleTv = (TextView) findViewById(R.id.titleTv);
        backIv = (ImageView) findViewById(R.id.backIv);
        recyclerView = (UltimateRecyclerView) findViewById(R.id.searchList);
        recyclerView.setHasFixedSize(false);
        noProductTv = (TextView) findViewById(R.id.tvPaymentND);
        titleTv.setText(getResources().getString(R.string.reviews));
        mainContainer = (LinearLayout) findViewById(R.id.mainContainer);

        linearLayoutManager = new LinearLayoutManager(mContext);
        recyclerView.setLayoutManager(linearLayoutManager);

        recyclerView.setLoadMoreView(LayoutInflater.from(mContext)
                .inflate(R.layout.custom_bottom_progressbar, null));


//        hideMerchantDetail();
        backIv.setOnClickListener(this);
    }


    private void serviceCall() {
        limit = 10;
        currentOffset = 0;
        totalRecord = 0;
        keyword = "";

        getReviewList(currentOffset, false, keyword);

        loadMore();
    }


    private void getReviewList(int offset, final boolean isLoadMore, String keyword) {
        try {
            this.keyword = keyword;
            if (!isLoadMore) {
                if (!showProgressDialog(ReviewListActivity.this)) {
                    noProductTv.setText(getString(R.string.network_error));
                    noProductTv.setVisibility(View.VISIBLE);
                    return;
                }
            }

            final LoginResponse.Users userDetail = Utils.readUserDetail(ReviewListActivity.this);
            Call<ReviewResponse> reviewRequest = null;

            /**
             * Request for product
             */
            if (productId != 0) {
                reviewRequest = ((TechquiqApplication) this.getApplicationContext()).getService()
                        .getProductRatings(userDetail.getUserId(),
                                Utils.getDeviceId(ReviewListActivity.this),
                                ApiParameter.DEVICE_TYPE_VALUE,
                                AppConstant.FCM_ID,
                                productId,
                                merchantId,
                                limit,
                                offset);
            }

            /**
             * Request for Merchant
             */
            else if (merchantId != 0) {
                reviewRequest = ((TechquiqApplication) this.getApplicationContext()).getService()
                        .getMerchantRatings(userDetail.getUserId(),
                                Utils.getDeviceId(ReviewListActivity.this),
                                ApiParameter.DEVICE_TYPE_VALUE,
                                AppConstant.FCM_ID,
                                merchantId,
                                limit,
                                offset);
            }

            Log.e(TAG, "Request : " + reviewRequest.request().url());
            reviewRequest.enqueue(new Callback<ReviewResponse>() {
                @Override
                public void onResponse(Call<ReviewResponse> call, Response<ReviewResponse> response) {

                    if (response == null) {
                        return;
                    }
                    if (!isLoadMore) {
                        hideProgressDialog();
                    }

                    ReviewResponse reviewResponse = response.body();
                    if (reviewResponse == null) {
                        setErrorMsg(getResources().getString(R.string.server_error));
                        return;
                    }
                    Log.e(TAG, "Response : " + new Gson().toJson(reviewResponse));
                    totalRecord = reviewResponse.getTotalRating();
                    Log.e(TAG, "Total Record : " + String.valueOf(totalRecord));

                    if (reviewResponse.getResponseCode().equalsIgnoreCase("0")) {
                        if (!isLoadMore) {
                            setErrorMsg(getResources().getString(R.string.no_review));
                        }
                        return;
                    } else {
                        mainContainer.setVisibility(View.VISIBLE);
                        recyclerView.setVisibility(View.VISIBLE);
                        hideMerchantDetail();
                        noProductTv.setVisibility(View.GONE);
                        if (productId == 0 && merchantId != 0) {
                            setMerchantInfo(reviewResponse);
                        }
                    }

                    if (isLoadMore) {
                        if (reviewList != null) {
                            int offset = reviewList.size();
                            for (int i = 0; i < reviewResponse.getUserReviews().size(); i++) {
                                reviewList.add(offset, reviewResponse.getUserReviews().get(i));
                                offset++;
                            }
                            reviewAdapter.notifyDataSetChanged();
                        }
                    } else {
                        reviewList = reviewResponse.getUserReviews();
                        if (reviewList != null && reviewList.size() > 0) {
                            reviewAdapter = new ReviewAdapter(ReviewListActivity.this, reviewList, reviewResponse, productId, merchantId);
                            recyclerView.setAdapter(reviewAdapter);
                        } else {

                        }
                    }
                }

                @Override
                public void onFailure(Call<ReviewResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        setErrorMsg(getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    setErrorMsg(getResources().getString(R.string.connection_timeout));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setErrorMsg(String msg) {
        noProductTv.setVisibility(View.VISIBLE);
        noProductTv.setText(msg);
        recyclerView.setVisibility(View.GONE);
        mainContainer.setVisibility(View.GONE);
    }

    private void loadMore() {
        enableLoadMore();
        if (recyclerView != null) {
            recyclerView.setOnLoadMoreListener(new UltimateRecyclerView.OnLoadMoreListener() {
                @Override
                public void loadMore(int itemsCount, int maxLastVisiblePosition) {
                    try {
                        if (totalRecord <= reviewList.size()) {
                            recyclerView.disableLoadmore();
                        } else {
                            currentOffset = currentOffset + limit;
                            getReviewList(currentOffset, true, keyword);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    }

    public void enableLoadMore() {
        if (recyclerView != null) {
            recyclerView.reenableLoadmore();
        }
    }

    public void hideMerchantDetail() {
        if (productId != 0) {
            mainContainer.setVisibility(View.GONE);
        } else {
            mainContainer.setVisibility(View.VISIBLE);
        }
    }

    public void setMerchantInfo(ReviewResponse reviewResponse) {
        if (ivMerchantProfile != null) {
            tvMerchantName.setText(reviewResponse.getMerchantInfo().getMerchantFirstName() + " " + reviewResponse.getMerchantInfo().getMerchantLastName());
            merchantRating.setRating(Float.parseFloat(reviewResponse.getAverageRating()));
            Glide.with(mContext).load(reviewResponse.getMerchantInfo().getMerchantImage()).asBitmap().centerCrop()
                    .placeholder(R.drawable.profile_img)
                    .error(R.drawable.profile_img)
                    .into(ivMerchantProfile);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.backIv:
                finish();
                break;

        }
    }
}

