package com.cdn.techquiq.consumer.database;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

/**
 * Created by avikaljain on 22/6/17.
 * <p>
 * For check Notification by NotificationId
 */
@DatabaseTable(tableName = "notification_type")
public class Notification {

    @DatabaseField(id = true)
    public String notificationTypeId;

    @DatabaseField
    public int notificationId;

    @DatabaseField
    public String notificationType;

    public String getNotificationTypeId() {
        return notificationTypeId;
    }

    public void setNotificationTypeId(String notificationTypeId) {
        this.notificationTypeId = notificationTypeId;
    }

    public int getNotificationId() {
        return notificationId;
    }

    public void setNotificationId(int notificationId) {
        this.notificationId = notificationId;
    }

    public String getNotificationType() {
        return notificationType;
    }

    public void setNotificationType(String notificationType) {
        this.notificationType = notificationType;
    }
}
