package com.cdn.techquiq.consumer.database;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;


/**
 * Created by himanshurathore on 12/5/17.
 */
@DatabaseTable(tableName = "chat_history")
public class Chat {

    @DatabaseField(id = true)
    public String msg_unique_id;

    @DatabaseField
    public int id;

    @DatabaseField
    public String message;

    @DatabaseField
    public int sent_by;

    @DatabaseField
    public int sent_to;

    @DatabaseField(columnName = "timestamp")
    public long timestamp;

    /**
     * 1 Approve
     * 2 rejected
     * 3 pending
     */
    @DatabaseField
    public int aprove_status;

    @DatabaseField
    public String date_created;

    @DatabaseField
    public String service_id;

    @DatabaseField
    public String merchant_id;

    @DatabaseField
    public boolean readMsg;

    @DatabaseField
    public boolean isSent;

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getSent_by() {
        return sent_by;
    }

    public void setSent_by(int sent_by) {
        this.sent_by = sent_by;
    }

    public int getSent_to() {
        return sent_to;
    }

    public void setSent_to(int sent_to) {
        this.sent_to = sent_to;
    }

    public int getAprove_status() {
        return aprove_status;
    }

    public void setAprove_status(int aprove_status) {
        this.aprove_status = aprove_status;
    }

    public String getDate_created() {
        return date_created;
    }

    public void setDate_created(String date_created) {
        this.date_created = date_created;
    }

    public String getService_id() {
        return service_id;
    }

    public void setService_id(String service_id) {
        this.service_id = service_id;
    }

    public String getMerchant_id() {
        return merchant_id;
    }

    public void setMerchant_id(String merchant_id) {
        this.merchant_id = merchant_id;
    }

    public boolean isReadMsg() {
        return readMsg;
    }

    public void setReadMsg(boolean readMsg) {
        this.readMsg = readMsg;
    }

    public boolean isSent() {
        return isSent;
    }

    public void setSent(boolean sent) {
        isSent = sent;
    }

    public String getMsg_unique_id() {
        return msg_unique_id;
    }

    public void setMsg_unique_id(String msg_unique_id) {
        this.msg_unique_id = msg_unique_id;
    }
}

