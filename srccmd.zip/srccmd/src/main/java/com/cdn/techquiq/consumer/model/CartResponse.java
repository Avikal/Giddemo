package com.cdn.techquiq.consumer.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by kajalsoni on 6/2/17.
 */
public class CartResponse extends BaseResponse {

    public CartDetail getCartDetail() {
        return cartDetail;
    }

    public void setCartDetail(CartDetail cartDetail) {
        this.cartDetail = cartDetail;
    }

    private int cart_id;

    public int getCart_id() {
        return cart_id;
    }

    public void setCart_id(int cart_id) {
        this.cart_id = cart_id;
    }

    @SerializedName("Result")
    private CartDetail cartDetail;

    public class CartDetail {

        @SerializedName("cart_id")
        private int cart_id;

        @SerializedName("cart_count")
        private int cart_count;

        @SerializedName("total_price")
        private String total_price;

        @SerializedName("offer_amount")
        private String offer_amount;

        @SerializedName("promo_code")
        private String promo_code;

        @SerializedName("promo_code_id")
        private String promo_code_id;

        @SerializedName("promo_code_description")
        private String promo_code_description;

        @SerializedName("items")
        private ArrayList<Items> itemses;

        @SerializedName("offer_removable")
        private boolean offerRemovable;

        public boolean isOfferRemovable() {
            return offerRemovable;
        }

        public void setOfferRemovable(boolean offerRemovable) {
            this.offerRemovable = offerRemovable;
        }

        public String getPromo_code_description() {
            return promo_code_description;
        }

        public void setPromo_code_description(String promo_code_description) {
            this.promo_code_description = promo_code_description;
        }


        public String getPromo_code_id() {
            return promo_code_id;
        }

        public void setPromo_code_id(String promo_code_id) {
            this.promo_code_id = promo_code_id;
        }


        public String getPromo_code() {
            return promo_code;
        }

        public void setPromo_code(String promo_code) {
            this.promo_code = promo_code;
        }

        public String getOffer_amount() {
            return offer_amount;
        }

        public void setOffer_amount(String offer_amount) {
            this.offer_amount = offer_amount;
        }

        public Integer getCart_id() {
            return cart_id;
        }

        public void setCart_id(int cart_id) {
            this.cart_id = cart_id;
        }

        public int getCart_count() {
            return cart_count;
        }

        public void setCart_count(int cart_count) {
            this.cart_count = cart_count;
        }

        public String getTotal_price() {
            return total_price;
        }

        public void setTotal_price(String total_price) {
            this.total_price = total_price;
        }

        public ArrayList<Items> getItemses() {
            return itemses;
        }

        public void setItemses(ArrayList<Items> itemses) {
            this.itemses = itemses;
        }

        public class Items {

            @SerializedName("item_id")
            private int item_id;

            @SerializedName("product_id")
            private int product_id;

            @SerializedName("product_name_en")
            private String product_name_en;

            @SerializedName("product_name_ar")
            private String product_name_ar;

            @SerializedName("category_id")
            private String category_id;

            @SerializedName("category_name_en")
            private String category_name_en;

            @SerializedName("category_name_ar")
            private String category_name_ar;

            @SerializedName("product_qty")
            private String product_qty;


            @SerializedName("product_base_price")
            private String product_base_price;

            @SerializedName("product_total_price")
            private String product_total_price;


            @SerializedName("selected_qty")
            private String selected_qty;

            @SerializedName("product_images")
            private ArrayList<ProductImage> product_images;

            public ArrayList<ProductImage> getProduct_images() {
                return product_images;
            }

            public void setProduct_images(ArrayList<ProductImage> product_images) {
                this.product_images = product_images;
            }

            public class ProductImage implements Serializable {

                public String getImage() {
                    return image;
                }

                public void setImage(String image) {
                    this.image = image;
                }

                @SerializedName("image")
                private String image;
            }


            public int getSelected_qty() {
                try {
                    return Integer.parseInt(selected_qty);
                } catch (Exception e) {
                    return 0;
                }

            }

            public void setSelected_qty(String selected_qty) {
                this.selected_qty = selected_qty;
            }

            public int getItem_id() {
                return item_id;
            }

            public void setItem_id(int item_id) {
                this.item_id = item_id;
            }

            public int getProduct_id() {
                return product_id;
            }

            public void setProduct_id(int product_id) {
                this.product_id = product_id;
            }

            public String getProduct_name_en() {
                return product_name_en;
            }

            public void setProduct_name_en(String product_name_en) {
                this.product_name_en = product_name_en;
            }

            public String getProduct_name_ar() {
                return product_name_ar;
            }

            public void setProduct_name_ar(String product_name_ar) {
                this.product_name_ar = product_name_ar;
            }

            public String getCategory_id() {
                return category_id;
            }

            public void setCategory_id(String category_id) {
                this.category_id = category_id;
            }

            public String getCategory_name_en() {
                return category_name_en;
            }

            public void setCategory_name_en(String category_name_en) {
                this.category_name_en = category_name_en;
            }

            public String getCategory_name_ar() {
                return category_name_ar;
            }

            public void setCategory_name_ar(String category_name_ar) {
                this.category_name_ar = category_name_ar;
            }

            public int getProduct_qty() {
                try {
                    return Integer.parseInt(product_qty);
                } catch (Exception e) {
                    return 0;
                }
            }

            public void setProduct_qty(String product_qty) {
                this.product_qty = product_qty;
            }

            public double getProduct_base_price() {
                try {
                    return Double.parseDouble(product_base_price);
                } catch (Exception e) {
                    return 0;
                }
            }

            public void setProduct_base_price(String product_base_price) {
                this.product_base_price = product_base_price;
            }

            public int getProduct_total_price() {
                try {
                    return Integer.parseInt(product_total_price);
                } catch (Exception e) {
                    return 0;
                }
            }

            public void setProduct_total_price(String product_total_price) {
                this.product_total_price = product_total_price;
            }
        }
    }
}
