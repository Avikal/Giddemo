package com.cdn.techquiq.consumer.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.Utils.SharedPrefrence;
import com.cdn.techquiq.consumer.Utils.Utils;

/**
 * Created by kajalsoni on 28/1/17.
 */

public class SplashActivity extends Activity {


    private static int SPLASH_TIME_OUT = 3000;

    private ImageView ivSetting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        Utils.loadFontFiles(this);
        moveToNextScreen();
    }

    public void moveToNextScreen() {

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                if (SharedPrefrence.getInstance(SplashActivity.this).readBooleanPrefs(SharedPrefrence.isLoggedIn)) {
                    MainActivity.mainCurrentTab = null;
                    Intent tempIntent = new Intent(SplashActivity.this, MainActivity.class);
                    startActivity(tempIntent);
                    finish();
                } else {
                    Intent tempIntent = new Intent(SplashActivity.this, LoginActivity.class);
                    startActivity(tempIntent);
                    finish();
                }

            }
        }, SPLASH_TIME_OUT);
    }

}
