package com.cdn.techquiq.consumer.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by avikaljain on 24/3/17.
 */

public class AddressResponse extends BaseResponse {

    public ArrayList<AddressDetail> getAddressDetail() {
        return addressDetail;
    }

    public void setAddressDetail(ArrayList<AddressDetail> addressDetail) {
        this.addressDetail = addressDetail;
    }

    @SerializedName("Result")
    private ArrayList<AddressDetail> addressDetail;

    public class AddressDetail implements Serializable {

        @SerializedName("id")
        private String id;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        @SerializedName("first_name")
        private String firstName;

        @SerializedName("last_name")
        private String lastName;

        @SerializedName("country_name")
        private String countryName;

        @SerializedName("state_name")
        private String stateName;

        @SerializedName("city_name")
        private String cityName;

        @SerializedName("address_type")
        private String addressType;

        @SerializedName("postalcode")
        private String postalCode;

        public String getStateName() {
            return stateName;
        }

        public void setStateName(String stateName) {
            this.stateName = stateName;
        }

        public String getLastName() {

            return lastName;
        }

        public void setLastName(String lastName) {
            this.lastName = lastName;
        }

        public String getFirstName() {

            return firstName;
        }

        public void setFirstName(String firstName) {
            this.firstName = firstName;
        }

        public String getCountryName() {

            return countryName;
        }

        public void setCountryName(String countryName) {
            this.countryName = countryName;
        }

        public String getCityName() {

            return cityName;
        }

        public void setCityName(String cityName) {
            this.cityName = cityName;
        }

        public String getAddressType() {

            return addressType;
        }

        public void setAddressType(String addressType) {
            this.addressType = addressType;
        }

        @SerializedName("address")
        private String address;

        @SerializedName("city_id")
        private String cityId;

        public String getCityId() {
            return cityId;
        }

        public void setCityId(String cityId) {
            this.cityId = cityId;
        }

        @SerializedName("country_id")
        private String countryId;

        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public String getStateId() {

            return stateId;
        }

        public void setStateId(String stateId) {
            this.stateId = stateId;
        }

        public String getCountryId() {

            return countryId;
        }

        public void setCountryId(String countryId) {
            this.countryId = countryId;
        }

        @SerializedName("state_id")
        private String stateId;

        @SerializedName("user_id")
        private String userId;

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getPostalCode() {
            return postalCode;
        }

        public void setPostalCode(String postalCode) {
            this.postalCode = postalCode;
        }
    }

    private String address;

    private boolean isSelected;

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
