
package com.cdn.techquiq.consumer.adapter;

/**
 * Created by kajalsoni on 31/1/17.
 */

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.activity.AlertDetailActivity;
import com.cdn.techquiq.consumer.model.AlertResponse;
import com.cdn.techquiq.consumer.model.commonResponse;
import com.marshalchen.ultimaterecyclerview.UltimateRecyclerviewViewHolder;
import com.marshalchen.ultimaterecyclerview.UltimateViewAdapter;

import java.util.ArrayList;
import java.util.List;

public class AlertAdapter extends UltimateViewAdapter {

    private List<commonResponse> commonBeanList;
    Context mContext;
    LayoutInflater mLayoutInflater;

    private List<AlertResponse.AlertList> alertList;

    public AlertAdapter(Context context, ArrayList<AlertResponse.AlertList> alertList) {
        this.mContext = context;
        this.alertList = alertList;
        mLayoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (alertList.size() == position) {
            Log.e("RETURN POSITION", "" + position);
            return;
        }

        final AlertResponse.AlertList alertBean = alertList.get(position);
        if (position < getItemCount() && (customHeaderView != null ? position <= alertList.size() : position < alertList.size()) && (customHeaderView != null ? position > 0 : true)) {

            String date = Utils.getRequiredFormattedDate(Utils.serverFormat, Utils.requiredFormat, alertBean.getDate());
            ((ViewHolderAlert) holder).titleTv.setText(alertBean.getName());
            ((ViewHolderAlert) holder).timeTv.setText(date);
            ((ViewHolderAlert) holder).descriptionTv.setText(alertBean.getDescription());

            ((ViewHolderAlert) holder).mparent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(mContext, AlertDetailActivity.class);
                    intent.putExtra("title", alertBean.getName());
                    intent.putExtra("description", alertBean.getDescription());
                    intent.putExtra("image", alertBean.getImage());
                    intent.putExtra("notificationTypeId", alertBean.getId());
                    mContext.startActivity(intent);
                }
            });
        }
    }

    @Override
    public RecyclerView.ViewHolder newFooterHolder(View view) {
        return new UltimateRecyclerviewViewHolder<>(view);
    }

    @Override
    public RecyclerView.ViewHolder newHeaderHolder(View view) {
        return new UltimateRecyclerviewViewHolder<>(view);
    }


    @Override
    public int getAdapterItemCount() {
        return alertList.size();
    }

    @Override
    public UltimateRecyclerviewViewHolder onCreateViewHolder(ViewGroup parent) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.alert_list_item, parent, false);
        ViewHolderAlert vh = new ViewHolderAlert(v);
        return vh;
    }

    public void insert(String string, int position) {
        insertInternal(alertList, string, position);
    }

    public void remove(int position) {
        removeInternal(alertList, position);
    }

    public void clear() {
        clearInternal(alertList);
    }


    public void swapPositions(int from, int to) {
        swapPositions(alertList, from, to);
    }


    @Override
    public long generateHeaderId(int position) {
        // URLogs.d("position--" + position + "   " + getItem(position));
        if (getItem(position).length() > 0)
            return getItem(position).charAt(0);
        else return -1;
    }

    @Override
    public RecyclerView.ViewHolder onCreateHeaderViewHolder(ViewGroup parent) {
        return null;
    }

    @Override
    public void onBindHeaderViewHolder(RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    public void onItemMove(int fromPosition, int toPosition) {
        if (fromPosition > 0 && toPosition > 0) {
            swapPositions(fromPosition, toPosition);
            super.onItemMove(fromPosition, toPosition);
        }
    }

    @Override
    public void onItemDismiss(int position) {
        if (position > 0) {
            remove(position);
            notifyDataSetChanged();
            super.onItemDismiss(position);
        }

    }

    public void setOnDragStartListener(OnStartDragListener dragStartListener) {
        mDragStartListener = dragStartListener;

    }

    class ViewHolderAlert extends UltimateRecyclerviewViewHolder {

        public TextView titleTv, timeTv, descriptionTv;
        View mparent;


        public ViewHolderAlert(View view) {
            super(view);
            mparent = view;
            titleTv = (TextView) view.findViewById(R.id.titleTv);
            timeTv = (TextView) view.findViewById(R.id.timeTv);
            descriptionTv = (TextView) view.findViewById(R.id.descriptionTv);

        }

        @Override
        public void onItemSelected() {
            itemView.setBackgroundColor(Color.LTGRAY);
        }

        @Override
        public void onItemClear() {
            itemView.setBackgroundColor(0);
        }
    }

    public String getItem(int position) {
        if (customHeaderView != null)
            position--;

        if (position >= 0 && position < alertList.size())
            return String.valueOf(alertList.get(position));
        else return "";
    }

}
