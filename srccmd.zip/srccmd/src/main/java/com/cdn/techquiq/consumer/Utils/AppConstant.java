package com.cdn.techquiq.consumer.Utils;


/**
 * Created by akshaysoni on 27/1/17.
 * This class is use to define all the constant in the application.
 */
public class AppConstant {

    public static String CURRENCY_SYMBOL = "SAR";
    public static String CURRENCY_PAYPAL = "USD";

    /**
     * Tab constant
     */
    public static final String TAB_HOME = "TAB_HOME";
    public static final String TAB_PRODUCT = "TAB_PRODUCT";
    public static final String TAB_SERVICE = "TAB_SERVICE";
    public static final String TAB_INBOX = "TAB_INBOX";
    public static final String TAB_ALERT = "TAB_ALERT";


    /**
     * Service status
     */
    public static String PICKEDUP = "pickedup";
    public static String COMPLETED = "Completed";
    public static String WITHDRAW = "Withdraw";
    public static String ASIGNEED = "Asghined";
    public static String READY_TO_DELIVER = "Ready to deliver";
    public static String DELIVERED = "Delivered";
    public static String REPAIRED = "repaired";

    /**
     * order status
     */
    //public static String ORDER_DELIVERED = "Delivered";
    //public static String ORDER_CANCELED = "Cancelled";
    //public static String ORDER_COMPLETED = "Completed";

    public static int ORDER_PENDING = 1;
    public static int ORDER_DELIVERED = 9;
    public static int ORDER_CANCELED = 5;
    public static int ORDER_COMPLETED = 4;

    /**
     * Constant for date format
     */
    public static String SERVER_DATE_FORMATE = "yyyy-MM-dd HH:mm:ss";
    public static String CHAT_DATE_FORMATE = "MMM dd, HH:mm";


    /**
     * Set limit of for the get data from the webservice
     */
    public static int AWARDED_LIMIT = 10;
    public static int PRODUCT_LIMIT = 10;
    public static int PROPOSAL_LIMIT = 10;
    public static int MESSAGE_LIMIT = 10;
    public static int MY_ORDER_LIMIT = 10;
    public static int OPEN_SERVICE_LIMIT = 10;
    public static int CHAT_LIMIT = 5;


    /**
     * Response status code to show message
     */
    public static int SUCCESS = 10000;
    public static int UNKNOWN_ERROR = 10001;
    public static int PARAM_MISSING = 10002;
    public static int INVALID_LOGIN_TOKEN = 10003;
    public static int UNAUTHORIZED_USER = 10004;
    public static int WRONG_CREDENTIALS = 10005;
    public static int NOT_REGISTERED = 10006;
    public static int PASSWORD_SENT = 10007;
    public static int EMAIL_ALREADY_REGISTERED = 10008;
    public static int WRONG_EXISTING_PASSWORD = 10009;
    public static int NO_DATA_FOUND = 10010;
    public static int NO_CART_FOUND = 100011;
    public static int EMPTY_CART = 10012;
    public static int PROMO_CODE_CAN_NOT_APPLIED = 10014;
    public static int INVALID_PROMO_CODE = 10013;
    public static int PROMO_CODE_ALREADY_APPLIED = 10015;
    public static int INVALID_CART_ID = 10016;
    public static int PRODUCT_OUT_OF_STOCK = 10017;
    public static int CART_AMT_CHANGED = 10018;

    /**
     * Constant for chat Action
     */
    public static final String CHAT_ACTION = "com.tecquick.consumer.activity.chat";
    public static final String UPDATE_CHAT_OWN_MSG = "UPDATE_CHAT_OWN_MSG";
    public static final String UPDATE_CHAT_RECEIVE_MSG = "UPDATE_CHAT_RECEIVE_MSG";
    public static final String UPDATE_CHAT_HISTORY = "UPDATE_CHAT_HISTORY";

    /**
     * Chat approve status
     */
    public static final int CHAT_APPROVED = 1;
    public static final int CHAT_REJECTED = 2;
    public static final int CHAT_PENDING = 3;
    public static final int CHAT_SENT = 4;

    /**
     * FCM constants
     */
    public static final String TOPIC_GLOBAL = "global";
    public static String FCM_ID = "";

    // broadcast receiver intent filters
    public static final String REGISTRATION_COMPLETE = "registrationComplete";
    public static final String PUSH_NOTIFICATION = "pushNotification";

    // Type to handle the notification in the notification tray
    public static final String ALERT_NOTIFICATION = "alertNotification";
    public static final String CHAT_NOTIFICATION = "chatNotification";

}
