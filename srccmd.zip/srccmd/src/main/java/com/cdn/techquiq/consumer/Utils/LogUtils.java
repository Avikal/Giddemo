package com.cdn.techquiq.consumer.Utils;


import android.util.Log;



/**
 * This is logging helper class.
 */
public class LogUtils {
    public static final String TAG = "TechQuiqConsumer";

    public static boolean DEBUG = true;


    public static void setLoggable(boolean tag) {
        DEBUG = tag;
    }

    public static void LogI(String tag, String msg) {
        if (DEBUG)
            Log.i(tag, msg);

    }

    public static void LogI(String tag, String msg, Throwable tr) {
        if (DEBUG)
            Log.i(tag, msg, tr);
    }


    public static void LogV(String tag, String msg) {
        if (DEBUG)
            Log.v(tag, msg);

    }

    public static void LogV(String tag, String msg, Throwable tr) {
        if (DEBUG)
            Log.v(tag, msg, tr);
    }

    public static void LogE(String tag, String msg) {
        if (DEBUG)
            Log.e(tag, msg);

    }

    public static void LogD(String tag, String msg) {
        if (DEBUG)
            Log.d(tag, msg);

    }

    public static void LogE(String tag, String msg, Throwable tr) {
        if (DEBUG)
            Log.e(tag, msg, tr);
    }

}
