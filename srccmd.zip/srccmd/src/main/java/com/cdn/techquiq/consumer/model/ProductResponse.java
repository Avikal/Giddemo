package com.cdn.techquiq.consumer.model;

import com.cdn.techquiq.consumer.Utils.Utils;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by kajalsoni on 30/1/17.
 */

public class ProductResponse extends BaseResponse {

    public int getTotalProduct() {
        return totalProduct;
    }

    public void setTotalProduct(int totalProduct) {
        this.totalProduct = totalProduct;
    }

    @SerializedName("Total_product")
    private int totalProduct;

    @SerializedName("Result")
    ArrayList<ProductDetail> productDetail;

    public ArrayList<ProductDetail> getProductDetail() {
        return productDetail;
    }

    public void setProductDetail(ArrayList<ProductDetail> productDetail) {
        this.productDetail = productDetail;
    }

    public class ProductDetail implements Serializable {

        @SerializedName("id")
        int id;

        @SerializedName("name_en")
        String name_en;

        @SerializedName("name_ar")
        String name_ar;


        @SerializedName("sku")
        String sku;

        @SerializedName("price")
        String price;

        @SerializedName("quantity")
        String quantity;

        @SerializedName("description_en")
        String description_en;

        @SerializedName("description_ar")
        String description_ar;


        @SerializedName("category_id")
        String category_id;

        @SerializedName("category_nameen")
        String category_nameen;

        @SerializedName("category_namear")
        String category_namear;

        @SerializedName("product_images")
        ArrayList<ProductImage> productImages;

        @SerializedName("average_rating")
        String average_rating;

        @SerializedName("related_products")
        ArrayList<RelatedProduct> relatedProducts;

        @SerializedName("rating_count")
        String rating_count;

        @SerializedName("merchant_id")
        private String merchantId;

        @SerializedName("merchant_first_name")
        private String merchantFirstName;

        @SerializedName("merchant_last_name")
        private String merchantLastName;

        @SerializedName("merchant_company")
        private String merchantCompany;

        @SerializedName("merchant_phone")
        private String merchantPhone;

        @SerializedName("merchant_email")
        private String merchantEmail;

        @SerializedName("merchant_address")
        private String merchantAddress;

        @SerializedName("image")
        private String merchantImage;

        @SerializedName("merchant_average_rating")
        private String merchantAverageRating;

        public String getMerchantAverageRating() {
            if (merchantAverageRating == null || merchantAverageRating.isEmpty()) {
                return "0.0";
            }
            return merchantAverageRating;
        }

        public void setMerchantAverageRating(String merchantAverageRating) {
            this.merchantAverageRating = merchantAverageRating;
        }

        public String getMerchantImage() {
            return merchantImage;
        }

        public void setMerchantImage(String merchantImage) {
            this.merchantImage = merchantImage;
        }

        public String getMerchantEmail() {
            return merchantEmail;
        }

        public void setMerchantEmail(String merchantEmail) {
            this.merchantEmail = merchantEmail;
        }

        public String getMerchantAddress() {
            return merchantAddress;
        }

        public void setMerchantAddress(String merchantAddress) {
            this.merchantAddress = merchantAddress;
        }

        public String getMerchantPhone() {
            return merchantPhone;
        }

        public void setMerchantPhone(String merchantPhone) {
            this.merchantPhone = merchantPhone;
        }

        public String getMerchantLastName() {
            return merchantLastName;
        }

        public void setMerchantLastName(String merchantLastName) {
            this.merchantLastName = merchantLastName;
        }

        public String getMerchantId() {
            return merchantId;
        }

        public void setMerchantId(String merchantId) {
            this.merchantId = merchantId;
        }

        public String getMerchantFirstName() {
            return merchantFirstName;
        }

        public void setMerchantFirstName(String merchantFirstName) {
            this.merchantFirstName = merchantFirstName;
        }

        public String getMerchantCompany() {

            return merchantCompany;
        }

        public void setMerchantCompany(String merchantCompany) {
            this.merchantCompany = merchantCompany;
        }

        public String getDescription() {
            if (Utils.getLocale().equalsIgnoreCase("ar")) {
                return getDescription_ar();
            } else {
                return getDescription_en();
            }
        }

        public String getName() {
            if (Utils.getLocale().equalsIgnoreCase("ar")) {
                return getName_ar();
            } else {
                return getName_en();
            }
        }

        public String getCategoryName() {
            if (Utils.getLocale().equalsIgnoreCase("ar")) {
                return getCategory_namear();
            } else {
                return getCategory_nameen();
            }
        }

        public String getAverage_rating() {
            if (average_rating == null || average_rating.isEmpty()) {
                return "0.0";
            }
            return average_rating;
        }

        public void setAverage_rating(String average_rating) {
            this.average_rating = average_rating;
        }

        public String getRating_count() {
            if (rating_count == null || rating_count.isEmpty()) {
                return "0";
            }
            return rating_count;
        }

        public void setRating_count(String rating_count) {
            this.rating_count = rating_count;
        }

        public ArrayList<RelatedProduct> getRelatedProducts() {
            return relatedProducts;
        }

        public void setRelatedProducts(ArrayList<RelatedProduct> relatedProducts) {
            this.relatedProducts = relatedProducts;
        }


        public class RelatedProduct implements Serializable {

            @SerializedName("id")
            int id;

            @SerializedName("name_en")
            String name_en;

            @SerializedName("name_ar")
            String name_ar;

            public String getName() {
                if (Utils.getLocale().equalsIgnoreCase("ar")) {
                    return getName_ar();
                } else {
                    return getName_en();
                }
            }

            @SerializedName("price")
            String price;

            @SerializedName("average_rating")
            String average_rating;

            @SerializedName("rating_count")
            String rating_count;

            public String getRating_count() {
                if (rating_count == null || rating_count.isEmpty()) {
                    return "0";
                }
                return rating_count;
            }

            public void setRating_count(String rating_count) {
                this.rating_count = rating_count;
            }

            public String getAverage_rating() {
                if (average_rating == null || average_rating.isEmpty()) {
                    return "0.0";
                }
                return average_rating;
            }

            public void setAverage_rating(String average_rating) {
                this.average_rating = average_rating;
            }


            @SerializedName("product_images")
            ArrayList<ProductImage> productImages;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getName_en() {
                return name_en;
            }

            public void setName_en(String name_en) {
                this.name_en = name_en;
            }

            public String getName_ar() {
                return name_ar;
            }

            public void setName_ar(String name_ar) {
                this.name_ar = name_ar;
            }

            public String getPrice() {
                if (price == null || price.isEmpty()) {
                    return "0";
                }
                return price;
            }

            public void setPrice(String price) {
                this.price = price;
            }


            public ArrayList<ProductImage> getProductImages() {
                return productImages;
            }

            public void setProductImages(ArrayList<ProductImage> productImages) {
                this.productImages = productImages;
            }

            public class ProductImage implements Serializable {

                public String getImage() {
                    return image;
                }

                public void setImage(String image) {
                    this.image = image;
                }

                @SerializedName("image")
                private String image;
            }
        }

        public ArrayList<ProductImage> getProductImages() {
            return productImages;
        }

        public void setProductImages(ArrayList<ProductImage> productImages) {
            this.productImages = productImages;
        }

        public class ProductImage implements Serializable {

            public String getImage() {
                return image;
            }

            public void setImage(String image) {
                this.image = image;
            }

            @SerializedName("image")
            private String image;
        }


        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName_en() {
            return name_en;
        }

        public void setName_en(String name_en) {
            this.name_en = name_en;
        }

        public String getName_ar() {
            return name_ar;
        }

        public void setName_ar(String name_ar) {
            this.name_ar = name_ar;
        }

        public String getSku() {
            return sku;
        }

        public void setSku(String sku) {
            this.sku = sku;
        }

        public String getPrice() {
            if (price == null || price.isEmpty()) {
                return "0";
            }
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public int getQuantity() {
            try {
                return Integer.parseInt(quantity);
            } catch (Exception e) {
                return 0;
            }

        }

        public void setQuantity(String quantity) {
            this.quantity = quantity;
        }

        public String getDescription_en() {
            return description_en;
        }

        public void setDescription_en(String description_en) {
            this.description_en = description_en;
        }

        public String getDescription_ar() {
            return description_ar;
        }

        public void setDescription_ar(String description_ar) {
            this.description_ar = description_ar;
        }

        public String getCategory_id() {
            return category_id;
        }

        public void setCategory_id(String category_id) {
            this.category_id = category_id;
        }

        public String getCategory_nameen() {
            return category_nameen;
        }

        public void setCategory_nameen(String category_nameen) {
            this.category_nameen = category_nameen;
        }

        public String getCategory_namear() {
            return category_namear;
        }

        public void setCategory_namear(String category_namear) {
            this.category_namear = category_namear;
        }

    }

}
