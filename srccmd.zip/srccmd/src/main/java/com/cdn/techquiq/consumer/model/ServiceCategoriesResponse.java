package com.cdn.techquiq.consumer.model;

import com.cdn.techquiq.consumer.Utils.Utils;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by avikaljain on 10/4/17.
 */

public class ServiceCategoriesResponse extends BaseResponse {

    public ArrayList<ServiceCategories> getCategoriesList() {
        return categoriesList;
    }

    public void setCategoriesList(ArrayList<ServiceCategories> categoriesList) {
        this.categoriesList = categoriesList;
    }

    @SerializedName("Result")
    private ArrayList<ServiceCategories> categoriesList;

    public class ServiceCategories implements Serializable {
        @SerializedName("id")
        private String id;

        @SerializedName("name_en")
        private String nameEn;

        public String getNameEn() {
            return nameEn;
        }

        public void setNameEn(String nameEn) {
            this.nameEn = nameEn;
        }

        public String getNameAr() {

            return nameAr;
        }

        public void setNameAr(String nameAr) {
            this.nameAr = nameAr;
        }

        public String getId() {

            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getDescriptionEn() {

            return descriptionEn;
        }

        public void setDescriptionEn(String descriptionEn) {
            this.descriptionEn = descriptionEn;
        }

        public String getDescription() {
            if (Utils.getLocale().equalsIgnoreCase("ar")) {
                return getDescriptionAr();
            } else {
                return getDescriptionEn();
            }
        }

        public String getName() {
            if (Utils.getLocale().equalsIgnoreCase("ar")) {
                return getNameAr();
            } else {
                return getNameEn();
            }
        }

        public String getDescriptionAr() {

            return descriptionAr;
        }

        public void setDescriptionAr(String descriptionAr) {
            this.descriptionAr = descriptionAr;
        }

        @SerializedName("name_ar")
        private String nameAr;

        @SerializedName("description_en")
        private String descriptionEn;

        @SerializedName("description_ar")
        private String descriptionAr;

        @SerializedName("sub_categories")
        private ArrayList<ServiceSubCategories> subCategories;

        public ArrayList<ServiceSubCategories> getSubCategories() {
            return subCategories;
        }

        public void setSubCategories(ArrayList<ServiceSubCategories> subCategories) {
            this.subCategories = subCategories;
        }

        public class ServiceSubCategories implements Serializable {
            @SerializedName("id")
            private String id;

            @SerializedName("name_en")
            private String nameEn;

            public String getNameEn() {
                return nameEn;
            }

            public void setNameEn(String nameEn) {
                this.nameEn = nameEn;
            }

            public String getNameAr() {

                return nameAr;
            }

            public void setNameAr(String nameAr) {
                this.nameAr = nameAr;
            }

            public String getDescriptionEn() {

                return descriptionEn;
            }

            public void setDescriptionEn(String descriptionEn) {
                this.descriptionEn = descriptionEn;
            }

            public String getDescriptionAr() {

                return descriptionAr;
            }

            public void setDescriptionAr(String descriptionAr) {
                this.descriptionAr = descriptionAr;
            }

            @SerializedName("name_ar")
            private String nameAr;

            @SerializedName("description_en")
            private String descriptionEn;

            @SerializedName("description_ar")
            private String descriptionAr;

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public String getDescription() {
                if (Utils.getLocale().equalsIgnoreCase("ar")) {
                    return getDescriptionAr();
                } else {
                    return getDescriptionEn();
                }
            }

            public String getName() {
                if (Utils.getLocale().equalsIgnoreCase("ar")) {
                    return getNameAr();
                } else {
                    return getNameEn();
                }
            }
        }
    }

}
