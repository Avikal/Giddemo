package com.cdn.techquiq.consumer.model;

import java.util.ArrayList;

/**
 * Created by kajalsoni on 30/1/17.
 */

public class StateResponse extends BaseResponse {


    ArrayList<State> Result;

    public ArrayList<State> getResult() {
        return Result;
    }

    public void setResult(ArrayList<State> result) {
        Result = result;
    }

    public class State {
        String state_id, state_name;

        public String getState_id() {
            return state_id;
        }

        public void setState_id(String state_id) {
            this.state_id = state_id;
        }

        public String getState_name() {
            return state_name;
        }

        public void setState_name(String state_name) {
            this.state_name = state_name;
        }
    }
}
