package com.cdn.techquiq.consumer.model;

import com.cdn.techquiq.consumer.Utils.Utils;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by akshaysoni on 24/3/17.
 */

public class OrderHistoryResponse extends BaseResponse {

    public int getTotalOrder() {
        return Total_order;
    }

    public void setTotalOrder(int Total_order) {
        this.Total_order = Total_order;
    }

    @SerializedName("Total_order")
    private int Total_order;


    @SerializedName("Result")
    private ArrayList<OrderHistoryResponse.OrderList> orderLists;

    public ArrayList<OrderList> getOrderLists() {
        return orderLists;
    }

    public void setOrderLists(ArrayList<OrderList> orderLists) {
        this.orderLists = orderLists;
    }

    public class OrderList implements Serializable {

        @SerializedName("id")
        private String id;

        @SerializedName("payment_status_id")
        private String paymentStatusId;

        private String orderStatus;

        @SerializedName("order_status")
        private String orderStatusEn;


        @SerializedName("order_status_ar")
        private String orderStatusAr;

        @SerializedName("payment_status")
        private String paymentStatus;

        @SerializedName("shipping_address")
        private String shippingAddress;

        @SerializedName("total_amount")
        private float totalAmount;

        @SerializedName("created_date")
        private String createdDate;

        @SerializedName("created_by")
        private String createdBy;

        @SerializedName("promo_code")
        private String promoCode;

        @SerializedName("promo_code_description")
        private String promoCodeDescription;

        @SerializedName("offer_amount")
        private String offerAmount;

        @SerializedName("can_update_review")
        private boolean isWriteReview;

        @SerializedName("payment_mode")
        private String paymentModeEn;

        @SerializedName("payment_mode_ar")
        private String paymentModeAr;

        private String paymentMode;

        public String getPaymentModeEn() {
            return paymentModeEn;
        }

        public void setPaymentModeEn(String paymentModeEn) {
            this.paymentModeEn = paymentModeEn;
        }

        public String getPaymentModeAr() {

            return paymentModeAr;
        }

        public void setPaymentModeAr(String paymentModeAr) {
            this.paymentModeAr = paymentModeAr;
        }

        public String getPaymentMode() {

            if (Utils.getLocale().equalsIgnoreCase("ar")) {
                return getPaymentModeAr();
            } else {
                return getPaymentModeEn();
            }
        }

        public boolean isWriteReview() {
            return isWriteReview;
        }

        public void setWriteReview(boolean writeReview) {
            isWriteReview = writeReview;
        }

        @SerializedName("order_detail")
        private ArrayList<OrderHistoryResponse.OrderList.OrderDetail> orderDetail;

        @SerializedName("order_status_code")
        int orderStatusCode;

        public int getOrderStatusCode() {
            return orderStatusCode;
        }

        public void setOrderStatusCode(int orderStatusCode) {
            this.orderStatusCode = orderStatusCode;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getPaymentStatusId() {
            return paymentStatusId;
        }

        public void setPaymentStatusId(String paymentStatusId) {
            this.paymentStatusId = paymentStatusId;
        }

        public String getOrderStatusEn() {
            return orderStatusEn;
        }

        public void setOrderStatusEn(String orderStatusEn) {
            this.orderStatusEn = orderStatusEn;
        }

        public String getOrderStatusAr() {

            return orderStatusAr;
        }

        public void setOrderStatusAr(String orderStatusAr) {
            this.orderStatusAr = orderStatusAr;
        }

        public String getOrderStatus() {
            if (Utils.getLocale().equalsIgnoreCase("ar")) {
                return getOrderStatusAr();
            } else {
                return getOrderStatusEn();
            }

        }

        public void setOrderStatus(String orderStatus) {
            this.orderStatus = orderStatus;
        }

        public String getPaymentStatus() {
            return paymentStatus;
        }

        public void setPaymentStatus(String paymentStatus) {
            this.paymentStatus = paymentStatus;
        }

        public String getShippingAddress() {
            return shippingAddress;
        }

        public void setShippingAddress(String shippingAddress) {
            this.shippingAddress = shippingAddress;
        }

        public float getTotalAmount() {
            return totalAmount;
        }

        public void setTotalAmount(int totalAmount) {
            this.totalAmount = totalAmount;
        }

        public String getCreatedDate() {
            return createdDate;
        }

        public void setCreatedDate(String createdDate) {
            this.createdDate = createdDate;
        }

        public String getCreatedBy() {
            return createdBy;
        }

        public void setCreatedBy(String createdBy) {
            this.createdBy = createdBy;
        }

        public String getPromoCode() {
            return promoCode;
        }

        public void setPromoCode(String promoCode) {
            this.promoCode = promoCode;
        }

        public String getOfferAmount() {
            return offerAmount;
        }

        public void setOfferAmount(String offerAmount) {
            this.offerAmount = offerAmount;
        }

        public String getPromoCodeDescription() {
            return promoCodeDescription;
        }

        public void setPromoCodeDescription(String promoCodeDescription) {
            this.promoCodeDescription = promoCodeDescription;
        }

        public ArrayList<OrderDetail> getOrderDetail() {
            return orderDetail;
        }

        public void setOrderDetail(ArrayList<OrderDetail> orderDetail) {
            this.orderDetail = orderDetail;
        }

        public class OrderDetail implements Serializable {

            @SerializedName("item_id")
            private String itemId;

            @SerializedName("product_id")
            private String product_id;

            @SerializedName("product_name_en")
            private String product_name_en;

            @SerializedName("product_name_ar")
            private String product_name_ar;

            @SerializedName("category_id")
            private String categoryId;

            @SerializedName("category_name_en")
            private String categoryNameEn;

            @SerializedName("product_image")
            private String productImage;

            @SerializedName("product_qty")
            private String productQty;

            @SerializedName("selected_qty")
            private String selectedQty;

            @SerializedName("product_base_price")
            private String productBasePrice;

            @SerializedName("product_total_price")
            private String productTotalPrice;

            @SerializedName("order_status")
            private String orderStatus;

            @SerializedName("payment_status")
            private String paymentStatus;

            @SerializedName("merchant_id")
            private String merchantId;

            @SerializedName("merchant_first_name")
            private String merchantFirstName;

            @SerializedName("merchant_last_name")
            private String merchantLastName;

            @SerializedName("merchant_company")
            private String merchantCompany;

            @SerializedName("merchant_phone")
            private String merchant_phone;

            @SerializedName("merchant_email")
            private String merchantEmail;

            @SerializedName("merchant_address")
            private String merchantAddress;

            @SerializedName("merchant_image")
            private String item_id;

            @SerializedName("product_images")
            private ArrayList<ProductImages> productImages;

            public String getProductName() {
                if (Utils.getLocale().equalsIgnoreCase("ar")) {
                    return getProduct_name_ar();
                } else {
                    return getProduct_name_en();
                }
            }

            public void setProductName(String productName) {
                this.productName = productName;
            }

            private String productName;

            public ArrayList<ProductImages> getProductImages() {
                return productImages;
            }

            public void setProductImages(ArrayList<ProductImages> productImages) {
                this.productImages = productImages;
            }

            public String getItemId() {
                return itemId;
            }

            public void setItemId(String itemId) {
                this.itemId = itemId;
            }

            public String getProduct_id() {
                return product_id;
            }

            public void setProduct_id(String product_id) {
                this.product_id = product_id;
            }

            public String getProduct_name_en() {
                return product_name_en;
            }

            public void setProduct_name_en(String product_name_en) {
                this.product_name_en = product_name_en;
            }

            public String getProduct_name_ar() {
                return product_name_ar;
            }

            public void setProduct_name_ar(String product_name_ar) {
                this.product_name_ar = product_name_ar;
            }

            public String getCategoryId() {
                return categoryId;
            }

            public void setCategoryId(String categoryId) {
                this.categoryId = categoryId;
            }

            public String getCategoryNameEn() {
                return categoryNameEn;
            }

            public void setCategoryNameEn(String categoryNameEn) {
                this.categoryNameEn = categoryNameEn;
            }

            public String getProductQty() {
                return productQty;
            }

            public void setProductQty(String productQty) {
                this.productQty = productQty;
            }

            public String getSelectedQty() {
                return selectedQty;
            }

            public void setSelectedQty(String selectedQty) {
                this.selectedQty = selectedQty;
            }

            public String getProductBasePrice() {
                return productBasePrice;
            }

            public void setProductBasePrice(String productBasePrice) {
                this.productBasePrice = productBasePrice;
            }

            public String getProductTotalPrice() {
                return productTotalPrice;
            }

            public void setProductTotalPrice(String productTotalPrice) {
                this.productTotalPrice = productTotalPrice;
            }

            public String getOrderStatus() {
                return orderStatus;
            }

            public void setOrderStatus(String orderStatus) {
                this.orderStatus = orderStatus;
            }

            public String getPaymentStatus() {
                return paymentStatus;
            }

            public void setPaymentStatus(String paymentStatus) {
                this.paymentStatus = paymentStatus;
            }

            public String getMerchantId() {
                return merchantId;
            }

            public void setMerchantId(String merchantId) {
                this.merchantId = merchantId;
            }

            public String getMerchantFirstName() {
                return merchantFirstName;
            }

            public void setMerchantFirstName(String merchantFirstName) {
                this.merchantFirstName = merchantFirstName;
            }

            public String getMerchantLastName() {
                return merchantLastName;
            }

            public void setMerchantLastName(String merchantLastName) {
                this.merchantLastName = merchantLastName;
            }

            public String getMerchantCompany() {
                return merchantCompany;
            }

            public void setMerchantCompany(String merchantCompany) {
                this.merchantCompany = merchantCompany;
            }

            public String getMerchant_phone() {
                return merchant_phone;
            }

            public void setMerchant_phone(String merchant_phone) {
                this.merchant_phone = merchant_phone;
            }

            public String getMerchantEmail() {
                return merchantEmail;
            }

            public void setMerchantEmail(String merchantEmail) {
                this.merchantEmail = merchantEmail;
            }

            public String getMerchantAddress() {
                return merchantAddress;
            }

            public void setMerchantAddress(String merchantAddress) {
                this.merchantAddress = merchantAddress;
            }

            public String getItem_id() {
                return item_id;
            }

            public void setItem_id(String item_id) {
                this.item_id = item_id;
            }


            public class ProductImages implements Serializable {

                @SerializedName("image")
                private String image;

                public String getImage() {
                    return image;
                }

                public void setImage(String image) {
                    this.image = image;
                }
            }

        }
    }

}
