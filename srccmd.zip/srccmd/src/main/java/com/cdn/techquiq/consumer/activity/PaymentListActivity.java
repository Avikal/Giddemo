package com.cdn.techquiq.consumer.activity;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.adapter.PaymentAdapter;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.PaymentResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.google.gson.Gson;
import com.marshalchen.ultimaterecyclerview.UltimateRecyclerView;
import com.miguelcatalan.materialsearchview.MaterialSearchView;

import java.net.SocketTimeoutException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by kajalsoni on 3/2/17.
 */

public class PaymentListActivity extends BaseActivity {

    private String TAG = PaymentListActivity.class.getSimpleName();

    private UltimateRecyclerView recyclerView;
    ArrayList<PaymentResponse.PaymentDetails> paymentList = new ArrayList<>();
    PaymentAdapter paymentAdapter;
    private TextView noProductTv, titleTv;
    private int limit;
    private int currentOffset;
    private int totalRecord;
    private String keyword;

    private ImageView backIv, sliderIv, cartIv, settingIv, searchIcon;
    private RelativeLayout cartCountTitleLayout;
    private MaterialSearchView searchView;
    private boolean isSearchVisible;
    private LinearLayoutManager linearLayoutManager;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.payment_history_list_activity);

        recyclerView = (UltimateRecyclerView) findViewById(R.id.paymentList);
        recyclerView.setHasFixedSize(false);
        noProductTv = (TextView) findViewById(R.id.tvPaymentND);
        titleTv = (TextView) findViewById(R.id.titleTv);
        titleTv.setText(getString(R.string.payment));
        backIv = (ImageView) findViewById(R.id.backIv);
        backIv.setOnClickListener(this);
        searchView = (MaterialSearchView) findViewById(R.id.search_view);
        sliderIv = (ImageView) findViewById(R.id.sliderIv);
        cartIv = (ImageView) findViewById(R.id.cartIv);
        cartCountTitleLayout = (RelativeLayout) findViewById(R.id.cartCountTitleLayout);
        settingIv = (ImageView) findViewById(R.id.settingIv);
        sliderIv.setVisibility(View.GONE);
        cartIv.setVisibility(View.GONE);
        cartCountTitleLayout.setVisibility(View.GONE);
        settingIv.setVisibility(View.GONE);
        searchIcon = (ImageView) findViewById(R.id.searchIcon);
        searchIcon.setOnClickListener(this);

        linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);

        recyclerView.setLoadMoreView(LayoutInflater.from(this)
                .inflate(R.layout.custom_bottom_progressbar, null));

        callWebService();

    }

    @Override
    public void onBackPressed() {
        if (searchView.isSearchOpen()) {
            closeSearchView();
        } else {
            backIv.performClick();
        }
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.backIv:
                finish();
                break;

            case R.id.searchIcon:
                searchFunctionality();
                break;
        }
    }

    private void callWebService() {
        limit = 10;
        currentOffset = 0;
        totalRecord = 0;
        keyword = "";
        getPaymentHistory(currentOffset, false, keyword);
        loadMore();
    }

    public void getPaymentHistory(int offset, final boolean isLoadMore, String keyword) {
        try {
            this.keyword = keyword;
            if (!isLoadMore) {
                if (!showProgressDialog(this)) {
                    noProductTv.setText(getString(R.string.network_error));
                    noProductTv.setVisibility(View.VISIBLE);
                    return;
                }
            }

            final LoginResponse.Users userDetail = Utils.readUserDetail(this);

            /*final String filterJson = SharedPrefrence.getInstance(getActivity())
                    .readPrefs(SharedPrefrence.filterJson);*/

            final Call<PaymentResponse> paymentRequest = ((TechquiqApplication) getApplicationContext())
                    .getService().getPaymentList(userDetail.getUserId(),
                            Utils.getDeviceId(this),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID,
                            limit,
                            offset,
                            keyword);

            Log.e(TAG, "Request : " + paymentRequest.request().url());

            paymentRequest.enqueue(new Callback<PaymentResponse>() {
                @Override
                public void onResponse(Call<PaymentResponse> call, Response<PaymentResponse> response) {

                    if (response == null) {
                        showToastMsg(mContext, getString(R.string.server_error));
                        return;
                    }

//                    recyclerView.loadMoreComplete();

                    if (!isLoadMore) {
                        hideProgressDialog();
                    }

                    PaymentResponse paymentResponse = response.body();
                    int responseStatusCode = paymentResponse.getResponseStatusCode();
                    if (responseStatusCode == AppConstant.NO_DATA_FOUND) {
                        setErrorMessage(getResources().getString(R.string.ws_no_payment_data));
                    } else if (responseStatusCode == AppConstant.UNKNOWN_ERROR) {
                        setErrorMessage(getResources().getString(R.string.ws_unkonwn_error));
                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        totalRecord = paymentResponse.getTotal();
                        Log.e(TAG, String.valueOf(totalRecord));
                        if (paymentResponse.getResponseCode().equalsIgnoreCase("0")) {
                            setErrorMessage(getResources().getString(R.string.ws_no_payment_data));
                            return;
                        } else {
                            searchIcon.setVisibility(View.VISIBLE);
                            recyclerView.setVisibility(View.VISIBLE);
                            noProductTv.setVisibility(View.GONE);

                            if (isLoadMore) {
                                if (paymentList != null) {
                                    int offset = paymentList.size();
                                    for (int i = 0; i < paymentResponse.getPaymentDetails().size(); i++) {
                                        paymentList.add(offset, paymentResponse.getPaymentDetails().get(i));
                                        offset++;
                                    }

                                    paymentAdapter.notifyDataSetChanged();
                                }
                            } else {
                                paymentList = paymentResponse.getPaymentDetails();
                                if (paymentList != null && paymentList.size() > 0) {
                                    paymentAdapter = new PaymentAdapter(PaymentListActivity.this, paymentList);
                                    recyclerView.setAdapter(paymentAdapter);
                                } else {

                                }
                            }
                        }
                    }
                    Log.e(TAG, "Response : " + new Gson().toJson(paymentResponse));


                }

                @Override
                public void onFailure(Call<PaymentResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        setErrorMessage(getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    setErrorMessage(getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadMore() {
        recyclerView.reenableLoadmore();
        recyclerView.setOnLoadMoreListener(new UltimateRecyclerView.OnLoadMoreListener() {
            @Override
            public void loadMore(int itemsCount, int maxLastVisiblePosition) {
                try {
                    if (totalRecord <= paymentList.size()) {
                        recyclerView.disableLoadmore();
                    } else {
                        currentOffset = currentOffset + limit;
                        getPaymentHistory(currentOffset, true, keyword);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }


    private void setErrorMessage(String msg) {
        searchIcon.setVisibility(View.GONE);
        noProductTv.setVisibility(View.VISIBLE);
        noProductTv.setText(msg);
        recyclerView.setVisibility(View.GONE);
    }

    /**
     * Below methods is used for searcg functionality
     */
    public void closeSearchView() {
        if (searchView.isSearchOpen()) {
            searchView.closeSearch();
        }
    }

    private void openSearchView() {
        if (!searchView.isSearchOpen()) {
            searchView.showSearch();
        }
    }

    private void searchFunctionality() {

        openSearchView();

        searchView.setOnQueryTextListener(new MaterialSearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                searchView.clearFocus();

                getPaymentHistory(0, false, query);

                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });

        searchView.setOnSearchViewListener(new MaterialSearchView.SearchViewListener() {
            @Override
            public void onSearchViewShown() {
                isSearchVisible = true;
            }

            @Override
            public void onSearchViewClosed() {
                isSearchVisible = false;
                getPaymentHistory(0, false, "");
            }
        });
    }
}
