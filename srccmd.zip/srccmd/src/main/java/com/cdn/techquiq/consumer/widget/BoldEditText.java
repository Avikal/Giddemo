package com.cdn.techquiq.consumer.widget;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.EditText;

import com.cdn.techquiq.consumer.Utils.Utils;

/**
 * Created by avikaljain on 2/3/17.
 * Custom EditText for displaying Bold Text
 */

public class BoldEditText extends EditText {

    public BoldEditText(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    public BoldEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public BoldEditText(Context context) {
        super(context);
        init();
    }

    private void init() {
        if (!isInEditMode()) {
            Typeface tf = null;
            if (Utils.getLocale().equalsIgnoreCase("EN")) {
                tf = Utils.robotoBold;
                if (tf != null) {
                    setTypeface(tf);
                }
            }
        }
    }
}