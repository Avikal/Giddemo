package com.cdn.techquiq.consumer.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.model.AbuseReportResponse;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.ReportSuccessResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;
import com.google.gson.Gson;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BaseActivity extends AppCompatActivity implements View.OnClickListener {

    private String TAG = BaseActivity.class.getSimpleName();
    public Context mContext;
    private long mLastClickTime = 0;
    public ProgressDialog mProgressDialog;
    public String reportMerchant = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
    }

    @Override
    public void onClick(View v) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < 1000) {
            return;
        }
        mLastClickTime = SystemClock.elapsedRealtime();
    }

    public void showToastMsg(Context mContext, String msg) {
        Toast.makeText(mContext, msg, Toast.LENGTH_SHORT).show();
    }

    /**
     * Use to show loading dialog.
     */
    public boolean showProgressDialog(Context context) {

        if (!CheckNetworkState.isOnline(context)) {
            showToastMsg(context, context.getString(R.string.network_error));
            return false;
        } else {
            if (mProgressDialog == null) {
                mProgressDialog = new ProgressDialog(context);
            }
            if (!mProgressDialog.isShowing()) {
                mProgressDialog.setCancelable(false);
                mProgressDialog.setMessage(context.getResources().getString(R.string.please_wait));
                mProgressDialog.show();
                mProgressDialog.setCanceledOnTouchOutside(false);
                TextView textView = (TextView) mProgressDialog.findViewById(android.R.id.message);
                Typeface face = Typeface.createFromAsset(getAssets(), "roboto_regular.ttf");
                textView.setTypeface(face);
            }
            return true;
        }
    }

    /**
     * Use to hide loading dialog.
     */
    public void hideProgressDialog() {
        if (mProgressDialog != null && mProgressDialog.isShowing()) {
            mProgressDialog.dismiss();
        }
    }

    public void getMerchantReport(final String merchantId) {

        if (!CheckNetworkState.isOnline(this)) {
            showToastMsg(this, getString(R.string.network_error));
            return;
        }
        showProgressDialog(this);
        try {
            final LoginResponse.Users userDetail = Utils.readUserDetail(this);
            final Call<AbuseReportResponse> merchantReportRequest = ((TechquiqApplication) this.getApplicationContext())
                    .getService().getAbuseReport(
                            userDetail.getUserId(),
                            Utils.getDeviceId(this),
                            AppConstant.FCM_ID,
                            ApiParameter.DEVICE_TYPE_VALUE,
                            Integer.parseInt(merchantId)
                    );

            Log.e(TAG, "Request : " + merchantReportRequest.request().url());

            merchantReportRequest.enqueue(new Callback<AbuseReportResponse>() {

                @Override
                public void onResponse(Call<AbuseReportResponse> call, Response<AbuseReportResponse> response) {
                    hideProgressDialog();

                    if (response == null) {
                        return;
                    }
                    Log.e(TAG, "Response : " + new Gson().toJson(response.body()));
                    Log.e(TAG, response.toString());

                    AbuseReportResponse reportResponse = response.body();
                    if (reportResponse == null) {
                        showToastMsg(BaseActivity.this, getString(R.string.server_error));
                        return;
                    }
                    int responseStatusCode = reportResponse.getResponseStatusCode();
                    if (responseStatusCode == AppConstant.NO_DATA_FOUND) {
                        dialogReport(merchantId, reportMerchant);
                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        String report = null;
                        if (reportResponse.getResponseCode().equalsIgnoreCase("0")) {
                            dialogReport(merchantId, reportMerchant);
                        } else {
                            ArrayList<AbuseReportResponse.Report> reportData = reportResponse.getReportList();
                            for (int i = 0; i < reportData.size(); i++) {
                                report = reportData.get(i).getMessage();
                            }

                            reportMerchant = report;
                            if (reportMerchant != null && !reportMerchant.isEmpty()) {
                                dialogReport(merchantId, reportMerchant);
                            } else {
                                dialogReport(merchantId, reportMerchant);

                            }
                        }

                    } else {
                        showToastMsg(BaseActivity.this, reportResponse.getResponseMessage());
                    }


                }

                @Override
                public void onFailure(Call<AbuseReportResponse> call, Throwable t) {
                    hideProgressDialog();
                    showToastMsg(BaseActivity.this, t.getMessage());

                }
            });
        } catch (Exception e) {
            e.printStackTrace();

        }

    }

    private void dialogReport(final String merchantId, final String report) {
        final Dialog dialog = new Dialog(this, R.style.Theme_Dialog);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_report);
        dialog.setTitle("Title...");
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.show();

        TextView tvReportDone = (TextView) dialog.findViewById(R.id.tvReportDone);
        final EditText etReport = (EditText) dialog.findViewById(R.id.etReport);
        if (report != null && !report.isEmpty()) {
            etReport.setText(report.trim());
            etReport.setEnabled(false);
            tvReportDone.setEnabled(false);
            tvReportDone.setAlpha(0.5f);
        }

        tvReportDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doMerchantAbuseReport(merchantId, etReport.getText().toString().trim());
                dialog.dismiss();
            }
        });
    }

    private void doMerchantAbuseReport(String merchantId, String reportMsg) {
        if (!CheckNetworkState.isOnline(BaseActivity.this)) {
            showToastMsg(BaseActivity.this, getString(R.string.network_error));
            return;
        }
        showProgressDialog(BaseActivity.this);
        try {
            final LoginResponse.Users userDetail = Utils.readUserDetail(BaseActivity.this);
            final Call<ReportSuccessResponse> merchantAbuseReportRequest = ((TechquiqApplication) BaseActivity.this.getApplicationContext())
                    .getService().doAbuseReport(
                            userDetail.getUserId(),
                            Utils.getDeviceId(BaseActivity.this),
                            AppConstant.FCM_ID,
                            ApiParameter.DEVICE_TYPE_VALUE,
                            Integer.parseInt(merchantId),
                            reportMsg
                    );

            Log.e(TAG, "Request : " + merchantAbuseReportRequest.request().url());

            merchantAbuseReportRequest.enqueue(new Callback<ReportSuccessResponse>() {

                @Override
                public void onResponse(Call<ReportSuccessResponse> call, Response<ReportSuccessResponse> response) {
                    hideProgressDialog();

                    if (response == null) {
                        return;
                    }
                    Log.e(TAG, "Response : " + new Gson().toJson(response.body()));
                    Log.e(TAG, response.toString());

                    ReportSuccessResponse reportResponse = response.body();
                    if (reportResponse.getResponseCode().equalsIgnoreCase("0")) {
                        showToastMsg(BaseActivity.this, reportResponse.getResponseMessage());
                    } else {
                        showToastMsg(BaseActivity.this, getString(R.string.ws_review_success_msg));
                    }

                }

                @Override
                public void onFailure(Call<ReportSuccessResponse> call, Throwable t) {
                    hideProgressDialog();
                    showToastMsg(BaseActivity.this, t.getMessage());
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
