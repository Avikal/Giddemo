package com.cdn.techquiq.consumer.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.SharedPrefrence;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.activity.FilterActivity;
import com.cdn.techquiq.consumer.activity.MainActivity;
import com.cdn.techquiq.consumer.adapter.ProductAdapter;
import com.cdn.techquiq.consumer.database.DBHelper;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.ProductResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;
import com.google.gson.Gson;
import com.marshalchen.ultimaterecyclerview.UltimateRecyclerView;

import java.net.SocketTimeoutException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by akshaysoni on 3/2/17.
 */
public class ProductFragment extends BaseFragment {

    private String TAG = ProductFragment.class.getSimpleName();
    private UltimateRecyclerView recyclerView;
    private ProductAdapter productAdapter;

    private int limit;
    private int currentOffset;
    private int totalRecord;
    private String keyword;
    private TextView productCountTv, filterTv;
    private TextView noProductTv;
    private RelativeLayout relativeHeader;
    private ImageView ivFilter;

    private ArrayList<ProductResponse.ProductDetail> productDetails;

    private LinearLayoutManager linearLayoutManager;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_product, null);

        recyclerView = (UltimateRecyclerView) rootView.findViewById(R.id.productList);
        recyclerView.setHasFixedSize(false);
        productCountTv = (TextView) rootView.findViewById(R.id.productCountTv);
        filterTv = (TextView) rootView.findViewById(R.id.filterTv);
        ivFilter = (ImageView) rootView.findViewById(R.id.ivFilter);
        ivFilter.setOnClickListener(this);
        filterTv.setOnClickListener(this);
        relativeHeader = (RelativeLayout) rootView.findViewById(R.id.relative_header);
        noProductTv = (TextView) rootView.findViewById(R.id.text_no_product);
        linearLayoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(linearLayoutManager);

        recyclerView.setLoadMoreView(LayoutInflater.from(getActivity())
                .inflate(R.layout.custom_bottom_progressbar, null));


        setHasOptionsMenu(true);
        return rootView;
    }

    public void callWebService(String keyword) {
        productDetails = null;
        limit = AppConstant.PRODUCT_LIMIT;
        currentOffset = 0;
        totalRecord = 0;
        this.keyword = keyword;

        searchProduct(currentOffset, false, keyword);

        productLoadMore();
    }

    @Override
    public void onResume() {
        super.onResume();
        topAndBelowTab();
        checkFilterApplyOrNot();
    }

    private void checkFilterApplyOrNot() {
        if (DBHelper.getInstance(getActivity()).isFilerApplied()) {
            ivFilter.setImageResource(R.drawable.filter_hover_icon);
        } else {
            ivFilter.setImageResource(R.drawable.filter_icon);
        }
    }

    public void topAndBelowTab() {
        if (getActivity() != null) {
            ((MainActivity) getActivity()).hideBackBtn(true);
            ((MainActivity) getActivity()).hideCartButton(false);
            ((MainActivity) getActivity()).hideSearchButton(false);
            ((MainActivity) getActivity()).hideSettingButton(true);
            ((MainActivity) getActivity()).hideBelowTabBar(false);
        }
    }

    private void productLoadMore() {

        enableLoadMore();

        if (recyclerView != null) {
            recyclerView.setOnLoadMoreListener(new UltimateRecyclerView.OnLoadMoreListener() {
                @Override
                public void loadMore(int itemsCount, int maxLastVisiblePosition) {
                    try {
                        if (totalRecord <= productDetails.size()) {
                            recyclerView.disableLoadmore();
                        } else {
                            currentOffset = currentOffset + limit;
                            searchProduct(currentOffset, true, keyword);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    }

    public void enableLoadMore() {
        if (recyclerView != null) {
            recyclerView.reenableLoadmore();
        }
    }

    public void searchProduct(int offset, final boolean isLoadMore, String keyword) {
        try {
            if (!CheckNetworkState.isOnline(getActivity())) {
                if (!isLoadMore) {
                    showLableAndHideList(getString(R.string.network_error));
                } else {
                    showToastMsg(getActivity(), getActivity().getString(R.string.network_error));
                    recyclerView.disableLoadmore();
                    currentOffset = currentOffset - limit;
                    offset = currentOffset;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            enableLoadMore();
                        }
                    }, 4000);
                }
                return;

            }

            this.keyword = keyword;
            if (!isLoadMore) {
                if (!showProgressDialog(getActivity())) {
                    return;
                }
            }

            final LoginResponse.Users userDetail = Utils.readUserDetail(getActivity());

            final String filterJson = SharedPrefrence.getInstance(getActivity())
                    .readPrefs(SharedPrefrence.filterJson);

            Call<ProductResponse> myProductRequest = ((TechquiqApplication) getActivity().getApplicationContext())
                    .getService().doSearchProduct(userDetail.getUserId(),
                            Utils.getDeviceId(getActivity()),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            SharedPrefrence.getInstance(getContext()).readPrefs(SharedPrefrence.pushToken),
                            limit,
                            offset,
                            0,
                            keyword,
                            filterJson);

            Log.e(TAG, "Request : " + myProductRequest.request().url());

            myProductRequest.enqueue(new Callback<ProductResponse>() {
                @Override
                public void onResponse(Call<ProductResponse> call, Response<ProductResponse> response) {

                    if (!isLoadMore) {
                        hideProgressDialog();
                    }
                    if (response == null) {
                        showToastMsg(getContext(), getString(R.string.server_error));
                        return;
                    }
                    ProductResponse productResponse = response.body();
                    if (productResponse == null) {
                        setErrorMessage(getString(R.string.server_error));
                        ((MainActivity) getActivity()).hideSearchButton(true);
//                        searchProduct(currentOffset, false, "");
                        return;
                    }
                    Log.e(TAG, "Response : " + new Gson().toJson(productResponse));
                    int responseStatusCode = productResponse.getResponseStatusCode();

                    if (responseStatusCode == AppConstant.NO_DATA_FOUND) {
                        setErrorMessage(getString(R.string.ws_no_product_data_found));
                        ((MainActivity) getActivity()).hideSearchButton(true);
                    } else if (responseStatusCode == AppConstant.UNKNOWN_ERROR) {
                        setErrorMessage(getString(R.string.ws_unkonwn_error));
                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        totalRecord = productResponse.getTotalProduct();
                        if (productResponse.getResponseCode().equalsIgnoreCase("0")) {
                            if (!isLoadMore) {
                                setErrorMessage(getString(R.string.ws_no_product_data_found));
                                ((MainActivity) getActivity()).hideSearchButton(true);
                            } else {
                                showToastMsg(getActivity(), response.body().getResponseMessage());
                            }
                            return;
                        } else {
                            showListAndHideLable();
                        }
                        if (isLoadMore) {
                            if (productDetails != null) {
                                int offset = productDetails.size();
                                for (int i = 0; i < productResponse.getProductDetail().size(); i++) {
                                    productDetails.add(offset, productResponse.getProductDetail().get(i));
                                    offset++;
                                }
                                productAdapter.notifyDataSetChanged();
                            }
                        } else {
                            productDetails = productResponse.getProductDetail();
                            if (productDetails != null && productDetails.size() > 0) {
                                showListAndHideLable();
                                productAdapter = new ProductAdapter(getActivity(), productDetails);
                                recyclerView.setAdapter(productAdapter);
                                productCountTv.setText(totalRecord + " " + getResources().getString(R.string.products));
                            }
                        }
                    } else {
                        showToastMsg(getContext(), productResponse.getResponseMessage());
                    }
                }

                @Override
                public void onFailure(Call<ProductResponse> call, Throwable t) {
                    if (!isLoadMore) {
                        hideProgressDialog();
                    }
                    if (t instanceof SocketTimeoutException) {
                        showLableAndHideList(getString(R.string.connection_timeout));
                        return;
                    }
                    showLableAndHideList(getString(R.string.server_error));
                    Log.e(TAG, t.getMessage());
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showListAndHideLable() {
        productCountTv.setVisibility(View.VISIBLE);
        recyclerView.setVisibility(View.VISIBLE);
        noProductTv.setVisibility(View.GONE);
        relativeHeader.setVisibility(View.VISIBLE);
        ((MainActivity) getActivity()).hideSearchButton(false);
    }

    private void showLableAndHideList(String msg) {
        productCountTv.setVisibility(View.GONE);
        recyclerView.setVisibility(View.GONE);
        noProductTv.setVisibility(View.VISIBLE);
        relativeHeader.setVisibility(View.GONE);
        ((MainActivity) getActivity()).hideSearchButton(true);
        noProductTv.setText(msg);
    }

    private void setErrorMessage(String msg) {
        noProductTv.setVisibility(View.VISIBLE);
        noProductTv.setText(msg);
        recyclerView.setVisibility(View.GONE);
        productCountTv.setVisibility(View.VISIBLE);
        productCountTv.setText(0 + " " + getResources().getString(R.string.product));
//        productCountTv.setText(getString(R.string.total_product) + " : " + 0);
        relativeHeader.setVisibility(View.VISIBLE);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.ivFilter:
                if (CheckNetworkState.isOnline(getActivity())) {
                    Intent intent = new Intent(getActivity(), FilterActivity.class);
                    getActivity().startActivityForResult(intent, MainActivity.REQUEST_FOR_FILTER);
                } else {
                    showToastMsg(getActivity(), getString(R.string.network_error));
                }
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == MainActivity.REQUEST_FOR_FILTER && resultCode == getActivity().RESULT_OK) {
            callWebService(keyword);
        }

    }

}