package com.cdn.techquiq.consumer.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;

/**
 * Created by kajalsoni on 3/2/17.
 */

public class AboutUsActivity extends BaseActivity {

    private ImageView backIv;
    private TextView titleTv;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about_us_activity);

        backIv = (ImageView) findViewById(R.id.backIv);
        backIv.setOnClickListener(this);
        titleTv = (TextView) findViewById(R.id.titleTv);
        titleTv.setText(mContext.getResources().getString(R.string.txt_aboutUs_title));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.backIv:
                finish();
                break;

        }
    }


}
