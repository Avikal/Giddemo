package com.cdn.techquiq.consumer.adapter;

/**
 * Created by kajalsoni on 31/1/17.
 */

import android.content.Context;
import android.graphics.Bitmap;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.BitmapImageViewTarget;
import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.SliderBean;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class SliderAdapter extends RecyclerView.Adapter<SliderAdapter.DataObjectHolder> {

    private List<SliderBean> sliderBeanArrayList;
    private Context mContext;
    private LoginResponse.Users userDetail;

    private class VIEW_TYPES {
        public static final int Header = 1;
        public static final int Normal = 2;
        public static final int Footer = 3;
    }

    public static class DataObjectHolder extends RecyclerView.ViewHolder {

        TextView sliderItemTv;
        TextView nameTV;
        CircleImageView profilePic;
        ImageView ivSlide;
        LinearLayout linear_slider;

        public DataObjectHolder(View itemView) {
            super(itemView);
            sliderItemTv = (TextView) itemView.findViewById(R.id.sliderItemTv);
            nameTV = (TextView) itemView.findViewById(R.id.nameTV);
            profilePic = (CircleImageView) itemView.findViewById(R.id.profilePic);
            ivSlide = (ImageView) itemView.findViewById(R.id.ivSlide);
            linear_slider = (LinearLayout) itemView.findViewById(R.id.linear_slider);

        }
    }

    public SliderAdapter(Context context, ArrayList<SliderBean> sliderBeanArrayList) {
        this.mContext = context;
        this.sliderBeanArrayList = sliderBeanArrayList;

        userDetail = Utils.readUserDetail(mContext);
    }


    @Override
    public DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;

        switch (viewType) {
            case VIEW_TYPES.Normal:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.slider_item, parent, false);
                break;
            case VIEW_TYPES.Header:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.slider_header, parent, false);
                break;
            case VIEW_TYPES.Footer:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.slider_footer, parent, false);
                break;
            default:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.slider_item, parent, false);
                break;
        }
        return new DataObjectHolder(view);


    }

    @Override
    public void onBindViewHolder(final DataObjectHolder holder, final int position) {
        if (getItemViewType(position) == VIEW_TYPES.Normal) {

            final int pos = position - 1;
            holder.ivSlide.setImageDrawable(sliderBeanArrayList.get(pos).getImage());
            holder.sliderItemTv.setText(sliderBeanArrayList.get(pos).getName());
//            holder.sliderItemTv.setCompoundDrawablesWithIntrinsicBounds(sliderBeanArrayList.get(pos).getImage(),
//                    null, null, null);

        } else if (getItemViewType(position) == VIEW_TYPES.Header) {

            holder.nameTV.setText(userDetail.getFirst_name() + " " + userDetail.getLast_name());
            if (userDetail.getImage() == null || userDetail.getImage().equalsIgnoreCase("")) {
                Glide.with(mContext).load(userDetail.getImage()).asBitmap().centerCrop()
                        .error(R.drawable.profile_img)
                        .placeholder(R.drawable.profile_img)
                        .into(holder.profilePic);
            } else {
                Glide.with(mContext).load(userDetail.getImage()).asBitmap().centerCrop()
                        .error(R.drawable.profile_img)
                        .placeholder(R.drawable.profile_img)
                        .into(new BitmapImageViewTarget(holder.profilePic) {
                            @Override
                            protected void setResource(Bitmap resource) {
                                RoundedBitmapDrawable circularBitmapDrawable =
                                        RoundedBitmapDrawableFactory.create(mContext.getResources(), resource);
                                circularBitmapDrawable.setCircular(true);
                                holder.profilePic.setImageDrawable(circularBitmapDrawable);
                            }
                        });
            }
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (position == 0) {
            return VIEW_TYPES.Header;
        } else if (sliderBeanArrayList.size() == position - 1) {
            return VIEW_TYPES.Footer;
        } else {
            return VIEW_TYPES.Normal;
        }
    }


    @Override
    public int getItemCount() {
        return sliderBeanArrayList.size() + 2;
    }
}
