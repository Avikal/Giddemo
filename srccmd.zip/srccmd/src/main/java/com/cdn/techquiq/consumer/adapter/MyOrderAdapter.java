
package com.cdn.techquiq.consumer.adapter;

/**
 * Created by akshaysoni on 31/1/17.
 */

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.activity.MainActivity;
import com.cdn.techquiq.consumer.activity.OrderDetailActivity;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.OrderHistoryResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;
import com.google.gson.Gson;
import com.marshalchen.ultimaterecyclerview.UltimateRecyclerviewViewHolder;
import com.marshalchen.ultimaterecyclerview.UltimateViewAdapter;

import java.net.SocketTimeoutException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MyOrderAdapter extends UltimateViewAdapter {

    private String TAG = MyOrderAdapter.class.getSimpleName();
    private ArrayList<OrderHistoryResponse.OrderList> orderList;
    private Context mContext;
    private LayoutInflater mLayoutInflater;

    public MyOrderAdapter(Context context, ArrayList<OrderHistoryResponse.OrderList> orderLists) {
        this.mContext = context;
        this.orderList = orderLists;
    }

    @Override
    public int getAdapterItemCount() {
        return orderList.size();
    }

    @Override
    public RecyclerView.ViewHolder newFooterHolder(View view) {
        return new UltimateRecyclerviewViewHolder<>(view);
    }

    @Override
    public RecyclerView.ViewHolder newHeaderHolder(View view) {
        return new UltimateRecyclerviewViewHolder<>(view);
    }

    @Override
    public UltimateRecyclerviewViewHolder onCreateViewHolder(ViewGroup parent) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.my_order_list_item, parent, false);
        ViewHolderOrder vh = new ViewHolderOrder(v);
        return vh;
    }

    public void insert(String string, int position) {
        insertInternal(orderList, string, position);
    }

    public void remove(int position) {
        removeInternal(orderList, position);
    }

    public void clear() {
        clearInternal(orderList);
    }


    public void swapPositions(int from, int to) {
        swapPositions(orderList, from, to);
    }

    @Override
    public long generateHeaderId(int position) {
        // URLogs.d("position--" + position + "   " + getItem(position));
        if (getItem(position).length() > 0)
            return getItem(position).charAt(0);
        else return -1;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        if (orderList.size() == position) {
            Log.e("RETURN POSITION", "" + position);
            return;
        }

        if (position < getItemCount() && (customHeaderView != null ? position <= orderList.size() : position < orderList.size()) && (customHeaderView != null ? position > 0 : true)) {
            String str = "";
            for (int i = 0; i < orderList.get(position).getOrderDetail().size(); i++) {
                if (i == 0) {
                    str = orderList.get(position).getOrderDetail().get(i).getProductName();
                } else {
                    str = str + ", " + orderList.get(position).getOrderDetail().get(i).getProductName();
                }
            }

            /**
             * set name and text from the here.
             * <p>
             * Show image from the below code
             */
            ((ViewHolderOrder) holder).nameTv.setText(str);
            ((ViewHolderOrder) holder).totalAmountTv.setText(AppConstant.CURRENCY_SYMBOL + " " + orderList.get(position).getTotalAmount());

            /**
             * Show image from the below code
             */
            String imageUrl = "";
            try {
                for (int i = 0; i < orderList.get(position).getOrderDetail().size(); i++) {
                    if (orderList.get(position).getOrderDetail().get(i).getProductImages().size() > 0) {
                        imageUrl = orderList.get(position).getOrderDetail().get(i).getProductImages().get(0).getImage();
                        if (imageUrl != null && !imageUrl.isEmpty()) {
                            break;
                        }
                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            Glide.with(mContext).load(imageUrl)
                    .crossFade()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .placeholder(R.drawable.placeholder_1)
                    .into(((ViewHolderOrder) holder).productImg);

            ((ViewHolderOrder) holder).myOrderContainer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    getOrderDetail(orderList.get(position).getId());
                }
            });
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateHeaderViewHolder(ViewGroup parent) {
        return null;
    }

    @Override
    public void onBindHeaderViewHolder(RecyclerView.ViewHolder holder, final int position) {
    }

    @Override
    public void onItemMove(int fromPosition, int toPosition) {
        if (fromPosition > 0 && toPosition > 0) {
            swapPositions(fromPosition, toPosition);
            super.onItemMove(fromPosition, toPosition);
        }
    }

    @Override
    public void onItemDismiss(int position) {
        if (position > 0) {
            remove(position);
            notifyDataSetChanged();
            super.onItemDismiss(position);
        }

    }

    public void setOnDragStartListener(OnStartDragListener dragStartListener) {
        mDragStartListener = dragStartListener;

    }

    class ViewHolderOrder extends UltimateRecyclerviewViewHolder {
        public TextView nameTv, totalAmountTv;
        public ImageView productImg;
        public LinearLayout myOrderContainer;

        public ViewHolderOrder(View view) {
            super(view);
            nameTv = (TextView) view.findViewById(R.id.nameTv);
            totalAmountTv = (TextView) view.findViewById(R.id.totalAmountTv);
            productImg = (ImageView) view.findViewById(R.id.productImg);
            myOrderContainer = (LinearLayout) view.findViewById(R.id.myOrderContainer);
        }

        @Override
        public void onItemSelected() {
            itemView.setBackgroundColor(Color.LTGRAY);
        }

        @Override
        public void onItemClear() {
            itemView.setBackgroundColor(0);
        }
    }


    public String getItem(int position) {
        if (customHeaderView != null)
            position--;

        if (position >= 0 && position < orderList.size())
            return String.valueOf(orderList.get(position));
        else return "";
    }

    private void getOrderDetail(String orderId) {
        try {

            if (!CheckNetworkState.isOnline(mContext)) {
                ((MainActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.network_error));
                return;
            }

            if (!((MainActivity) mContext).showProgressDialog(mContext)) {
                return;
            }

            final LoginResponse.Users userDetail = Utils.readUserDetail(mContext);
            final Call<OrderHistoryResponse> orderHistoryRequest = ((TechquiqApplication) mContext.getApplicationContext())
                    .getService().orderHistory(userDetail.getUserId(),
                            Utils.getDeviceId(mContext),
                            AppConstant.FCM_ID,
                            ApiParameter.DEVICE_TYPE_VALUE,
                            orderId,
                            null, 0, 0);//orderId for get the order detail

            Log.e(TAG, "Request : " + orderHistoryRequest.request().url());

            orderHistoryRequest.enqueue(new Callback<OrderHistoryResponse>() {
                @Override
                public void onResponse(Call<OrderHistoryResponse> call, Response<OrderHistoryResponse> response) {
                    Log.e(TAG, "Response : " + new Gson().toJson(response.body()));
                    ((MainActivity) mContext).hideProgressDialog();

                    OrderHistoryResponse orderHistoryResponse = response.body();

                    if (orderHistoryResponse.getResponseCode().equalsIgnoreCase("0")) {
                        ((MainActivity) mContext).showToastMsg(mContext, orderHistoryResponse.getResponseMessage());
                    } else if (orderHistoryResponse.getOrderLists() != null && orderHistoryResponse.getOrderLists().size() > 0) {
                        Intent intent = new Intent(mContext, OrderDetailActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("orderList", orderHistoryResponse.getOrderLists().get(0));
                        intent.putExtras(bundle);
                        mContext.startActivity(intent);
                    }

                }

                @Override
                public void onFailure(Call<OrderHistoryResponse> call, Throwable t) {
                    ((MainActivity) mContext).hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        ((MainActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.connection_timeout));
                        return;
                    }
                    ((MainActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.server_error));
                    Log.e(TAG, "Error : " + t.getMessage());
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

