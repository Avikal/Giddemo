package com.cdn.techquiq.consumer.model;

import com.cdn.techquiq.consumer.Utils.Utils;
import com.google.gson.annotations.SerializedName;

/**
 * Created by avikaljain on 13/6/17.
 */

public class NotificationResponse extends BaseResponse {

    @SerializedName("Result")
    private StatusResult result;

    public StatusResult getResult() {
        return result;
    }

    public void setResult(StatusResult result) {
        this.result = result;
    }

    public class StatusResult {
        @SerializedName("pushnotification_status")
        private String notificationStatus;

        public String getNotificationStatus() {
            return notificationStatus;
        }

        public void setNotificationStatus(String notificationStatus) {
            this.notificationStatus = notificationStatus;
        }
    }


    @SerializedName("notification_id")
    private String notificationId;

    public String getNotificationId() {
        return notificationId;
    }

    public void setNotificationId(String notificationId) {
        this.notificationId = notificationId;
    }

    @SerializedName("message")
    private String messageEn;

    public String getMessageEn() {
        return messageEn;
    }

    public void setMessageEn(String messageEn) {
        this.messageEn = messageEn;
    }

    @SerializedName("message_ar")
    private String messageAr;

    public String getMessageAr() {
        return messageAr;
    }

    public void setMessageAr(String messageAr) {
        this.messageAr = messageAr;
    }

    @SerializedName("notification_name")
    private String notificationNameEn;

    public String getNotificationNameEn() {
        return notificationNameEn;
    }

    public void setNotificationNameEn(String notificationNameEn) {
        this.notificationNameEn = notificationNameEn;
    }

    @SerializedName("notification_name_ar")
    private String notificationNameAr;

    public String getNotificationNameAr() {
        return notificationNameAr;
    }

    public void setNotificationNameAr(String notificationNameAr) {
        this.notificationNameAr = notificationNameAr;
    }


    public String getDescription() {
        if (Utils.getLocale().equalsIgnoreCase("ar")) {
            return getMessageAr();
        } else {
            return getMessageEn();
        }
    }

    public String getName() {
        if (Utils.getLocale().equalsIgnoreCase("ar")) {
            return getNotificationNameAr();
        } else {
            return getNotificationNameEn();
        }
    }
}
