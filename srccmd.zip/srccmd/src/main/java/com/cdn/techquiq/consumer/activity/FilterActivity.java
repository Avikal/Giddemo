package com.cdn.techquiq.consumer.activity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.SerializationUtils;
import com.cdn.techquiq.consumer.Utils.SharedPrefrence;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.adapter.FilterListAdapter;
import com.cdn.techquiq.consumer.database.DBHelper;
import com.cdn.techquiq.consumer.database.Filter;
import com.cdn.techquiq.consumer.model.FilterResponse;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.google.gson.Gson;

import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FilterActivity extends BaseActivity {

    private String TAG = FilterActivity.class.getSimpleName();

    private TextView titleTv;
    private ImageView backIv, submitIv;
    private TextView applyTv;
    private TextView clearTv;
    private boolean isChange;

    /**
     * For List
     */
    FilterListAdapter listAdapter;
    ExpandableListView expListView;
    List<FilterResponse.FilterResult> listDataHeader;
    HashMap<FilterResponse.FilterResult, List<FilterResponse.FilterResult.Items>> listDataChild;
    private DBHelper dbHelper;
    private FilterResponse filterResponse;
    private ArrayList<Filter> selectedFilterLocalList;

    @Nullable
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.filter_layout);

        titleTv = (TextView) findViewById(R.id.titleTv);
        titleTv.setText(getString(R.string.filter));
        backIv = (ImageView) findViewById(R.id.backIv);
        applyTv = (TextView) findViewById(R.id.text_apply);
        applyTv.setOnClickListener(this);
        clearTv = (TextView) findViewById(R.id.text_clear);
        clearTv.setOnClickListener(this);
        backIv.setOnClickListener(this);
        submitIv = (ImageView) findViewById(R.id.submitIv);
        submitIv.setOnClickListener(this);
        submitIv.setVisibility(View.GONE);
        dbHelper = DBHelper.getInstance(this);
        selectedFilterLocalList = new ArrayList<>();

        init();

        getFilter();

    }

    private void init() {
        expListView = (ExpandableListView) findViewById(R.id.filterExList);

        expListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView expandableListView,
                                        View view, int i, int i1, long l) {

                LinearLayout linearLayout = (LinearLayout) view.findViewById(R.id.lblListItem);
                ImageView ivCheckBox = (ImageView) view.findViewById(R.id.ivCheckBox);
                boolean selected = !((FilterResponse.FilterResult.Items) listAdapter.getChild(i, i1)).isSelected();
                ((FilterResponse.FilterResult.Items) listAdapter.getChild(i, i1)).setSelected(selected);
                if (((FilterResponse.FilterResult.Items) listAdapter.getChild(i, i1)).isSelected()) {
                    Drawable img = getResources().getDrawable(R.drawable.fill_check_box);
                    ivCheckBox.setImageDrawable(img);
//                    textView.setCompoundDrawablesWithIntrinsicBounds(img, null, null, null);
                } else {
                    Drawable img = getResources().getDrawable(R.drawable.blank_check_box);
                    ivCheckBox.setImageDrawable(img);
//                    textView.setCompoundDrawablesWithIntrinsicBounds(img, null, null, null);
                }

                /**
                 * Add filter in local list
                 */
                int filterId = ((FilterResponse.FilterResult) listAdapter.getGroup(i)).getFilter_id();
                int itemId = ((FilterResponse.FilterResult.Items) listAdapter.getChild(i, i1)).getId();
                Filter filter = new Filter();
                filter.setFilterId(filterId);
                filter.setItemId(itemId);
                filter.setSelected(selected);
                filter.setFilterItemId(filterId + "_" + itemId);
                if (selectedFilterLocalList.contains(filter)) {
                    selectedFilterLocalList.remove(filter);
                }
                selectedFilterLocalList.add(filter);
                return false;
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.backIv:
                onBackPressed();
                break;

            case R.id.text_apply:
                isChange = true;
                for (int i = 0; i < selectedFilterLocalList.size(); i++) {
                    dbHelper.insertProductFiler(selectedFilterLocalList.get(i).getFilterId(),
                            selectedFilterLocalList.get(i).getItemId(),
                            selectedFilterLocalList.get(i).isSelected());
                }
                generateJsonForServer();
                onBackPressed();
                break;

            case R.id.text_clear:
                try {
                    isChange = true;
                    selectedFilterLocalList.clear();
                    dbHelper.clearAllProductFilter();
                    prepareListData(filterResponse.getResult());
                    generateJsonForServer();
                    showToastMsg(mContext, "Clear all the filter");
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
        }
    }

    @Override
    public void onBackPressed() {
        Intent intent = this.getIntent();
        if (isChange) {
            this.setResult(RESULT_OK, intent);
        } else {
            this.setResult(RESULT_CANCELED, intent);
        }
        finish();
    }

    private void getFilter() {
        try {
            if (!showProgressDialog(this)) {
                return;
            }

            final LoginResponse.Users userDetail = Utils.readUserDetail(mContext);
            final Call<FilterResponse> filterRequest = ((TechquiqApplication) mContext.getApplicationContext())
                    .getService().getFilter(userDetail.getUserId(),
                            Utils.getDeviceId(mContext),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID);

            Log.e(TAG, "Request : " + filterRequest.request().url());
            filterRequest.enqueue(new Callback<FilterResponse>() {
                @Override
                public void onResponse(Call<FilterResponse> call, Response<FilterResponse> response) {
                    hideProgressDialog();
                    Log.e(TAG, "Response : " + new Gson().toJson(response.body()));
                    if (response == null) {
                        showToastMsg(mContext, getString(R.string.server_error));
                        return;
                    }
                    filterResponse = response.body();
                    if (filterResponse == null) {
                        showToastMsg(mContext, getString(R.string.server_error));
                        return;
                    }
                    if (response.code() == 0) {
                        showToastMsg(mContext, response.message());
                        return;
                    }

                    prepareListData(filterResponse.getResult());
                }

                @Override
                public void onFailure(Call<FilterResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void prepareListData(ArrayList<FilterResponse.FilterResult> filterResponses) {

        /**
         * first false the active state for the filter item
         */
        List<Filter> selectedFilter = dbHelper.getSelectedFilterId();
        for (int m = 0; m < selectedFilter.size(); m++) {
            dbHelper.updateFilterActiveStatus(selectedFilter.get(m).getFilterId(),
                    selectedFilter.get(m).getItemId(), false);
        }

        /**
         * Update selected value in model as per the database
         */
        if (selectedFilter != null && filterResponses != null && filterResponses.size() > 0) {
            for (int i = 0; i < filterResponses.size(); i++) {
                ArrayList<FilterResponse.FilterResult.Items> itemses = filterResponses.get(i).getItems();
                for (int j = 0; j < itemses.size(); j++) {
                    int filterId = filterResponses.get(i).getFilter_id();
                    int itemId = itemses.get(j).getId();

                    filterResponses.get(i).getItems().get(j).setSelected(false);
                    for (int k = 0; k < selectedFilter.size(); k++) {
                        int sFilterId = selectedFilter.get(k).getFilterId();
                        int sItemId = selectedFilter.get(k).getItemId();
                        boolean isSelected = selectedFilter.get(k).isSelected();

                        if (filterId == sFilterId && itemId == sItemId && isSelected) {
                            filterResponses.get(i).getItems().get(j).setSelected(true);

                            /**
                             * If item is already present in db and response also
                             * then true the active state of filter item
                             */
                            dbHelper.updateFilterActiveStatus(sFilterId, itemId, true);
                            break;
                        }
                    }
                }
            }
        }

        /**
         * Remove deactivated state from the database.
         */
        int deactivatedFilerSize = dbHelper.getDeactivatedFilterItem();
        if (deactivatedFilerSize > 0) {
            isChange = true;
            dbHelper.removeDeactivatedFilterItem();
            generateJsonForServer();
        }


        /**
         * prepare list for header and footer.
         */
        listDataHeader = new ArrayList<>();
        listDataChild = new HashMap<FilterResponse.FilterResult, List<FilterResponse.FilterResult.Items>>();
        if (filterResponses != null && filterResponses.size() > 0) {
            for (int i = 0; i < filterResponses.size(); i++) {
                listDataHeader.add(filterResponses.get(i));
                ArrayList<FilterResponse.FilterResult.Items> itemses = filterResponses.get(i).getItems();
                for (int j = 0; j < itemses.size(); j++) {
                    listDataChild.put(listDataHeader.get(i), itemses);
                }
            }
        }

        setAdapter();
    }


    private void setAdapter() {
        if (listAdapter == null) {
            listAdapter = new FilterListAdapter(expListView, FilterActivity.this, listDataHeader, listDataChild);
            expListView.setAdapter(listAdapter);
        } else {
            listAdapter.notifyData();
        }
    }

    private void generateJsonForServer() {

        ArrayList<FilterResponse.FilterResult> key = filterResponse.getResult();

        ArrayList<FilterResponse.FilterResult> filterList = new ArrayList<>();
        for (int i = 0; i < key.size(); i++) {
            FilterResponse.FilterResult filterResult = filterResponse.new FilterResult();

            filterResult.setFilter_id(key.get(i).getFilter_id());
            filterResult.setFilter_name_ar(key.get(i).getFilter_name_ar());
            filterResult.setFilter_name_en(key.get(i).getFilter_name_en());

            ArrayList<FilterResponse.FilterResult.Items> itemses = key.get(i).getItems();

            ArrayList<FilterResponse.FilterResult.Items> newitems = new ArrayList<>();

            for (int j = 0; j < itemses.size(); j++) {
                if (itemses.get(j).isSelected()) {
                    FilterResponse.FilterResult.Items items = filterResult.new Items();
                    items.setId(itemses.get(j).getId());
                    items.setSelected(itemses.get(j).isSelected());
                    items.setName_en(itemses.get(j).getName_en());
                    items.setName_ar(itemses.get(j).getName_ar());
                    newitems.add(items);
                }
            }

            filterResult.setItems(newitems);
            filterList.add(filterResult);
        }

        FilterResponse newFilterResponse = SerializationUtils.cloneObject(filterResponse);
        newFilterResponse.setResult(filterList);
        Gson gson = new Gson();
        String json = gson.toJson(newFilterResponse.getResult());
        Log.e(TAG, json);
        SharedPrefrence.getInstance(this).writePrefs(SharedPrefrence.filterJson, json);
    }
}
