package com.cdn.techquiq.consumer.model;

import java.util.ArrayList;

/**
 * Created by kajalsoni on 30/1/17.
 */

public class CityResponse extends BaseResponse {


    ArrayList<City> Result;

    public ArrayList<City> getResult() {
        return Result;
    }

    public void setResult(ArrayList<City> result) {
        Result = result;
    }


    public class City {

        String city_id, city_name;

        public String getCity_id() {
            return city_id;
        }

        public void setCity_id(String city_id) {
            this.city_id = city_id;
        }

        public String getCity_name() {
            return city_name;
        }

        public void setCity_name(String city_name) {
            this.city_name = city_name;
        }
    }
}
