package com.cdn.techquiq.consumer.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by kajalsoni on 6/2/17.
 */
public class ValidateCartResponse extends BaseResponse {

    public CartDetail getCartDetail() {
        return cartDetail;
    }

    public void setCartDetail(CartDetail cartDetail) {
        this.cartDetail = cartDetail;
    }

    @SerializedName("Result")
    private CartDetail cartDetail;

    public class CartDetail {


    }
}
