package com.cdn.techquiq.consumer.adapter;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.BitmapImageViewTarget;
import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.activity.BaseActivity;
import com.cdn.techquiq.consumer.activity.ChatActivity;
import com.cdn.techquiq.consumer.activity.ReviewListActivity;
import com.cdn.techquiq.consumer.model.ServiceResponse;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by avikaljain on 5/4/17.
 */

public class OpenDetailAdapter extends RecyclerView.Adapter<OpenDetailAdapter.MyViewHolder> {

    private String TAG = OpenDetailAdapter.class.getSimpleName();

    private List<ServiceResponse.ServiceDetail> openDetails;
    private ArrayList<ServiceResponse.ServiceDetail.ServiceProposalData> proposalData;
    private Context mContext;
    private LayoutInflater mLayoutInflater;

    public String serviceId;
    public String merchantId;
    public String merchantName;
    public String merchantCompany;
    public String merchantPhone;
    public String merchantAddress;
    public String merchantEmail;
    public String merchantImage;
    public float merchantRating;

    private EditText etReport;
    private TextView tvReportDone;


    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView tVName, tVPrice;
        public ImageView iVProfile;
        public View mparent;
        public LinearLayout oDContainer;
        public ImageView iVForwardArrow;

        public MyViewHolder(View view) {
            super(view);
            mparent = view;
            tVName = (TextView) view.findViewById(R.id.tVName);
            iVProfile = (ImageView) view.findViewById(R.id.iVProfile);
            tVPrice = (TextView) view.findViewById(R.id.tVPrice);
            oDContainer = (LinearLayout) view.findViewById(R.id.mainContainer);
            iVForwardArrow = (ImageView) view.findViewById(R.id.iVForwardArrow);
        }
    }

    public OpenDetailAdapter(Context context, ArrayList<ServiceResponse.ServiceDetail> openDetails, ArrayList<ServiceResponse.ServiceDetail.ServiceProposalData> proposalData) {
        this.mContext = context;
        this.openDetails = openDetails;
        this.proposalData = proposalData;
        mLayoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public OpenDetailAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mLayoutInflater
                .inflate(R.layout.open_detail_list_item, parent, false);
        return new OpenDetailAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final OpenDetailAdapter.MyViewHolder holder, final int position) {
        final ServiceResponse.ServiceDetail openDetail = openDetails.get(0);

        final ArrayList<ServiceResponse.ServiceDetail.ServiceProposalData> proposalDetail = openDetail.getServiceProposal();
        if (proposalDetail.size() > 0) {
            holder.oDContainer.setVisibility(View.VISIBLE);
            merchantInfo(position);

            holder.tVName.setText(merchantName);
            holder.tVPrice.setText(AppConstant.CURRENCY_SYMBOL + " " + proposalDetail.get(position).getService_price());
            serviceId = openDetail.getId();
            Glide.with(mContext).load(proposalDetail.get(position).getImage()).asBitmap().centerCrop()
                    .placeholder(R.drawable.profile_img)
                    .error(R.drawable.profile_img)
                    .into(new BitmapImageViewTarget(holder.iVProfile) {
                        @Override
                        protected void setResource(Bitmap resource) {
                            RoundedBitmapDrawable circularBitmapDrawable =
                                    RoundedBitmapDrawableFactory.create(mContext.getResources(), resource);
                            circularBitmapDrawable.setCircular(true);
                            holder.iVProfile.setImageDrawable(circularBitmapDrawable);
                        }
                    });

            holder.iVForwardArrow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    merchantInfo(position);
                    Intent intent = new Intent(mContext, ChatActivity.class);
                    intent.putExtra("merchantId", merchantId);
                    intent.putExtra("serviceId", openDetail.getId());
                    intent.putExtra("merchantName", merchantName);
                    intent.putExtra("merchantImage", merchantImage);
                    intent.putExtra("awardStatus", openDetail.getAwardStatus());
                    intent.putExtra("title", URLDecoder.decode(openDetail.getName()));
                    intent.putExtra("totalAmount", proposalDetail.get(position).getService_price());
                    intent.putExtra("bidId", proposalDetail.get(position).getBidId());
                    mContext.startActivity(intent);
                }
            });
            holder.tVName.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ratingDialog(position);

                }
            });

            holder.iVProfile.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ratingDialog(position);
                }
            });

        } else {
            holder.oDContainer.setVisibility(View.GONE);
        }


    }

    private void ratingDialog(int position) {
        // custom dialog
        final Dialog dialog = new Dialog(mContext, R.style.Theme_Dialog);
        //RatingBar ratingBar;
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_rating);
        dialog.setTitle("Title...");
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.show();
        // set the custom dialog components - text, image and button
        final CircleImageView ivMerchantImage = (CircleImageView) dialog.findViewById(R.id.ivMerchantImage);
        RatingBar ratingBar = (RatingBar) dialog.findViewById(R.id.ratingBar);
        TextView tvEmail = (TextView) dialog.findViewById(R.id.tvEmail);
        TextView tvMerchantName = (TextView) dialog.findViewById(R.id.tvMerchantName);
        TextView tvPhone = (TextView) dialog.findViewById(R.id.tvPhone);
        TextView tvAddress = (TextView) dialog.findViewById(R.id.tvAddress);
        TextView tvCompanyName = (TextView) dialog.findViewById(R.id.tvCompanyName);
        TextView tvReportAbuse = (TextView) dialog.findViewById(R.id.tvReportAbuse);
        tvMerchantName.setVisibility(View.VISIBLE);
        merchantInfo(position);
        ratingBar.setIsIndicator(false);
        ratingBar.setEnabled(false);
        ratingBar.setRating(merchantRating);
        tvEmail.setText(merchantEmail);
        tvMerchantName.setText(merchantName);
        tvPhone.setText(merchantPhone);
        tvAddress.setText(merchantAddress);
        tvCompanyName.setText(merchantCompany);
        TextView tvReadReview = (TextView) dialog.findViewById(R.id.tvReadReview);
        Glide.with(mContext).load(merchantImage).asBitmap().centerCrop()
                .placeholder(R.drawable.profile_img)
                .error(R.drawable.profile_img)
                .override(100, 100)
                .into(ivMerchantImage);


        tvReadReview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (merchantId != null) {
                    /**
                     * rating on merchant
                     */
                    Intent intent = new Intent(mContext, ReviewListActivity.class);
                    intent.putExtra("merchantId", Integer.parseInt(merchantId));
                    mContext.startActivity(intent);
                    dialog.dismiss();
                }
            }
        });

        tvReportAbuse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((BaseActivity) mContext).getMerchantReport(merchantId);
                dialog.dismiss();
            }
        });

    }


    public void merchantInfo(int position) {
        if (proposalData != null && proposalData.size() > 0) {
            merchantId = proposalData.get(position).getUser_id();
            merchantName = proposalData.get(position).getFirst_name() + " " + proposalData.get(position).getLast_name();
            merchantCompany = proposalData.get(position).getMerchantCompany();
            merchantPhone = proposalData.get(position).getMerchantPhone();
            merchantAddress = proposalData.get(position).getAddress();
            merchantEmail = proposalData.get(position).getEmail();
            merchantRating = proposalData.get(position).getAverageRating();
            merchantImage = proposalData.get(position).getImage();
        }
    }

    @Override
    public int getItemCount() {
        return proposalData.size();
    }
}
