package com.cdn.techquiq.consumer.activity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.adapter.ServiceViewAdapter;
import com.cdn.techquiq.consumer.model.BaseResponse;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.RatingResponse;
import com.cdn.techquiq.consumer.model.ServiceImage;
import com.cdn.techquiq.consumer.model.ServiceResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;
import com.google.gson.Gson;

import java.net.SocketTimeoutException;
import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by avikaljain on 6/5/17.
 */

public class AwardDetailActivity extends BaseActivity {

    private String TAG = AwardDetailActivity.class.getSimpleName();
    private ArrayList<ServiceResponse.ServiceDetail> proposalDetail = new ArrayList<>();

    private ImageView backIv;
    private TextView titleTv;

    private TextView tVAwardTitle;
    private TextView tVCategories;
    private TextView tVComplainDes;
    private TextView tvAwardDate;

    private TextView tvMsgAward;

    private TextView tVAwardPrice;
    private float awardedPrice;
    private TextView tVPayNow, paidStatusTv, marKDeliverTv;
    private TextView tVAwardName;
    private TextView tvAwardReview;
    private TextView tVStatusDes;

    private String serviceId;
    private String orderId;
    private Bundle bundle;

    private RecyclerView awardList;
    private ServiceViewAdapter serviceAdapter;

    private String merchantId;
    private String merchantName;
    private String merchantImage;
    private String awardStatus;

    private float userRating;
    public String review;

    public TextView tvPaymentND;
    public LinearLayout awardDetailContainer;
    public LinearLayout mainLayout;

    private String merchantEmail;
    private String merchantPhone;
    private String merchantCompany;
    private String merchantAddress;
    private float merchantRating;

    private String title, subject, description;

    private EditText etReport;
    private TextView tvReportDone;


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_award_detail);

        bundle = getIntent().getExtras();

        if (bundle != null) {
            serviceId = bundle.getString("id");
        }
        setUpUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        serviceAwardDetail();
    }

    private void setUpUi() {
        titleTv = (TextView) findViewById(R.id.titleTv);
        tVAwardTitle = (TextView) findViewById(R.id.tVAwardTitle);
        tVCategories = (TextView) findViewById(R.id.tVCategories);
        tVComplainDes = (TextView) findViewById(R.id.tVComplainDes);
        tvAwardDate = (TextView) findViewById(R.id.tvAwardDate);
        tvPaymentND = (TextView) findViewById(R.id.tvPaymentND);
        tVAwardPrice = (TextView) findViewById(R.id.tVAwardPrice);
        tVPayNow = (TextView) findViewById(R.id.tVPayNow);
        paidStatusTv = (TextView) findViewById(R.id.paidStatusTv);
        tVAwardName = (TextView) findViewById(R.id.tVAwardName);
        tvAwardReview = (TextView) findViewById(R.id.tvAwardReview);
        tVStatusDes = (TextView) findViewById(R.id.tVStatusDes);
        awardDetailContainer = (LinearLayout) findViewById(R.id.awardDetailContainer);
        mainLayout = (LinearLayout) findViewById(R.id.mainLayout);
        tvMsgAward = (TextView) findViewById(R.id.tvMsgAward);
        marKDeliverTv = (TextView) findViewById(R.id.marKDeliverTv);
        awardList = (RecyclerView) findViewById(R.id.awardList);
        backIv = (ImageView) findViewById(R.id.backIv);

        backIv.setOnClickListener(this);
        tVPayNow.setOnClickListener(this);
        tvMsgAward.setOnClickListener(this);
        tvAwardReview.setOnClickListener(this);
        tVAwardName.setOnClickListener(this);
        marKDeliverTv.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.backIv:
                finish();
                break;

            case R.id.tVPayNow:
                Intent payIntent = new Intent(AwardDetailActivity.this, ChoosePaymentOptionActivity.class);
                payIntent.putExtra("merchantId", "" + merchantId);
                payIntent.putExtra("serviceId", "" + serviceId);
                payIntent.putExtra("totalAmount", "" + awardedPrice);
                payIntent.putExtra("primaryDescription", "" + title);
                startActivity(payIntent);
                break;

            case R.id.tvMsgAward:
                Intent intent = new Intent(mContext, ChatActivity.class);
                intent.putExtra("merchantId", merchantId);
                intent.putExtra("serviceId", serviceId);
                intent.putExtra("merchantName", merchantName);
                intent.putExtra("merchantImage", merchantImage);
                intent.putExtra("awardStatus", awardStatus);
                intent.putExtra("title", title);
                startActivity(intent);
                break;

            case R.id.tvAwardReview:
                getServiceRating();
                break;

            case R.id.tVAwardName:
                ratingDialog();
                break;

            case R.id.marKDeliverTv:
                conformationDialog();
                break;
        }
    }


    private void conformationDialog() {
        new AlertDialog.Builder(mContext)
                .setTitle(mContext.getString(R.string.app_name))
                .setMessage("Are you sure?")
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        updateServiceStatus();
                    }
                })
                .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .setIcon(R.drawable.ic_launcher)
                .show();
    }

    private void getServiceRating() {
        if (!CheckNetworkState.isOnline(AwardDetailActivity.this)) {
            showToastMsg(this, getString(R.string.network_error));
            return;
        }
        showProgressDialog(this);
        try {
            final LoginResponse.Users userDetail = Utils.readUserDetail(mContext);
            final Call<RatingResponse> getMerchantRatingRequest = ((TechquiqApplication) mContext.getApplicationContext())
                    .getService().getServiceRating(userDetail.getUserId(),
                            Utils.getDeviceId(mContext),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID,
                            Integer.parseInt(merchantId),
                            Integer.parseInt(serviceId)
                    );

            Log.e(TAG, "Request : " + getMerchantRatingRequest.request().url());

            getMerchantRatingRequest.enqueue(new Callback<RatingResponse>() {

                @Override
                public void onResponse(Call<RatingResponse> call, Response<RatingResponse> response) {
                    hideProgressDialog();

                    if (response == null) {
                        showToastMsg(mContext, getString(R.string.server_error));
                        return;
                    }

                    Log.e(TAG, "Response : " + new Gson().toJson(response.body()));
                    Log.e(TAG, response.toString());

                    RatingResponse ratingResponse = response.body();
                    int responseStatusCode = ratingResponse.getResponseStatusCode();
                    if (responseStatusCode == AppConstant.NO_DATA_FOUND) {
                        reviewDialog();
                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        if (ratingResponse.getResponseCode().equalsIgnoreCase("0")) {
                            reviewDialog();
                        } else if (ratingResponse.getResponseCode().equalsIgnoreCase("1")) {
                            review = ratingResponse.getRatingResult().get(0).getReview();
                            userRating = Float.parseFloat(ratingResponse.getRatingResult().get(0).getRating());
                            reviewDialog();
                        }
                    }

                }

                @Override
                public void onFailure(Call<RatingResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void reviewDialog() {
        // custom dialog
        final Dialog dialog = new Dialog(mContext, R.style.Theme_Dialog);
        RatingBar ratingBar;
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_review);
        dialog.setTitle(getResources().getString(R.string.app_name));
        dialog.show();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        // set the custom dialog components - text, image and button
        final TextView tvReviewDone = (TextView) dialog.findViewById(R.id.tvReviewDone);
        final EditText etReview = (EditText) dialog.findViewById(R.id.etReview);
        ratingBar = (RatingBar) dialog.findViewById(R.id.ratingBar);
        etReview.setText(review);
        ratingBar.setRating(userRating);
        userRating = ratingBar.getRating();
        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            public void onRatingChanged(RatingBar ratingBar, float rating,
                                        boolean fromUser) {
                userRating = rating;
            }
        });

        tvReviewDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                review = etReview.getText().toString();
                if (review != null && review.isEmpty()) {
                    showToastMsg(mContext, getString(R.string.message_required));
                    return;
                }
                if (userRating < 1) {
                    showToastMsg(mContext, getResources().getString(R.string.please_give_rating));
                    return;

                } else {
                    rateOnService();
                }
                dialog.dismiss();
            }

        });


    }

    private void rateOnService() {

        if (!CheckNetworkState.isOnline(this)) {
            showToastMsg(this, getString(R.string.network_error));
            return;
        }
        showProgressDialog(mContext);
        try {
            final LoginResponse.Users userDetail = Utils.readUserDetail(mContext);
            final Call<RatingResponse> serviceRateRequest = ((TechquiqApplication) mContext.getApplicationContext())
                    .getService().rateOnService(
                            userDetail.getUserId(),
                            Utils.getDeviceId(mContext),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID,
                            merchantId,
                            serviceId,
                            userRating,
                            review);

            Log.e(TAG, "Request : " + serviceRateRequest.request().url());

            serviceRateRequest.enqueue(new Callback<RatingResponse>() {

                @Override
                public void onResponse(Call<RatingResponse> call, Response<RatingResponse> response) {
                    hideProgressDialog();

                    if (response == null) {
                        return;
                    }
                    Log.e(TAG, "Response : " + new Gson().toJson(response.body()));
                    Log.e(TAG, response.toString());

                    RatingResponse chatResponse = response.body();
                    if (chatResponse.getResponseCode().equalsIgnoreCase("0")) {
                        showToastMsg(mContext, chatResponse.getResponseMessage());
                    } else {
                        showToastMsg(mContext, getString(R.string.ws_review_success_msg));
                    }

                }

                @Override
                public void onFailure(Call<RatingResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void serviceAwardDetail() {
        if (!CheckNetworkState.isOnline(this)) {
            showToastMsg(this, getString(R.string.network_error));
            setUpErrorMsg(getString(R.string.network_error));
            return;
        }
        if (!showProgressDialog(this)) {
            showToastMsg(this, getString(R.string.network_error));
            setUpErrorMsg(getString(R.string.network_error));
            return;
        }
        try {
            final LoginResponse.Users userDetail = Utils.readUserDetail(this);
            Log.e(TAG, String.valueOf(userDetail.getUserId()));
            Call<ServiceResponse> myServiceProductRequest = ((TechquiqApplication) getApplicationContext())
                    .getService().getServiceList(userDetail.getUserId(),
                            Utils.getDeviceId(this),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID,
                            10,
                            0, 1,
                            serviceId,
                            null);

            Log.e(TAG, "Request : " + myServiceProductRequest.request().url());

            myServiceProductRequest.enqueue(new Callback<ServiceResponse>() {
                @Override
                public void onResponse(Call<ServiceResponse> call, Response<ServiceResponse> response) {
                    hideProgressDialog();

                    if (response == null) {
                        return;
                    }
                    Log.e(TAG, "Response : " + new Gson().toJson(response.body()));
                    Log.e(TAG, response.toString());
                    ServiceResponse serviceResponse = response.body();

                    if (serviceResponse.getResponseCode() != null && serviceResponse.getResponseCode().equalsIgnoreCase("0")) {
                        setUpErrorMsg(getResources().getString(R.string.ws_no_award_service_found));
                        return;
                    } else if (serviceResponse.getResponseCode() != null && serviceResponse.getResponseCode().equalsIgnoreCase("1")) {

                        tvPaymentND.setVisibility(View.GONE);
                        awardDetailContainer.setVisibility(View.VISIBLE);
                        mainLayout.setVisibility(View.VISIBLE);
                        tvMsgAward.setVisibility(View.VISIBLE);
                        ArrayList<ServiceResponse.ServiceDetail> serviceList = serviceResponse.getServiceDetails();


                        if (serviceList.size() > 0) {
                            orderId = serviceList.get(0).getOrderId();
                            boolean canUpdateReview = serviceList.get(0).isCanUpdateReview();
                            if (canUpdateReview) {
                                tvAwardReview.setVisibility(View.VISIBLE);
                            } else {
                                tvAwardReview.setVisibility(View.GONE);
                            }
                        }

                        for (int i = 0; i < serviceList.size(); i++) {
                            title = Utils.decodeString(serviceList.get(i).getName());
                            description = Utils.decodeString(serviceList.get(i).getDescription());
                            titleTv.setText(title);
                            tVAwardTitle.setText(title);
                            tVCategories.setText(serviceList.get(i).getServiceCategory() + " > " + serviceList.get(i).getServiceSubCategory());
                            tVComplainDes.setText(description);
                            tvAwardDate.setText(serviceList.get(i).getDate());
                            tVStatusDes.setText(serviceList.get(i).getServiceStatus());

                            if (serviceList.get(i).getServiceStatus().equalsIgnoreCase(AppConstant.REPAIRED)) {
                                marKDeliverTv.setVisibility(View.VISIBLE);
                            } else {
                                marKDeliverTv.setVisibility(View.GONE);
                            }


                            awardStatus = serviceList.get(i).getAwardStatus();
                            if (serviceList.get(i).getPaymentStatus() != null && serviceList.get(i).getPaymentStatus().equalsIgnoreCase("0")) {
                                tVPayNow.setVisibility(View.VISIBLE);
                                tVPayNow.setText(getResources().getString(R.string.pay_now));
                                paidStatusTv.setVisibility(View.GONE);
                            } else {
                                paidStatusTv.setVisibility(View.VISIBLE);
                                paidStatusTv.setText(getResources().getString(R.string.paid));
                                tVPayNow.setVisibility(View.GONE);
                            }

                            ArrayList<ServiceResponse.ServiceDetail.SProductImage> productImages = serviceList.get(i).getsProductImages();
                            proposalDetail = serviceList;
                            ArrayList<ServiceImage> serviceImageArrayList = new ArrayList<>();
                            for (int j = 0; j < productImages.size(); j++) {
                                if (productImages != null && productImages.size() > 0) {
                                    ServiceImage serviceImage = new ServiceImage();
                                    serviceImage.setFileName(productImages.get(j).getImage());
                                    serviceImageArrayList.add(serviceImage);
                                }
                            }

                            if (serviceList.size() > 0) {

                                if (serviceImageArrayList != null && serviceImageArrayList.size() > 0) {
                                    setAdpter(serviceImageArrayList);
                                }

                                if (proposalDetail.size() > 0) {
                                    ArrayList<ServiceResponse.ServiceDetail.ServiceProposalData> proposalDatas = proposalDetail.get(i).getServiceProposal();
                                    for (int j = 0; j < proposalDatas.size(); j++) {
                                        if (proposalDatas.get(j).getServiceAwarded() != null && !proposalDatas.get(j).getServiceAwarded().isEmpty() && !proposalDatas.get(j).getServiceAwarded().equalsIgnoreCase("")) {
                                            awardedPrice = Float.parseFloat(proposalDatas.get(j).getService_price());
                                            tVAwardPrice.setText(AppConstant.CURRENCY_SYMBOL + " " + awardedPrice);
                                            tVAwardName.setText(proposalDatas.get(j).getFirst_name() + " " + proposalDatas.get(j).getLast_name());

                                            merchantId = proposalDatas.get(i).getUser_id();
                                            merchantName = proposalDatas.get(i).getFirst_name() + " " + proposalDatas.get(j).getLast_name();
                                            merchantAddress = proposalDatas.get(i).getAddress();
                                            merchantCompany = proposalDatas.get(i).getMerchantCompany();
                                            merchantEmail = proposalDatas.get(i).getEmail();
                                            merchantRating = proposalDatas.get(i).getAverageRating();
                                            merchantPhone = proposalDatas.get(i).getMerchantPhone();
                                            merchantImage = proposalDatas.get(i).getImage();
                                            break;
                                        }
                                    }
                                }
                            }
                        }

                    }
                }

                @Override
                public void onFailure(Call<ServiceResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        setUpErrorMsg(getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    setUpErrorMsg(getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void setUpErrorMsg(String msg) {
        awardDetailContainer.setVisibility(View.GONE);
        mainLayout.setVisibility(View.GONE);
        tvPaymentND.setText(msg);
        tvPaymentND.setVisibility(View.VISIBLE);
        tvMsgAward.setVisibility(View.GONE);
        titleTv.setText(getResources().getString(R.string.txt_services_title));

    }

    private void setAdpter(ArrayList<ServiceImage> serviceImageArrayList) {
        serviceAdapter = new ServiceViewAdapter(this, serviceImageArrayList);
        awardList.setAdapter(serviceAdapter);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        awardList.setLayoutManager(layoutManager);
    }

    private void ratingDialog() {
        // custom dialog
        final Dialog dialog = new Dialog(mContext, R.style.Theme_Dialog);
        //RatingBar ratingBar;
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_rating);
        dialog.setTitle("Title...");
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.show();
        // set the custom dialog components - text, image and button
        final CircleImageView ivMerchantImage = (CircleImageView) dialog.findViewById(R.id.ivMerchantImage);
        RatingBar ratingBar = (RatingBar) dialog.findViewById(R.id.ratingBar);
        TextView tvEmail = (TextView) dialog.findViewById(R.id.tvEmail);
        TextView tvMerchantName = (TextView) dialog.findViewById(R.id.tvMerchantName);
        TextView tvPhone = (TextView) dialog.findViewById(R.id.tvPhone);
        TextView tvAddress = (TextView) dialog.findViewById(R.id.tvAddress);
        TextView tvCompanyName = (TextView) dialog.findViewById(R.id.tvCompanyName);
        TextView tvReportAbuse = (TextView) dialog.findViewById(R.id.tvReportAbuse);
        ratingBar.setEnabled(false);
        ratingBar.setIsIndicator(false);
        ratingBar.setRating(merchantRating);
        tvEmail.setText(merchantEmail);
        tvMerchantName.setText(merchantName);
        tvPhone.setText(merchantPhone);
        tvAddress.setText(merchantAddress);
        tvCompanyName.setText(merchantCompany);
        TextView tvReadReview = (TextView) dialog.findViewById(R.id.tvReadReview);

        Glide.with(mContext).load(merchantImage).asBitmap().centerCrop()
                .placeholder(R.drawable.profile_img)
                .error(R.drawable.profile_img)
                .override(100, 100)
                .into(ivMerchantImage);


        tvReadReview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (merchantId != null) {
                    Intent intent = new Intent(mContext, ReviewListActivity.class);
                    intent.putExtra("merchantId", Integer.parseInt(merchantId));
                    mContext.startActivity(intent);
                    dialog.dismiss();
                }
            }
        });

        tvReportAbuse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getMerchantReport(merchantId);
                dialog.dismiss();
            }
        });


    }

    private void updateServiceStatus() {
        if (!CheckNetworkState.isOnline(this)) {
            showToastMsg(this, getString(R.string.network_error));
            tvPaymentND.setText(getString(R.string.network_error));
            tvPaymentND.setVisibility(View.VISIBLE);
            awardDetailContainer.setVisibility(View.GONE);
            return;
        }
        if (!showProgressDialog(this)) {
            tvPaymentND.setText(getString(R.string.network_error));
            tvPaymentND.setVisibility(View.VISIBLE);
            awardDetailContainer.setVisibility(View.GONE);
            return;
        }
        try {
            final LoginResponse.Users userDetail = Utils.readUserDetail(this);
            Call<BaseResponse> updateServiceStatusRequest = ((TechquiqApplication) getApplicationContext())
                    .getService().updateServiceStatus(userDetail.getUserId(),
                            Utils.getDeviceId(this),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID,
                            orderId,
                            merchantId,
                            serviceId);

            Log.e(TAG, "Request : " + updateServiceStatusRequest.request().url());


            updateServiceStatusRequest.enqueue(new Callback<BaseResponse>() {
                @Override
                public void onResponse(Call<BaseResponse> call, Response<BaseResponse> response) {
                    hideProgressDialog();
                    if (response == null) {
                        return;
                    }
                    Log.e(TAG, "Response : " + new Gson().toJson(response.body()));
                }

                @Override
                public void onFailure(Call<BaseResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
