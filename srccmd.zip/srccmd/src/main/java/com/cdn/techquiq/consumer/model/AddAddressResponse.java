package com.cdn.techquiq.consumer.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by avikaljain on 24/3/17.
 */

public class AddAddressResponse extends BaseResponse {

    @SerializedName("Result")
    private ArrayList<AddAddressResponse.AddAddress> result;

    public ArrayList<AddAddress> getResult() {
        return result;
    }

    public void setResult(ArrayList<AddAddress> result) {
        this.result = result;
    }
//    public AddAddress getChat() {
//        return Chat;
//    }
//
//    public void setChat(AddAddress result) {
//        Chat = result;
//    }

    public class AddAddress {
        @SerializedName("id")
        private String id;

        @SerializedName("firstName")
        private String firstName;


        @SerializedName("lastName")
        private String lastName;

        @SerializedName("address")
        private String address;

        @SerializedName("country_id")
        private String countryId;

        @SerializedName("state_id")
        private String stateId;

        @SerializedName("user_id")
        private String userId;


        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public String getStateId() {

            return stateId;
        }

        public void setStateId(String stateId) {
            this.stateId = stateId;
        }

        public String getLastName() {

            return lastName;
        }

        public void setLastName(String lastName) {
            this.lastName = lastName;
        }

        public String getId() {

            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getFirstName() {

            return firstName;
        }

        public void setFirstName(String firstName) {
            this.firstName = firstName;
        }

        public String getCountryId() {

            return countryId;
        }

        public void setCountryId(String countryId) {
            this.countryId = countryId;
        }

        public String getAddress() {

            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }
    }
}
