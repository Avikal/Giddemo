package com.cdn.techquiq.consumer.model;

/**
 * Created by kajalsoni on 30/1/17.
 */

public class ForgetPasswordResponse extends BaseResponse {


    String Result;

    public String getResult() {
        return Result;
    }

    public void setResult(String result) {
        Result = result;
    }
}
