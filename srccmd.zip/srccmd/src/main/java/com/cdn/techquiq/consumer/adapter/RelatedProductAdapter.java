
package com.cdn.techquiq.consumer.adapter;

/**
 * Created by kajalsoni on 31/1/17.
 */

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.activity.MainActivity;
import com.cdn.techquiq.consumer.activity.ProductDetailActivity;
import com.cdn.techquiq.consumer.fragment.ProductDetailFragment;
import com.cdn.techquiq.consumer.model.ProductResponse;

import java.util.ArrayList;
import java.util.List;

public class RelatedProductAdapter extends RecyclerView.Adapter<RelatedProductAdapter.MyViewHolder> {

    private List<ProductResponse.ProductDetail.RelatedProduct> relatedProductResponseList;
    Context mContext;
    LayoutInflater mLayoutInflater;


    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView nameTv;
        ImageView productImg;
        RatingBar ratingBar;
        View mparent;

        public MyViewHolder(View view) {
            super(view);
            mparent = view;
            nameTv = (TextView) view.findViewById(R.id.productName);
            productImg = (ImageView) view.findViewById(R.id.productImage);
            ratingBar = (RatingBar) view.findViewById(R.id.productRating);
        }
    }

    public RelatedProductAdapter(Context context,
                                 ArrayList<ProductResponse.ProductDetail.RelatedProduct> relatedProductResponseList) {
        this.mContext = context;
        this.relatedProductResponseList = relatedProductResponseList;
        mLayoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mLayoutInflater
                .inflate(R.layout.related_products_list_item, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {
        final ProductResponse.ProductDetail.RelatedProduct relatedProduct = relatedProductResponseList.get(position);

        holder.nameTv.setText(relatedProduct.getName());
        holder.ratingBar.setRating(Float.parseFloat(relatedProduct.getRating_count()));

        ArrayList<ProductResponse.ProductDetail.RelatedProduct.ProductImage> productImages =
                relatedProduct.getProductImages();
        if (productImages != null && productImages.size() > 0) {
            Glide.with(mContext).load(productImages.get(0).getImage())
                    .crossFade()
                    .error(R.drawable.placeholder_1)
                    .placeholder(R.drawable.placeholder_1)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(holder.productImg);
        }

        holder.mparent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mContext instanceof MainActivity) {
                    ProductDetailFragment productDetailFragment = (ProductDetailFragment)
                            ((MainActivity) mContext).getSupportFragmentManager()
                                    .findFragmentById(R.id.fragment_container);
                    productDetailFragment.productId = relatedProduct.getId();
                    productDetailFragment.updateData(relatedProduct.getId());
                } else if (mContext instanceof ProductDetailActivity) {
                    ProductDetailFragment productDetailFragment = (ProductDetailFragment)
                            ((ProductDetailActivity) mContext).getSupportFragmentManager()
                                    .findFragmentById(R.id.fragment_container);
                    productDetailFragment.productId = relatedProduct.getId();
                    productDetailFragment.updateData(relatedProduct.getId());
                }
            }
        });
    }


    @Override
    public int getItemCount() {
        return relatedProductResponseList.size();
    }
}
