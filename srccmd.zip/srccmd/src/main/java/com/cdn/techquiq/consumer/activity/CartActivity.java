package com.cdn.techquiq.consumer.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.SharedPrefrence;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.adapter.CartAdapter;
import com.cdn.techquiq.consumer.model.CartResponse;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;
import com.google.gson.Gson;

import java.net.SocketTimeoutException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by akshaysoni on 3/2/17.
 */
public class CartActivity extends BaseActivity {

    private String TAG = CartActivity.class.getSimpleName();
    private RecyclerView cartList;
    private CartAdapter cartAdapter;
    private ImageView backIv;
    private TextView titleTv, noCartTv;
    private Button continueShoppingBtn, makePaymentBtn;
    private TextView cartCountTv, cartAmountTv;
    private LinearLayout belowLayout;
    private int cartId;
    private String totalPayment;
    private String primaryDescription;

    private ArrayList<CartResponse.CartDetail.Items> itemsList;

    @Nullable
    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.cart_activity);

        setUpUI();

    }

    public void getCartItems() {
        try {

            if (!CheckNetworkState.isOnline(mContext)) {
                cartList.setVisibility(View.GONE);
                noCartTv.setText(getResources().getString(R.string.network_error));
                noCartTv.setVisibility(View.VISIBLE);
                return;
            }

            if (!showProgressDialog(this)) {
                return;
            }

            final LoginResponse.Users userDetail = Utils.readUserDetail(mContext);

            Call<CartResponse> myProductRequest = ((TechquiqApplication) getApplicationContext())
                    .getService().getCartDetail(userDetail.getUserId(),
                            userDetail.getCartId(),
                            Utils.getDeviceId(this),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID);

            Log.e(TAG, "Request cart: " + myProductRequest.request().url());

            myProductRequest.enqueue(new Callback<CartResponse>() {
                @Override
                public void onResponse(Call<CartResponse> call, Response<CartResponse> response) {
                    hideProgressDialog();

                    if (response == null) {
                        showToastMsg(mContext, getString(R.string.server_error));
                        noCartTv.setText(getResources().getString(R.string.server_error));
                        return;
                    }
                    CartResponse cartResponse = response.body();
                    if (cartResponse == null) {
                        showToastMsg(mContext, getString(R.string.server_error));
                        noCartTv.setText(getResources().getString(R.string.server_error));
                        return;
                    }
                    int responseStatusCode = cartResponse.getResponseStatusCode();
                    if (responseStatusCode == AppConstant.PARAM_MISSING) {
                        showToastMsg(mContext, getString(R.string.ws_param_missing));
                    } else if (responseStatusCode == AppConstant.UNAUTHORIZED_USER) {
                        showToastMsg(mContext, getString(R.string.ws_unauthorized_user));
                    } else if (responseStatusCode == AppConstant.NO_CART_FOUND) {
                        noCartTv.setText(getResources().getString(R.string.ws_no_cart_found));
                    } else if (responseStatusCode == AppConstant.NO_DATA_FOUND) {
                        noCartTv.setText(getResources().getString(R.string.ws_no_cart_found));
                    } else if (responseStatusCode == AppConstant.EMPTY_CART) {
                        noCartTv.setText(getResources().getString(R.string.ws_empty_cart));
                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        if (cartResponse.getResponseCode().equalsIgnoreCase("0")) {
                            cartList.setVisibility(View.GONE);
                            belowLayout.setVisibility(View.GONE);
                            noCartTv.setText(getResources().getString(R.string.error_no_item_in_cart));
                            noCartTv.setVisibility(View.VISIBLE);
                            return;
                        }
                    } else {
                        showToastMsg(mContext, cartResponse.getResponseMessage());
                    }

                    Log.e(TAG, "Response cart: " + new Gson().toJson(cartResponse));

                    if (cartResponse.getCartDetail() != null &&
                            cartResponse.getCartDetail().getCart_id() != null) {
                        Utils.updateCartId(mContext, cartResponse.getCartDetail().getCart_id());
                        setAdapter(cartResponse);
                    } else {
                        Utils.writeUserDetail(CartActivity.this, userDetail);
                        SharedPrefrence.getInstance(CartActivity.this).writeIntPrefs(SharedPrefrence.cartCount, 0);
                        cartList.setVisibility(View.GONE);
                        belowLayout.setVisibility(View.GONE);
                        noCartTv.setText(getResources().getString(R.string.error_no_item_in_cart));
                        noCartTv.setVisibility(View.VISIBLE);
                    }


                }

                @Override
                public void onFailure(Call<CartResponse> call, Throwable t) {
                    hideProgressDialog();
                    cartList.setVisibility(View.GONE);
                    belowLayout.setVisibility(View.GONE);
                    noCartTv.setVisibility(View.VISIBLE);
                    if (t instanceof SocketTimeoutException) {
                        noCartTv.setText(getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    noCartTv.setText(getResources().getString(R.string.server_error));

                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void setCartValue(CartResponse cartResponse) {
        if (cartResponse != null && cartResponse.getCartDetail() != null) {
            int cartCount = cartResponse.getCartDetail().getCart_count();
            SharedPrefrence.getInstance(CartActivity.this)
                    .writeIntPrefs(SharedPrefrence.cartCount, cartCount);
            cartCountTv.setText(mContext.getString(R.string.total_count) + " : " + cartCount);
            cartAmountTv.setText(mContext.getString(R.string.total_amount) + " : " +
                    AppConstant.CURRENCY_SYMBOL + " " +
                    Utils.roundDecimal(cartResponse.getCartDetail().getTotal_price()));
            totalPayment = cartResponse.getCartDetail().getTotal_price();

            itemsList = cartResponse.getCartDetail().getItemses();
            for (int i = 0; i < itemsList.size(); i++) {
                if (i == 0) {
                    primaryDescription = itemsList.get(i).getProduct_name_en();
                } else {
                    primaryDescription = primaryDescription + ", " + itemsList.get(i).getProduct_name_en();
                }
            }
        }
    }


    public void setAdapter(CartResponse cartResponse) {
        if (cartResponse != null && cartResponse.getCartDetail() != null) {
            if (cartResponse.getCartDetail().getItemses() != null && cartResponse.getCartDetail().getItemses().size() > 0) {
                cartAdapter = new CartAdapter(CartActivity.this, cartResponse.getCartDetail());
                cartId = cartResponse.getCartDetail().getCart_id();
                LinearLayoutManager lManger = new LinearLayoutManager(CartActivity.this,
                        LinearLayoutManager.VERTICAL, false);
                cartList.setLayoutManager(lManger);
                cartList.setAdapter(cartAdapter);
                cartList.setVisibility(View.VISIBLE);
                belowLayout.setVisibility(View.VISIBLE);
                noCartTv.setVisibility(View.GONE);
            } else {
                cartList.setVisibility(View.GONE);
                belowLayout.setVisibility(View.GONE);
                noCartTv.setVisibility(View.VISIBLE);
            }

            setCartValue(cartResponse);
        }
    }


    private void setUpUI() {
        titleTv = (TextView) findViewById(R.id.titleTv);
        titleTv.setText(getResources().getString(R.string.txt_cart_title));
        cartList = (RecyclerView) findViewById(R.id.cartList);
        backIv = (ImageView) findViewById(R.id.backIv);
        backIv.setOnClickListener(this);
        continueShoppingBtn = (Button) findViewById(R.id.continueShoppingBtn);
        makePaymentBtn = (Button) findViewById(R.id.makePaymentBtn);
        continueShoppingBtn.setOnClickListener(this);
        makePaymentBtn.setOnClickListener(this);
        cartCountTv = (TextView) findViewById(R.id.cartCountTv);
        cartAmountTv = (TextView) findViewById(R.id.cartAmountTv);
        belowLayout = (LinearLayout) findViewById(R.id.belowLayout);
        noCartTv = (TextView) findViewById(R.id.noCartTv);
    }

    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.backIv:
                finish();
                break;

            case R.id.continueShoppingBtn:
                MainActivity.mainStacks.get(AppConstant.TAB_PRODUCT).clear();
                MainActivity.mainCurrentTab = AppConstant.TAB_PRODUCT;

                Intent intent = new Intent(this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                break;

            case R.id.makePaymentBtn:
                Intent intent1 = new Intent(mContext, ChoosePaymentOptionActivity.class);
                intent1.putExtra("cartId", cartId);
                intent1.putExtra("shippingAddress", cartAdapter.getAddressDetail());
                intent1.putExtra("totalAmount", totalPayment);
                intent1.putExtra("primaryDescription", primaryDescription);
                mContext.startActivity(intent1);
                break;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        getCartItems();
    }
}
