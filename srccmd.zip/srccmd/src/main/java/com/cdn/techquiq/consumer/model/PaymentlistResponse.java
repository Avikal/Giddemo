package com.cdn.techquiq.consumer.model;

/**
 * Created by kajalsoni on 6/2/17.
 */

public class PaymentlistResponse {

    String name, orderId, date, time, amount;

    public PaymentlistResponse(String name, String orderId, String date, String time, String amount) {
        this.name = name;
        this.orderId = orderId;
        this.date = date;
        this.time = time;
        this.amount = amount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }
}
