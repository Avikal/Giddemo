package com.cdn.techquiq.consumer.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by avikaljain on 10/4/17.
 */

public class ServiceAddResponse extends BaseResponse {

    @SerializedName("Result")
    private ArrayList<ServiceAdd> serviceAdd;

    public ArrayList<ServiceAdd> getServiceAdd() {
        return serviceAdd;
    }

    public void setServiceAdd(ArrayList<ServiceAdd> serviceAdd) {
        this.serviceAdd = serviceAdd;
    }


    public class ServiceAdd implements Serializable {
        @SerializedName("image")
        private String image;

        @SerializedName("service_id")
        private String service_id;

        public String getService_id() {
            return service_id;
        }

        public void setService_id(String service_id) {
            this.service_id = service_id;
        }

        public String getImage() {

            return image;
        }

        public void setImage(String image) {
            this.image = image;
        }
    }
}
