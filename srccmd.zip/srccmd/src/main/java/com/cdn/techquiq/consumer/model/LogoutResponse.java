package com.cdn.techquiq.consumer.model;

public class LogoutResponse extends BaseResponse {


}
