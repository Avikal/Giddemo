package com.cdn.techquiq.consumer.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.activity.AddAddressActivity;
import com.cdn.techquiq.consumer.activity.AddressActivity;
import com.cdn.techquiq.consumer.model.AddressResponse;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.google.gson.Gson;

import java.net.SocketTimeoutException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by avikaljain on 3/4/17.
 */

public class AddressAdapter extends RecyclerView.Adapter<AddressAdapter.MyViewHolder> {

    private String TAG = AddressAdapter.class.getSimpleName();

    private LayoutInflater mLayoutInflater;
    private ArrayList<AddressResponse.AddressDetail> addressList;
    private Context mContext;
    public String addressId;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewAddressDetail;
        public ImageView imageViewSelect;
        public ImageView ivUnSelect;
        public LinearLayout linearMain;
        public LinearLayout linearSelectAddress;
        public TextView tvDeliveryAddress;
        public TextView tvAddressName;
        public RelativeLayout rlEditAddress;
        public RelativeLayout rlDeleteAddress;
        public TextView tvView;

        public MyViewHolder(View view) {
            super(view);
            textViewAddressDetail = (TextView) view.findViewById(R.id.textViewAddressDetail);
            imageViewSelect = (ImageView) view.findViewById(R.id.imageViewSelect);
            linearMain = (LinearLayout) view.findViewById(R.id.linearMain);
            ivUnSelect = (ImageView) view.findViewById(R.id.ivUnSelect);
            linearSelectAddress = (LinearLayout) view.findViewById(R.id.linearSelectAddress);
            tvDeliveryAddress = (TextView) view.findViewById(R.id.tvDeliveryAddress);
            tvAddressName = (TextView) view.findViewById(R.id.tvAddressName);
            rlEditAddress = (RelativeLayout) view.findViewById(R.id.rlEditAddress);
            rlDeleteAddress = (RelativeLayout) view.findViewById(R.id.rlDeleteAddress);

            tvView = (TextView) view.findViewById(R.id.tvView);

        }
    }


    public AddressAdapter(Context context, ArrayList<AddressResponse.AddressDetail> addressList) {
        this.mContext = context;
        this.addressList = addressList;
        mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mLayoutInflater.inflate(R.layout.address_list_item, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {
        final AddressResponse.AddressDetail addressResponse = addressList.get(position);

        if (addressList.size() == 1) {
            holder.rlDeleteAddress.setEnabled(false);
            holder.rlDeleteAddress.setAlpha(0.5f);
        } else {
            holder.rlDeleteAddress.setEnabled(true);
            holder.rlDeleteAddress.setAlpha(1f);
        }
        holder.textViewAddressDetail.setText(addressResponse.getAddress() + ", " + addressResponse.getCityName() + ", " +
                addressResponse.getStateName() + ", " + addressResponse.getCountryName() + ", " + addressResponse.getPostalCode());
        holder.tvAddressName.setText(addressResponse.getFirstName() + " " + addressResponse.getLastName());
        holder.linearMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (int i = 0; i < addressList.size(); i++) {
                    addressList.get(i).setAddressType("");
                }
                addressList.get(position).setAddressType("1");
                notifyDataSetChanged();
            }
        });
        if (addressResponse.getAddressType().equalsIgnoreCase("1")) {
            holder.linearSelectAddress.setVisibility(View.VISIBLE);
            holder.imageViewSelect.setVisibility(View.VISIBLE);
            holder.ivUnSelect.setVisibility(View.GONE);
            holder.tvView.setVisibility(View.GONE);
        } else {
            holder.linearSelectAddress.setVisibility(View.GONE);
            holder.imageViewSelect.setVisibility(View.GONE);
            holder.ivUnSelect.setVisibility(View.VISIBLE);
            holder.tvView.setVisibility(View.VISIBLE);
        }

        holder.tvDeliveryAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addressId = addressList.get(position).getId();
                makeDeliveryAddress(false);
            }
        });


        holder.rlEditAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addressId = addressList.get(position).getId();
                Intent intent = new Intent(mContext, AddAddressActivity.class);
                intent.putExtra("status", "edit");
                intent.putExtra("addressId", addressId);
                intent.putExtra("addressList", addressList);
                intent.putExtra("position", position);
                mContext.startActivity(intent);


            }
        });
        holder.rlDeleteAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addressId = addressList.get(position).getId();
                deleteAddress(position);
//                notifyDataSetChanged();
            }
        });
    }

    private void deleteAddress(final int position) {

        ((AddressActivity) mContext).showProgressDialog(mContext);
        try {
            final LoginResponse.Users userDetail = Utils.readUserDetail(mContext);
            Call<AddressResponse> deleteAddressRequest = ((TechquiqApplication) mContext
                    .getApplicationContext()).getService().deleteAddress(
                    Utils.getDeviceId(mContext),
                    AppConstant.FCM_ID,
                    ApiParameter.DEVICE_TYPE_VALUE,
                    userDetail.getUserId(),
                    addressId
            );

            Log.e(TAG, "Request : " + deleteAddressRequest.request().url());

            deleteAddressRequest.enqueue(new Callback<AddressResponse>() {
                @Override
                public void onResponse(Call<AddressResponse> call, Response<AddressResponse> response) {
                    ((AddressActivity) mContext).hideProgressDialog();
                    if (response == null) {
                        ((AddressActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.server_error));
                        return;
                    }
                    Log.e(TAG, "Response : " + new Gson().toJson(response.body()));
                    Log.e(TAG, "Response Address" + response.toString());
                    AddressResponse addressResponse = response.body();
                    int responseStatusCode = addressResponse.getResponseStatusCode();
                    if (responseStatusCode == AppConstant.PARAM_MISSING) {
                        ((AddressActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.ws_param_missing));

                    } else if (responseStatusCode == AppConstant.UNKNOWN_ERROR) {
                        ((AddressActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.ws_unkonwn_error));
                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        if (addressResponse.getResponseCode() != null && addressResponse.getResponseCode().equalsIgnoreCase("0")) {
                            ((AddressActivity) mContext).showToastMsg(mContext, response.body().getResponseMessage());
                            return;
                        } else if (addressResponse.getResponseCode() != null && addressResponse.getResponseCode().equalsIgnoreCase("1")) {
                            if (position + 1 == addressList.size()) {
                                addressId = addressList.get(0).getId();
                                makeDeliveryAddress(true);
                            } else {
                                addressId = addressList.get(position + 1).getId();
                                makeDeliveryAddress(true);
                            }


                        }
                    } else {
                        ((AddressActivity) mContext).showToastMsg(mContext, response.body().getResponseMessage());
                    }


                }

                @Override
                public void onFailure(Call<AddressResponse> call, Throwable t) {
                    ((AddressActivity) mContext).hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        ((AddressActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.connection_timeout));
                        return;
                    }
                    ((AddressActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
        notifyDataSetChanged();
    }

    private void makeDeliveryAddress(final boolean isDelete) {
        ((AddressActivity) mContext).showProgressDialog(mContext);
        try {
            final LoginResponse.Users userDetail = Utils.readUserDetail(mContext);
            Call<AddressResponse> shippingAddressRequest = ((TechquiqApplication) mContext
                    .getApplicationContext()).getService().setDeliveryAddress(
                    userDetail.getUserId(),
                    addressId,
                    Utils.getDeviceId(mContext),
                    AppConstant.FCM_ID,
                    ApiParameter.DEVICE_TYPE_VALUE
            );

            Log.e(TAG, "Request : " + shippingAddressRequest.request().url());

            shippingAddressRequest.enqueue(new Callback<AddressResponse>() {
                @Override
                public void onResponse(Call<AddressResponse> call, Response<AddressResponse> response) {
                    ((AddressActivity) mContext).hideProgressDialog();

                    Log.e(TAG, "Address Response : " + new Gson().toJson(response.body()));
                    Log.e(TAG, "Response Address" + response.toString());
                    AddressResponse registrationResponse = response.body();

                    if (registrationResponse.getResponseCode() != null && registrationResponse.getResponseCode().equalsIgnoreCase("0")) {
                        ((AddressActivity) mContext).showToastMsg(mContext, response.body().getResponseMessage());
                        return;
                    } else if (registrationResponse.getResponseCode() != null
                            && registrationResponse.getResponseCode().equalsIgnoreCase("1")) {
                        if (!isDelete) {
                            ((AddressActivity) mContext).setResult(Activity.RESULT_OK);
                            ((AddressActivity) mContext).finish();
                        } else {
                            ((AddressActivity) mContext).setResult(Activity.RESULT_OK);
                            ((AddressActivity) mContext).setNewList();
                        }
                    }
                }

                @Override
                public void onFailure(Call<AddressResponse> call, Throwable t) {
                    ((AddressActivity) mContext).hideProgressDialog();

                    if (t instanceof SocketTimeoutException) {
                        ((AddressActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.connection_timeout));
                        return;
                    }
                    ((AddressActivity) mContext).showToastMsg(mContext, mContext.getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount() {
        return addressList.size();
    }
}
