package com.cdn.techquiq.consumer.fragment;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.ScrollView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.LogUtils;
import com.cdn.techquiq.consumer.Utils.SharedPrefrence;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.activity.BaseActivity;
import com.cdn.techquiq.consumer.activity.CartActivity;
import com.cdn.techquiq.consumer.activity.ProductDetailActivity;
import com.cdn.techquiq.consumer.activity.ReviewListActivity;
import com.cdn.techquiq.consumer.adapter.ProductDetailPagerAdapter;
import com.cdn.techquiq.consumer.adapter.RelatedProductAdapter;
import com.cdn.techquiq.consumer.custom.ClickableViewPager;
import com.cdn.techquiq.consumer.model.CartResponse;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.ProductResponse;
import com.cdn.techquiq.consumer.model.RatingResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;
import com.google.gson.Gson;

import java.net.SocketTimeoutException;

import de.hdodenhof.circleimageview.CircleImageView;
import me.relex.circleindicator.CircleIndicator;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by kajalsoni on 3/2/17.
 */
public class ProductDetailFragment extends BaseFragment implements ViewPager.OnPageChangeListener,
        AdapterView.OnItemSelectedListener {

    private String TAG = ProductDetailFragment.class.getSimpleName();

    private RecyclerView relatedProductRecyclerView;
    private RelatedProductAdapter relatedProductAdapter;

    private CircleIndicator indicator;
    private TextView addtocartBt;
    private TextView buyknowBt;

    private ProductResponse.ProductDetail productDetail;
    private TextView priceTv, productDescription, productReviewTv;
    private ClickableViewPager viewPager;
    private ImageView ivPager;
    private TextView relatedTitleTv;
    private RatingBar productRating;
    private TextView qtyTv, plusTv, minusTv;


    private TextView tvMerchantName;
    private LinearLayout reviewLayout;
    private String merchantId;
    public int productId;

    private LinearLayout linearOffer;

    private String merchantName;
    private String merchantImage;
    private String merchantEmail;
    private String merchantPhone;
    private String merchantCompany;
    private String merchantAddress;
    private float merchantRating;
    private ScrollView scrollMain;

    private TextView productWriteReviewTv;
    private TextView merchantWriteReviewTv;
    public String review;

    private boolean isProduct;
    private LinearLayout layoutRelated;
    private LinearLayout layoutBottomButton;
    private boolean isRatingProduct;
    private TextView tvQty;
    private LinearLayout qtyLayout;
    private boolean isReviewWrite;
    private TextView tvNoProduct;
    private float userRating;
    private int productRatingCount = 0;
    private long mLastClickTime = 0;

    private EditText etReport;
    private TextView tvReportDone;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_product_detail, null);
        productId = ((ProductDetailActivity) getActivity()).getProductId();
        isProduct = ((ProductDetailActivity) getActivity()).isFromProduct();
        isReviewWrite = ((ProductDetailActivity) getActivity()).isWriteReview();
        init(rootView);


        return rootView;
    }

    @Override
    public void onResume() {
        super.onResume();
        updateData(productId);
        topAndBelowTab();
    }

    public void updateData(int productId) {
        getProductList(productId);
        scrollMain.fullScroll(ScrollView.FOCUS_UP);
    }


    private void topAndBelowTab() {
        if (getActivity() instanceof ProductDetailActivity) {
            ((ProductDetailActivity) getActivity()).hideBackBtn(false);
            hideCart();
            ((ProductDetailActivity) getActivity()).hideSearchButton(true);
            ((ProductDetailActivity) getActivity()).hideSettingButton(true);
        }
    }

    private void hideCart() {
        if (isProduct) {
            ((ProductDetailActivity) getActivity()).hideCartButton(false);
        } else {
            ((ProductDetailActivity) getActivity()).hideCartButton(true);
        }
    }

    private void getProductList(final int productId) {
        try {

            if (!showProgressDialog(getActivity())) {
                return;
            }

            final LoginResponse.Users userDetail = Utils.readUserDetail(getActivity());

            Call<ProductResponse> myProductRequest = ((TechquiqApplication) getActivity().getApplicationContext())
                    .getService().doSearchProduct(userDetail.getUserId(),
                            Utils.getDeviceId(getActivity()),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID,
                            10,
                            0,
                            productId,
                            "", "");

            Log.e(TAG, "Request : " + myProductRequest.request().url());

            myProductRequest.enqueue(new Callback<ProductResponse>() {
                @Override
                public void onResponse(Call<ProductResponse> call, Response<ProductResponse> response) {

                    hideProgressDialog();

                    ProductResponse productResponse = response.body();

                    Log.e(TAG, "Response : " + new Gson().toJson(productResponse));

                    if (productResponse != null) {
                        if (productResponse.getResponseStatusCode() == AppConstant.NO_DATA_FOUND) {
                            setNoDataText(getString(R.string.ws_no_product_data_found));

                        } else if (productResponse.getResponseStatusCode() == AppConstant.SUCCESS) {

                            if (productResponse.getResponseCode().equalsIgnoreCase("0")) {
                                setNoDataText(getString(R.string.ws_no_product_data_found));
                                return;
                            } else if (productResponse.getResponseCode().equalsIgnoreCase("1")) {
                                tvNoProduct.setVisibility(View.GONE);
                                scrollMain.setVisibility(View.VISIBLE);
                                productDetail = productResponse.getProductDetail().get(0);
                                setData(productDetail);
                            }
                            ;
                        } else {
                            showToastMsg(getActivity(), response.body().getResponseMessage());
                        }

                    }
                }

                @Override
                public void onFailure(Call<ProductResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        setNoDataText(getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    setNoDataText(getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void init(View rootView) {
        relatedProductRecyclerView = (RecyclerView) rootView.findViewById(R.id.relatedProductList);
        buyknowBt = (TextView) rootView.findViewById(R.id.buyknowBt);
        addtocartBt = (TextView) rootView.findViewById(R.id.addToCartBtn);
        indicator = (CircleIndicator) rootView.findViewById(R.id.indicator);
        productWriteReviewTv = (TextView) rootView.findViewById(R.id.productWriteReviewTv);
        merchantWriteReviewTv = (TextView) rootView.findViewById(R.id.merchantWriteReviewTv);

        priceTv = (TextView) rootView.findViewById(R.id.priceTv);
        reviewLayout = (LinearLayout) rootView.findViewById(R.id.reviewLayout);
        productDescription = (TextView) rootView.findViewById(R.id.productDescription);
        tvMerchantName = (TextView) rootView.findViewById(R.id.tvMerchantName);
        productReviewTv = (TextView) rootView.findViewById(R.id.productReviewTv);
        viewPager = (ClickableViewPager) rootView.findViewById(R.id.viewPager);
        relatedTitleTv = (TextView) rootView.findViewById(R.id.relatedTitleTv);
        productRating = (RatingBar) rootView.findViewById(R.id.productRating);
        qtyTv = (TextView) rootView.findViewById(R.id.qtyTv);
        plusTv = (TextView) rootView.findViewById(R.id.plusTv);
        minusTv = (TextView) rootView.findViewById(R.id.minusTv);
        linearOffer = (LinearLayout) rootView.findViewById(R.id.linearOffer);
        scrollMain = (ScrollView) rootView.findViewById(R.id.scrollMain);
        layoutRelated = (LinearLayout) rootView.findViewById(R.id.layoutRelated);
        layoutBottomButton = (LinearLayout) rootView.findViewById(R.id.layoutBottomButton);
        tvQty = (TextView) rootView.findViewById(R.id.tvQty);
        qtyLayout = (LinearLayout) rootView.findViewById(R.id.qtyLayout);
        tvNoProduct = (TextView) rootView.findViewById(R.id.tvNoProduct);
        ivPager = (ImageView) rootView.findViewById(R.id.ivPager);
        plusTv.setOnClickListener(this);
        minusTv.setOnClickListener(this);
        reviewLayout.setOnClickListener(this);
        linearOffer.setOnClickListener(this);
        buyknowBt.setOnClickListener(this);
        addtocartBt.setOnClickListener(this);
        productWriteReviewTv.setOnClickListener(this);
        merchantWriteReviewTv.setOnClickListener(this);
        viewShowOrNot();

    }

    private void viewShowOrNot() {
        if (isProduct) {
            productWriteReviewTv.setVisibility(View.GONE);
            merchantWriteReviewTv.setVisibility(View.GONE);
            layoutRelated.setVisibility(View.VISIBLE);
            layoutBottomButton.setVisibility(View.VISIBLE);
            tvQty.setVisibility(View.VISIBLE);
            qtyLayout.setVisibility(View.VISIBLE);
            ((ProductDetailActivity) getActivity()).hideCartButton(false);

        } else {
            if (isReviewWrite) {
                productWriteReviewTv.setVisibility(View.VISIBLE);
                merchantWriteReviewTv.setVisibility(View.VISIBLE);
            } else {
                productWriteReviewTv.setVisibility(View.GONE);
                merchantWriteReviewTv.setVisibility(View.GONE);
            }

            layoutRelated.setVisibility(View.GONE);
            layoutBottomButton.setVisibility(View.GONE);
            tvQty.setVisibility(View.INVISIBLE);
            qtyLayout.setVisibility(View.INVISIBLE);
        }
    }

    private void setNoDataText(String error) {
        scrollMain.setVisibility(View.GONE);
        tvNoProduct.setVisibility(View.VISIBLE);
        layoutBottomButton.setVisibility(View.GONE);
        tvNoProduct.setText(error);
        setTitleText(getString(R.string.product_detail));
    }

    private void setData(ProductResponse.ProductDetail productDetail) {

        merchantName = productDetail.getMerchantFirstName() + " " + productDetail.getMerchantLastName();
        merchantAddress = productDetail.getMerchantAddress();
        merchantCompany = productDetail.getMerchantCompany();
        merchantEmail = productDetail.getMerchantEmail();
        merchantPhone = productDetail.getMerchantPhone();
        merchantImage = productDetail.getMerchantImage();
        merchantRating = Float.parseFloat(productDetail.getMerchantAverageRating());

        setTitleText(productDetail.getName());
        priceTv.setText(AppConstant.CURRENCY_SYMBOL + " " + productDetail.getPrice());
        productRating.setRating(Float.parseFloat(productDetail.getAverage_rating()));
        productRating.setIsIndicator(true);
        productDescription.setText(productDetail.getDescription());
        tvMerchantName.setText(merchantName);
        productRatingCount = Integer.parseInt(productDetail.getRating_count());
        productReviewTv.setText(getString(R.string.read_review) + " (" + productDetail.getRating_count() + ")");
        productRating.setRating(Float.parseFloat(productDetail.getAverage_rating()));
        merchantId = productDetail.getMerchantId();

        setQuantity(productDetail);

        setProductImages();

        relatedProductList(productDetail);

    }

    void setQuantity(final ProductResponse.ProductDetail productDetail) {

        if (productDetail.getQuantity() > 0) {
            qtyTv.setText("" + 1);
        }
        minusTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (SystemClock.elapsedRealtime() - mLastClickTime < 1000) {
                    return;
                }
                mLastClickTime = SystemClock.elapsedRealtime();

                int quantity = Integer.parseInt(qtyTv.getText().toString());
                if (quantity == 1) {
                    return;
                } else {
                    quantity = quantity - 1;
                    qtyTv.setText("" + quantity);
                }
            }
        });

        plusTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (SystemClock.elapsedRealtime() - mLastClickTime < 1000) {
                    return;
                }
                mLastClickTime = SystemClock.elapsedRealtime();

                int quantity = Integer.parseInt(qtyTv.getText().toString());
                if (productDetail.getQuantity() == 0) {
                    showToastMsg(getContext(), getResources().getString(R.string.out_of_stock));
                    return;
                }
                if (quantity == productDetail.getQuantity()) {
                    showToastMsg(getContext(), getResources().getString(R.string.product_count_msg, quantity));
                    return;
                } else {
                    quantity = quantity + 1;
                    qtyTv.setText("" + quantity);
                }
            }
        });


    }

    private void setProductImages() {
        ProductDetailPagerAdapter mAdapter = new ProductDetailPagerAdapter(getActivity(), productDetail);
        viewPager.setAdapter(mAdapter);

        viewPager.setOnItemClickListener(new ClickableViewPager.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {

            }
        });
        if (productDetail.getProductImages().size() > 1) {
            indicator.setViewPager(viewPager);

        }

        if (productDetail.getProductImages().size() == 0) {
            viewPager.setVisibility(View.GONE);
            ivPager.setVisibility(View.VISIBLE);
        } else {
            viewPager.setVisibility(View.VISIBLE);
            ivPager.setVisibility(View.GONE);
        }

    }

    private void relatedProductList(ProductResponse.ProductDetail productDetail) {
        if (productDetail != null && productDetail.getRelatedProducts() != null
                && productDetail.getRelatedProducts().size() > 0) {

            relatedTitleTv.setVisibility(View.VISIBLE);
            relatedProductAdapter = new RelatedProductAdapter(getActivity(), productDetail.getRelatedProducts());
            LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
            relatedProductRecyclerView.setLayoutManager(layoutManager);
            relatedProductRecyclerView.setAdapter(relatedProductAdapter);
        } else {
            relatedTitleTv.setVisibility(View.GONE);
            LogUtils.LogE(TAG, "No related product found.");
        }
    }


    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.buyknowBt:
                addProductToCart(true);
                break;
            case R.id.addToCartBtn:

                if (SystemClock.elapsedRealtime() - mLastClickTime < 1000) {
                    return;
                }
                mLastClickTime = SystemClock.elapsedRealtime();
                addProductToCart(false);
                break;
            case R.id.reviewLayout:
                if (productRatingCount == 0) {
                    showToastMsg(getContext(), getString(R.string.no_review));
                    return;
                }

                if (productId != 0) {
                    Intent intent = new Intent(getActivity(), ReviewListActivity.class);
                    intent.putExtra("productId", productId);
                    intent.putExtra("merchantId", Integer.parseInt(merchantId));
                    startActivity(intent);
                }
                break;
            case R.id.linearOffer:
                ratingDialog();
                break;
            case R.id.productWriteReviewTv:
                isRatingProduct = true;
                getProductRating();
                break;

            case R.id.merchantWriteReviewTv:
                isRatingProduct = false;
                getMerchantRating();
                break;

        }
    }

    private void getProductRating() {
        review = "";
        userRating = 0;
        if (!CheckNetworkState.isOnline(getContext())) {
            showToastMsg(getContext(), getString(R.string.network_error));
            return;
        }
        showProgressDialog(getContext());
        try {
            final LoginResponse.Users userDetail = Utils.readUserDetail(getContext());
            final Call<RatingResponse> getProductRatingRequest = ((TechquiqApplication) getContext().getApplicationContext())
                    .getService().getUserProductRating(userDetail.getUserId(),
                            Utils.getDeviceId(getContext()),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID,
                            productId
                    );

            Log.e(TAG, "Request : " + getProductRatingRequest.request().url());

            getProductRatingRequest.enqueue(new Callback<RatingResponse>() {

                @Override
                public void onResponse(Call<RatingResponse> call, Response<RatingResponse> response) {
                    hideProgressDialog();

                    if (response == null) {
                        showToastMsg(getContext(), getString(R.string.server_error));
                        return;
                    }

                    Log.e(TAG, "Response : " + new Gson().toJson(response.body()));
                    Log.e(TAG, response.toString());

                    RatingResponse ratingResponse = response.body();
                    int responseStatusCode = ratingResponse.getResponseStatusCode();
                    if (responseStatusCode == AppConstant.NO_DATA_FOUND) {
                        merchantReviewDialog();
                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        if (ratingResponse.getResponseCode().equalsIgnoreCase("0")) {
                            merchantReviewDialog();
                        } else if (ratingResponse.getResponseCode().equalsIgnoreCase("1")) {
                            review = ratingResponse.getRatingResult().get(0).getReview();
                            userRating = Float.parseFloat(ratingResponse.getRatingResult().get(0).getRating());
                            merchantReviewDialog();
                        }
                    }


                }

                @Override
                public void onFailure(Call<RatingResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(getContext(), getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(getContext(), getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void getMerchantRating() {
        review = "";
        userRating = 0;
        if (!CheckNetworkState.isOnline(getContext())) {
            showToastMsg(getContext(), getString(R.string.network_error));
            return;
        }
        showProgressDialog(getContext());
        try {
            final LoginResponse.Users userDetail = Utils.readUserDetail(getContext());
            final Call<RatingResponse> getMerchantRatingRequest = ((TechquiqApplication) getContext().getApplicationContext())
                    .getService().getUserMerchantRating(userDetail.getUserId(),
                            Utils.getDeviceId(getContext()),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID,
                            Integer.parseInt(merchantId)
                    );

            Log.e(TAG, "Request Merchant Rating: " + getMerchantRatingRequest.request().url());

            getMerchantRatingRequest.enqueue(new Callback<RatingResponse>() {

                @Override
                public void onResponse(Call<RatingResponse> call, Response<RatingResponse> response) {
                    hideProgressDialog();

                    if (response == null) {
                        showToastMsg(getContext(), getString(R.string.server_error));
                        return;
                    }

                    Log.e(TAG, "Response : " + new Gson().toJson(response.body()));
                    Log.e(TAG, response.toString());

                    RatingResponse ratingResponse = response.body();
                    int responseStatusCode = ratingResponse.getResponseStatusCode();
                    if (responseStatusCode == AppConstant.NO_DATA_FOUND) {
                        merchantReviewDialog();
                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        if (ratingResponse.getResponseCode().equalsIgnoreCase("0")) {
                            merchantReviewDialog();
                        } else if (ratingResponse.getResponseCode().equalsIgnoreCase("1")) {
                            review = ratingResponse.getRatingResult().get(0).getReview();
                            userRating = Float.parseFloat(ratingResponse.getRatingResult().get(0).getRating());
                            merchantReviewDialog();
                        }
                    }

                }

                @Override
                public void onFailure(Call<RatingResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(getContext(), getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(getContext(), getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void addProductToCart(boolean cart) {
        if (productDetail.getQuantity() != 0) {
            doAddToCart(cart, productDetail);
        } else {
            showToastMsg(getContext(), getResources().getString(R.string.out_of_stock));
        }
    }

    private void merchantReviewDialog() {
        // custom dialog
        final Dialog dialog = new Dialog(getContext(), R.style.Theme_Dialog);
        RatingBar ratingBar;
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_review);
        dialog.setTitle(getResources().getString(R.string.app_name));
        dialog.show();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        // set the custom dialog components - text, image and button
        final TextView tvReviewDone = (TextView) dialog.findViewById(R.id.tvReviewDone);
        final EditText etReview = (EditText) dialog.findViewById(R.id.etReview);

        ratingBar = (RatingBar) dialog.findViewById(R.id.ratingBar);
        etReview.setText(review);
        ratingBar.setRating(userRating);
        userRating = ratingBar.getRating();
        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                userRating = rating;
            }
        });

        tvReviewDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                review = etReview.getText().toString();
                if (review != null && review.isEmpty()) {
                    showToastMsg(getContext(), getString(R.string.message_required));
                    return;
                }

                if (isRatingProduct) {
                    if (userRating < 1) {
                        showToastMsg(getContext(), getResources().getString(R.string.please_give_rating));
                        return;
                    } else {
                        rateOnProduct();
                    }

                } else {
                    rateOnMerchant();
                }

                dialog.dismiss();
            }

        });


    }

    public void ratingDialog() {
        // custom dialog
        final Dialog dialog = new Dialog(getActivity(), R.style.Theme_Dialog);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_rating);
        dialog.setTitle("Title...");
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.show();
        // set the custom dialog components - text, image and button
        final CircleImageView ivMerchantImage = (CircleImageView) dialog.findViewById(R.id.ivMerchantImage);
        RatingBar ratingBar = (RatingBar) dialog.findViewById(R.id.ratingBar);
        TextView tvEmail = (TextView) dialog.findViewById(R.id.tvEmail);
        TextView tvMerchantName = (TextView) dialog.findViewById(R.id.tvMerchantName);
        TextView tvPhone = (TextView) dialog.findViewById(R.id.tvPhone);
        TextView tvAddress = (TextView) dialog.findViewById(R.id.tvAddress);
        TextView tvCompanyName = (TextView) dialog.findViewById(R.id.tvCompanyName);
        TextView tvReportAbuse = (TextView) dialog.findViewById(R.id.tvReportAbuse);


        ratingBar.setEnabled(false);
        ratingBar.setIsIndicator(false);
        ratingBar.setRating(merchantRating);
        tvEmail.setText(merchantEmail);
        tvMerchantName.setText(merchantName);
        tvPhone.setText(merchantPhone);
        tvAddress.setText(merchantAddress);
        tvCompanyName.setText(merchantCompany);

        TextView tvReadReview = (TextView) dialog.findViewById(R.id.tvReadReview);

        Glide.with(getActivity()).load(merchantImage).asBitmap().centerCrop()
                .placeholder(R.drawable.profile_img)
                .error(R.drawable.profile_img)
                .override(100, 100)
                .into(ivMerchantImage);

        tvReadReview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (merchantId != null) {
                    Intent intent = new Intent(getActivity(), ReviewListActivity.class);
                    intent.putExtra("merchantId", Integer.parseInt(merchantId));
                    getActivity().startActivity(intent);
                    dialog.dismiss();
                }
            }
        });

        tvReportAbuse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((BaseActivity) getActivity()).getMerchantReport(merchantId);
                dialog.dismiss();

            }
        });


    }

    private void rateOnMerchant() {

        if (!CheckNetworkState.isOnline(getContext())) {
            showToastMsg(getContext(), getString(R.string.network_error));
            return;
        }
        showProgressDialog(getContext());
        try {
            final LoginResponse.Users userDetail = Utils.readUserDetail(getContext());
            final Call<RatingResponse> shippingAddressRequest = ((TechquiqApplication) getContext().getApplicationContext())
                    .getService().rateOnMerchant(
                            userDetail.getUserId(),
                            Utils.getDeviceId(getContext()),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID,
                            merchantId,
                            userRating,
                            review);

            Log.e(TAG, "Request : " + shippingAddressRequest.request().url());

            shippingAddressRequest.enqueue(new Callback<RatingResponse>() {

                @Override
                public void onResponse(Call<RatingResponse> call, Response<RatingResponse> response) {
                    hideProgressDialog();

                    if (response == null) {
                        return;
                    }
                    Log.e(TAG, "Response : " + new Gson().toJson(response.body()));
                    Log.e(TAG, response.toString());

                    RatingResponse ratingResponse = response.body();
                    if (ratingResponse.getResponseCode().equalsIgnoreCase("0")) {
                        showToastMsg(getActivity(), ratingResponse.getResponseMessage());
                    } else {
                        showToastMsg(getActivity(), getString(R.string.ws_review_success_msg));
                    }

                }

                @Override
                public void onFailure(Call<RatingResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(getContext(), getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(getContext(), getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void rateOnProduct() {

        if (!CheckNetworkState.isOnline(getContext())) {
            showToastMsg(getContext(), getString(R.string.network_error));
            return;
        }
        showProgressDialog(getContext());
        try {
            final LoginResponse.Users userDetail = Utils.readUserDetail(getContext());
            final Call<RatingResponse> shippingAddressRequest = ((TechquiqApplication) getContext().getApplicationContext())
                    .getService().rateOnProduct(userDetail.getUserId(),
                            Utils.getDeviceId(getContext()),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID,
                            String.valueOf(productId),
                            merchantId,
                            userRating,
                            review);

            Log.e(TAG, "Request : " + shippingAddressRequest.request().url());

            shippingAddressRequest.enqueue(new Callback<RatingResponse>() {

                @Override
                public void onResponse(Call<RatingResponse> call, Response<RatingResponse> response) {
                    hideProgressDialog();

                    if (response == null) {
                        showToastMsg(getContext(), getString(R.string.server_error));
                        return;
                    }

                    Log.e(TAG, "Response : " + new Gson().toJson(response.body()));
                    Log.e(TAG, response.toString());

                    RatingResponse ratingResponse = response.body();
                    if (ratingResponse.getResponseCode().equalsIgnoreCase("0")) {
                        showToastMsg(getActivity(), ratingResponse.getResponseMessage());
                    } else {
                        showToastMsg(getActivity(), getString(R.string.ws_review_success_msg));
                    }
                }

                @Override
                public void onFailure(Call<RatingResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(getContext(), getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(getContext(), getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void doAddToCart(final boolean isBuyNow, final ProductResponse.ProductDetail productDetail) {

        if (!CheckNetworkState.isOnline(getActivity())) {
            showToastMsg(getActivity(), getString(R.string.network_error));
            return;
        }

        try {
            showProgressDialog(getActivity());

            final LoginResponse.Users userDetail = Utils.readUserDetail(getActivity());

            Call<CartResponse> myProductRequest = ((TechquiqApplication) getActivity().getApplicationContext())
                    .getService().addToCartService(userDetail.getUserId(),
                            userDetail.getCartId(),
                            productDetail.getId(),
                            qtyTv.getText().toString(),
                            productDetail.getPrice(),
                            Utils.getDeviceId(getActivity()),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID);


            Log.e(TAG, "" + myProductRequest.request().url());

            myProductRequest.enqueue(new Callback<CartResponse>() {
                @Override
                public void onResponse(Call<CartResponse> call, Response<CartResponse> response) {
                    hideProgressDialog();
                    if (response == null) {
                        showToastMsg(getContext(), getString(R.string.server_error));
                        return;
                    }
                    CartResponse cartResponse = response.body();

                    if (cartResponse != null) {
                        int responseStatusCode = cartResponse.getResponseStatusCode();
                        if (responseStatusCode == AppConstant.INVALID_CART_ID) {
                            Utils.updateCartId(getContext(), cartResponse.getCart_id());

                            doAddToCart(isBuyNow, productDetail);
                        } else if (responseStatusCode == AppConstant.SUCCESS) {
                            SharedPrefrence.getInstance(getActivity())
                                    .writeIntPrefs(SharedPrefrence.cartCount,
                                            cartResponse.getCartDetail().getCart_count());

                            Log.e(TAG, new Gson().toJson(cartResponse));

                            if (cartResponse.getResponseCode().equalsIgnoreCase("0")) {
                                showToastMsg(getActivity(), cartResponse.getResponseMessage());
                            } else if (cartResponse.getResponseCode().equalsIgnoreCase("1")) {


                                Utils.updateCartId(getActivity(), cartResponse.getCartDetail().getCart_id());


                                if (getActivity() instanceof ProductDetailActivity) {
                                    hideCart();
                                }

                                if (isBuyNow) {
                                    Intent intent = new Intent(getActivity(), CartActivity.class);
                                    startActivity(intent);
                                } else {
                                    showToastMsg(getActivity(), getResources().getString(R.string.cart_add_msg));
                                }
                            } else {
                                showToastMsg(getActivity(), cartResponse.getResponseMessage());
                            }
                        } else {
                            showToastMsg(getActivity(), cartResponse.getResponseMessage());
                        }

                    } else if (cartResponse != null) {
                        showToastMsg(getActivity(), cartResponse.getResponseMessage());
                    }
                }

                @Override
                public void onFailure(Call<CartResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(getContext(), getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(getContext(), getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*public void showPopUp() {

        LayoutInflater factory = LayoutInflater.from(getActivity());
        final View deleteDialogView = factory.inflate(R.layout.addtocart_popup, null);
        final AlertDialog deleteDialog = new AlertDialog.Builder(getActivity()).create();
        deleteDialog.setView(deleteDialogView);
        deleteDialog.show();


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                deleteDialog.dismiss();

            }
        }, 1000);

    }*/

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
        String quantity = adapterView.getItemAtPosition(position).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
