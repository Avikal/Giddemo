package com.cdn.techquiq.consumer.Utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.provider.Settings;
import android.support.v4.app.Fragment;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.activity.ChatActivity;
import com.cdn.techquiq.consumer.activity.MainActivity;
import com.cdn.techquiq.consumer.activity.UserActivity;
import com.cdn.techquiq.consumer.database.Chat;
import com.cdn.techquiq.consumer.database.DBHelper;
import com.cdn.techquiq.consumer.fragment.InboxFragment;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.ReceiveMessageBean;
import com.google.gson.Gson;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.UUID;

/**
 * Created by kajalsoni on 28/1/17.
 * Utility Class
 */
public class Utils {

    public static final String serverFormatWithZone = "yyyy-MM-dd HH:mm:ss z";
    public static final String serverFormat = "yyyy-MM-dd HH:mm:ss";
    public static final String requiredFormat = "MMM dd, HH:mm";
    public static Typeface robotoRegular, robotoBold, robotoLight, robotoMedium;

    public static String Toast(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
        return message;
    }

    /**
     * Used to get android device id.
     *
     * @param mContext
     * @return
     */
    public static String getDeviceId(Context mContext) {
        return Settings.Secure.getString(mContext.getContentResolver(),
                Settings.Secure.ANDROID_ID);
    }


    public static String getUniqueId() {
        return "Android_" + UUID.randomUUID().toString();
    }

    public static String getRequiredFormattedDate(String serverFormat, String requiredFormat, String ourDate) {

        DateFormat theDateFormat = new SimpleDateFormat(serverFormat, Locale.getDefault());
        Date date = null;
        String dateStr = "";
        try {
            if (ourDate != null && !ourDate.equals("null")) {
                date = theDateFormat.parse(ourDate);
                theDateFormat = new SimpleDateFormat(requiredFormat, Locale.getDefault());
                dateStr = theDateFormat.format(date);
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return dateStr;
    }

    /*public static void setLocale(Context mContext) {
        String lang = Locale.getDefault().toString();

        Locale locale;

        if (lang.contains("ar")) {
            locale = new Locale("ar");
        } else {
            locale = Locale.ENGLISH;
        }

        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        mContext.getResources().updateConfiguration(config,
                mContext.getResources().getDisplayMetrics());

    }*/

    public static String getLocale() {
        String lang = Locale.getDefault().toString();

        if (lang.contains("ar")) {
            lang = "ar";
        } else {
            lang = "EN";
        }

        return lang;
    }

    /*public static void loadUrlInExternalBrowser(String url, Context mContext) {

        if (CheckNetworkState.isOnline(mContext)) {
            try {
                Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                mContext.startActivity(myIntent);
            } catch (Exception e) {
                Toast.makeText(mContext, "No application can handle this request."
                        + " Please install a webbrowser", Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }
        } else {
            Toast.makeText(mContext, mContext.getResources().getString(R.string.network_error),
                    Toast.LENGTH_LONG).show();
        }
    }*/

    public static void loadFontFiles(Context mContext) {
        robotoRegular = Typeface.createFromAsset(mContext.getAssets(), "roboto_regular.ttf");
        robotoBold = Typeface.createFromAsset(mContext.getAssets(), "roboto_black.ttf");
        robotoLight = Typeface.createFromAsset(mContext.getAssets(), "roboto_light.ttf");
        robotoMedium = Typeface.createFromAsset(mContext.getAssets(), "roboto_medium.ttf");
    }

    public static void hideKeyBoard(Context mContext) {
        try {
            InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(((Activity) mContext).getWindow().getCurrentFocus().getWindowToken(), 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*public static int getAppVersion(Context mContext) {
        int versionCode = 1;
        try {
            versionCode = mContext.getPackageManager()
                    .getPackageInfo(mContext.getPackageName(), 0).versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return versionCode;
    }*/


    //This method is used for change date format
    public static String getRequiredFormatDate(String serverFormat,
                                               String requiredFormat, String ourDate) {
        DateFormat theDateFormat = new SimpleDateFormat(serverFormat, Locale.getDefault());
        Date date;
        String dateStr = "";
        try {
            if (ourDate != null && !ourDate.equals("null") && !ourDate.isEmpty()) {
                date = theDateFormat.parse(ourDate + " UTC");
                theDateFormat = new SimpleDateFormat(requiredFormat, Locale.getDefault());
                TimeZone tz = TimeZone.getDefault();
                theDateFormat.setTimeZone(tz);
                dateStr = theDateFormat.format(date).toString();
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return dateStr;
    }


    /*public static String getDateWithDefaultTimeZone(String serverFormat, String requiredFormat, String ourDate) {

        DateFormat theDateFormat = new SimpleDateFormat(serverFormat, Locale.ENGLISH);
        Date date;
        String dateStr = "";

        try {
            if (ourDate != null && !ourDate.equals("null") && !ourDate.isEmpty()) {
                date = theDateFormat.parse(ourDate);

                theDateFormat = new SimpleDateFormat(requiredFormat, Locale.ENGLISH);
                theDateFormat.setTimeZone(TimeZone.getDefault());
                dateStr = theDateFormat.format(date).toString();
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return dateStr;
    }*/

    public static String getDateInUTC(String serverFormat, Date ourDate) {
        DateFormat theDateFormat = new SimpleDateFormat(serverFormat, Locale.getDefault());
        theDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        return theDateFormat.format(ourDate).toString();
    }

    public static void writeUserDetail(Context mContext, LoginResponse.Users userDetail) {
        Gson gson = new Gson();
        String json = gson.toJson(userDetail);
        SharedPrefrence sPref = SharedPrefrence.getInstance(mContext);
        sPref.writePrefs(SharedPrefrence.userDetail, json);
    }

    public static LoginResponse.Users readUserDetail(Context mContext) {
        String json = SharedPrefrence.getInstance(mContext).readPrefs(SharedPrefrence.userDetail);
        Gson gson = new Gson();
        return gson.fromJson(json, LoginResponse.Users.class);
    }

    public static String appVersion(Context mContext) {
        PackageInfo pInfo = null;
        String version = null;
        try {
            pInfo = mContext.getPackageManager().getPackageInfo(mContext.getPackageName(), 0);
            version = pInfo.versionName + "." + pInfo.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return version;
    }

    public static void updateCartId(Context context, int cartId) {
        LoginResponse.Users userDetail = Utils.readUserDetail(context);
        userDetail.setCartId(cartId);
        Utils.writeUserDetail(context, userDetail);
    }


    public static void callOnRecivedChatMsg(Intent intent, Context context, boolean isRead, List<Chat> chatList) {
        String msgReceive = intent.getExtras().getString("bean");
        Gson gsonReceive = new Gson();
        ReceiveMessageBean message2 = gsonReceive.fromJson(msgReceive, ReceiveMessageBean.class);

        String merchantId = message2.getSent_by();
        String serviceId = message2.getService_id();
        Chat chat = new Chat();
        chat.setMessage(message2.getMessage());
        chat.setSent_by(Integer.parseInt(message2.getSent_by()));
        chat.setSent_to(Integer.parseInt(message2.getSent_to()));
        chat.setService_id(serviceId);
        chat.setMerchant_id(merchantId);
        chat.setDate_created(message2.getDate_created());
        chat.setTimestamp(message2.getTimestamp());
        chat.setReadMsg(isRead);
        chat.setSent(true);
        DBHelper dbHelper = DBHelper.getInstance(context);

        /**
         * Check condition and refresh UI
         */
        if (context instanceof MainActivity) {
            final Fragment fragment = ((MainActivity) context).getSupportFragmentManager()
                    .findFragmentById(R.id.fragment_container);
            if (fragment instanceof InboxFragment) {
                ((InboxFragment) fragment).notifyData();
            }
        } else if (context instanceof UserActivity) {
            ((UserActivity) context).notifyList();
        } else if (context instanceof ChatActivity) {
            if (chatList != null && chatList.size() > 0) {
                if (chatList.get(0).getMerchant_id().equalsIgnoreCase(chat.getMerchant_id()) &&
                        chatList.get(0).getService_id().equalsIgnoreCase(chat.getService_id())) {
                    chatList.add(chat);
                    ((ChatActivity) context).setAdapter();
                    dbHelper.updateMessageAsRead(serviceId, merchantId);
                }
            }
        }
    }

    public static String roundDecimal(String str) {
        try {
            double d = Double.parseDouble(str);
            return String.format("%.2f", d);
        } catch (Exception e) {
            return "0.00";
        }
    }

    public static void saveDeviceTokenId(Context context, String token) {
        SharedPrefrence.getInstance(context).writePrefs(SharedPrefrence.pushToken, token);
    }

    /**
     * Encode a String to UTF-8
     */

    public static String encodeString(String normalString) {
        try {
            return URLEncoder.encode(normalString, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return normalString;
        }
    }

    /**
     * Decode a String to UTF-8
     */

    public static String decodeString(String normalString) {
        try {
            return URLDecoder.decode(normalString, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return normalString;
        }
    }
}
