
package com.cdn.techquiq.consumer.adapter;

/**
 * Created by kajalsoni on 31/1/17.
 */

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.activity.MainActivity;
import com.cdn.techquiq.consumer.activity.UserActivity;
import com.cdn.techquiq.consumer.database.DBHelper;
import com.cdn.techquiq.consumer.model.InboxListResponse;
import com.marshalchen.ultimaterecyclerview.UltimateRecyclerviewViewHolder;
import com.marshalchen.ultimaterecyclerview.UltimateViewAdapter;

import java.util.ArrayList;

public class InboxAdapter extends UltimateViewAdapter {

    private static final String TAG = InboxAdapter.class.getSimpleName();

    private ArrayList<InboxListResponse.InboxList> inboxList;
    Context mContext;
    LayoutInflater mLayoutInflater;

    public DBHelper dbHelper;

    private String subject, description;

    public InboxAdapter(Context context, ArrayList<InboxListResponse.InboxList> inboxList) {
        this.mContext = context;
        this.inboxList = inboxList;
        dbHelper = new DBHelper(mContext);
        mLayoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (inboxList.size() == position) {
            Log.e("RETURN POSITION", "" + position);
            return;
        }

        final InboxListResponse.InboxList inboxBean = inboxList.get(position);
        if (position < getItemCount() && (customHeaderView != null ? position <= inboxList.size() : position < inboxList.size()) && (customHeaderView != null ? position > 0 : true)) {
            subject = Utils.decodeString(inboxBean.getName());
            description = Utils.decodeString(inboxBean.getDescription());

            ((ViewHolderInbox) holder).tVMsgTitle.setText(subject);
            ((ViewHolderInbox) holder).tVMsgDes.setText(description);

            String serviceId = inboxBean.getId();
            ArrayList<InboxListResponse.InboxList.ImageList> inboxImages = inboxBean.getImages();
            if (inboxImages != null && inboxImages.size() > 0) {
                try {
                    Glide.with(mContext).load(inboxImages.get(0).getImage())
                            .asBitmap()
                            .centerCrop().override(300, 300)
                            .priority(Priority.IMMEDIATE)
                            .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                            .placeholder(R.drawable.placeholder_1)
                            .into(((ViewHolderInbox) holder).iVMessage);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            ((ViewHolderInbox) holder).msgContainer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ((MainActivity) mContext).stopChatReceiver();
                    Intent intent = new Intent(mContext, UserActivity.class);
                    intent.putExtra("title", inboxBean.getName());
                    intent.putExtra("serviceId", inboxBean.getId());
                    mContext.startActivity(intent);
                }
            });

            /**
             * below code for show unread message count.
             */
            int unreadMsgCount = dbHelper.getUnReadMessageCountForService(serviceId);
            if (unreadMsgCount > 0) {
                ((ViewHolderInbox) holder).linearMsgRight.setVisibility(View.VISIBLE);

                if (unreadMsgCount > 99) {
                    ((ViewHolderInbox) holder).tvMsgCount.setText("" + 99 + "+");
                } else {
                    ((ViewHolderInbox) holder).tvMsgCount.setText("" + unreadMsgCount);
                }


                ((ViewHolderInbox) holder).tvMsgCount.setText(" " + unreadMsgCount + " ");
            } else {
                ((ViewHolderInbox) holder).linearMsgRight.setVisibility(View.GONE);
            }

        }
    }


    @Override
    public RecyclerView.ViewHolder newFooterHolder(View view) {
        return new UltimateRecyclerviewViewHolder<>(view);
    }

    @Override
    public RecyclerView.ViewHolder newHeaderHolder(View view) {
        return new UltimateRecyclerviewViewHolder<>(view);
    }


    @Override
    public int getAdapterItemCount() {
        return inboxList.size();
    }


    @Override
    public UltimateRecyclerviewViewHolder onCreateViewHolder(ViewGroup parent) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.message_list_item, parent, false);
        ViewHolderInbox vh = new ViewHolderInbox(v);
        return vh;
    }


    public void insert(String string, int position) {
        insertInternal(inboxList, string, position);
    }

    public void remove(int position) {
        removeInternal(inboxList, position);
    }

    public void clear() {
        clearInternal(inboxList);
    }


    public void swapPositions(int from, int to) {
        swapPositions(inboxList, from, to);
    }


    @Override
    public long generateHeaderId(int position) {
        // URLogs.d("position--" + position + "   " + getItem(position));
        if (getItem(position).length() > 0)
            return getItem(position).charAt(0);
        else return -1;
    }

    @Override
    public RecyclerView.ViewHolder onCreateHeaderViewHolder(ViewGroup parent) {
        return null;
    }

    @Override
    public void onBindHeaderViewHolder(RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    public void onItemMove(int fromPosition, int toPosition) {
        if (fromPosition > 0 && toPosition > 0) {
            swapPositions(fromPosition, toPosition);
            super.onItemMove(fromPosition, toPosition);
        }
    }

    @Override
    public void onItemDismiss(int position) {
        if (position > 0) {
            remove(position);
            notifyDataSetChanged();
            super.onItemDismiss(position);
        }

    }

    public void setOnDragStartListener(OnStartDragListener dragStartListener) {
        mDragStartListener = dragStartListener;

    }

    class ViewHolderInbox extends UltimateRecyclerviewViewHolder {

        public TextView tVMsgTitle, tVMsgDes, tvMsgCount;
        View mparent;
        public ImageView iVMessage;
        public LinearLayout msgContainer;
        LinearLayout linearMsgRight;

        public ViewHolderInbox(View view) {
            super(view);
            mparent = view;
            tVMsgTitle = (TextView) view.findViewById(R.id.tVMsgTitle);
            tVMsgDes = (TextView) view.findViewById(R.id.tVMsgDes);
            iVMessage = (ImageView) view.findViewById(R.id.iVMessage);
            tvMsgCount = (TextView) view.findViewById(R.id.tvMsgCount);
            msgContainer = (LinearLayout) view.findViewById(R.id.msgContainer);
            linearMsgRight = (LinearLayout) view.findViewById(R.id.linearMsgRight);

        }

        @Override
        public void onItemSelected() {
            itemView.setBackgroundColor(Color.LTGRAY);
        }

        @Override
        public void onItemClear() {
            itemView.setBackgroundColor(0);
        }
    }

    public String getItem(int position) {
        if (customHeaderView != null)
            position--;

        if (position >= 0 && position < inboxList.size())
            return String.valueOf(inboxList.get(position));
        else return "";
    }
}

