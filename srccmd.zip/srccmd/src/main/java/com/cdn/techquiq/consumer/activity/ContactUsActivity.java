package com.cdn.techquiq.consumer.activity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.model.ContactResponse;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;
import com.google.gson.Gson;

import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEvent;
import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEventListener;

import java.net.SocketTimeoutException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by avikaljain on 8/6/17.
 */

public class ContactUsActivity extends BaseActivity {

    private String TAG = ContactUsActivity.class.getSimpleName();

    private ImageView backIv;
    private TextView titleTv;
    private TextView tVSubmit;

    private EditText eTSubject;
    private EditText eTDescription;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_us);
        setUpUI();
        KeyboardVisibilityEvent.setEventListener(
                this,
                new KeyboardVisibilityEventListener() {
                    @Override
                    public void onVisibilityChanged(boolean isOpen) {
                        if (isOpen) {
                            tVSubmit.setVisibility(View.GONE);
                        } else {
                            tVSubmit.setVisibility(View.VISIBLE);
                        }

                    }
                });
    }

    private void setUpUI() {
        backIv = (ImageView) findViewById(R.id.backIv);
        backIv.setOnClickListener(this);
        titleTv = (TextView) findViewById(R.id.titleTv);
        titleTv.setText(mContext.getResources().getString(R.string.txt_contact_us));
        tVSubmit = (TextView) findViewById(R.id.tVSubmit);
        eTSubject = (EditText) findViewById(R.id.etSubject);
        eTDescription = (EditText) findViewById(R.id.eTDescription);
        tVSubmit.setOnClickListener(this);
    }

    private boolean isValidate() {
        if (eTSubject.getText().toString().trim() == null || eTSubject.getText().toString().trim().isEmpty() || eTSubject.getText().toString().trim().equalsIgnoreCase("")) {
            showToastMsg(this, getResources().getString(R.string.please_enter_subject));
            return false;
        } else if (eTDescription.getText().toString().trim() == null || eTDescription.getText().toString().trim().isEmpty() || eTDescription.getText().toString().trim().equalsIgnoreCase("")) {
            showToastMsg(this, getResources().getString(R.string.please_select_description));
            return false;
        } else {
            return true;
        }


    }

    private void contactSubmit() {
        try {
            if (!CheckNetworkState.isOnline(mContext)) {
                showToastMsg(mContext, getString(R.string.network_error));
                return;
            }

            if (!showProgressDialog(mContext)) {
                return;
            }
            final LoginResponse.Users userDetail = Utils.readUserDetail(this);
            final Call<ContactResponse> contactRequest = ((TechquiqApplication) mContext.getApplicationContext())
                    .getService().contactService(userDetail.getUserId(),
                            Utils.getDeviceId(this),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID,
                            eTSubject.getText().toString().trim(),
                            eTDescription.getText().toString().trim());

            Log.e(TAG, "Request : " + contactRequest.request().url());

            contactRequest.enqueue(new Callback<ContactResponse>() {
                @Override
                public void onResponse(Call<ContactResponse> call, Response<ContactResponse> response) {
                    Log.e(TAG, "Response : " + new Gson().toJson(response.toString()));
                    hideProgressDialog();
                    if (response == null) {
                        showToastMsg(mContext, getString(R.string.server_error));
                        return;
                    }
                    ContactResponse contactResponse = response.body();

                    if (contactResponse == null) {
                        showToastMsg(mContext, getString(R.string.server_error));
                        return;
                    }
                    Log.e(TAG, new Gson().toJson(contactResponse));
                    int responseStatusCode = contactResponse.getResponseStatusCode();

                    if (responseStatusCode == AppConstant.SUCCESS) {
                        if (contactResponse.getResponseCode() != null && contactResponse.getResponseCode().equalsIgnoreCase("0")) {
                            showToastMsg(ContactUsActivity.this, contactResponse.getResponseMessage());
                            return;
                        } else if (contactResponse.getResponseCode() != null && contactResponse.getResponseCode().equalsIgnoreCase("1")) {
                            showToastMsg(mContext, getString(R.string.ws_msg_sent));
                            eTSubject.setText("");
                            eTDescription.setText("");
                            finish();
                        }
                    } else {
                        showToastMsg(mContext, contactResponse.getResponseMessage());
                    }
                }

                @Override
                public void onFailure(Call<ContactResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(mContext, getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(mContext, getResources().getString(R.string.server_error));
                    Log.e(TAG, "Error : " + t.getMessage());
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.backIv:
                finish();
                break;
            case R.id.tVSubmit:
                if (isValidate()) {
                    contactSubmit();
                }
                break;

        }
    }
}
