package com.cdn.techquiq.consumer.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.cdn.techquiq.consumer.R;
import com.cdn.techquiq.consumer.TechquiqApplication;
import com.cdn.techquiq.consumer.Utils.AppConstant;
import com.cdn.techquiq.consumer.Utils.Utils;
import com.cdn.techquiq.consumer.activity.MainActivity;
import com.cdn.techquiq.consumer.adapter.HomeProductAdapter;
import com.cdn.techquiq.consumer.adapter.OfferAdapter;
import com.cdn.techquiq.consumer.custom.ClickableViewPager;
import com.cdn.techquiq.consumer.model.AlertResponse;
import com.cdn.techquiq.consumer.model.LoginResponse;
import com.cdn.techquiq.consumer.model.ProductResponse;
import com.cdn.techquiq.consumer.model.ProposalCountResponse;
import com.cdn.techquiq.consumer.netcomm.ApiParameter;
import com.cdn.techquiq.consumer.netcomm.CheckNetworkState;
import com.google.gson.Gson;

import java.net.SocketTimeoutException;
import java.util.ArrayList;

import me.relex.circleindicator.CircleIndicator;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * Created by akshaysoni on 31/1/17.
 */
public class HomeFragment extends BaseFragment {

    private LinearLayout dealsOfferSection;
    private RecyclerView productList;
    private ClickableViewPager offerViewPager;
    private TextView productViewAll, serviceViewAll, alertViewAll;
    private CircleIndicator indicator;

    private static final String TAG = HomeFragment.class.getSimpleName();
    private ImageView ivServiceSection;
    private RelativeLayout rlInboxSection;
    private int proposalCount;
    private TextView proposalCountTv;
    private GestureDetector gestureDetector;
    private TextView noProductTv;
    private int limit;
    private int currentOffset;
    private int totalRecord;
    private String keyword;
    private ArrayList<AlertResponse.AlertList> alertList;

    private TextView tvNoOffer;
    private RelativeLayout showOfferLayout;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_home, container, false);

        setTitleText(getString(R.string.txt_home_title));

        dealsOfferSection = (LinearLayout) view.findViewById(R.id.dealsOfferSection);
        dealsOfferSection.setOnClickListener(this);
        productList = (RecyclerView) view.findViewById(R.id.productList);
        offerViewPager = (ClickableViewPager) view.findViewById(R.id.offerViewPager);
        productViewAll = (TextView) view.findViewById(R.id.productViewAll);
        productViewAll.setOnClickListener(this);
        serviceViewAll = (TextView) view.findViewById(R.id.serviceViewAll);
        serviceViewAll.setOnClickListener(this);
        alertViewAll = (TextView) view.findViewById(R.id.alertViewAll);
        alertViewAll.setOnClickListener(this);
        indicator = (CircleIndicator) view.findViewById(R.id.indicator);
        ivServiceSection = (ImageView) view.findViewById(R.id.ivServiceSection);
        rlInboxSection = (RelativeLayout) view.findViewById(R.id.rlInboxSection);
        proposalCountTv = (TextView) view.findViewById(R.id.proposalCountTv);
        noProductTv = (TextView) view.findViewById(R.id.noProductTv);
        tvNoOffer = (TextView) view.findViewById(R.id.tvNoOffer);
        showOfferLayout = (RelativeLayout) view.findViewById(R.id.showOfferLayout);
        ivServiceSection.setOnClickListener(this);
        rlInboxSection.setOnClickListener(this);
        alertList = new ArrayList<>();
        setOffers();
        getProposalCount();
        getProductList();

        /**
         * disable click for swipe on service section
         */
        gestureDetector = new GestureDetector(getActivity(), new SingleTapConfirm());
        ivServiceSection.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View arg0, MotionEvent arg1) {
                if (gestureDetector.onTouchEvent(arg1)) {
                    ((MainActivity) getActivity()).openServiceTab();
                    return true;
                }
                return false;
            }
        });

        /**
         * disable click for swipe on inbox section
         */
        rlInboxSection.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View arg0, MotionEvent arg1) {

                if (gestureDetector.onTouchEvent(arg1)) {
                    ((MainActivity) getActivity()).inboxTab();
                    return true;
                }
                return false;
            }
        });
        return view;
    }

    private class SingleTapConfirm extends GestureDetector.SimpleOnGestureListener {

        @Override
        public boolean onSingleTapUp(MotionEvent event) {
            return true;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        topAndBelowTab();
    }

    public void topAndBelowTab() {
        ((MainActivity) getActivity()).hideBackBtn(true);
        ((MainActivity) getActivity()).hideCartButton(false);
        ((MainActivity) getActivity()).hideSearchButton(false);
        ((MainActivity) getActivity()).hideSettingButton(true);
        ((MainActivity) getActivity()).hideBelowTabBar(false);
    }

    private void setOffers() {
        webServiceCall();
    }

    public void webServiceCall() {
        limit = AppConstant.AWARDED_LIMIT;
        currentOffset = 0;
        totalRecord = 0;
        keyword = "";
        getAlertList(currentOffset, false, keyword);
    }

    private void getAlertList(int offset, final boolean isLoadMore, String keyword) {
        try {
            if (!CheckNetworkState.isOnline(getActivity())) {
                if (!isLoadMore) {
                    setUPNoOffer();
                    showToastMsg(getContext(), getActivity().getString(R.string.network_error));
                } else {
                    setUPNoOffer();
                    showToastMsg(getActivity(), getActivity().getString(R.string.network_error));
                }
                return;
            }

            this.keyword = keyword;
            if (!isLoadMore) {
                if (!showProgressDialog(getActivity())) {
                    return;
                }
            }

            final LoginResponse.Users userDetail = Utils.readUserDetail(getActivity());
            Call<AlertResponse> alertRequest = ((TechquiqApplication) getActivity()
                    .getApplicationContext()).getService().getAlert(
                    userDetail.getUserId(),
                    Utils.getDeviceId(getActivity()),
                    AppConstant.FCM_ID,
                    ApiParameter.DEVICE_TYPE_VALUE,
                    limit,
                    offset, keyword
            );

            Log.e(TAG, "Request : " + alertRequest.request().url());

            alertRequest.enqueue(new Callback<AlertResponse>() {
                @Override
                public void onResponse(Call<AlertResponse> call, Response<AlertResponse> response) {
                    if (response == null) {
                        setUPNoOffer();
                        showToastMsg(getContext(), getString(R.string.server_error));
                        return;
                    }

                    if (!isLoadMore) {
                        hideProgressDialog();
                    }

                    Log.e(TAG, "Categories Response : " + new Gson().toJson(response.body()));
                    AlertResponse alertResponse = response.body();

                    if (alertResponse == null) {
                        showToastMsg(getContext(), getString(R.string.server_error));
                        return;
                    }

                    int responseStatusCode = alertResponse.getResponseStatusCode();
                    if (responseStatusCode == AppConstant.PARAM_MISSING) {
                        setUPNoOffer();
                        showToastMsg(getContext(), getString(R.string.ws_param_missing));
                    } else if (responseStatusCode == AppConstant.NO_DATA_FOUND) {
                        setUPNoOffer();
                    } else if (responseStatusCode == AppConstant.UNKNOWN_ERROR) {
                        setUPNoOffer();
                        showToastMsg(getContext(), getString(R.string.ws_unkonwn_error));
                    } else if (responseStatusCode == AppConstant.SUCCESS) {
                        if (alertResponse.getResponseCode().equalsIgnoreCase("0")) {
                            setUPNoOffer();
                            if (!isLoadMore) {

                                ((MainActivity) getActivity()).hideSearchButton(true);
                            } else {
                                ((MainActivity) getActivity()).hideSearchButton(false);
                                showToastMsg(getActivity(), response.body().getResponseMessage());
                            }
                            return;
                        } else {
                            showOfferLayout.setVisibility(View.VISIBLE);
                            tvNoOffer.setVisibility(View.GONE);
                            ((MainActivity) getActivity()).hideSearchButton(false);
                            if (isLoadMore) {
                                if (alertList != null) {
                                    int offset = alertList.size();
                                    for (int i = 0; i < alertResponse.getAlertList().size(); i++) {
                                        alertList.add(offset, alertResponse.getAlertList().get(i));
                                        offset++;
                                    }
//                                messageAdapter.notifyDataSetChanged();
                                }
                            } else {
                                alertList = alertResponse.getAlertList();
                                if (alertList != null && alertList.size() > 0) {
                                    ArrayList<AlertResponse.AlertList> tempList = new ArrayList<AlertResponse.AlertList>();
                                    int size = tempList.size();
                                    for (int i = 0; i < alertList.size(); i++) {
                                        if (alertList.get(i).getType().equalsIgnoreCase("Offer")) {
                                            tempList.add(size, alertResponse.getAlertList().get(i));
                                            size++;
                                        }
                                    }
                                    OfferAdapter offerAdapter = new OfferAdapter(getActivity(), tempList);
                                    offerViewPager.setAdapter(offerAdapter);
                                    indicator.setViewPager(offerViewPager);


                                }
                            }
                        }

                    } else {
                        setUPNoOffer();
                        showToastMsg(getContext(), alertResponse.getResponseMessage());
                    }


                }

                @Override
                public void onFailure(Call<AlertResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(getActivity(), getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(getActivity(), getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void setUPNoOffer() {
        showOfferLayout.setVisibility(View.GONE);
        tvNoOffer.setVisibility(View.VISIBLE);
        tvNoOffer.setText(getString(R.string.text_no_offer));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.serviceViewAll:
                ((MainActivity) getActivity()).openServiceTab();
                break;

            case R.id.dealsOfferSection:
                break;

            case R.id.productViewAll:
                ((MainActivity) getActivity()).openProductTab();
                break;
            case R.id.alertViewAll:
                ((MainActivity) getActivity()).openAlertTab();
                break;
        }
    }


    private void getProductList() {
        try {

            if (!CheckNetworkState.isOnline(getActivity())) {
                noProductTv.setVisibility(View.VISIBLE);
                noProductTv.setText(getActivity().getString(R.string.network_error));
                productList.setVisibility(View.GONE);
                return;
            }

            if (!showProgressDialog(getActivity())) {
                return;
            }

            final LoginResponse.Users userDetail = Utils.readUserDetail(getActivity());

            Call<ProductResponse> myProductRequest = ((TechquiqApplication) getActivity().getApplicationContext())
                    .getService().doSearchProduct(userDetail.getUserId(),
                            Utils.getDeviceId(getActivity()),
                            ApiParameter.DEVICE_TYPE_VALUE,
                            AppConstant.FCM_ID,
                            AppConstant.PRODUCT_LIMIT,
                            0,
                            0,
                            "",
                            "");

            Log.e(TAG, "Product Request : " + myProductRequest.request().url());

            myProductRequest.enqueue(new Callback<ProductResponse>() {
                @Override
                public void onResponse(Call<ProductResponse> call, Response<ProductResponse> response) {

                    hideProgressDialog();

                    ProductResponse productResponse = response.body();
                    Log.e(TAG, new Gson().toJson(productResponse));
                    if (productResponse == null) {
                        return;
                    }
                    if (productResponse.getResponseCode().equalsIgnoreCase("0")) {
                        noResultFound(productResponse.getResponseMessage());
                        return;
                    }

                    final ArrayList<ProductResponse.ProductDetail> productDetails = productResponse.getProductDetail();

                    if (productDetails != null && productDetails.size() > 0) {
                        HomeProductAdapter productAdapter = new HomeProductAdapter(getActivity(), productDetails);
                        productList.setAdapter(productAdapter);
                        LinearLayoutManager layoutManager
                                = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
                        productList.setLayoutManager(layoutManager);
                        noProductTv.setVisibility(View.GONE);
                    } else {
                        noResultFound(productResponse.getResponseMessage());
                    }
                }

                @Override
                public void onFailure(Call<ProductResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        noResultFound(getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    noResultFound(getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void noResultFound(String msg) {
        noProductTv.setVisibility(View.VISIBLE);
        productList.setVisibility(View.GONE);
        noProductTv.setText(msg);
    }

    private void getProposalCount() {
        try {
            if (!CheckNetworkState.isOnline(getActivity())) {
                showToastMsg(getActivity(), getString(R.string.network_error));
                return;
            }

            final LoginResponse.Users userDetail = Utils.readUserDetail(getActivity());
            Call<ProposalCountResponse> proposalCountRequest = ((TechquiqApplication) getActivity()
                    .getApplicationContext()).getService().getProposalCount(
                    userDetail.getUserId(),
                    Utils.getDeviceId(getActivity()),
                    ApiParameter.DEVICE_TYPE_VALUE,
                    AppConstant.FCM_ID);

            Log.e(TAG, "Request Count: " + proposalCountRequest.request().url());
            proposalCountRequest.enqueue(new Callback<ProposalCountResponse>() {
                @Override
                public void onResponse(Call<ProposalCountResponse> call, Response<ProposalCountResponse> response) {


                    if (response == null) {
                        showToastMsg(getActivity(), getString(R.string.server_error));
                        return;
                    }
                    Log.e(TAG, "Categories Response : " + new Gson().toJson(response.body()));
                    ProposalCountResponse proposalCountResponse = response.body();

                    if (proposalCountResponse != null) {
                        proposalCount = proposalCountResponse.getProposalCount();
                        proposalCountTv.setText("" + proposalCount);
                        Log.e(TAG, "Total Service " + String.valueOf(proposalCount));
                    } else {
                        proposalCountTv.setText("" + 0);
                    }


                }

                @Override
                public void onFailure(Call<ProposalCountResponse> call, Throwable t) {
                    hideProgressDialog();
                    if (t instanceof SocketTimeoutException) {
                        showToastMsg(getActivity(), getResources().getString(R.string.connection_timeout));
                        return;
                    }
                    showToastMsg(getActivity(), getResources().getString(R.string.server_error));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
