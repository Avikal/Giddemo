package com.cdn.techquiq.consumer;

public class AppSettings {

    public static final String URL = "http://www.cdnsolutionsgroup.com/techquiq/ws/";
    public static final String CHAT_SERVER_IP = "http://cdnsolutionsgroup.com";
    public static final String CHAT_PORT = ":9008/";
}
